const fs = require('fs');
const file = 'src/components/SCMPipelineView.tsx';
let content = fs.readFileSync(file, 'utf8');

const regex = /const \[customRules, setCustomRules\] = useState<any\[\]>\(\[\]\);/;
const replacement = `interface CustomPricingRule {
  id: string;
  name: string;
  age: string;
  scope: string;
}
  const [customRules, setCustomRules] = useState<CustomPricingRule[]>([]);`;

content = content.replace(regex, replacement);
fs.writeFileSync(file, content);
