const fs = require('fs');
const file = 'src/components/SCMPipelineView.tsx';
let content = fs.readFileSync(file, 'utf8');

const summaryRegex = /\{\/\* Concise Rules Summary \*\/\}[\s\S]*?(?=<\/div>\s*<\/div>\s*\{\/\* Right Column: Rules Options & Stats \*\/)/;

const newSummary = `{/* Pricing Rules Controls (Left Panel) */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 mt-4 space-y-3">
                <h4 className="text-[11px] font-black text-slate-800 mb-2 uppercase tracking-wider">Pricing Rules Applied</h4>
                <div className="space-y-3">
                  {/* Material Markup */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Material Markup: {rulesAConfig.materialMarkupPercent}%</span>
                    </div>
                    <input type="range" min="0" max="40" step="0.5" value={rulesAConfig.materialMarkupPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, materialMarkupPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-purple-600 cursor-pointer" />
                  </div>
                  {/* Direct Labor */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Direct Labor: {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' ? \`\${rulesAConfig.directLaborPercent}% of Mat.\` : \`\${rulesAConfig.estimatedLaborHours} hrs at \${rulesAConfig.directLaborHourlyRateQAR} QAR/hr\`}</span>
                    </div>
                    {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' && (
                      <input type="range" min="5" max="30" step="0.5" value={rulesAConfig.directLaborPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, directLaborPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-emerald-600 cursor-pointer" />
                    )}
                  </div>
                  {/* Admin & Site Overheads */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Admin & Site Overheads: {rulesAConfig.overheadsPercent}%</span>
                    </div>
                    <input type="range" min="2" max="20" step="0.5" value={rulesAConfig.overheadsPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, overheadsPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-amber-700 cursor-pointer" />
                  </div>
                  {/* Wastage & Scrap */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Wastage & Scrap: {rulesAConfig.wastageScrapPercent}%</span>
                    </div>
                    <input type="range" min="0" max="15" step="0.5" value={rulesAConfig.wastageScrapPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, wastageScrapPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-yellow-400 cursor-pointer" />
                  </div>
                  {/* Transport & Logistics */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Transport & Logistics: {rulesAConfig.logisticsTransportPercent}%</span>
                    </div>
                    <input type="range" min="1" max="12" step="0.5" value={rulesAConfig.logisticsTransportPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, logisticsTransportPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-pink-600 cursor-pointer" />
                  </div>
                  {/* Insurance & Bonds */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Insurance & Bonds: {rulesAConfig.insuranceAndBondsPercent}%</span>
                    </div>
                    <input type="range" min="0" max="10" step="0.5" value={rulesAConfig.insuranceAndBondsPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, insuranceAndBondsPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-yellow-200 cursor-pointer" />
                  </div>
                  {/* Profit Margin (P1) */}
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-[10px] font-medium text-slate-600">
                      <span>• Profit Margin (P1): {rulesAConfig.standardProfitMarginP1}%</span>
                    </div>
                    <input type="range" min="5" max="40" step="0.5" value={rulesAConfig.standardProfitMarginP1} onChange={(e) => setRulesAConfig({ ...rulesAConfig, standardProfitMarginP1: parseFloat(e.target.value) })} className="w-full h-1.5 accent-purple-600 cursor-pointer" />
                  </div>
                </div>
              </div>`;

content = content.replace(summaryRegex, newSummary + "\n            </div>");

const slidersGridRegex = /\{\/\* Rules Sliders Grid \*\/\}[\s\S]*?(?=\{\/\* Custom Pricing Rules \*\/)/;
content = content.replace(slidersGridRegex, "");

fs.writeFileSync(file, content);
