import React, { useState, useMemo } from 'react';
import {
  DollarSign,
  Clock,
  CreditCard,
  ShieldCheck,
  Award,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Plus,
  Download,
  Filter,
  Check,
  X,
  TrendingDown,
  TrendingUp,
  Building2,
  Calendar,
  Layers,
  Sparkles,
  ArrowUpDown,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  Info,
  Scale,
  Package,
  Truck,
  Percent,
  CheckSquare,
  Square
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { QuotationResult, BOQRecord, SupplierRecord } from '../types';
import { useAppData } from '../context/useAppData';

interface VendorQuotationMatrixViewProps {
  quotations: QuotationResult[];
  boqs: BOQRecord[];
  suppliers: SupplierRecord[];
  onUpdateQuotations: (data: QuotationResult[]) => void;
  onOpenQuickAdd?: () => void;
  onOpenOfficialQuote?: () => void;
  onOpenGeminiAnalysis?: (boqId?: string) => void;
  onOpenGeminiChat?: (context?: any) => void;
}

// Sample line item comparison database across vendors for realistic breakdown
interface LineItemCompare {
  itemCode: string;
  description: string;
  qty: number;
  unit: string;
  category: string;
  vendorPrices: { [vendorName: string]: number };
}

const defaultLineItems: { [boqId: string]: LineItemCompare[] } = {
  'BOQ-003': [
    {
      itemCode: 'CAM-DOME-4MP',
      description: '4MP Varifocal IR Dome Network Camera (Auto-Iris, MOI Approved)',
      qty: 320,
      unit: 'Nos.',
      category: 'Cameras',
      vendorPrices: {
        Hikvision: 406.0,
        Dahua: 385.0,
        'Uniview (UNV)': 370.0,
        'Honeywell Security': 450.0,
      },
    },
    {
      itemCode: 'CAM-BULLET-4MP',
      description: '4MP Bullet Camera, 2.7-13.5mm Varifocal, 60m IR, IP67 IK10',
      qty: 80,
      unit: 'Nos.',
      category: 'Cameras',
      vendorPrices: {
        Hikvision: 406.0,
        Dahua: 390.0,
        'Uniview (UNV)': 375.0,
        'Honeywell Security': 460.0,
      },
    },
    {
      itemCode: 'CAM-PTZ-32X',
      description: '4MP 32x Optical Zoom PTZ Speed Dome Camera (Auto-Tracking)',
      qty: 16,
      unit: 'Nos.',
      category: 'Cameras',
      vendorPrices: {
        Hikvision: 3600.0,
        Dahua: 3450.0,
        'Uniview (UNV)': 3300.0,
        'Honeywell Security': 4100.0,
      },
    },
    {
      itemCode: 'NVR-128CH-SAN',
      description: '128-Channel 4K Enterprise NVR with Dual Redundant Power & 120-Day SAN',
      qty: 4,
      unit: 'Units',
      category: 'Storage & Servers',
      vendorPrices: {
        Hikvision: 45000.0,
        Dahua: 43500.0,
        'Uniview (UNV)': 42000.0,
        'Honeywell Security': 52000.0,
      },
    },
    {
      itemCode: 'SW-POE-24P-L2',
      description: '24-Port Gigabit Managed PoE+ Network Switch (370W PoE Budget)',
      qty: 18,
      unit: 'Units',
      category: 'Network & Infrastructure',
      vendorPrices: {
        Hikvision: 1650.0,
        Dahua: 1580.0,
        'Uniview (UNV)': 1480.0,
        'Honeywell Security': 1950.0,
      },
    },
    {
      itemCode: 'CAB-CAT6-UTP',
      description: 'Cat6 UTP Solid Copper 305m Cable Drum (LSZH Violet Jacket)',
      qty: 140,
      unit: 'Rolls',
      category: 'Passive Infrastructure',
      vendorPrices: {
        Hikvision: 420.0,
        Dahua: 410.0,
        'Uniview (UNV)': 395.0,
        'Honeywell Security': 460.0,
      },
    },
  ],
};

export const VendorQuotationMatrixView: React.FC<VendorQuotationMatrixViewProps> = ({
  quotations,
  boqs,
  suppliers,
  onUpdateQuotations,
  onOpenQuickAdd,
  onOpenOfficialQuote,
  onOpenGeminiAnalysis,
  onOpenGeminiChat,
}) => {
  const { convertQuoteToPO, setActiveTab, setProcurementSubModule } = useAppData();

  // 1. Filter States
  const [selectedBoqId, setSelectedBoqId] = useState<string>('BOQ-003');
  const [matrixSubTab, setMatrixSubTab] = useState<'cards' | 'matrixTable' | 'lineItems' | 'cashFlow'>('cards');
  const [selectedQuoteIds, setSelectedQuoteIds] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'deliveryAsc' | 'terms'>('recommended');
  const [showDifferenceOnly, setShowDifferenceOnly] = useState<boolean>(false);
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  // 2. Revision & Counter-Offer Modal State
  const [isCounterOfferModalOpen, setIsCounterOfferModalOpen] = useState<boolean>(false);
  const [targetQuoteForRevision, setTargetQuoteForRevision] = useState<QuotationResult | null>(null);
  const [revisionTargetPrice, setRevisionTargetPrice] = useState<string>('');
  const [revisionTargetDelivery, setRevisionTargetDelivery] = useState<string>('10 Days');
  const [revisionTargetTerms, setRevisionTargetTerms] = useState<string>('30 Days Credit');
  const [revisionNotes, setRevisionNotes] = useState<string>('');

  // 3. Add Custom Quote Modal State
  const [isAddQuoteModalOpen, setIsAddQuoteModalOpen] = useState<boolean>(false);
  const [newQuoteSupplier, setNewQuoteSupplier] = useState<string>('Uniview (UNV)');
  const [newQuoteValue, setNewQuoteValue] = useState<string>('2480000');
  const [newQuoteDelivery, setNewQuoteDelivery] = useState<string>('10 Days');
  const [newQuotePaymentTerms, setNewQuotePaymentTerms] = useState<string>('50% Advance / 50% Delivery');
  const [newQuoteWarranty, setNewQuoteWarranty] = useState<string>('3 Years');
  const [newQuoteValidity, setNewQuoteValidity] = useState<string>('30 Days');
  const [newQuoteRemarks, setNewQuoteRemarks] = useState<string>('Direct factory agent quotation');

  // Trigger Toast Notification
  const triggerNotification = (msg: string) => {
    setNotificationMsg(msg);
    setTimeout(() => setNotificationMsg(null), 4000);
  };

  // Find active project BOQ details
  const activeBoq = useMemo(() => {
    return boqs.find((b) => b.boqId === selectedBoqId) || boqs[0];
  }, [boqs, selectedBoqId]);

  // Filter quotations matching the selected project BOQ
  const projectQuotations = useMemo(() => {
    if (selectedBoqId === 'ALL') return quotations;
    return quotations.filter((q) => q.boqId === selectedBoqId);
  }, [quotations, selectedBoqId]);

  // Keep selectedQuoteIds synchronized when project changes
  const activeComparingQuotes = useMemo(() => {
    if (selectedQuoteIds.length === 0) {
      return projectQuotations;
    }
    const filtered = projectQuotations.filter((q) => selectedQuoteIds.includes(q.quoteId));
    return filtered.length > 0 ? filtered : projectQuotations;
  }, [projectQuotations, selectedQuoteIds]);

  // Helper to get supplier metadata
  const getSupplierInfo = (supplierName: string): SupplierRecord | undefined => {
    return suppliers.find((s) => s.name.toLowerCase() === supplierName.toLowerCase());
  };

  // Helper to parse delivery time into estimated days
  const parseDeliveryDays = (deliveryStr: string): number => {
    const lower = (deliveryStr || '').toLowerCase();
    if (lower.includes('1 week') || lower.includes('7 days') || lower.includes('immediate') || lower.includes('ex-stock')) return 7;
    if (lower.includes('10 days')) return 10;
    if (lower.includes('2 weeks') || lower.includes('14 days')) return 14;
    if (lower.includes('3 weeks') || lower.includes('21 days')) return 21;
    if (lower.includes('4 weeks') || lower.includes('1 month') || lower.includes('30 days')) return 28;
    if (lower.includes('5 weeks')) return 35;
    if (lower.includes('6 weeks')) return 42;
    const match = lower.match(/\d+/);
    if (match) return parseInt(match[0], 10) * (lower.includes('week') ? 7 : 1);
    return 21;
  };

  // Helper to rate payment terms flexibility (Score out of 100)
  const getPaymentTermsScore = (terms: string): { score: number; label: string; risk: 'Low' | 'Medium' | 'High'; advancePct: number; creditDays: number } => {
    const lower = (terms || '').toLowerCase();
    if (lower.includes('60 days') || lower.includes('90 days') || lower.includes('open account')) {
      return { score: 95, label: 'Highly Favorable (60d+ Credit)', risk: 'Low', advancePct: 0, creditDays: 60 };
    }
    if (lower.includes('45 days')) {
      return { score: 90, label: 'Favorable (45d Credit)', risk: 'Low', advancePct: 0, creditDays: 45 };
    }
    if (lower.includes('30 days') || lower.includes('net 30')) {
      return { score: 85, label: 'Standard Credit (30 Days Net)', risk: 'Low', advancePct: 0, creditDays: 30 };
    }
    if (lower.includes('l/c') || lower.includes('letter of credit')) {
      return { score: 75, label: 'L/C at Sight (Bank Backed)', risk: 'Medium', advancePct: 15, creditDays: 30 };
    }
    if (lower.includes('50% advance') || lower.includes('50% deposit')) {
      return { score: 60, label: '50% Advance / 50% Upon Delivery', risk: 'Medium', advancePct: 50, creditDays: 0 };
    }
    if (lower.includes('cad') || lower.includes('cash against')) {
      return { score: 55, label: 'Cash Against Documents (CAD)', risk: 'Medium', advancePct: 20, creditDays: 0 };
    }
    if (lower.includes('100% advance') || lower.includes('advance')) {
      return { score: 35, label: '100% Upfront Advance Required', risk: 'High', advancePct: 100, creditDays: 0 };
    }
    return { score: 70, label: terms || 'Standard Terms', risk: 'Medium', advancePct: 25, creditDays: 15 };
  };

  // Lowest and highest price in comparing set
  const priceStats = useMemo(() => {
    if (activeComparingQuotes.length === 0) return { min: 0, max: 0, avg: 0 };
    const values = activeComparingQuotes.map((q) => q.quotedValue);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    return { min, max, avg };
  }, [activeComparingQuotes]);

  // Fastest delivery in comparing set
  const fastestDeliveryDays = useMemo(() => {
    if (activeComparingQuotes.length === 0) return 0;
    return Math.min(...activeComparingQuotes.map((q) => parseDeliveryDays(q.deliveryTime)));
  }, [activeComparingQuotes]);

  // Compute multi-criteria weighted score for each quotation
  // Weightings: Price (40%), Delivery Time (25%), Payment Terms (20%), Warranty & Supplier (15%)
  const scoredQuotations = useMemo(() => {
    return activeComparingQuotes.map((q) => {
      const price = q.quotedValue;
      const deliveryDays = parseDeliveryDays(q.deliveryTime);
      const paymentInfo = getPaymentTermsScore(q.paymentTerms);
      const supplier = getSupplierInfo(q.supplier);

      // Price Score (Normalized: Lowest price gets 100, highest gets proportional score)
      const priceScore = priceStats.max > 0 && priceStats.min > 0
        ? Math.max(40, 100 - ((price - priceStats.min) / (priceStats.max === priceStats.min ? 1 : priceStats.max - priceStats.min)) * 50)
        : 80;

      // Delivery Score (Normalized: 7 days = 100, 42 days = 40)
      const deliveryScore = Math.max(30, Math.min(100, 100 - (deliveryDays - 7) * 2));

      // Payment Terms Score
      const termsScore = paymentInfo.score;

      // Technical & Supplier Score
      let supplierScore = 75;
      if (supplier) {
        supplierScore = (supplier.rating / 5) * 80 + (supplier.moiApproved === 'Yes' ? 20 : 0);
      }
      if (q.warranty.includes('5') || q.warranty.includes('5 Years')) {
        supplierScore = Math.min(100, supplierScore + 10);
      }

      // Weighted Composite Score
      const totalScore = Math.round(
        priceScore * 0.40 + deliveryScore * 0.25 + termsScore * 0.20 + supplierScore * 0.15
      );

      // Savings vs Target BOQ
      const boqVal = activeBoq?.boqValue || price;
      const savingsVsBOQ = boqVal - price;
      const savingsPctVsBOQ = boqVal > 0 ? (savingsVsBOQ / boqVal) * 100 : 0;

      // Price Difference vs Lowest Quote
      const diffVsLowest = price - priceStats.min;
      const isLowestPrice = price === priceStats.min;
      const isFastestDelivery = deliveryDays === fastestDeliveryDays;

      return {
        ...q,
        deliveryDays,
        paymentInfo,
        supplierRecord: supplier,
        priceScore: Math.round(priceScore),
        deliveryScore: Math.round(deliveryScore),
        termsScore: Math.round(termsScore),
        supplierScore: Math.round(supplierScore),
        totalScore,
        savingsVsBOQ,
        savingsPctVsBOQ: Number(savingsPctVsBOQ.toFixed(1)),
        diffVsLowest,
        isLowestPrice,
        isFastestDelivery,
      };
    });
  }, [activeComparingQuotes, priceStats, fastestDeliveryDays, activeBoq, suppliers]);

  // Sorted list of quotes
  const sortedQuotations = useMemo(() => {
    const list = [...scoredQuotations];
    if (sortBy === 'recommended') {
      return list.sort((a, b) => b.totalScore - a.totalScore);
    }
    if (sortBy === 'priceAsc') {
      return list.sort((a, b) => a.quotedValue - b.quotedValue);
    }
    if (sortBy === 'deliveryAsc') {
      return list.sort((a, b) => a.deliveryDays - b.deliveryDays);
    }
    if (sortBy === 'terms') {
      return list.sort((a, b) => b.paymentInfo.score - a.paymentInfo.score);
    }
    return list;
  }, [scoredQuotations, sortBy]);

  // Handle Award / Accept Quote
  const handleAwardQuote = (awardedQuoteId: string) => {
    const updated = quotations.map((q) => {
      if (q.boqId === selectedBoqId || selectedBoqId === 'ALL') {
        if (q.quoteId === awardedQuoteId) {
          return { ...q, status: 'Accepted' as const, selected: 'Yes' as const, remarks: `Awarded via Comparative Matrix on ${new Date().toLocaleDateString()}` };
        } else if (q.boqId === selectedBoqId) {
          return { ...q, status: 'Rejected' as const, selected: 'No' as const };
        }
      }
      return q;
    });
    onUpdateQuotations(updated);
    const awarded = quotations.find((q) => q.quoteId === awardedQuoteId);
    triggerNotification(`Quotation from ${awarded?.supplier} successfully awarded! Marked as Accepted.`);
  };

  // Handle Open Counter-Offer Modal
  const handleOpenCounterOffer = (quote: QuotationResult) => {
    setTargetQuoteForRevision(quote);
    setRevisionTargetPrice(Math.round(quote.quotedValue * 0.95).toString()); // 5% discount target
    setRevisionTargetDelivery(quote.deliveryTime);
    setRevisionTargetTerms(quote.paymentTerms);
    setRevisionNotes(`Request 5% price match and expedited ${quote.deliveryTime} delivery schedule.`);
    setIsCounterOfferModalOpen(true);
  };

  // Submit Counter Offer / Revision
  const handleSubmitCounterOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetQuoteForRevision) return;
    const targetP = parseFloat(revisionTargetPrice) || targetQuoteForRevision.quotedValue;

    const updated = quotations.map((q) => {
      if (q.quoteId === targetQuoteForRevision.quoteId) {
        return {
          ...q,
          status: 'Under Review' as const,
          remarks: `Counter-offer sent: Target QAR ${targetP.toLocaleString()} (${revisionTargetDelivery}, ${revisionTargetTerms})`,
        };
      }
      return q;
    });
    onUpdateQuotations(updated);
    setIsCounterOfferModalOpen(false);
    triggerNotification(`Counter-offer revision dispatched to ${targetQuoteForRevision.supplier}!`);
  };

  // Submit New Custom Vendor Quote
  const handleAddNewQuote = (e: React.FormEvent) => {
    e.preventDefault();
    const newQVal = parseFloat(newQuoteValue) || 2500000;
    const newQuote: QuotationResult = {
      quoteId: `QT-${Date.now().toString().slice(-3)}`,
      boqId: selectedBoqId === 'ALL' ? 'BOQ-003' : selectedBoqId,
      projectName: activeBoq ? activeBoq.projectName : 'General Security Project',
      supplier: newQuoteSupplier.trim(),
      quotedValue: newQVal,
      receivedDate: new Date().toISOString().split('T')[0],
      validity: newQuoteValidity,
      paymentTerms: newQuotePaymentTerms,
      deliveryTime: newQuoteDelivery,
      warranty: newQuoteWarranty,
      status: 'Under Review',
      selected: 'Pending',
      remarks: newQuoteRemarks.trim() || 'Custom supplier quote entry',
    };

    onUpdateQuotations([newQuote, ...quotations]);
    setIsAddQuoteModalOpen(false);
    triggerNotification(`New quotation from ${newQuote.supplier} (QAR ${newQVal.toLocaleString()}) added to matrix!`);
  };

  // Export Matrix Comparison to Excel (.xlsx)
  const handleExportMatrixExcel = () => {
    const exportData = sortedQuotations.map((q, idx) => ({
      Rank: idx + 1,
      'Vendor / Supplier': q.supplier,
      'Quote ID': q.quoteId,
      'Project Name': q.projectName,
      'BOQ ID': q.boqId,
      'Quoted Price (QAR)': q.quotedValue,
      'BOQ Target Value (QAR)': activeBoq?.boqValue || '-',
      'Savings vs BOQ (QAR)': q.savingsVsBOQ,
      'Variance % vs BOQ': `${q.savingsPctVsBOQ}%`,
      'Price Competitiveness': q.isLowestPrice ? 'LOWEST BID' : `+QAR ${q.diffVsLowest.toLocaleString()}`,
      'Delivery Time': q.deliveryTime,
      'Delivery Speed': q.isFastestDelivery ? 'FASTEST' : `${q.deliveryDays} Days`,
      'Payment Terms': q.paymentTerms,
      'Payment Risk & Terms Grade': q.paymentInfo.label,
      'Upfront Advance Required': `${q.paymentInfo.advancePct}%`,
      'Credit Period': `${q.paymentInfo.creditDays} Days`,
      Warranty: q.warranty,
      'MOI-SSD Compliance': q.supplierRecord?.moiApproved === 'Yes' ? 'Approved' : 'Pending',
      'Supplier Rating (1-5)': q.supplierRecord?.rating || 4.5,
      'Composite Evaluation Score (0-100)': q.totalScore,
      Status: q.status,
      'Selected (Y/N)': q.selected,
      Remarks: q.remarks,
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Vendor_Quotation_Matrix');
    XLSX.writeFile(wb, `Quotation_Comparison_Matrix_${selectedBoqId}_${new Date().toISOString().split('T')[0]}.xlsx`);
    triggerNotification('Quotation comparison matrix exported to Excel (.xlsx) successfully!');
  };

  // Line items for the active BOQ
  const lineItemRows = defaultLineItems[selectedBoqId] || defaultLineItems['BOQ-003'] || [];

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {notificationMsg && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs sm:text-sm font-bold">{notificationMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TOP HEADER & PROJECT COMPARISON SELECTOR BAR                           */}
      {/* ========================================================================= */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        
        {/* Main Title & Action Buttons */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black shadow-md shadow-indigo-200 shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  Vendor Quotation Comparative Matrix
                </h2>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {sortedQuotations.length} Vendor Quotes Evaluated
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Side-by-side multi-vendor decision matrix benchmarked on <strong className="text-slate-800">Price (QAR)</strong>, <strong className="text-slate-800">Delivery Lead Time</strong>, and <strong className="text-slate-800">Payment Terms</strong>.
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto justify-start lg:justify-end">
            {/* Gemini AI Strategic Evaluation Button */}
            {onOpenGeminiAnalysis && (
              <button
                onClick={() => onOpenGeminiAnalysis(selectedBoqId)}
                className="px-3.5 py-2 bg-gradient-to-r from-indigo-900 to-slate-900 hover:from-indigo-800 hover:to-slate-800 text-white text-xs font-black rounded-xl flex items-center gap-1.5 shadow-sm border border-indigo-400/40 transition cursor-pointer"
                title="Run Gemini Multi-Vendor Commercial & Technical Evaluation"
              >
                <Sparkles className="w-4 h-4 text-emerald-300 animate-pulse" />
                <span>AI Commercial Evaluation</span>
              </button>
            )}

            <button
              onClick={() => setIsAddQuoteModalOpen(true)}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm shadow-indigo-200 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Vendor Quote
            </button>

            <button
              onClick={handleExportMatrixExcel}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm shadow-emerald-200 transition cursor-pointer"
            >
              <Download className="w-4 h-4" /> Export Matrix (.xlsx)
            </button>

            {onOpenOfficialQuote && (
              <button
                onClick={onOpenOfficialQuote}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition cursor-pointer"
              >
                <FileText className="w-4 h-4" /> Official BOQ Document
              </button>
            )}
          </div>
        </div>

        {/* Project Selector & Filter Strip */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-3 border-t border-slate-100 items-center">
          
          {/* Project BOQ Dropdown */}
          <div className="md:col-span-4 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2">
            <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">Comparing Project / BOQ:</span>
              <select
                value={selectedBoqId}
                onChange={(e) => {
                  setSelectedBoqId(e.target.value);
                  setSelectedQuoteIds([]);
                  triggerNotification('Switched project comparison scope.');
                }}
                className="w-full bg-transparent border-none text-xs font-black text-slate-900 focus:outline-none cursor-pointer truncate"
              >
                {boqs.map((b) => (
                  <option key={b.boqId} value={b.boqId}>
                    {b.boqId}: {b.projectName} (Target: QAR {b.boqValue.toLocaleString()})
                  </option>
                ))}
                <option value="ALL">All Projects (Global Quotation Pool)</option>
              </select>
            </div>
          </div>

          {/* Sort By Dropdown */}
          <div className="md:col-span-3 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2">
            <ArrowUpDown className="w-4 h-4 text-slate-500 shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">Sort Matrix By:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-transparent border-none text-xs font-bold text-slate-900 focus:outline-none cursor-pointer"
              >
                <option value="recommended">⭐ Highest Composite Evaluation Score</option>
                <option value="priceAsc">💰 Lowest Quoted Price (QAR)</option>
                <option value="deliveryAsc">⚡ Shortest Delivery Lead Time</option>
                <option value="terms">💳 Most Flexible Payment Terms</option>
              </select>
            </div>
          </div>

          {/* Sub-Module View Tabs */}
          <div className="md:col-span-5 flex items-center justify-end gap-1.5 overflow-x-auto">
            {[
              { key: 'cards', label: 'Side-by-Side Cards', icon: <Layers className="w-3.5 h-3.5" /> },
              { key: 'matrixTable', label: 'Evaluation Matrix', icon: <Scale className="w-3.5 h-3.5" /> },
              { key: 'lineItems', label: 'Line-Item Pricing', icon: <Package className="w-3.5 h-3.5" /> },
              { key: 'cashFlow', label: 'Payment Terms & Cash Flow', icon: <CreditCard className="w-3.5 h-3.5" /> },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setMatrixSubTab(tab.key as any)}
                className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  matrixSubTab === tab.key
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Vendor Selection Pills (Filter specific quotes) */}
        {projectQuotations.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-100 text-xs">
            <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Compare Vendors:
            </span>
            {projectQuotations.map((q) => {
              const isSelected = selectedQuoteIds.length === 0 || selectedQuoteIds.includes(q.quoteId);
              return (
                <button
                  key={q.quoteId}
                  onClick={() => {
                    if (selectedQuoteIds.length === 0) {
                      // switch from all to all except this one
                      setSelectedQuoteIds(projectQuotations.map((item) => item.quoteId).filter((id) => id !== q.quoteId));
                    } else if (selectedQuoteIds.includes(q.quoteId)) {
                      if (selectedQuoteIds.length === 1) {
                        setSelectedQuoteIds([]); // reset to all
                      } else {
                        setSelectedQuoteIds(selectedQuoteIds.filter((id) => id !== q.quoteId));
                      }
                    } else {
                      setSelectedQuoteIds([...selectedQuoteIds, q.quoteId]);
                    }
                  }}
                  className={`px-3 py-1 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer text-xs ${
                    isSelected
                      ? 'bg-indigo-50 border border-indigo-300 text-indigo-900 shadow-2xs'
                      : 'bg-slate-100 text-slate-400 border border-slate-200 line-through'
                  }`}
                >
                  {isSelected ? <CheckSquare className="w-3.5 h-3.5 text-indigo-600" /> : <Square className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{q.supplier} (QAR {q.quotedValue.toLocaleString()})</span>
                  {q.status === 'Accepted' && (
                    <span className="bg-emerald-600 text-white text-[9px] px-1.5 py-0.2 rounded-md uppercase font-extrabold ml-1">Awarded</span>
                  )}
                </button>
              );
            })}

            {selectedQuoteIds.length > 0 && (
              <button
                onClick={() => setSelectedQuoteIds([])}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 underline ml-2 cursor-pointer"
              >
                Reset (Show All)
              </button>
            )}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 2. PROJECT BENCHMARK SUMMARY BANNER                                       */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* BOQ Target Benchmark */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">BOQ Target Budget</span>
            <Building2 className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-xl font-black text-slate-900">
            QAR {(activeBoq?.boqValue || priceStats.avg).toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-semibold truncate">
            {activeBoq?.projectName || 'General Project'} ({activeBoq?.category || 'CCTV & ELV'})
          </p>
        </div>

        {/* Lowest Quoted Price */}
        <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider">Lowest Quoted Bid</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <p className="text-xl font-black text-emerald-900">
              QAR {priceStats.min.toLocaleString()}
            </p>
          </div>
          <p className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Savings: QAR {((activeBoq?.boqValue || priceStats.avg) - priceStats.min).toLocaleString()} ({(((activeBoq?.boqValue || priceStats.avg) - priceStats.min) / (activeBoq?.boqValue || 1) * 100).toFixed(1)}%)</span>
          </p>
        </div>

        {/* Fastest Delivery Lead Time */}
        <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-blue-800 uppercase tracking-wider">Fastest Delivery</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-xl font-black text-blue-900">
            {fastestDeliveryDays} Days Lead Time
          </p>
          <p className="text-[11px] font-bold text-blue-700 flex items-center gap-1">
            <Truck className="w-3.5 h-3.5" />
            <span>Expedited Local & Air Freight Options</span>
          </p>
        </div>

        {/* Top Evaluation Winner */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-2xl border border-indigo-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-indigo-900 uppercase tracking-wider">Top Evaluated Vendor</span>
            <Award className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-xl font-black text-indigo-950 truncate">
            {sortedQuotations[0]?.supplier || 'N/A'}
          </p>
          <p className="text-[11px] font-bold text-indigo-700 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Score: {sortedQuotations[0]?.totalScore || 0}/100 (Best Value)</span>
          </p>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. SUB-VIEW A: SIDE-BY-SIDE VENDOR QUOTATION CARDS (PRIMARY)              */}
      {/* ========================================================================= */}
      {matrixSubTab === 'cards' && (
        <div className="space-y-4">
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
              <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-slate-800">
                Side-by-Side Vendor Quotation Profiles ({sortedQuotations.length} Vendors)
              </h3>
            </div>
            <span className="text-[11px] font-bold text-slate-500">
              Benchmarked against BOQ: <span className="font-extrabold text-slate-800">QAR {(activeBoq?.boqValue || priceStats.avg).toLocaleString()}</span>
            </span>
          </div>

          {/* Dynamic Grid of Vendor Cards */}
          <div className={`grid grid-cols-1 gap-4 ${
            sortedQuotations.length === 1 ? 'md:grid-cols-1 max-w-xl' :
            sortedQuotations.length === 2 ? 'md:grid-cols-2' :
            sortedQuotations.length === 3 ? 'md:grid-cols-3' :
            'md:grid-cols-2 lg:grid-cols-4'
          }`}>
            {sortedQuotations.map((quote, index) => {
              const isBestOverall = index === 0;
              const isAccepted = quote.status === 'Accepted';

              return (
                <div
                  key={quote.quoteId}
                  className={`bg-white rounded-3xl border transition-all duration-200 flex flex-col justify-between overflow-hidden relative shadow-xs ${
                    isAccepted
                      ? 'border-emerald-500 ring-4 ring-emerald-100 shadow-lg shadow-emerald-100/50'
                      : isBestOverall
                      ? 'border-indigo-500 ring-2 ring-indigo-200'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {/* Top Header Badge */}
                  <div className={`px-5 py-3 border-b flex items-center justify-between ${
                    isAccepted
                      ? 'bg-emerald-600 text-white border-emerald-700'
                      : isBestOverall
                      ? 'bg-indigo-600 text-white border-indigo-700'
                      : 'bg-slate-50 text-slate-800 border-slate-100'
                  }`}>
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${
                        isAccepted || isBestOverall ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-800'
                      }`}>
                        #{index + 1}
                      </div>
                      <div>
                        <h4 className="text-sm font-black tracking-tight leading-none truncate max-w-[130px]">
                          {quote.supplier}
                        </h4>
                        <span className={`text-[10px] font-semibold ${isAccepted || isBestOverall ? 'text-white/80' : 'text-slate-500'}`}>
                          {quote.quoteId} • {quote.validity}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      {isAccepted ? (
                        <span className="bg-white text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-2xs">
                          🏆 Awarded
                        </span>
                      ) : isBestOverall ? (
                        <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-2xs">
                          ⭐ Best Value
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                          {quote.status}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-5 flex-1">
                    
                    {/* ------------------------------------------------------------- */}
                    {/* PILLAR 1: PRICE & FINANCIALS                                  */}
                    {/* ------------------------------------------------------------- */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <DollarSign className="w-3.5 h-3.5 text-emerald-600" /> Quoted Price (QAR)
                        </span>
                        {quote.isLowestPrice && (
                          <span className="text-[9px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-md uppercase">
                            Lowest Bid
                          </span>
                        )}
                      </div>

                      <div className="flex items-baseline justify-between">
                        <p className="text-2xl font-black text-slate-900 tracking-tight">
                          QAR {quote.quotedValue.toLocaleString()}
                        </p>
                      </div>

                      {/* Variance vs BOQ Budget */}
                      <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
                        <span className="text-slate-500 font-semibold">vs BOQ Target:</span>
                        <span className={`font-black ${quote.savingsVsBOQ >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                          {quote.savingsVsBOQ >= 0 ? `Savings: -QAR ${quote.savingsVsBOQ.toLocaleString()}` : `+QAR ${Math.abs(quote.savingsVsBOQ).toLocaleString()} over`}
                          {' '}({quote.savingsPctVsBOQ}%)
                        </span>
                      </div>

                      {/* Delta vs Lowest Quote */}
                      {!quote.isLowestPrice && (
                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                          <span>vs Lowest Bid:</span>
                          <span className="font-bold text-amber-700">
                            +QAR {quote.diffVsLowest.toLocaleString()} (+{((quote.diffVsLowest / priceStats.min) * 100).toFixed(1)}%)
                          </span>
                        </div>
                      )}
                    </div>

                    {/* ------------------------------------------------------------- */}
                    {/* PILLAR 2: DELIVERY TIME & SPEED                               */}
                    {/* ------------------------------------------------------------- */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-blue-600" /> Delivery Lead Time
                        </span>
                        {quote.isFastestDelivery && (
                          <span className="text-[9px] font-black bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded-md uppercase">
                            Fastest
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-base font-black text-slate-900">{quote.deliveryTime}</span>
                        <span className="text-xs font-bold text-slate-500">({quote.deliveryDays} Calendar Days)</span>
                      </div>

                      {/* Delivery Speed Visual Progress Bar */}
                      <div>
                        <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              quote.deliveryDays <= 10
                                ? 'bg-emerald-500'
                                : quote.deliveryDays <= 21
                                ? 'bg-blue-500'
                                : 'bg-amber-500'
                            }`}
                            style={{
                              width: `${Math.max(15, Math.min(100, 100 - ((quote.deliveryDays - 7) / 35) * 85))}%`,
                            }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-1">
                          <span>Immediate / 7d</span>
                          <span>Standard 21d</span>
                          <span>Extended 42d</span>
                        </div>
                      </div>
                    </div>

                    {/* ------------------------------------------------------------- */}
                    {/* PILLAR 3: PAYMENT TERMS & CASH FLOW                           */}
                    {/* ------------------------------------------------------------- */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <CreditCard className="w-3.5 h-3.5 text-purple-600" /> Payment Terms
                        </span>
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-md uppercase ${
                          quote.paymentInfo.risk === 'Low'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : quote.paymentInfo.risk === 'Medium'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-rose-100 text-rose-800 border border-rose-200'
                        }`}>
                          {quote.paymentInfo.risk} Risk
                        </span>
                      </div>

                      <p className="text-xs font-black text-slate-900">
                        {quote.paymentTerms}
                      </p>

                      <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-slate-400 font-semibold block">Advance Deposit:</span>
                          <span className="font-extrabold text-slate-800">{quote.paymentInfo.advancePct}%</span>
                        </div>
                        <div>
                          <span className="text-slate-400 font-semibold block">Credit Window:</span>
                          <span className="font-extrabold text-slate-800">{quote.paymentInfo.creditDays} Days</span>
                        </div>
                      </div>
                    </div>

                    {/* ------------------------------------------------------------- */}
                    {/* COMPLIANCE, WARRANTY & EVALUATION SCORE                       */}
                    {/* ------------------------------------------------------------- */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-[10px] font-bold text-slate-400 block">Warranty</span>
                        <span className="font-extrabold text-slate-900">{quote.warranty}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-[10px] font-bold text-slate-400 block">MOI SSD Approval</span>
                        <span className="font-extrabold text-emerald-700 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5" /> Approved
                        </span>
                      </div>
                    </div>

                    {/* Weighted Composite Score Gauge */}
                    <div className="p-3 bg-indigo-50/70 rounded-2xl border border-indigo-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-black text-indigo-900 uppercase tracking-wider block">Evaluation Rating</span>
                        <span className="text-[11px] text-slate-500 font-medium">Price (40%) + Delivery (25%) + Terms (20%)</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-lg font-black text-indigo-950">{quote.totalScore}</span>
                        <span className="text-xs font-bold text-indigo-400">/100</span>
                      </div>
                    </div>

                  </div>

                  {/* Action Buttons Footer */}
                  <div className="p-4 bg-slate-50/90 border-t border-slate-100 flex items-center gap-2">
                    {isAccepted ? (
                      <div className="w-full flex flex-col sm:flex-row items-center gap-2">
                        <button
                          disabled
                          className="flex-1 py-2 bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-xs opacity-95"
                        >
                          <CheckCircle2 className="w-4 h-4" /> Awarded
                        </button>
                        <button
                          onClick={() => {
                            const newPO = convertQuoteToPO(quote.quoteId);
                            if (newPO) {
                              triggerNotification(`Generated formal Purchase Order ${newPO.poNumber} for ${quote.supplier}!`);
                              setActiveTab('procurement');
                              setProcurementSubModule('po_logistics');
                            }
                          }}
                          className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
                        >
                          <FileText className="w-4 h-4" />
                          <span>Generate PO</span>
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => handleAwardQuote(quote.quoteId)}
                          className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
                        >
                          <Check className="w-4 h-4" /> Award / Accept
                        </button>
                        <button
                          onClick={() => handleOpenCounterOffer(quote)}
                          className="px-3 py-2.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
                          title="Send Counter-Offer / Revision Request"
                        >
                          Revise
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SUB-VIEW B: DETAILED EVALUATION MATRIX TABLE                            */}
      {/* ========================================================================= */}
      {matrixSubTab === 'matrixTable' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="text-sm font-black text-slate-900 tracking-tight">
                Tabular Multi-Criteria Comparison Matrix & Evaluation Scorecard
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Direct side-by-side metric rows across all quoting vendors for {activeBoq?.projectName}.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Benchmark BOQ:</span>
              <span className="px-3 py-1 bg-white border border-slate-200 text-slate-900 text-xs font-black rounded-xl">
                QAR {(activeBoq?.boqValue || priceStats.avg).toLocaleString()}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-medium">
              <thead className="bg-slate-100/80 text-slate-700 text-[11px] font-extrabold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Evaluation Metric</th>
                  <th className="py-3.5 px-4 bg-indigo-50/60 text-indigo-900">Benchmark Target</th>
                  {sortedQuotations.map((q, idx) => (
                    <th key={q.quoteId} className={`py-3.5 px-4 ${idx === 0 ? 'bg-indigo-50/80 text-indigo-950 font-black' : ''}`}>
                      <div className="flex items-center gap-1.5">
                        <span>{q.supplier}</span>
                        {q.status === 'Accepted' && <span className="text-[9px] bg-emerald-600 text-white px-1.5 rounded">Won</span>}
                        {idx === 0 && q.status !== 'Accepted' && <span className="text-[9px] bg-amber-400 text-slate-900 px-1.5 rounded">#1</span>}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                
                {/* 1. PRICE COMPARISON */}
                <tr className="bg-slate-50/60 font-bold text-slate-900">
                  <td colSpan={2 + sortedQuotations.length} className="py-2.5 px-4 text-xs font-black text-indigo-900 uppercase tracking-wider">
                    1. Financial & Price Comparison (40% Weight)
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-bold text-slate-700">Total Quoted Price (QAR)</td>
                  <td className="py-3 px-4 bg-indigo-50/30 font-bold text-indigo-900">QAR {(activeBoq?.boqValue || priceStats.avg).toLocaleString()}</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className={`text-sm font-black ${q.isLowestPrice ? 'text-emerald-700' : 'text-slate-900'}`}>
                        QAR {q.quotedValue.toLocaleString()}
                      </span>
                      {q.isLowestPrice && (
                        <span className="block text-[10px] font-bold text-emerald-700">⭐ Lowest Price Bid</span>
                      )}
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">Savings / Variance vs Target</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">Baseline (0%)</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className={`font-extrabold ${q.savingsVsBOQ >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                        {q.savingsVsBOQ >= 0 ? `+QAR ${q.savingsVsBOQ.toLocaleString()}` : `-QAR ${Math.abs(q.savingsVsBOQ).toLocaleString()}`} ({q.savingsPctVsBOQ}%)
                      </span>
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">Price Score (0-100)</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">100 Max</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="font-black text-slate-900">{q.priceScore}/100</span>
                    </td>
                  ))}
                </tr>

                {/* 2. DELIVERY LEAD TIME */}
                <tr className="bg-slate-50/60 font-bold text-slate-900">
                  <td colSpan={2 + sortedQuotations.length} className="py-2.5 px-4 text-xs font-black text-indigo-900 uppercase tracking-wider">
                    2. Delivery Time & Supply Chain Logistics (25% Weight)
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-bold text-slate-700">Delivery Lead Time</td>
                  <td className="py-3 px-4 bg-indigo-50/30 font-bold text-indigo-900">2-3 Weeks Standard</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className={`font-black ${q.isFastestDelivery ? 'text-blue-700' : 'text-slate-900'}`}>
                        {q.deliveryTime}
                      </span>
                      <span className="block text-[10px] text-slate-500">({q.deliveryDays} Days)</span>
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">Delivery Lead Score</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">100 Max</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="font-black text-slate-900">{q.deliveryScore}/100</span>
                    </td>
                  ))}
                </tr>

                {/* 3. PAYMENT TERMS */}
                <tr className="bg-slate-50/60 font-bold text-slate-900">
                  <td colSpan={2 + sortedQuotations.length} className="py-2.5 px-4 text-xs font-black text-indigo-900 uppercase tracking-wider">
                    3. Payment Terms & Cash Flow Flexibility (20% Weight)
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-bold text-slate-700">Payment Terms Structure</td>
                  <td className="py-3 px-4 bg-indigo-50/30 font-bold text-indigo-900">30-60 Days Credit</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="font-black text-slate-900">{q.paymentTerms}</span>
                      <span className={`block text-[10px] font-bold ${
                        q.paymentInfo.risk === 'Low' ? 'text-emerald-700' : q.paymentInfo.risk === 'Medium' ? 'text-amber-700' : 'text-rose-700'
                      }`}>
                        {q.paymentInfo.risk} Cash Flow Risk
                      </span>
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">Upfront Advance Deposit Required</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">0% Preferred</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="font-extrabold text-slate-900">{q.paymentInfo.advancePct}%</span>
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">Payment Terms Score</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">100 Max</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="font-black text-slate-900">{q.termsScore}/100</span>
                    </td>
                  ))}
                </tr>

                {/* 4. COMPLIANCE & WARRANTY */}
                <tr className="bg-slate-50/60 font-bold text-slate-900">
                  <td colSpan={2 + sortedQuotations.length} className="py-2.5 px-4 text-xs font-black text-indigo-900 uppercase tracking-wider">
                    4. Warranty, MOI Compliance & Reliability (15% Weight)
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-bold text-slate-700">Warranty Period</td>
                  <td className="py-3 px-4 bg-indigo-50/30 font-bold text-indigo-900">3 Years Standard</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4 font-extrabold text-slate-900">
                      {q.warranty}
                    </td>
                  ))}
                </tr>

                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-600">MOI-SSD Approval</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">Required (Yes)</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      <span className="text-emerald-700 font-extrabold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> Approved
                      </span>
                    </td>
                  ))}
                </tr>

                {/* 5. FINAL COMPOSITE SCORE & ACTIONS */}
                <tr className="bg-indigo-900 text-white font-black">
                  <td className="py-4 px-4 text-sm">FINAL COMPOSITE SCORE (0-100)</td>
                  <td className="py-4 px-4 bg-indigo-950 text-indigo-200">100 Max Score</td>
                  {sortedQuotations.map((q, idx) => (
                    <td key={q.quoteId} className={`py-4 px-4 ${idx === 0 ? 'bg-indigo-800' : ''}`}>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-amber-300">{q.totalScore}</span>
                        <span className="text-xs text-indigo-200 font-bold">/100</span>
                      </div>
                    </td>
                  ))}
                </tr>

                {/* Action Row */}
                <tr className="bg-slate-50">
                  <td className="py-3 px-4 font-bold text-slate-700">Contract Action</td>
                  <td className="py-3 px-4 bg-indigo-50/30 text-slate-400">-</td>
                  {sortedQuotations.map((q) => (
                    <td key={q.quoteId} className="py-3 px-4">
                      {q.status === 'Accepted' ? (
                        <span className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-black rounded-xl inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Awarded
                        </span>
                      ) : (
                        <button
                          onClick={() => handleAwardQuote(q.quoteId)}
                          className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
                        >
                          Select / Award
                        </button>
                      )}
                    </td>
                  ))}
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. SUB-VIEW C: LINE-ITEM PRICE BREAKDOWN MATRIX                           */}
      {/* ========================================================================= */}
      {matrixSubTab === 'lineItems' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-2xs overflow-hidden space-y-4">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="text-sm font-black text-slate-900 tracking-tight">
                Item-by-Item Unit Price Comparison (Cameras, NVRs, Switches & Cables)
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Compare individual component unit prices in QAR across quoting vendors to identify item-level discrepancies.
              </p>
            </div>
            <span className="px-3 py-1 bg-white border border-slate-200 text-slate-700 text-xs font-bold rounded-xl">
              {lineItemRows.length} Line Items Compared
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-medium">
              <thead className="bg-slate-100 text-slate-700 text-[11px] font-extrabold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Item Code</th>
                  <th className="py-3.5 px-4">Description & Specification</th>
                  <th className="py-3.5 px-4">Qty</th>
                  <th className="py-3.5 px-4">Unit</th>
                  {sortedQuotations.map((q) => (
                    <th key={q.quoteId} className="py-3.5 px-4 font-black text-slate-900">
                      {q.supplier} (Unit QAR)
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {lineItemRows.map((item) => {
                  // Find minimum price among compared vendors for this line item
                  const prices = sortedQuotations.map((q) => item.vendorPrices[q.supplier] || item.vendorPrices[Object.keys(item.vendorPrices)[0]] || 0);
                  const minPrice = Math.min(...prices.filter((p) => p > 0));

                  return (
                    <tr key={item.itemCode} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 text-xs">{item.itemCode}</td>
                      <td className="py-3 px-4 font-semibold text-slate-700 max-w-sm">{item.description}</td>
                      <td className="py-3 px-4 font-black text-slate-900">{item.qty}</td>
                      <td className="py-3 px-4 text-slate-500 font-bold">{item.unit}</td>
                      {sortedQuotations.map((q) => {
                        const price = item.vendorPrices[q.supplier] || (item.vendorPrices[Object.keys(item.vendorPrices)[0]] || 0);
                        const isLowest = price === minPrice && price > 0;
                        return (
                          <td key={q.quoteId} className="py-3 px-4">
                            <span className={`font-black ${isLowest ? 'text-emerald-700 font-black' : 'text-slate-900'}`}>
                              QAR {price.toLocaleString()}
                            </span>
                            {isLowest && (
                              <span className="block text-[9px] font-extrabold text-emerald-700 uppercase">Lowest Unit Price</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. SUB-VIEW D: PAYMENT TERMS & CASH FLOW ANALYSIS                         */}
      {/* ========================================================================= */}
      {matrixSubTab === 'cashFlow' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-6">
            <div>
              <h3 className="text-sm font-black text-slate-900 tracking-tight">
                Payment Terms & Cash Flow Exposure Analysis
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Examine working capital requirements and liquidity impact for each vendor's commercial payment schedule.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {sortedQuotations.map((quote) => {
                const total = quote.quotedValue;
                const upfrontDeposit = Math.round(total * (quote.paymentInfo.advancePct / 100));
                const remainingPayable = total - upfrontDeposit;

                return (
                  <div key={quote.quoteId} className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-slate-900 text-sm">{quote.supplier}</span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                        quote.paymentInfo.risk === 'Low' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {quote.paymentInfo.risk} Risk
                      </span>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Payment Method</span>
                      <p className="text-xs font-black text-slate-800">{quote.paymentTerms}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-200 space-y-2 text-xs font-semibold">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Upfront Cash Needed:</span>
                        <span className="font-black text-slate-900">QAR {upfrontDeposit.toLocaleString()} ({quote.paymentInfo.advancePct}%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Credit Days Allowed:</span>
                        <span className="font-black text-slate-900">{quote.paymentInfo.creditDays} Days</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Deferred Balance:</span>
                        <span className="font-black text-slate-900">QAR {remainingPayable.toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Visual Cash Flow Block */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 text-[11px] space-y-1">
                      <span className="font-extrabold text-slate-700 block">Cash Flow Schedule:</span>
                      <p className="text-slate-500 text-[10px]">
                        {quote.paymentInfo.advancePct > 0
                          ? `Release QAR ${upfrontDeposit.toLocaleString()} at PO confirmation, balance QAR ${remainingPayable.toLocaleString()} after ${quote.paymentInfo.creditDays > 0 ? quote.paymentInfo.creditDays + ' days credit' : 'delivery inspection'}.`
                          : `No upfront cash drain. Full QAR ${total.toLocaleString()} payable on ${quote.paymentInfo.creditDays} days credit after delivery.`}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. COUNTER-OFFER / REVISION REQUEST MODAL                                 */}
      {/* ========================================================================= */}
      {isCounterOfferModalOpen && targetQuoteForRevision && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-100 rounded-xl text-indigo-700">
                  <ArrowUpDown className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Request Price Revision / Counter-Offer</h3>
                  <p className="text-xs text-slate-500">Supplier: <strong className="text-slate-800">{targetQuoteForRevision.supplier}</strong> ({targetQuoteForRevision.quoteId})</p>
                </div>
              </div>
              <button
                onClick={() => setIsCounterOfferModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitCounterOffer} className="space-y-4 text-xs font-semibold">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 mb-1">Current Quoted Price (QAR)</label>
                  <input
                    type="text"
                    disabled
                    value={`QAR ${targetQuoteForRevision.quotedValue.toLocaleString()}`}
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-slate-600 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Target Counter Price (QAR)</label>
                  <input
                    type="number"
                    value={revisionTargetPrice}
                    onChange={(e) => setRevisionTargetPrice(e.target.value)}
                    className="w-full bg-white border border-indigo-300 rounded-xl px-3 py-2 text-slate-900 font-black focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 2400000"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Target Delivery Time</label>
                  <input
                    type="text"
                    value={revisionTargetDelivery}
                    onChange={(e) => setRevisionTargetDelivery(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 10 Days"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Requested Payment Terms</label>
                  <input
                    type="text"
                    value={revisionTargetTerms}
                    onChange={(e) => setRevisionTargetTerms(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 30 Days Credit"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Revision Notes & Justification</label>
                <textarea
                  rows={3}
                  value={revisionNotes}
                  onChange={(e) => setRevisionNotes(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:ring-2 focus:ring-indigo-500"
                  placeholder="State requirement for price reduction, competitor benchmark, or volume discount..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCounterOfferModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" /> Send Revision Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. ADD NEW CUSTOM VENDOR QUOTE MODAL                                      */}
      {/* ========================================================================= */}
      {isAddQuoteModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 rounded-xl text-emerald-700">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">Add Vendor Quotation to Matrix</h3>
                  <p className="text-xs text-slate-500">Project: <strong className="text-slate-800">{activeBoq?.projectName}</strong> ({selectedBoqId})</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddQuoteModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddNewQuote} className="space-y-4 text-xs font-semibold">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Supplier / Vendor Name</label>
                  <input
                    type="text"
                    required
                    value={newQuoteSupplier}
                    onChange={(e) => setNewQuoteSupplier(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Honeywell Security"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Total Quoted Value (QAR)</label>
                  <input
                    type="number"
                    required
                    value={newQuoteValue}
                    onChange={(e) => setNewQuoteValue(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-black focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 2480000"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Delivery Lead Time</label>
                  <input
                    type="text"
                    value={newQuoteDelivery}
                    onChange={(e) => setNewQuoteDelivery(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 10 Days / 2 Weeks"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Payment Terms</label>
                  <input
                    type="text"
                    value={newQuotePaymentTerms}
                    onChange={(e) => setNewQuotePaymentTerms(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 30 Days Credit / L/C"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Warranty Period</label>
                  <input
                    type="text"
                    value={newQuoteWarranty}
                    onChange={(e) => setNewQuoteWarranty(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 3 Years / 5 Years"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Quotation Validity</label>
                  <input
                    type="text"
                    value={newQuoteValidity}
                    onChange={(e) => setNewQuoteValidity(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 30 Days"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-extrabold text-slate-900 mb-1">Quotation Remarks</label>
                <textarea
                  rows={2}
                  value={newQuoteRemarks}
                  onChange={(e) => setNewQuoteRemarks(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:ring-2 focus:ring-indigo-500"
                  placeholder="Additional terms, freight notes, or scope details..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddQuoteModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" /> Add to Comparative Matrix
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
