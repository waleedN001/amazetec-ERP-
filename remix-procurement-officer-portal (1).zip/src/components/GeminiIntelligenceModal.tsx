import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Scale,
  FileText,
  Mail,
  Lightbulb,
  Copy,
  Check,
  Download,
  AlertCircle,
  TrendingDown,
  ShieldCheck,
  Building2,
  DollarSign,
  Clock,
  ArrowRight,
  Bot,
  Layers,
  UploadCloud,
  FileCode2,
  PlusCircle,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { BOQRecord, QuotationResult, SupplierRecord } from '../types';

interface GeminiIntelligenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?:
    | 'dwg-extractor'
    | 'quote-analysis'
    | 'counter-offer'
    | 'boq-generator'
    | 'value-engineering'
    | 'sales-proposal'
    | 'moi-audit'
    | 'pm-risk'
    | 'amc-diagnostic'
    | 'finance-audit';
  boqs?: BOQRecord[];
  quotations?: QuotationResult[];
  suppliers?: SupplierRecord[];
  selectedBoqId?: string;
  onAddBOQRecord?: (boq: BOQRecord) => void;
  onNavigateTab?: (tab: string, subModule?: string) => void;
}

export const GeminiIntelligenceModal: React.FC<GeminiIntelligenceModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'dwg-extractor',
  boqs = [],
  quotations = [],
  suppliers = [],
  selectedBoqId,
  onAddBOQRecord,
  onNavigateTab,
}) => {
  const [activeMode, setActiveMode] = useState<
    | 'dwg-extractor'
    | 'quote-analysis'
    | 'counter-offer'
    | 'boq-generator'
    | 'value-engineering'
    | 'sales-proposal'
    | 'moi-audit'
    | 'pm-risk'
    | 'amc-diagnostic'
    | 'finance-audit'
  >(initialMode);
  const [currentBoqId, setCurrentBoqId] = useState<string>(selectedBoqId || (boqs[0]?.boqId || 'BOQ-003'));
  const [selectedSupplier, setSelectedSupplier] = useState<string>('Hikvision');

  // DWG / CAD Drawing Extractor State
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    size: number;
    mimeType: string;
    base64: string;
  } | null>(null);
  const [drawingNotes, setDrawingNotes] = useState('Extract all Low Current / ELV / CCTV / Wi-Fi / Access Control / GRMS / Structured Cabling components, conduits, and accessories for 1-Bedroom Beach Villa.');
  const [extractedBOQData, setExtractedBOQData] = useState<any | null>(null);
  const [injectedSuccess, setInjectedSuccess] = useState(false);
  
  // BOQ Spec Generator Form State
  const [specItemName, setSpecItemName] = useState('4MP IR Network Dome Camera (MOI-SSD Approved)');
  const [specCategory, setSpecCategory] = useState('CCTV Cameras & Optics');
  const [specProjectType, setSpecProjectType] = useState('Residential Compound (Ezdan)');
  const [specRequirements, setSpecRequirements] = useState('120dB WDR, H.265+, 30m IR, IK10 vandal proof, ONVIF Profile S/G/T');

  // Counter Offer Form State
  const [targetPriceReduction, setTargetPriceReduction] = useState(8);
  const [requestedTerms, setRequestedTerms] = useState('30 Days Credit / L/C 60 Days');
  const [requestedDelivery, setRequestedDelivery] = useState('2 Weeks (Expedited via Qatar Warehouse)');

  // Value Engineering Form State
  const [targetSavingsPercent, setTargetSavingsPercent] = useState(15);
  const [targetProduct, setTargetProduct] = useState('Enterprise 64-Channel 4K NVR with 120-Day RAID 6 SAN');

  // Sales Proposal Form State
  const [salesClient, setSalesClient] = useState('Alfardan Properties W.L.L.');
  const [salesProject, setSalesProject] = useState('Alfardan Commercial Tower CCTV Upgrade');
  const [salesSector, setSalesSector] = useState('Commercial Real Estate');
  const [salesValue, setSalesValue] = useState(480000);
  const [salesScope, setSalesScope] = useState('Full turnkey supply, CAT6A cabling, 128 IP Cameras, 120-day Dell EMC SAN storage, and MOI SSD Final Handover Certificate.');

  // MOI Audit Form State
  const [moiCamCount, setMoiCamCount] = useState(96);
  const [moiResolution, setMoiResolution] = useState('4MP');
  const [moiFps, setMoiFps] = useState(25);
  const [moiCompression, setMoiCompression] = useState('H.265');
  const [moiDays, setMoiDays] = useState(120);

  // PM Risk Form State
  const [pmProject, setPmProject] = useState('Lusail Marina Towers ELV Package');
  const [pmStage, setPmStage] = useState('2nd Fix & Containment Pulling');
  const [pmBlocker, setPmBlocker] = useState('Main MEP ceiling closure delayed by 10 days; MOI SSD inspection booked for 28th.');

  // AMC Diagnostic State
  const [amcSystem, setAmcSystem] = useState('CCTV Network & Core PoE Switch');
  const [amcIssue, setAmcIssue] = useState('Cameras on Floor 3 to 6 intermittently offline after 6 PM; NVR showing RTSP packet loss errors.');

  // Finance 3-Way Audit State
  const [finPoRef, setFinPoRef] = useState('PO-2026-089');
  const [finPoValue, setFinPoValue] = useState(185000);
  const [finInvValue, setFinInvValue] = useState(192500);
  const [finNotes, setFinNotes] = useState('Vendor billed QAR 7,500 extra for air freight without prior PO amendment.');

  // Output States
  const [isLoading, setIsLoading] = useState(false);
  const [generatedResult, setGeneratedResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentBoq = boqs.find((b) => b.boqId === currentBoqId || (b as any).id === currentBoqId) || boqs[0];
  const projectQuotes = quotations.filter((q) => q.boqId === currentBoqId || (currentBoq && q.projectName === currentBoq.projectName));

  // File Upload Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      const base64Content = resultStr.includes(',') ? resultStr.split(',')[1] : resultStr;
      setSelectedFile({
        name: file.name,
        size: file.size,
        mimeType: file.type || 'application/octet-stream',
        base64: base64Content,
      });
      setExtractedBOQData(null);
      setInjectedSuccess(false);
    };
    reader.readAsDataURL(file);
  };

  // Load Sample Maldives Rosewood Drawing Data
  const handleLoadSampleMaldivesDrawing = () => {
    setSelectedFile({
      name: 'RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201.dwg',
      size: 1420500,
      mimeType: 'application/acad',
      base64: '',
    });
    setDrawingNotes(
      'Project: ROYAL ROSEWOOD RESORT, MALDIVES\nPackage: P-04 GUEST VILLAS - 1 BEDROOM BEACH VILLA\nDrawing No: RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201 (Rev 00)\nClient: Estithmar Holding Q.P.S.C. / IDCC / UCC\nELV Contractor: Amazetec Security (Doha, Qatar)\nConsultants: Shaker (MEP) / Olson Kundig (Arch)\nLegend Tags on Plan: 1BBV-GF-TDW-01/02 (Telephone Wall), 1BBV-GF-TD-01/02 (Desk), 1BBV-GF-TV-01/02 (IPTV), 1BBV-GF-AP-01..04 (Indoor Wi-Fi AP), 1BBV-GF-APWP-01 (Outdoor AP), 1BBV-GF-LCP-01/02 (LCP), 1BBV-GF-GR-01/02 (GRMS RCU), 1BBV-GF-AC-01 (Access Control Panel), 1BBV-GF-CRE-01/02 (Door Card Reader Sets), 6U Wall Rack, 25mm uPVC & 20mm GI Conduits.'
    );
    setExtractedBOQData(null);
    setInjectedSuccess(false);
  };

  // Run DWG / CAD Drawing Parser
  const handleParseDWGPlan = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setExtractedBOQData(null);
    setInjectedSuccess(false);

    try {
      const res = await fetch('/api/gemini/parse-dwg-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileBase64: selectedFile?.base64 || '',
          fileName: selectedFile?.name || 'RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201.dwg',
          mimeType: selectedFile?.mimeType || 'application/acad',
          extractedText: drawingNotes,
          projectNotes: drawingNotes,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      if (data.boq) {
        setExtractedBOQData(data.boq);
      } else {
        throw new Error('No structured BOQ data returned.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to parse .dwg drawing with Gemini.');
    } finally {
      setIsLoading(false);
    }
  };

  // Inject extracted BOQ directly into Application State
  const handleInjectIntoMasterBOQ = () => {
    if (!extractedBOQData) return;

    const newBoqId = `BOQ-00${boqs.length + 1}`;
    const newBoqRecord: BOQRecord = {
      boqId: newBoqId,
      projectName: extractedBOQData.projectName || 'Royal Rosewood Resort - 1BR Beach Villa',
      boqValue: Number(extractedBOQData.totalBOQValue) || 44762,
      boqDate: new Date().toISOString().split('T')[0],
      preparedBy: 'Amazetec AI CAD Estimator',
      approvedBy: 'Eng. Hassan Al-Kuwari',
      status: 'Approved',
      category: extractedBOQData.category || 'ELV / Low Current',
      sector: extractedBOQData.sector || 'Hospitality',
      clientName: extractedBOQData.clientName || 'Estithmar Holding / UCC',
      totalItems: extractedBOQData.items?.length || 18,
      materialCost: extractedBOQData.totalMaterialCost || 28400,
      labourCost: extractedBOQData.totalLabourCost || 8500,
      overheadCost: extractedBOQData.overheadCost || 4200,
      marginPercent: extractedBOQData.marginPercent || 15,
      remarks: `Auto-generated from CAD Drawing: ${extractedBOQData.drawingNumber || 'RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201'}. Contains ${extractedBOQData.items?.length || 0} line items.`,
    };

    if (onAddBOQRecord) {
      onAddBOQRecord(newBoqRecord);
      setInjectedSuccess(true);
    }
  };

  const handleRunQuotationAnalysis = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/analyze-quotations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          boq: currentBoq,
          quotations: projectQuotes.length > 0 ? projectQuotes : quotations.slice(0, 4),
          suppliers,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.analysis);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to analyze quotations with Gemini.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunCounterOffer = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    const quote = projectQuotes.find((q) => q.supplier === selectedSupplier) || projectQuotes[0] || quotations[0];
    const currentPrice = quote ? quote.quotedValue : 2550000;
    const targetPrice = Math.round(currentPrice * (1 - targetPriceReduction / 100));

    try {
      const res = await fetch('/api/gemini/draft-negotiation-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supplierName: quote?.supplier || selectedSupplier,
          projectName: currentBoq?.projectName || 'Argentine Laborhood',
          currentQuotedValue: currentPrice,
          targetPrice,
          currentDelivery: quote?.deliveryTime || '3 Weeks',
          targetDelivery: requestedDelivery,
          currentTerms: quote?.paymentTerms || '50% Advance',
          targetTerms: requestedTerms,
          notes: `We have 3 competing bids submitted for this project. Approving counter-offer guarantees immediate Purchase Order issuance.`,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.letter);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to draft counter-offer letter.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunBoqGenerator = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/generate-boq-specs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          itemName: specItemName,
          category: specCategory,
          projectType: specProjectType,
          requirements: specRequirements,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.specs);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate BOQ specs.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunValueEngineering = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/value-engineering', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product: {
            name: targetProduct,
            project: currentBoq?.projectName,
            targetCostReductionPercent: targetSavingsPercent,
          },
          targetSavingsPercent,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.recommendation);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run value engineering advisor.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunSalesProposal = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/sales-proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: salesClient,
          projectName: salesProject,
          sector: salesSector,
          estimatedValueQAR: salesValue,
          scope: salesScope,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.proposal);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate proposal.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunMoiAudit = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/moi-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cameraCount: moiCamCount,
          resolution: moiResolution,
          fps: moiFps,
          compression: moiCompression,
          retentionDays: moiDays,
          sector: 'Commercial & Hospitality',
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.audit);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run MOI audit.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunPmRisk = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/pm-risk-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project: {
            name: pmProject,
            currentStage: pmStage,
            siteBlockerNotes: pmBlocker,
          },
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.riskAnalysis);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run PM risk analysis.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunAmcDiagnostic = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/amc-diagnostic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticket: {
            subsystem: amcSystem,
            description: amcIssue,
            severity: 'High / Critical',
          },
          contract: {
            slaResponseTime: '2 Hours (On-site in Doha)',
            terms: 'Comprehensive 24/7 AMC with spares',
          },
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.diagnostic);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run AMC diagnostic.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunFinanceAudit = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setGeneratedResult(null);

    try {
      const res = await fetch('/api/gemini/finance-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          purchaseOrder: { poNumber: finPoRef, totalQAR: finPoValue },
          deliveryNote: { grnStatus: 'Received & Verified at Warehouse' },
          invoice: { billedTotalQAR: finInvValue },
          variances: [{ type: 'Unapproved Freight / Price Surcharge', notes: finNotes }],
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      setGeneratedResult(data.financeAudit);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run finance audit.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedResult) return;
    navigator.clipboard.writeText(generatedResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Top Bar */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight text-white">Gemini Procurement Intelligence Hub</h3>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-400/30">
                  Qatar Enterprise AI
                </span>
              </div>
              <p className="text-xs text-slate-300">Automated commercial evaluation, negotiations, and technical BOQ engineering</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Intelligence Mode Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => { setActiveMode('dwg-extractor'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'dwg-extractor'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>📐 CAD / .DWG Drawing to BOQ Extractor</span>
          </button>

          <button
            onClick={() => { setActiveMode('quote-analysis'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'quote-analysis'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Quotation Evaluation & Award</span>
          </button>

          <button
            onClick={() => { setActiveMode('counter-offer'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'counter-offer'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Counter-Offer & Negotiation Draft</span>
          </button>

          <button
            onClick={() => { setActiveMode('boq-generator'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'boq-generator'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>BOQ Spec & Cost Estimator</span>
          </button>

          <button
            onClick={() => { setActiveMode('value-engineering'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'value-engineering'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Value Engineering & Alternatives</span>
          </button>

          <button
            onClick={() => { setActiveMode('sales-proposal'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'sales-proposal'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sales Proposal & Tender BP</span>
          </button>

          <button
            onClick={() => { setActiveMode('moi-audit'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'moi-audit'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>MOI-SSD Storage & Compliance Audit</span>
          </button>

          <button
            onClick={() => { setActiveMode('pm-risk'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'pm-risk'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>PM Schedule & Site Risk Audit</span>
          </button>

          <button
            onClick={() => { setActiveMode('amc-diagnostic'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'amc-diagnostic'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>AMC Diagnostic & SLA Mitigation</span>
          </button>

          <button
            onClick={() => { setActiveMode('finance-audit'); setGeneratedResult(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeMode === 'finance-audit'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>3-Way Finance Reconciliation</span>
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* 1. Mode Configuration Form */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
            
            {/* Mode: CAD / DWG Drawing to BOQ Extractor */}
            {activeMode === 'dwg-extractor' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-indigo-50/70 border border-indigo-100 p-3 rounded-2xl">
                  <div className="flex items-center gap-2.5">
                    <FileCode2 className="w-5 h-5 text-indigo-700 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black text-indigo-950">
                        AutoCAD .DWG / .DXF / PDF Plan Take-Off Engine
                      </h4>
                      <p className="text-[11px] text-indigo-800">
                        Upload floor plans or symbol drawings to extract item quantities, device tags, and automatically price your Master BOQ.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handleLoadSampleMaldivesDrawing}
                    type="button"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-black rounded-xl transition cursor-pointer shrink-0 shadow-xs flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                    <span>Load Maldives Rosewood Villa Plan</span>
                  </button>
                </div>

                {/* Upload Zone */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                      Upload Drawing (.dwg, .dxf, .pdf, .png, .jpg):
                    </label>
                    <label className="border-2 border-dashed border-slate-300 hover:border-indigo-500 bg-white rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition group">
                      <UploadCloud className="w-7 h-7 text-slate-400 group-hover:text-indigo-600 mb-1.5 transition" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-indigo-700">
                        {selectedFile ? selectedFile.name : 'Click to select or drag drawing file'}
                      </span>
                      <span className="text-[10px] text-slate-400 mt-0.5">
                        {selectedFile
                          ? `${(selectedFile.size / 1024).toFixed(1)} KB • Ready for extraction`
                          : 'Supports AutoCAD DWG, DXF vector schedules, or PDF/Image layouts'}
                      </span>
                      <input
                        type="file"
                        accept=".dwg,.dxf,.pdf,.png,.jpg,.jpeg"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                      Drawing Scope / Engineering Notes:
                    </label>
                    <textarea
                      rows={3}
                      value={drawingNotes}
                      onChange={(e) => setDrawingNotes(e.target.value)}
                      placeholder="Enter specific project packages, tags, or consultant instructions..."
                      className="w-full bg-white border border-slate-300 rounded-2xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 font-mono resize-none"
                    />
                  </div>
                </div>

                <button
                  onClick={handleParseDWGPlan}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isLoading
                      ? 'Gemini is Reading CAD Layers, Tags & Quantities...'
                      : 'Extract Quantities & Generate Master BOQ'}
                  </span>
                </button>
              </div>
            )}

            {/* Mode: Quote Analysis */}
            {activeMode === 'quote-analysis' && (
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">
                      Select Target BOQ Project to Evaluate:
                    </label>
                    <select
                      value={currentBoqId}
                      onChange={(e) => setCurrentBoqId(e.target.value)}
                      className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer min-w-[280px]"
                    >
                      {boqs.map((b) => (
                        <option key={b.boqId} value={b.boqId}>
                          {b.boqId}: {b.projectName} (Target: QAR {b.boqValue?.toLocaleString()})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <span className="font-semibold">Competing Bids Attached:</span>
                    <span className="bg-indigo-100 text-indigo-800 font-extrabold px-2.5 py-0.5 rounded-full">
                      {projectQuotes.length} Vendor Quotes
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleRunQuotationAnalysis}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                  <span>{isLoading ? 'Gemini is Evaluating Commercial Disparities...' : 'Generate AI Commercial & Technical Evaluation'}</span>
                </button>
              </div>
            )}

            {/* Mode: Counter Offer */}
            {activeMode === 'counter-offer' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Target Project:</label>
                    <select
                      value={currentBoqId}
                      onChange={(e) => setCurrentBoqId(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      {boqs.map((b) => (
                        <option key={b.boqId} value={b.boqId}>
                          {b.boqId}: {b.projectName}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Target Supplier:</label>
                    <select
                      value={selectedSupplier}
                      onChange={(e) => setSelectedSupplier(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      {['Hikvision', 'Dahua', 'Uniview (UNV)', 'Honeywell Security', 'Bosch Security', 'Axis Communications'].map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">
                      Discount Target (%):
                    </label>
                    <input
                      type="number"
                      value={targetPriceReduction}
                      onChange={(e) => setTargetPriceReduction(Number(e.target.value))}
                      min={1}
                      max={40}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Requested Payment Terms:</label>
                    <input
                      type="text"
                      value={requestedTerms}
                      onChange={(e) => setRequestedTerms(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Requested Expedited Delivery:</label>
                    <input
                      type="text"
                      value={requestedDelivery}
                      onChange={(e) => setRequestedDelivery(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <button
                  onClick={handleRunCounterOffer}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Drafting Negotiation Letter...' : 'Generate Formal Vendor Counter-Offer Letter'}</span>
                </button>
              </div>
            )}

            {/* Mode: BOQ Generator */}
            {activeMode === 'boq-generator' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Item / Security Equipment Name:</label>
                    <input
                      type="text"
                      value={specItemName}
                      onChange={(e) => setSpecItemName(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Category:</label>
                    <select
                      value={specCategory}
                      onChange={(e) => setSpecCategory(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="CCTV Cameras & Optics">CCTV Cameras & Optics</option>
                      <option value="Recording & Storage SAN/NVR">Recording & Storage SAN/NVR</option>
                      <option value="Active Switching & Network">Active Switching & Network</option>
                      <option value="Access Control & Barrier">Access Control & Barrier</option>
                      <option value="Structured Cabling & Fiber">Structured Cabling & Fiber</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mandatory Technical Requirements / Standards:</label>
                  <input
                    type="text"
                    value={specRequirements}
                    onChange={(e) => setSpecRequirements(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <button
                  onClick={handleRunBoqGenerator}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <FileText className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Generating MOI Spec & Costing...' : 'Generate Technical Spec & QAR Cost Range'}</span>
                </button>
              </div>
            )}

            {/* Mode: Value Engineering */}
            {activeMode === 'value-engineering' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Target Product to Value-Engineer:</label>
                    <input
                      type="text"
                      value={targetProduct}
                      onChange={(e) => setTargetProduct(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Target Savings (%):</label>
                    <input
                      type="number"
                      value={targetSavingsPercent}
                      onChange={(e) => setTargetSavingsPercent(Number(e.target.value))}
                      min={5}
                      max={35}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <button
                  onClick={handleRunValueEngineering}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Lightbulb className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Evaluating Value Engineering...' : 'Find Cost-Optimized Alternative Models'}</span>
                </button>
              </div>
            )}

            {/* Mode: Sales Proposal Generator */}
            {activeMode === 'sales-proposal' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Client Name:</label>
                    <input
                      type="text"
                      value={salesClient}
                      onChange={(e) => setSalesClient(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Project Name:</label>
                    <input
                      type="text"
                      value={salesProject}
                      onChange={(e) => setSalesProject(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Sector:</label>
                    <select
                      value={salesSector}
                      onChange={(e) => setSalesSector(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="Commercial Real Estate">Commercial Real Estate</option>
                      <option value="Government & Defense">Government & Defense</option>
                      <option value="Hospitality & Leisure">Hospitality & Leisure</option>
                      <option value="Healthcare & Education">Healthcare & Education</option>
                      <option value="Banking & Retail">Banking & Retail</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Estimated Tender Value (QAR):</label>
                    <input
                      type="number"
                      value={salesValue}
                      onChange={(e) => setSalesValue(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Scope & Key Inclusions:</label>
                  <textarea
                    rows={2}
                    value={salesScope}
                    onChange={(e) => setSalesScope(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <button
                  onClick={handleRunSalesProposal}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Drafting Business Proposal...' : 'Generate Executive Sales Proposal (Markdown)'}</span>
                </button>
              </div>
            )}

            {/* Mode: MOI-SSD Audit */}
            {activeMode === 'moi-audit' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Camera Count:</label>
                    <input
                      type="number"
                      value={moiCamCount}
                      onChange={(e) => setMoiCamCount(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Standard Resolution:</label>
                    <select
                      value={moiResolution}
                      onChange={(e) => setMoiResolution(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="2MP">2MP (1080p Full HD)</option>
                      <option value="4MP">4MP (2K Quad HD)</option>
                      <option value="8MP">8MP (4K Ultra HD)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Mandatory Retention:</label>
                    <select
                      value={moiDays}
                      onChange={(e) => setMoiDays(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value={120}>120 Days (Standard MOI-SSD Mandate)</option>
                      <option value={180}>180 Days (High Security / Critical Infra)</option>
                      <option value={90}>90 Days (Legacy Non-SSD)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Frame Rate (FPS):</label>
                    <input
                      type="number"
                      value={moiFps}
                      onChange={(e) => setMoiFps(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Compression Standard:</label>
                    <select
                      value={moiCompression}
                      onChange={(e) => setMoiCompression(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="H.265">H.265 HEVC (Standard)</option>
                      <option value="H.265+">H.265+ Smart Stream</option>
                      <option value="H.264">H.264 Baseline</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleRunMoiAudit}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Auditing MOI Storage & Spec...' : 'Run Full MOI-SSD Compliance & Storage Calculation'}</span>
                </button>
              </div>
            )}

            {/* Mode: PM Risk */}
            {activeMode === 'pm-risk' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Project Name:</label>
                    <input
                      type="text"
                      value={pmProject}
                      onChange={(e) => setPmProject(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Current Execution Milestone:</label>
                    <input
                      type="text"
                      value={pmStage}
                      onChange={(e) => setPmStage(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Active Site Impediments / Blocker Notes:</label>
                  <textarea
                    rows={2}
                    value={pmBlocker}
                    onChange={(e) => setPmBlocker(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <button
                  onClick={handleRunPmRisk}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Clock className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Analyzing Project Risks...' : 'Audit Critical Path & Mitigation Plan'}</span>
                </button>
              </div>
            )}

            {/* Mode: AMC Diagnostic */}
            {activeMode === 'amc-diagnostic' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Subsystem / Hardware:</label>
                    <input
                      type="text"
                      value={amcSystem}
                      onChange={(e) => setAmcSystem(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Trouble Symptom / Log Output:</label>
                    <input
                      type="text"
                      value={amcIssue}
                      onChange={(e) => setAmcIssue(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <button
                  onClick={handleRunAmcDiagnostic}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Bot className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Diagnosing Trouble Ticket...' : 'Generate Field Troubleshooting Guide & SLA Defense'}</span>
                </button>
              </div>
            )}

            {/* Mode: Finance 3-Way Audit */}
            {activeMode === 'finance-audit' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">PO Reference:</label>
                    <input
                      type="text"
                      value={finPoRef}
                      onChange={(e) => setFinPoRef(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">PO Approved Value (QAR):</label>
                    <input
                      type="number"
                      value={finPoValue}
                      onChange={(e) => setFinPoValue(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-800 mb-1">Vendor Invoiced Value (QAR):</label>
                    <input
                      type="number"
                      value={finInvValue}
                      onChange={(e) => setFinInvValue(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Detected Discrepancy / Line Item Notes:</label>
                  <textarea
                    rows={2}
                    value={finNotes}
                    onChange={(e) => setFinNotes(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <button
                  onClick={handleRunFinanceAudit}
                  disabled={isLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>{isLoading ? 'Gemini is Auditing 3-Way Match...' : 'Perform 3-Way Match & Generate Debit Note Draft'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Error Display */}
          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl flex items-start gap-3 text-xs">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold">Error communicating with Gemini:</strong>
                <p className="mt-1">{errorMessage}</p>
                <p className="mt-1 text-slate-500">Make sure GEMINI_API_KEY is configured in Settings &gt; Secrets.</p>
              </div>
            </div>
          )}

          {/* Extracted BOQ Interactive Preview Table (DWG Extractor Mode) */}
          {activeMode === 'dwg-extractor' && extractedBOQData && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden space-y-4 p-5 animate-in fade-in duration-200">
              {/* Header Info & Mapping Action */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-800">
                      {extractedBOQData.package || 'ELV Package'}
                    </span>
                    <span className="text-slate-400 text-xs">•</span>
                    <span className="font-mono text-xs font-bold text-slate-600">
                      DWG No: {extractedBOQData.drawingNumber || 'RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201'}
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-slate-900 mt-1">
                    {extractedBOQData.projectName || 'Royal Rosewood Resort - 1 Bedroom Beach Villa'}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Client: {extractedBOQData.clientName || 'Estithmar Holding / UCC'} | Sector: {extractedBOQData.sector || 'Hospitality'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {injectedSuccess ? (
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-2 bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Mapped into Master BOQ!</span>
                      </span>
                      {onNavigateTab && (
                        <button
                          onClick={() => {
                            onClose();
                            onNavigateTab('procurement', 'boq');
                          }}
                          className="px-3 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition cursor-pointer flex items-center gap-1.5"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          <span>View in BOQ Table</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={handleInjectIntoMasterBOQ}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition flex items-center gap-2 cursor-pointer"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>⚡ Map & Inject into Master BOQ</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Detected Tags Badges */}
              {extractedBOQData.detectedTags && extractedBOQData.detectedTags.length > 0 && (
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Detected CAD Block & Device Tags:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {extractedBOQData.detectedTags.map((tag: string, idx: number) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-slate-100 text-slate-700 font-mono text-[11px] font-bold rounded-lg border border-slate-200"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Line Items Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                    <tr>
                      <th className="p-2.5 text-center w-10">#</th>
                      <th className="p-2.5">Tag / Code</th>
                      <th className="p-2.5">Category & Description</th>
                      <th className="p-2.5 text-center">Qty</th>
                      <th className="p-2.5 text-center">Unit</th>
                      <th className="p-2.5 text-right">Unit Rate (QAR)</th>
                      <th className="p-2.5 text-right">Total (QAR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    {extractedBOQData.items?.map((it: any, idx: number) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 text-center font-mono text-slate-400 text-[11px]">{idx + 1}</td>
                        <td className="p-2.5 font-mono text-[11px] font-bold text-indigo-700 whitespace-nowrap">
                          {it.tag || it.itemCode || `ITEM-${idx + 1}`}
                        </td>
                        <td className="p-2.5">
                          <span className="font-bold text-slate-900 block">{it.description}</span>
                          <span className="text-[10px] text-slate-500 font-normal">{it.category} • {it.specs}</span>
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold">{it.quantity}</td>
                        <td className="p-2.5 text-center text-slate-600">{it.unit}</td>
                        <td className="p-2.5 text-right font-mono font-semibold">
                          QAR {(it.unitMaterialCostQAR || it.unitRateQAR || 0).toLocaleString()}
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                          QAR {(it.totalCostQAR || it.totalPriceQAR || (it.quantity * (it.unitMaterialCostQAR || 0))).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Financial KPI Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Material Cost:</span>
                  <p className="text-sm font-extrabold font-mono text-slate-900">
                    QAR {(extractedBOQData.totalMaterialCost || 28400).toLocaleString()}
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Labour & Testing:</span>
                  <p className="text-sm font-extrabold font-mono text-slate-900">
                    QAR {(extractedBOQData.totalLabourCost || 8500).toLocaleString()}
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Overhead & Margin:</span>
                  <p className="text-sm font-extrabold font-mono text-slate-900">
                    {extractedBOQData.marginPercent || 15}% (QAR {(extractedBOQData.overheadCost || 4200).toLocaleString()})
                  </p>
                </div>

                <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-200">
                  <span className="text-[10px] font-extrabold text-indigo-700 uppercase">Total BOQ Value:</span>
                  <p className="text-base font-black font-mono text-indigo-950">
                    QAR {(extractedBOQData.totalBOQValue || 44762).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Results Display Area */}
          {generatedResult && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden animate-in fade-in duration-200">
              <div className="bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-emerald-400" />
                  <span className="font-extrabold text-xs tracking-tight">Gemini Strategic Output</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy Output'}</span>
                  </button>
                </div>
              </div>

              <div className="p-5 text-xs text-slate-800 leading-relaxed space-y-3 prose-xs max-w-none [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_strong]:text-slate-950 [&_table]:w-full [&_table]:border [&_table]:border-slate-200 [&_th]:bg-slate-100 [&_th]:p-2 [&_td]:p-2 [&_td]:border-t [&_td]:border-slate-200">
                <ReactMarkdown>{generatedResult}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
