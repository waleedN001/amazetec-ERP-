import React, { useState } from 'react';
import {
  Scale,
  CheckCircle2,
  AlertCircle,
  Clock,
  DollarSign,
  FileCheck,
  ShieldCheck,
  Building2,
  FileText,
  Printer,
  X,
  ArrowRight,
  Sparkles,
  BadgeCheck,
  Eye,
  AlertTriangle,
} from 'lucide-react';
import { InvoiceReconciliationRecord } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';

interface Invoice3WayReconciliationViewProps {
  reconciliations: InvoiceReconciliationRecord[];
  onUpdateReconciliations: (data: InvoiceReconciliationRecord[]) => void;
  onOpenQuickAdd: () => void;
}

export const Invoice3WayReconciliationView: React.FC<Invoice3WayReconciliationViewProps> = ({
  reconciliations,
  onUpdateReconciliations,
  onOpenQuickAdd,
}) => {
  const [selectedRecon, setSelectedRecon] = useState<InvoiceReconciliationRecord | null>(null);
  const [isInspectorOpen, setIsInspectorOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  const reconColumns: ColumnDef[] = [
    { key: 'reconciliationId', label: 'Match ID', type: 'readonly' },
    { key: 'invoiceNumber', label: 'Invoice #', type: 'text' },
    { key: 'poNumber', label: 'PO Ref', type: 'text' },
    { key: 'supplier', label: 'Supplier / Vendor', type: 'text' },
    { key: 'deliveryAdviceNo', label: 'Delivery Note (DA)', type: 'text' },
    { key: 'grnNo', label: 'GRN No.', type: 'text' },
    { key: 'poAmountQAR', label: 'PO Amount', type: 'currency' },
    { key: 'grnReceivedAmountQAR', label: 'GRN Value', type: 'currency' },
    { key: 'invoiceAmountQAR', label: 'Invoice Amount', type: 'currency' },
    {
      key: 'varianceAmountQAR',
      label: 'Variance (QAR)',
      type: 'currency',
      isFormula: true,
      formulaLabel: '=Invoice - PO',
    },
    {
      key: 'matchStatus',
      label: '3-Way Match Status',
      type: 'select',
      options: [
        '3-Way Matched (100% OK)',
        'Price Discrepancy',
        'Quantity Mismatch',
        'Pending GRN',
        'Pending Approval',
      ],
    },
    { key: 'qaQcPassed', label: 'QA/QC OK', type: 'select', options: ['Yes', 'No'] },
    {
      key: 'financeReleaseStatus',
      label: 'Finance Release',
      type: 'select',
      options: ['Approved for Payment', 'Payment On Hold', 'Paid', 'Under Audit'],
    },
    { key: 'reviewedBy', label: 'Audited By', type: 'text' },
  ];

  const handleUpdate = (updated: InvoiceReconciliationRecord[]) => {
    const recalculated = updated.map((row) => {
      const inv = Number(row.invoiceAmountQAR) || 0;
      const po = Number(row.poAmountQAR) || 0;
      const grn = Number(row.grnReceivedAmountQAR) || 0;
      const variance = inv - po;
      let status = row.matchStatus;

      if (variance === 0 && inv === grn && row.qaQcPassed === 'Yes') {
        status = '3-Way Matched (100% OK)';
      } else if (variance !== 0) {
        status = 'Price Discrepancy';
      } else if (inv !== grn && grn > 0) {
        status = 'Quantity Mismatch';
      }

      return {
        ...row,
        varianceAmountQAR: variance,
        matchStatus: status,
      };
    });
    onUpdateReconciliations(recalculated);
  };

  const handle1ClickApproveRelease = (reconId: string) => {
    const updated = reconciliations.map((r) => {
      if (r.reconciliationId === reconId) {
        return {
          ...r,
          financeReleaseStatus: 'Approved for Payment' as const,
          qaQcPassed: 'Yes' as const,
          matchStatus: '3-Way Matched (100% OK)' as const,
          reviewedBy: 'Eng. Waleed (Chief Procurement Officer)',
        };
      }
      return r;
    });
    onUpdateReconciliations(updated);
    setNotification(`Authorized 3-Way Match ${reconId} for Immediate Finance Disbursement.`);
    setTimeout(() => setNotification(null), 4000);
    if (selectedRecon?.reconciliationId === reconId) {
      setSelectedRecon((prev) => (prev ? { ...prev, financeReleaseStatus: 'Approved for Payment' } : null));
    }
  };

  const totalInvoiceSum = reconciliations.reduce((acc, r) => acc + (Number(r.invoiceAmountQAR) || 0), 0);
  const matchedSum = reconciliations
    .filter((r) => r.matchStatus === '3-Way Matched (100% OK)')
    .reduce((acc, r) => acc + (Number(r.invoiceAmountQAR) || 0), 0);
  const matchedCount = reconciliations.filter((r) => r.matchStatus === '3-Way Matched (100% OK)').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white p-5 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-purple-900/40">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-purple-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-purple-600/30">
            <Scale className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base tracking-tight text-white">
                3-Way Reconciliation Audit Engine (PO ⟷ GRN ⟷ Supplier Invoice)
              </h3>
              <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-2xs px-2 py-0.5 rounded-full font-semibold">
                Zero Variance Policy
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Audit and reconcile Purchase Orders with Goods Receipt Notes (GRN) and Vendor Invoices before financial disbursement.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl font-bold">
            {matchedCount} of {reconciliations.length} Matched (100% OK)
          </span>
          <span className="px-3 py-1.5 bg-white/10 text-slate-200 border border-white/20 rounded-xl font-mono font-bold">
            QAR {matchedSum.toLocaleString()} Approved
          </span>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-2.5 text-xs text-emerald-800 font-semibold animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Key Metric Highlights & Quick Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reconciliations.slice(0, 3).map((recon) => {
          const isMatched = recon.matchStatus === '3-Way Matched (100% OK)';
          const isApproved = recon.financeReleaseStatus === 'Approved for Payment' || recon.financeReleaseStatus === 'Paid';

          return (
            <div
              key={recon.reconciliationId}
              className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs hover:shadow-md transition space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-extrabold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-lg border border-purple-100">
                    {recon.reconciliationId}
                  </span>
                  <span
                    className={`text-2xs font-bold px-2 py-0.5 rounded-full ${
                      isMatched
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {recon.matchStatus}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{recon.supplier}</h4>
                  <div className="flex items-center justify-between text-2xs text-slate-500">
                    <span>PO Ref: <strong className="font-mono text-slate-700">{recon.poNumber}</strong></span>
                    <span>GRN: <strong className="font-mono text-slate-700">{recon.grnNo}</strong></span>
                  </div>
                </div>

                <div className="mt-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 space-y-1 text-2xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">PO Value:</span>
                    <span className="font-mono font-semibold">QAR {Number(recon.poAmountQAR).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Invoice:</span>
                    <span className="font-mono font-semibold text-slate-900">QAR {Number(recon.invoiceAmountQAR).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-200">
                    <span className="text-slate-500 font-bold">Variance:</span>
                    <span className={`font-mono font-black ${recon.varianceAmountQAR === 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                      QAR {Number(recon.varianceAmountQAR).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    setSelectedRecon(recon);
                    setIsInspectorOpen(true);
                  }}
                  className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3 h-3 text-slate-500" />
                  <span>Inspect Triad</span>
                </button>
                {!isApproved ? (
                  <button
                    onClick={() => handle1ClickApproveRelease(recon.reconciliationId)}
                    className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Approve Payment</span>
                  </button>
                ) : (
                  <span className="flex-1 py-1.5 px-2 bg-emerald-50 text-emerald-700 text-2xs font-bold rounded-lg border border-emerald-200 flex items-center justify-center gap-1">
                    <BadgeCheck className="w-3 h-3 text-emerald-600" />
                    <span>Released</span>
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Editable Table */}
      <EditableTable
        title="3-Way Reconciliation Audit Register"
        subtitle="Automatic validation of PO Amount = GRN Quantity Value = Supplier Invoice Amount"
        columns={reconColumns}
        data={reconciliations}
        onUpdateData={handleUpdate}
        onAddRow={onOpenQuickAdd}
        badge="Table 2D"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />

      {/* ========================================================================= */}
      {/* 3-WAY MATCHING INSPECTOR MODAL (SIDE-BY-SIDE PO, GRN & INVOICE) */}
      {/* ========================================================================= */}
      {isInspectorOpen && selectedRecon && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-300 my-auto flex flex-col">
            {/* Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl shrink-0">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-purple-400" />
                <span className="font-bold text-sm">
                  3-Way Audit Triad Inspector — {selectedRecon.reconciliationId}
                </span>
              </div>
              <button
                onClick={() => setIsInspectorOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Triad Visual Pillars */}
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Pillar 1: Purchase Order */}
                <div className="bg-indigo-50/60 border border-indigo-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-2xs font-extrabold uppercase tracking-wider text-indigo-800">1. Purchase Order</span>
                    <span className="text-xs font-mono font-black text-indigo-700">{selectedRecon.poNumber}</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="text-slate-500 text-2xs">Authorized Commitment</div>
                    <div className="text-lg font-mono font-black text-slate-900">
                      QAR {Number(selectedRecon.poAmountQAR).toLocaleString()}
                    </div>
                    <p className="text-2xs text-slate-600">Vendor: {selectedRecon.supplier}</p>
                  </div>
                </div>

                {/* Pillar 2: Goods Receipt Note (GRN) */}
                <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-2xs font-extrabold uppercase tracking-wider text-emerald-800">2. Site GRN & DA</span>
                    <span className="text-xs font-mono font-black text-emerald-700">{selectedRecon.grnNo}</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="text-slate-500 text-2xs">Physically Verified on Site</div>
                    <div className="text-lg font-mono font-black text-slate-900">
                      QAR {Number(selectedRecon.grnReceivedAmountQAR).toLocaleString()}
                    </div>
                    <p className="text-2xs text-slate-600">Delivery Advice: {selectedRecon.deliveryAdviceNo}</p>
                    <div className="flex items-center gap-1 text-2xs font-bold text-emerald-700">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>QA/QC Inspected: {selectedRecon.qaQcPassed}</span>
                    </div>
                  </div>
                </div>

                {/* Pillar 3: Supplier Invoice */}
                <div className="bg-purple-50/60 border border-purple-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-2xs font-extrabold uppercase tracking-wider text-purple-800">3. Vendor Invoice</span>
                    <span className="text-xs font-mono font-black text-purple-700">{selectedRecon.invoiceNumber}</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="text-slate-500 text-2xs">Commercial Claim Amount</div>
                    <div className="text-lg font-mono font-black text-slate-900">
                      QAR {Number(selectedRecon.invoiceAmountQAR).toLocaleString()}
                    </div>
                    <p className="text-2xs text-slate-600">Status: {selectedRecon.financeReleaseStatus}</p>
                  </div>
                </div>
              </div>

              {/* Variance Audit Verdict */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Reconciliation Verdict</div>
                  <div className="flex items-center gap-2 mt-1">
                    {selectedRecon.varianceAmountQAR === 0 ? (
                      <span className="flex items-center gap-1.5 text-sm font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-xl">
                        <BadgeCheck className="w-4 h-4 text-emerald-600" />
                        Zero Discrepancy (100% Validated Match)
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-sm font-bold text-rose-700 bg-rose-100 px-3 py-1 rounded-xl">
                        <AlertTriangle className="w-4 h-4 text-rose-600" />
                        Discrepancy Detected: QAR {Number(selectedRecon.varianceAmountQAR).toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => window.print()}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Audit Certificate</span>
                  </button>
                  {selectedRecon.financeReleaseStatus !== 'Approved for Payment' && selectedRecon.financeReleaseStatus !== 'Paid' && (
                    <button
                      onClick={() => handle1ClickApproveRelease(selectedRecon.reconciliationId)}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-md"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Release for Payment</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
