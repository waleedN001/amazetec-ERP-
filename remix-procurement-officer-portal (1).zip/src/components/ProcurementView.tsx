import React, { useState, useMemo } from 'react';
import { EditableTable, ColumnDef } from './EditableTable';
import { PriceHistoryAnalytics } from './PriceHistoryAnalytics';
import { ProductCatalogView } from './ProductCatalogView';
import { OfficialQuotationView, sampleOfficialQuotationData } from './OfficialQuotationView';
import { VendorQuotationMatrixView } from './VendorQuotationMatrixView';
import { ProcurementKPIDashboard } from './ProcurementKPIDashboard';
import { PurchaseRequisitionsView } from './PurchaseRequisitionsView';
import { MaterialSubmittalsView } from './MaterialSubmittalsView';
import { PurchaseOrdersView } from './PurchaseOrdersView';
import { LogisticsCustomsView } from './LogisticsCustomsView';
import { Invoice3WayReconciliationView } from './Invoice3WayReconciliationView';
import { SupplierAVLView } from './SupplierAVLView';
import { SCMPipelineView } from './SCMPipelineView';
import {
  FileText,
  X,
  LayoutDashboard,
  ClipboardList,
  FileCheck2,
  Tags,
  Scale,
  FileCheck,
  Truck,
  Building2,
  History,
  MessageSquareText,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  Workflow,
} from 'lucide-react';
import {
  BOQRecord,
  QuotationResult,
  SupplierRecord,
  PriceHistoryRecord,
  ProcurementFollowUp,
  ProcurementRevision,
  DropdownMaster,
  SecurityProductCatalogItem,
  PurchaseRequisition,
  MaterialSubmittal,
  PurchaseOrder,
  LogisticsShipment,
  InvoiceReconciliationRecord,
  ProcurementSubModule,
} from '../types';

interface ProcurementViewProps {
  boqs: BOQRecord[];
  quotations: QuotationResult[];
  suppliers: SupplierRecord[];
  priceHistory: PriceHistoryRecord[];
  followUps: ProcurementFollowUp[];
  revisions: ProcurementRevision[];
  securityCatalog: SecurityProductCatalogItem[];
  purchaseRequisitions: PurchaseRequisition[];
  materialSubmittals: MaterialSubmittal[];
  purchaseOrders: PurchaseOrder[];
  shipments: LogisticsShipment[];
  reconciliations: InvoiceReconciliationRecord[];
  dropdowns: DropdownMaster[];
  activeSubModule?: ProcurementSubModule;
  onSubModuleChange?: (sub: ProcurementSubModule) => void;
  onUpdateBOQs: (data: BOQRecord[]) => void;
  onUpdateQuotations: (data: QuotationResult[]) => void;
  onUpdateSuppliers: (data: SupplierRecord[]) => void;
  onUpdatePriceHistory: (data: PriceHistoryRecord[]) => void;
  onUpdateFollowUps: (data: ProcurementFollowUp[]) => void;
  onUpdateRevisions: (data: ProcurementRevision[]) => void;
  onUpdateSecurityCatalog: (data: SecurityProductCatalogItem[]) => void;
  onUpdatePurchaseRequisitions: (data: PurchaseRequisition[]) => void;
  onUpdateMaterialSubmittals: (data: MaterialSubmittal[]) => void;
  onUpdatePurchaseOrders: (data: PurchaseOrder[]) => void;
  onUpdateShipments: (data: LogisticsShipment[]) => void;
  onUpdateReconciliations: (data: InvoiceReconciliationRecord[]) => void;
  onOpenQuickAdd: () => void;
  onOpenGeminiAnalysis?: (boqId?: string) => void;
  onOpenGeminiChat?: (context?: any) => void;
}

export const ProcurementView: React.FC<ProcurementViewProps> = ({
  boqs,
  quotations,
  suppliers,
  priceHistory,
  followUps,
  revisions,
  securityCatalog,
  purchaseRequisitions,
  materialSubmittals,
  purchaseOrders,
  shipments,
  reconciliations,
  dropdowns,
  activeSubModule = 'scm_pipeline',
  onSubModuleChange,
  onUpdateBOQs,
  onUpdateQuotations,
  onUpdateSuppliers,
  onUpdatePriceHistory,
  onUpdateFollowUps,
  onUpdateRevisions,
  onUpdateSecurityCatalog,
  onUpdatePurchaseRequisitions,
  onUpdateMaterialSubmittals,
  onUpdatePurchaseOrders,
  onUpdateShipments,
  onUpdateReconciliations,
  onOpenQuickAdd,
  onOpenGeminiAnalysis,
  onOpenGeminiChat,
}) => {
  const [priceFilter, setPriceFilter] = useState<string>('all');
  const [priceSearch, setPriceSearch] = useState<string>('');
  const [priceComponentClass, setPriceComponentClass] = useState<string>('All');
  const [priceLocation, setPriceLocation] = useState<string>('All');
  const [priceMoi, setPriceMoi] = useState<string>('All');
  const [priceProject, setPriceProject] = useState<string>('All');
  const [priceQuotation, setPriceQuotation] = useState<string>('All');
  const [priceBrand, setPriceBrand] = useState<string>('All');
  const [priceRevision, setPriceRevision] = useState<string>('All');
  const [isOfficialQuoteOpen, setIsOfficialQuoteOpen] = useState<boolean>(false);

  const filteredPriceHistory = useMemo(() => {
    return priceHistory.filter((item) => {
      // Variance Filter
      if (priceFilter === 'Decrease' && item.changeType !== 'Decrease') return false;
      if (priceFilter === 'Increase' && item.changeType !== 'Increase') return false;
      if (priceFilter === 'moi' && item.moiApproved !== 'Yes') return false;

      // Active vs Passive Component Type Filter
      if (priceComponentClass !== 'All') {
        if (priceComponentClass === 'Active' && item.componentClass === 'Passive') return false;
        if (priceComponentClass === 'Passive' && item.componentClass !== 'Passive') return false;
      }

      // Location Filter
      if (priceLocation !== 'All' && item.cityLocation && item.cityLocation !== priceLocation && item.cityLocation !== 'All Qatar') {
        return false;
      }

      // Project Filter
      if (priceProject !== 'All' && item.projectName && item.projectName !== priceProject) {
        return false;
      }

      // Quotation Filter
      if (priceQuotation !== 'All' && item.quotationName && item.quotationName !== priceQuotation) {
        return false;
      }

      // Brand Filter
      if (priceBrand !== 'All' && item.brand && item.brand !== priceBrand) {
        return false;
      }

      // Revision Filter
      if (priceRevision !== 'All' && item.revisionNumber && item.revisionNumber !== priceRevision) {
        return false;
      }

      // MOI Approval Filter
      if (priceMoi === 'Yes' && item.moiApproved !== 'Yes') return false;
      if (priceMoi === 'No' && item.moiApproved === 'Yes') return false;

      // Search Query (Brand, Model, Specification, Product Name, Supplier, Notes, Reason)
      if (priceSearch.trim()) {
        const q = priceSearch.toLowerCase();
        const matchName = item.productName?.toLowerCase().includes(q);
        const matchCode = item.productCode?.toLowerCase().includes(q);
        const matchSupplier = item.supplier?.toLowerCase().includes(q);
        const matchReason = item.reason?.toLowerCase().includes(q);
        const matchBrand = item.brand?.toLowerCase().includes(q);
        const matchModel = item.model?.toLowerCase().includes(q);
        const matchNotes = item.notes?.toLowerCase().includes(q);
        return matchName || matchCode || matchSupplier || matchReason || matchBrand || matchModel || matchNotes;
      }
      return true;
    });
  }, [priceHistory, priceFilter, priceSearch, priceComponentClass, priceLocation, priceMoi, priceProject, priceQuotation, priceBrand, priceRevision]);

  const getDropdownOptions = (catName: string) => {
    const found = dropdowns.find((d) => d.categoryName.toLowerCase().includes(catName.toLowerCase()));
    return found ? found.options : [];
  };

  // Master BOQ List Columns
  const boqMasterCols: ColumnDef[] = [
    { key: 'boqId', label: 'BOQ ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'clientName', label: 'Client', type: 'text' },
    { key: 'category', label: 'Category', type: 'select', options: getDropdownOptions('Categories') },
    { key: 'totalItems', label: 'Items Count', type: 'number' },
    { key: 'materialCost', label: 'Material Cost', type: 'currency' },
    { key: 'labourCost', label: 'Labour Cost', type: 'currency' },
    { key: 'overheadCost', label: 'Overhead Cost', type: 'currency' },
    { key: 'boqValue', label: 'BOQ Total Value', type: 'currency' },
    { key: 'marginPercent', label: 'Margin (%)', type: 'percent' },
    { key: 'status', label: 'Status', type: 'select', options: ['Draft', 'In Progress', 'Under Review', 'Approved', 'Rejected', 'On Hold'] },
  ];

  // Supplier Database Columns
  const supplierCols: ColumnDef[] = [
    { key: 'code', label: 'Code', type: 'readonly' },
    { key: 'name', label: 'Supplier Name', type: 'text' },
    { key: 'country', label: 'Country', type: 'text' },
    { key: 'contactPerson', label: 'Contact', type: 'text' },
    { key: 'phone', label: 'Phone', type: 'text' },
    { key: 'email', label: 'Email', type: 'text' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'select', options: ['Yes', 'No', 'Pending'] },
    { key: 'products', label: 'Products', type: 'text' },
    { key: 'creditTerms', label: 'Credit Terms', type: 'text' },
    { key: 'paymentTerms', label: 'Payment Terms', type: 'select', options: getDropdownOptions('Payment Terms') },
    { key: 'deliveryLeadTime', label: 'Lead Time', type: 'text' },
    { key: 'rating', label: 'Rating (1-5)', type: 'number' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive', 'Onboarding', 'Suspended', 'Pending Approval'] },
  ];

  // Price History Columns (Old vs New Auto Calculation)
  const priceCols: ColumnDef[] = [
    { key: 'productCode', label: 'Product Code', type: 'readonly' },
    { key: 'productName', label: 'Product Name', type: 'text' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model No.', type: 'text' },
    { key: 'componentClass', label: 'Type', type: 'select', options: ['Active', 'Passive'] },
    { key: 'cityLocation', label: 'Location', type: 'select', options: ['All', 'Doha', 'Lusail', 'Al Rayyan', 'Al Wakrah', 'Al Khor', 'Ras Laffan', 'All Qatar'] },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'oldPrice', label: 'Old Price', type: 'currency' },
    { key: 'newPrice', label: 'New Price', type: 'currency' },
    { key: 'priceChange', label: 'Price Change', type: 'currency', isFormula: true, formulaLabel: '=New - Old' },
    { key: 'percentChange', label: '% Change', type: 'percent', isFormula: true, formulaLabel: '=((New-Old)/Old)*100' },
    { key: 'effectiveDate', label: 'Effective From', type: 'date' },
    { key: 'validDuration', label: 'Valid Duration (e.g. 3 Weeks)', type: 'text' },
    { key: 'reason', label: 'Reason', type: 'text' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'select', options: ['Yes', 'No'] },
  ];

  // Follow-ups Columns
  const followUpCols: ColumnDef[] = [
    { key: 'id', label: 'F-ID', type: 'readonly' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'subject', label: 'Subject', type: 'text' },
    { key: 'dateCreated', label: 'Created Date', type: 'date' },
    { key: 'currentStatus', label: 'Status', type: 'select', options: ['In Progress', 'Completed', 'Pending', 'On Hold'] },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'priority', label: 'Priority', type: 'select', options: ['High', 'Medium', 'Low'] },
    { key: 'resolution', label: 'Resolution', type: 'text' },
  ];

  // Revisions Columns
  const revisionCols: ColumnDef[] = [
    { key: 'revisionId', label: 'Rev ID', type: 'readonly' },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'revisionDate', label: 'Rev Date', type: 'date' },
    { key: 'revisionNo', label: 'Rev #', type: 'text' },
    { key: 'oldValue', label: 'Old Value', type: 'currency' },
    { key: 'newValue', label: 'New Value', type: 'currency' },
    { key: 'changeReason', label: 'Change Reason', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Approved', 'Pending', 'Rejected'] },
  ];

  const handlePriceUpdate = (updatedPriceData: PriceHistoryRecord[]) => {
    const recalculated = updatedPriceData.map((row) => {
      const oldP = Number(row.oldPrice) || 0;
      const newP = Number(row.newPrice) || 0;
      const diff = newP - oldP;
      const pct = oldP > 0 ? (diff / oldP) * 100 : 0;
      let type: 'Decrease' | 'Increase' | 'Unchanged' = 'Unchanged';
      if (diff < 0) type = 'Decrease';
      if (diff > 0) type = 'Increase';

      return {
        ...row,
        priceChange: diff,
        percentChange: Number(pct.toFixed(1)),
        changeType: type,
      };
    });
    onUpdatePriceHistory(recalculated);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 0. Automated SCM & Quotation Pipeline */}
      {activeSubModule === 'scm_pipeline' && (
        <SCMPipelineView
          securityCatalog={securityCatalog}
          onUpdateSecurityCatalog={onUpdateSecurityCatalog}
          onOpenQuickAdd={onOpenQuickAdd}
          onNavigateToSubModule={(sub) => onSubModuleChange?.(sub as any)}
        />
      )}

      {/* 1. KPI Executive Scorecard */}
      {activeSubModule === 'kpi' && (
        <ProcurementKPIDashboard
          purchaseOrders={purchaseOrders}
          shipments={shipments}
          reconciliations={reconciliations}
          boqs={boqs}
          quotations={quotations}
          onNavigateToSubModule={(sub) => onSubModuleChange?.(sub)}
          onOpenGeminiChat={onOpenGeminiChat}
        />
      )}

      {/* 1. Site Purchase Requisitions & Master BOQ Costing */}
      {activeSubModule === 'pr_boq' && (
        <div className="space-y-6">
          <PurchaseRequisitionsView
            requisitions={purchaseRequisitions}
            onUpdateRequisitions={onUpdatePurchaseRequisitions}
            onOpenQuickAdd={onOpenQuickAdd}
          />

          <EditableTable
            title="Master BOQ Cost Breakdowns"
            subtitle="Detailed cost breakdown: Material Cost + Labour Cost + Overhead + Target Margin %"
            columns={boqMasterCols}
            data={boqs}
            onUpdateData={onUpdateBOQs}
            onAddRow={onOpenQuickAdd}
            badge="Table 1"
          />
        </div>
      )}

      {/* 2. Submittals, PO & Vendors */}
      {/* Moved to Inventory Module */}

      {/* 3. Security Products Master Catalog */}
      {activeSubModule === 'catalog' && (
        <ProductCatalogView
          catalog={securityCatalog}
          onUpdateCatalog={onUpdateSecurityCatalog}
          onOpenQuickAdd={onOpenQuickAdd}
        />
      )}

      {/* 4. Vendor Quotations & Comparative Matrix */}
      {activeSubModule === 'quote' && (
        <VendorQuotationMatrixView
          quotations={quotations}
          boqs={boqs}
          suppliers={suppliers}
          onUpdateQuotations={onUpdateQuotations}
          onOpenQuickAdd={onOpenQuickAdd}
          onOpenOfficialQuote={() => setIsOfficialQuoteOpen(true)}
          onOpenGeminiAnalysis={onOpenGeminiAnalysis}
          onOpenGeminiChat={onOpenGeminiChat}
        />
      )}

      {/* 4. Purchase Orders & Logistics */}
      {activeSubModule === 'po_logistics' && (
        <div className="space-y-8">
          <PurchaseOrdersView
            purchaseOrders={purchaseOrders}
            suppliers={suppliers}
            boqs={boqs}
            onUpdatePurchaseOrders={onUpdatePurchaseOrders}
            onOpenQuickAdd={onOpenQuickAdd}
          />
          <LogisticsCustomsView
            shipments={shipments}
            onUpdateShipments={onUpdateShipments}
            onOpenQuickAdd={onOpenQuickAdd}
          />
        </div>
      )}

      {/* 8. Supplier Database (AVL) */}
      {activeSubModule === 'supplier' && (
        <SupplierAVLView
          suppliers={suppliers}
          boqs={boqs}
          onUpdateSuppliers={onUpdateSuppliers}
          onOpenQuickAdd={onOpenQuickAdd}
          dropdownOptions={getDropdownOptions('Payment Terms')}
        />
      )}

      {/* 9. Price History Logs */}
      {activeSubModule === 'price' && (
        <div className="space-y-4">
          <PriceHistoryAnalytics
            priceHistory={priceHistory}
            suppliers={suppliers}
            onOpenQuickAdd={onOpenQuickAdd}
            selectedFilter={priceFilter}
            onFilterChange={setPriceFilter}
            searchQuery={priceSearch}
            onSearchChange={setPriceSearch}
            componentClass={priceComponentClass}
            onComponentClassChange={setPriceComponentClass}
            location={priceLocation}
            onLocationChange={setPriceLocation}
            moi={priceMoi}
            onMoiChange={setPriceMoi}
            project={priceProject}
            onProjectChange={setPriceProject}
            quotation={priceQuotation}
            onQuotationChange={setPriceQuotation}
            brand={priceBrand}
            onBrandChange={setPriceBrand}
            revision={priceRevision}
            onRevisionChange={setPriceRevision}
          />

          <EditableTable
            title="Price History & Variance Logs (Latest vs Old)"
            subtitle="Automated variance calculation: Price Change = New - Old, % Change = ((New - Old) / Old) * 100"
            columns={priceCols}
            data={filteredPriceHistory}
            onUpdateData={handlePriceUpdate}
            onAddRow={onOpenQuickAdd}
            badge="Table 4"
            badgeColor="bg-rose-50 text-rose-700 border-rose-200"
            enableSelection={false}
          />
        </div>
      )}

      {/* 10. Follow-ups (F1...Fn) & Revisions (R1...Rn) */}
      {activeSubModule === 'followup' && (
        <div className="space-y-6">
          <EditableTable
            title="Procurement Follow-ups Log (F1...Fn)"
            subtitle="Vendor negotiations, bulk discounts, quote requests and issue resolution logs"
            columns={followUpCols}
            data={followUps}
            onUpdateData={onUpdateFollowUps}
            badge="Table 5A"
            badgeColor="bg-amber-50 text-amber-700 border-amber-200"
          />

          <EditableTable
            title="BOQ & Scope Revisions Log (R1...Rn)"
            subtitle="Price changes and scope adjustments (e.g. Ezdan Phase 1 additional camera revisions)"
            columns={revisionCols}
            data={revisions}
            onUpdateData={onUpdateRevisions}
            badge="Table 5B"
            badgeColor="bg-amber-50 text-amber-700 border-amber-200"
          />
        </div>
      )}

      {/* OFFICIAL QUOTATION SHEET MODAL */}
      {isOfficialQuoteOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 md:p-6 overflow-y-auto">
          <div className="bg-white w-full max-w-7xl rounded-2xl shadow-2xl overflow-hidden my-auto relative max-h-[95vh] flex flex-col">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-sm tracking-wide">
                  Qatar Official BOQ Quotation Document
                </h3>
              </div>
              <button
                onClick={() => setIsOfficialQuoteOpen(false)}
                className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-2 md:p-4 bg-slate-100">
              <OfficialQuotationView
                onClose={() => setIsOfficialQuoteOpen(false)}
                initialItems={sampleOfficialQuotationData}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
