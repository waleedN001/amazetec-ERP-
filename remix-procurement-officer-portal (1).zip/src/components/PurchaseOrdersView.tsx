import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Download,
  Plus,
  CheckCircle2,
  Clock,
  Building2,
  MapPin,
  Calendar,
  DollarSign,
  AlertCircle,
  X,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Scale,
  QrCode,
  BadgeCheck,
  Send,
  Eye,
} from 'lucide-react';
import { PurchaseOrder, SupplierRecord, BOQRecord } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';
import { useAppData } from '../context/useAppData';

interface PurchaseOrdersViewProps {
  purchaseOrders: PurchaseOrder[];
  suppliers: SupplierRecord[];
  boqs: BOQRecord[];
  onUpdatePurchaseOrders: (orders: PurchaseOrder[]) => void;
  onOpenQuickAdd: () => void;
}

export const PurchaseOrdersView: React.FC<PurchaseOrdersViewProps> = ({
  purchaseOrders,
  suppliers,
  boqs,
  onUpdatePurchaseOrders,
  onOpenQuickAdd,
}) => {
  const { createReconciliationForPO, setActiveTab, setProcurementSubModule } = useAppData();
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(purchaseOrders[0] || null);
  const [isPoModalOpen, setIsPoModalOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  const poColumns: ColumnDef[] = [
    { key: 'poNumber', label: 'PO Number', type: 'readonly' },
    { key: 'prId', label: 'PR Ref', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'supplier', label: 'Supplier / Vendor', type: 'text' },
    { key: 'totalAmountQAR', label: 'Total Amount (QAR)', type: 'currency' },
    { key: 'paymentTerms', label: 'Payment Terms', type: 'text' },
    { key: 'issueDate', label: 'Issue Date', type: 'date' },
    { key: 'deliveryDueDate', label: 'Delivery Due', type: 'date' },
    { key: 'turnaroundHours', label: 'Turnaround (h)', type: 'number' },
    { key: 'materialSubmittalApproved', label: 'Submittal OK', type: 'select', options: ['Yes', 'No'] },
    { key: 'budgetAllocated', label: 'Budget OK', type: 'select', options: ['Yes', 'No'] },
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: ['Draft', 'Approved', 'Issued to Vendor', 'Partially Delivered', 'Delivered', 'Closed', 'Cancelled'],
    },
  ];

  const handleOpenPoDoc = (po: PurchaseOrder) => {
    setSelectedPO(po);
    setIsPoModalOpen(true);
  };

  const handlePrintPo = () => {
    window.print();
  };

  const handle1ClickReconciliation = (po: PurchaseOrder) => {
    const recon = createReconciliationForPO(po.poNumber);
    if (recon) {
      setNotification(`Created 3-Way Reconciliation ${recon.reconciliationId} for PO ${po.poNumber}`);
      setTimeout(() => setNotification(null), 4500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-indigo-900/40">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-indigo-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-indigo-600/30">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base tracking-tight text-white">
                Official Purchase Order (PO) Registry & Document Generator
              </h3>
              <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-2xs px-2 py-0.5 rounded-full font-semibold">
                SLA &lt; 48h
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Legally binding PO issuance adhering to Qatar commercial laws and MOI-SSD procurement compliance standards.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {purchaseOrders.length > 0 && (
            <button
              onClick={() => handleOpenPoDoc(purchaseOrders[0])}
              className="bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-2 cursor-pointer border border-indigo-500/30 shadow-xs"
            >
              <Eye className="w-4 h-4 text-indigo-300" />
              <span>Preview Official PO Doc</span>
            </button>
          )}
          <button
            onClick={onOpenQuickAdd}
            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Issue New PO</span>
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {notification && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2.5 text-xs text-emerald-800 font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{notification}</span>
          </div>
          <button
            onClick={() => {
              setActiveTab('procurement');
              setProcurementSubModule('po_logistics');
            }}
            className="text-xs font-bold text-emerald-700 hover:underline flex items-center gap-1"
          >
            <span>View Reconciliations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Quick Action PO Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {purchaseOrders.slice(0, 3).map((po) => (
          <div
            key={po.poNumber}
            className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs hover:shadow-md transition space-y-3 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100">
                  {po.poNumber}
                </span>
                <span
                  className={`text-2xs font-bold px-2 py-0.5 rounded-full ${
                    po.status === 'Issued to Vendor'
                      ? 'bg-blue-100 text-blue-800'
                      : po.status === 'Approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : po.status === 'Delivered'
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {po.status}
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{po.projectName}</h4>
              <p className="text-2xs text-slate-500 flex items-center gap-1 mt-0.5">
                <Building2 className="w-3 h-3 text-slate-400" />
                {po.supplier}
              </p>
              <div className="mt-3 flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500 text-2xs">Total Value:</span>
                <span className="font-extrabold text-emerald-700">
                  QAR {Number(po.totalAmountQAR).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                onClick={() => handleOpenPoDoc(po)}
                className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1"
              >
                <FileText className="w-3 h-3 text-slate-500" />
                <span>PO Document</span>
              </button>
              <button
                onClick={() => handle1ClickReconciliation(po)}
                title="1-Click: Create 3-Way Reconciliation with GRN and Invoice"
                className="flex-1 py-1.5 px-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer"
              >
                <Scale className="w-3 h-3 text-purple-600" />
                <span>3-Way Match</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* PO List Table */}
      <EditableTable
        title="Purchase Orders Master Registry"
        subtitle="Commercial PO commitments issued to authorized security distributors in Qatar"
        columns={poColumns}
        data={purchaseOrders}
        onUpdateData={onUpdatePurchaseOrders}
        onAddRow={onOpenQuickAdd}
        badge="Table 2B"
        badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
      />

      {/* ========================================================================= */}
      {/* OFFICIAL PURCHASE ORDER DOCUMENT PREVIEW MODAL (PRINT & PDF READY) */}
      {/* ========================================================================= */}
      {isPoModalOpen && selectedPO && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-300 my-auto flex flex-col">
            {/* Modal Actions Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl shrink-0 print:hidden">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <span className="font-bold text-sm">Official Commercial Purchase Order — {selectedPO.poNumber}</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrintPo}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5 shadow-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print / Save PDF</span>
                </button>
                <button
                  onClick={() => setIsPoModalOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Printable Body */}
            <div id="printable-po-document" className="p-8 sm:p-12 space-y-8 bg-white text-slate-900 font-sans">
              {/* Document Header & Company Branding */}
              <div className="flex flex-col sm:flex-row justify-between items-start gap-6 border-b-2 border-slate-900 pb-6">
                <div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black text-xl">
                      A
                    </div>
                    <div>
                      <h1 className="text-xl font-black tracking-tight text-slate-900">
                        AMAZETEC SECURITY & ELV SYSTEMS W.L.L.
                      </h1>
                      <p className="text-2xs text-slate-500 font-semibold uppercase tracking-wider">
                        Qatar Commercial Registration: CR-98214-01 | MOI-SSD Security License: SSD-QA-2021/88
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 text-xs text-slate-600 space-y-0.5">
                    <p>Building 42, Street 902, Zone 56, Salwa Road Industrial Area, Doha, Qatar</p>
                    <p>Tel: +974 4498 1234 | Email: procurement@amazetec.qa | Web: www.amazetec.qa</p>
                  </div>
                </div>

                <div className="sm:text-right bg-slate-50 p-4 rounded-2xl border border-slate-200 shrink-0">
                  <div className="text-xs font-bold uppercase tracking-wider text-indigo-700">Official Purchase Order</div>
                  <div className="text-xl font-mono font-black text-slate-900 mt-0.5">{selectedPO.poNumber}</div>
                  <div className="text-2xs text-slate-500 mt-1 font-medium">Issue Date: {selectedPO.issueDate}</div>
                  <div className="text-2xs text-slate-500 font-medium">Delivery Due: {selectedPO.deliveryDueDate}</div>
                </div>
              </div>

              {/* Vendor & Delivery Information Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-50/80 p-5 rounded-2xl border border-slate-200 text-xs">
                <div className="space-y-1">
                  <span className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Vendor / Supplier</span>
                  <p className="font-extrabold text-sm text-slate-900">{selectedPO.supplier}</p>
                  <p className="text-slate-600">Authorized Qatar Security Systems Distributor</p>
                  <p className="text-slate-600">Payment Terms: <strong className="text-slate-800">{selectedPO.paymentTerms}</strong></p>
                  <p className="text-slate-600">Reference PR: <strong className="text-indigo-600 font-mono">{selectedPO.prId}</strong></p>
                </div>

                <div className="space-y-1 sm:border-l sm:border-slate-200 sm:pl-6">
                  <span className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">Delivery & Site Destination</span>
                  <p className="font-bold text-slate-900">{selectedPO.projectName}</p>
                  <p className="text-slate-600">{selectedPO.deliveryLocation}</p>
                  <p className="text-slate-600">Site Contact: Eng. Tariq Al-Mansoor (+974 5512 8844)</p>
                  <div className="flex items-center gap-1 text-2xs text-emerald-700 font-semibold pt-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Material Submittal Approved: {selectedPO.materialSubmittalApproved}</span>
                  </div>
                </div>
              </div>

              {/* Line Items Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-900 text-white font-bold text-2xs uppercase tracking-wider">
                    <tr>
                      <th className="p-3">#</th>
                      <th className="p-3">Item Code & Specification Description</th>
                      <th className="p-3 text-center">Unit</th>
                      <th className="p-3 text-center">Qty</th>
                      <th className="p-3 text-right">Unit Price (QAR)</th>
                      <th className="p-3 text-right">Total Amount (QAR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    <tr>
                      <td className="p-3 font-mono text-slate-400">01</td>
                      <td className="p-3 font-semibold text-slate-900">
                        <div>{selectedPO.remarks || 'High-Resolution IP Security Equipment Package'}</div>
                        <div className="text-2xs text-slate-500 font-normal">
                          Compliance: Qatar MOI-SSD 2026 CCTV Standards, 120 Days Retention Support, CE/UL Certified
                        </div>
                      </td>
                      <td className="p-3 text-center text-slate-600">Package</td>
                      <td className="p-3 text-center font-bold">1</td>
                      <td className="p-3 text-right font-mono">
                        {Number(selectedPO.totalAmountQAR).toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-slate-900">
                        {Number(selectedPO.totalAmountQAR).toLocaleString()}
                      </td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-slate-50 font-bold border-t-2 border-slate-300">
                    <tr>
                      <td colSpan={4} className="p-3 text-right text-slate-600 text-2xs uppercase tracking-wider">
                        Subtotal Amount:
                      </td>
                      <td colSpan={2} className="p-3 text-right font-mono text-slate-900">
                        QAR {Number(selectedPO.totalAmountQAR).toLocaleString()}
                      </td>
                    </tr>
                    <tr>
                      <td colSpan={4} className="p-3 text-right text-slate-600 text-2xs uppercase tracking-wider">
                        Qatar Value Added Tax / Customs (0%):
                      </td>
                      <td colSpan={2} className="p-3 text-right font-mono text-slate-900">
                        QAR 0.00
                      </td>
                    </tr>
                    <tr className="bg-indigo-50 text-indigo-950 text-sm">
                      <td colSpan={4} className="p-4 text-right font-extrabold uppercase tracking-wider">
                        Grand Total Committed Value (QAR):
                      </td>
                      <td colSpan={2} className="p-4 text-right font-mono font-black text-emerald-800 text-base">
                        QAR {Number(selectedPO.totalAmountQAR).toLocaleString()}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Terms, Conditions & MOI Stamping */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-2xs text-slate-600 border-t border-slate-200 pt-6">
                <div className="sm:col-span-2 space-y-2">
                  <h5 className="font-bold text-slate-900 uppercase tracking-wider text-xs">
                    Standard Commercial Terms & Conditions
                  </h5>
                  <ul className="list-disc list-inside space-y-1 text-slate-600">
                    <li>Delivery must be accompanied by 3 original copies of Delivery Advice (DA) and Commercial Invoice.</li>
                    <li>All active security cameras and NVRs must carry minimum 24-month manufacturer warranty with local RMA.</li>
                    <li>Site acceptance is contingent on QA/QC inspection and MOI consultant sign-off on delivered serial numbers.</li>
                    <li>Late delivery penalty: 0.5% per calendar day of delay up to maximum 10% of PO total value.</li>
                  </ul>
                </div>

                {/* Digital Verification & Stamp */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col items-center justify-center text-center">
                  <div className="p-2 bg-white rounded-xl border border-slate-200 shadow-2xs mb-2">
                    <QrCode className="w-14 h-14 text-slate-800" />
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">PO Hash: {selectedPO.poNumber}-SEC-2026</span>
                  <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                    <BadgeCheck className="w-3.5 h-3.5" />
                    <span>Digitally Authorized & Verified</span>
                  </div>
                </div>
              </div>

              {/* Signatures & Authorizations */}
              <div className="grid grid-cols-2 gap-8 border-t border-slate-200 pt-8">
                <div className="space-y-6">
                  <div className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">
                    Prepared By: Procurement Department
                  </div>
                  <div className="h-10 border-b border-slate-300 font-serif italic text-slate-700 flex items-end">
                    Eng. Waleed - Lead Procurement Specialist
                  </div>
                  <div className="text-2xs text-slate-500">Amazetec Procurement Officer</div>
                </div>

                <div className="space-y-6">
                  <div className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">
                    Authorized Signatory: Managing Director / CFO
                  </div>
                  <div className="h-10 border-b border-slate-300 font-serif italic text-slate-700 flex items-end">
                    {selectedPO.authorizedBy || 'Board of Directors Approval'}
                  </div>
                  <div className="text-2xs text-slate-500">Commercial Signatory for Amazetec W.L.L.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
