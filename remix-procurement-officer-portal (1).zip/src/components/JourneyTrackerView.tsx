import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Building2,
  Car,
  FileText,
  Plus,
  Send,
  MessageSquare,
  Shield,
  ShieldCheck,
  CheckCircle2,
  Download,
  Upload,
  User,
  Activity,
  Briefcase,
  ChevronRight,
  Clock,
  ExternalLink,
  X,
  Bot,
  Calendar,
  DollarSign,
  MapPin,
  Check,
  AlertCircle,
  Users,
  Wrench,
  Mail,
  MessageCircle,
  CheckSquare,
  RefreshCw,
  Search,
  CheckCircle,
  ArrowRight,
  ClipboardList,
  Sparkles,
  Layers,
  Paperclip,
  Share2,
  Truck,
  Loader2,
  Maximize2,
  Minimize2,
  RotateCcw,
  Copy
} from 'lucide-react';
import { LeadRecord, ProjectOverview, WorkflowJourneyState, LeadChannelType, DispatchedRoleType, ProjectExecutionStep } from '../types';

interface JourneyTrackerViewProps {
  leads?: LeadRecord[];
  projects?: ProjectOverview[];
  onOpenQuickAdd?: () => void;
}

export const JourneyTrackerView: React.FC<JourneyTrackerViewProps> = ({
  leads = [],
  projects = [],
  onOpenQuickAdd,
}) => {
  // Main Navigation View: 'workflow' (6-Stage Process Journey), 'matrix' (Stakeholder Gate Matrix), 'vault' (Project Documents), 'notes' (Case Activity)
  const [activePortalTab, setActivePortalTab] = useState<'workflow' | 'matrix' | 'vault' | 'notes'>('workflow');

  // Multi-Client / Project Profiles Master List
  const [clientProfiles, setClientProfiles] = useState<WorkflowJourneyState[]>([
    {
      id: 'WF-2026-001',
      leadId: 'LEAD-001',
      projectId: 'PRJ-001',
      clientName: 'Al Rayyan Hotel & Towers W.L.L.',
      channel: 'LinkedIn (B2B)',
      leadStatus: 'Qualified',
      leadNotes: 'Enterprise hospitality inquiry for 128 Camera CCTV Upgrade & MOI SSD Licensing.',
      siteVisitStatus: 'Completed',
      dispatchedRoles: ['ELV Engineer', 'Technician (ET)', 'Technical Team (TT)'],
      certificationsChecked: ['MEA', 'MOI', 'Civil Defence'],
      siteRequirementsSummary: 'Surveyed 128 dome locations, control room rack space, 120-day SAN storage, and MEA/MOI standards.',
      boqCreated: true,
      boqTotalValue: 450000,
      supplierQuotesGathered: true,
      bpStatus: 'Sent via WhatsApp',
      bpRevisionNotes: 'Client requested 5% scope addition for gate barrier ANPR integration. BP updated.',
      poIssuedToSuppliers: true,
      clientAdvance50Received: true,
      supplierAdvance50Paid: true,
      projectPlanCreated: true,
      materialInspectedOnSite: true,
      currentExecutionStep: 'Installation',
      staffAllocated: {
        permanentStaffCount: 4,
        contractStaffCount: 6,
        dailyWageCount: 8,
      },
      amcActive: true,
      amcDurationMonths: 12,
      amcStartDate: '2026-12-01',
      amcEndDate: '2027-11-30',
      amcMaintenanceLogs: [
        {
          date: '2026-12-15',
          type: 'Fix',
          notes: 'Replaced dome camera bracket on Gate 3 after vehicle mirror impact. Tested video feed.',
          performedBy: 'Zain Tariq (PS ELV)',
        },
        {
          date: '2027-01-10',
          type: 'System Update',
          notes: 'Updated VMS Firmware v4.2 & applied latest security patch for MOI compliance.',
          performedBy: 'Ali Al-Mansoori (PM)',
        },
        {
          date: '2027-02-01',
          type: 'Repainting',
          notes: 'Outdoor junction box repainting & weatherproof sealant application.',
          performedBy: 'Contract Staff Team',
        },
      ],
    },
    {
      id: 'WF-2026-002',
      leadId: 'LEAD-002',
      projectId: 'PRJ-002',
      clientName: 'Lusail Marina Commercial Tower',
      channel: 'Referrals',
      leadStatus: 'Qualified',
      leadNotes: 'Referred by Katara Hospitality. Upgrade 64 PTZ cameras & 2 Gate Barriers.',
      siteVisitStatus: 'Completed',
      dispatchedRoles: ['ELV Engineer', 'Technical Team (TT)'],
      certificationsChecked: ['MOI', 'Civil Defence'],
      siteRequirementsSummary: 'Fiber backbone infrastructure and high-speed ANPR gate barriers required.',
      boqCreated: true,
      boqTotalValue: 320000,
      supplierQuotesGathered: true,
      bpStatus: 'Approved',
      poIssuedToSuppliers: true,
      clientAdvance50Received: true,
      supplierAdvance50Paid: true,
      projectPlanCreated: true,
      materialInspectedOnSite: true,
      currentExecutionStep: 'Testing & Commissioning',
      staffAllocated: {
        permanentStaffCount: 3,
        contractStaffCount: 4,
        dailyWageCount: 5,
      },
      amcActive: true,
      amcDurationMonths: 12,
      amcStartDate: '2026-10-01',
      amcEndDate: '2027-09-30',
      amcMaintenanceLogs: [
        {
          date: '2026-10-15',
          type: 'Inspection',
          notes: 'Initial post-handover 30-day health check. All 64 channels streaming seamlessly.',
          performedBy: 'Zain Tariq (PS ELV)',
        },
      ],
    },
    {
      id: 'WF-2026-003',
      leadId: 'LEAD-003',
      projectId: 'PRJ-003',
      clientName: 'Doha West Bay Medical Center',
      channel: 'Upwork / Fiverr',
      leadStatus: 'Acquired',
      leadNotes: 'International healthcare group requiring access control & face recognition terminals.',
      siteVisitStatus: 'Scheduled',
      dispatchedRoles: ['ELV Engineer'],
      certificationsChecked: ['MOI'],
      siteRequirementsSummary: 'Awaiting site survey to verify door dimensions and network cabling paths.',
      boqCreated: false,
      boqTotalValue: 180000,
      supplierQuotesGathered: false,
      bpStatus: 'Draft',
      poIssuedToSuppliers: false,
      clientAdvance50Received: false,
      supplierAdvance50Paid: false,
      projectPlanCreated: false,
      materialInspectedOnSite: false,
      currentExecutionStep: 'Initial Setup',
      staffAllocated: {
        permanentStaffCount: 2,
        contractStaffCount: 2,
        dailyWageCount: 2,
      },
      amcActive: false,
      amcDurationMonths: 12,
      amcMaintenanceLogs: [],
    },
  ]);

  // Active Selected Client State
  const [selectedClientId, setSelectedClientId] = useState<string>('WF-2026-001');

  // Currently Active Workflow State object derived from selectedClientId
  const activeClientIndex = clientProfiles.findIndex((c) => c.id === selectedClientId);
  const workflowData = clientProfiles[activeClientIndex >= 0 ? activeClientIndex : 0] || clientProfiles[0];

  // Helper function to update active client state
  const setWorkflowData = (
    updater: ((prev: WorkflowJourneyState) => WorkflowJourneyState) | WorkflowJourneyState | Partial<WorkflowJourneyState>
  ) => {
    setClientProfiles((prevProfiles) => {
      const copy = [...prevProfiles];
      const targetIdx = copy.findIndex((c) => c.id === workflowData.id);
      if (targetIdx >= 0) {
        if (typeof updater === 'function') {
          copy[targetIdx] = updater(copy[targetIdx]);
        } else {
          copy[targetIdx] = { ...copy[targetIdx], ...updater };
        }
      }
      return copy;
    });
  };

  // Workflow Active Stage Step (1..6)
  const [workflowActiveStage, setWorkflowActiveStage] = useState<number>(1);

  // Toast Notification State
  const [actionNotification, setActionNotification] = useState<string | null>(null);
  const triggerNotification = (msg: string) => {
    setActionNotification(msg);
    setTimeout(() => setActionNotification(null), 4000);
  };

  // Interactive Activity & Case Notes State
  const [notesList, setNotesList] = useState<
    { id: string; author: string; date: string; category: string; text: string }[]
  >([
    {
      id: 'note-1',
      author: 'Eng. Rashid Al-Kuwari',
      date: '2026-08-10 10:30 AM',
      category: 'Site Survey',
      text: 'Completed site survey for Lusail Marina Tower with ELV Engineers & TT Team. Verified 128 camera locations and MOI SSD server room rack capacity.',
    },
    {
      id: 'note-2',
      author: 'Waleed (Procurement Lead)',
      date: '2026-08-11 02:15 PM',
      category: 'MOI Approval',
      text: 'MOI approval certificate received for Hikvision Darkfighter 4MP Dome & BFT Gate Barriers.',
    },
    {
      id: 'note-3',
      author: 'Eng. Ali Al-Mansoori',
      date: '2026-08-12 09:00 AM',
      category: 'Cabling & Fiber',
      text: 'Fiber backbone cabling passed Fluke testing. 10 Gbps uplink confirmed between Control Room and Switch Racks.',
    },
  ]);
  const [newNote, setNewNote] = useState('');
  const [noteCategory, setNoteCategory] = useState('Site Log');

  // Documents List State
  const [documentList, setDocumentList] = useState([
    { id: 'doc-1', name: 'MOI_Approved_CCTV_Schematics_v2.pdf', type: 'MOI Approval', size: '4.2 MB', date: '2026-08-01', status: 'Approved' },
    { id: 'doc-2', name: 'Fluke_Fiber_Backbone_Test_Report.pdf', type: 'Testing Report', size: '1.8 MB', date: '2026-08-05', status: 'Verified' },
    { id: 'doc-3', name: 'Official_BOQ_Quotation_Signed.docx', type: 'BOQ & Contract', size: '850 KB', date: '2026-07-28', status: 'Signed' },
    { id: 'doc-4', name: 'Civil_Defence_Fire_Safe_Rack_Cert.pdf', type: 'Compliance', size: '2.4 MB', date: '2026-08-08', status: 'Approved' },
    { id: 'doc-5', name: 'IPC_Invoice_Payment_Cert_01.pdf', type: 'Billing', size: '1.1 MB', date: '2026-08-10', status: 'Paid' },
  ]);

  // Modal Dialog States
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [docNameInput, setDocNameInput] = useState('');
  const [docTypeInput, setDocTypeInput] = useState('MOI Drawing');

  const [isAMCLogModalOpen, setIsAMCLogModalOpen] = useState(false);
  const [amcLogType, setAmcLogType] = useState<'Fix' | 'System Update' | 'Repainting' | 'Inspection'>('Inspection');
  const [amcLogNotes, setAmcLogNotes] = useState('');
  const [amcLogTech, setAmcLogTech] = useState('Zain Tariq (PS ELV)');

  const [isNewLeadModalOpen, setIsNewLeadModalOpen] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientChannel, setNewClientChannel] = useState<LeadChannelType>('LinkedIn (B2B)');
  const [newClientValue, setNewClientValue] = useState('350000');
  const [newClientNotes, setNewClientNotes] = useState('');

  // Floating Chat Drawer State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isChatExpanded, setIsChatExpanded] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [copiedChatId, setCopiedChatId] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<
    { id: string; sender: 'user' | 'ai'; text: string; time: string }[]
  >([
    {
      id: 'welcome-0',
      sender: 'ai',
      text: `👋 **Marhaba! I am your Amazetec Project & Business Lifecycle Assistant.**

I have real-time access to our entire client portfolio, 6-stage lifecycle pipelines, BOQ valuations, 50% advance payments, site surveys, and MOI-SSD compliance.

**Ask me anything, for example:**
* 📊 *"Give me an overall business & financial report"*
* 💰 *"What is our collected 50% advance vs pending cashflow?"*
* 🏢 *"Give me a status summary of ${workflowData.clientName}"*
* 🛡️ *"Audit MOI-SSD compliance and site survey certifications"*
* 👥 *"Show staffing counts (Permanent, Contract, Daily Wage)"*`,
      time: 'Just now',
    },
  ]);
  const [inputChat, setInputChat] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isChatOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isChatOpen, chatMessages, isChatLoading]);

  const handleCopyChat = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedChatId(id);
    setTimeout(() => setCopiedChatId(null), 2000);
  };

  const handleClearChat = () => {
    setChatMessages([
      {
        id: `welcome-${Date.now()}`,
        sender: 'ai',
        text: `🧹 Conversation cleared. Ready for your next query on business reports, client stages, BOQ valuations, or MOI-SSD compliance.`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Event Handlers
  const handleAddNote = () => {
    if (!newNote.trim()) return;
    setNotesList([
      {
        id: `note-${Date.now()}`,
        author: 'Current User',
        date: new Date().toLocaleString([], { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }),
        category: noteCategory,
        text: newNote.trim(),
      },
      ...notesList,
    ]);
    setNewNote('');
    triggerNotification('New site log entry recorded.');
  };

  const handleUploadDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docNameInput.trim()) return;
    setDocumentList([
      {
        id: `doc-${Date.now()}`,
        name: docNameInput.trim().endsWith('.pdf') || docNameInput.trim().endsWith('.docx') ? docNameInput.trim() : `${docNameInput.trim()}.pdf`,
        type: docTypeInput,
        size: '2.5 MB',
        date: new Date().toISOString().split('T')[0],
        status: 'Uploaded',
      },
      ...documentList,
    ]);
    setDocNameInput('');
    setIsUploadModalOpen(false);
    triggerNotification(`Document "${docNameInput}" uploaded successfully.`);
  };

  const handleAddAMCLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amcLogNotes.trim()) return;
    setWorkflowData((prev) => ({
      ...prev,
      amcMaintenanceLogs: [
        {
          date: new Date().toISOString().split('T')[0],
          type: amcLogType,
          notes: amcLogNotes.trim(),
          performedBy: amcLogTech,
        },
        ...prev.amcMaintenanceLogs,
      ],
    }));
    setAmcLogNotes('');
    setIsAMCLogModalOpen(false);
    triggerNotification('AMC Maintenance Log recorded.');
  };

  const handleCreateNewLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim()) return;
    const newProfile: WorkflowJourneyState = {
      id: `WF-${Date.now().toString().slice(-4)}`,
      leadId: `LEAD-${Date.now().toString().slice(-3)}`,
      clientName: newClientName.trim(),
      channel: newClientChannel,
      leadStatus: 'Acquired',
      leadNotes: newClientNotes.trim() || 'New client inquiry logged.',
      siteVisitStatus: 'Pending',
      dispatchedRoles: ['ELV Engineer'],
      certificationsChecked: ['MOI'],
      siteRequirementsSummary: 'Initial survey pending.',
      boqCreated: false,
      boqTotalValue: parseFloat(newClientValue) || 250000,
      supplierQuotesGathered: false,
      bpStatus: 'Draft',
      poIssuedToSuppliers: false,
      clientAdvance50Received: false,
      supplierAdvance50Paid: false,
      projectPlanCreated: false,
      materialInspectedOnSite: false,
      currentExecutionStep: 'Initial Setup',
      staffAllocated: { permanentStaffCount: 2, contractStaffCount: 2, dailyWageCount: 2 },
      amcActive: false,
      amcDurationMonths: 12,
      amcMaintenanceLogs: [],
    };
    setClientProfiles([newProfile, ...clientProfiles]);
    setSelectedClientId(newProfile.id);
    setNewClientName('');
    setNewClientNotes('');
    setIsNewLeadModalOpen(false);
    setWorkflowActiveStage(1);
    triggerNotification(`New client project "${newProfile.clientName}" created in Stage 1.`);
  };

  const handleSendChat = async (overridePrompt?: string) => {
    const userMsg = (overridePrompt || inputChat).trim();
    if (!userMsg || isChatLoading) return;

    const userMsgObj = {
      id: `user-${Date.now()}`,
      sender: 'user' as const,
      text: userMsg,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...chatMessages, userMsgObj];
    setChatMessages(newHistory);
    setInputChat('');
    setIsChatLoading(true);

    // Calculate aggregated business metrics
    const totalPipelineValue = clientProfiles.reduce((sum, c) => sum + (c.boqTotalValue || 0), 0);
    const advancesCollected = clientProfiles
      .filter((c) => c.clientAdvance50Received)
      .reduce((sum, c) => sum + ((c.boqTotalValue || 0) * 0.5), 0);
    const advancesPending = (totalPipelineValue * 0.5) - advancesCollected;
    const qualifiedLeadsCount = clientProfiles.filter((c) => c.leadStatus === 'Qualified').length;
    const activeExecutionCount = clientProfiles.filter((c) => c.currentExecutionStep !== 'Initial Setup').length;
    const activeAmcCount = clientProfiles.filter((c) => c.amcActive).length;

    // Structured context payload for Gemini
    const projectContextPayload = {
      businessSummary: {
        totalProjects: clientProfiles.length,
        totalPipelineValueQAR: totalPipelineValue,
        total50PercentAdvancesCollectedQAR: advancesCollected,
        total50PercentAdvancesPendingQAR: advancesPending,
        averageProjectValueQAR: Math.round(totalPipelineValue / (clientProfiles.length || 1)),
        qualifiedLeadsCount,
        activeExecutionCount,
        activeAmcCount,
      },
      allClientProfiles: clientProfiles.map((c) => ({
        id: c.id,
        clientName: c.clientName,
        channel: c.channel,
        leadStatus: c.leadStatus,
        boqTotalValueQAR: c.boqTotalValue,
        siteVisitStatus: c.siteVisitStatus,
        dispatchedRoles: c.dispatchedRoles,
        certificationsChecked: c.certificationsChecked,
        bpStatus: c.bpStatus,
        poIssuedToSuppliers: c.poIssuedToSuppliers,
        clientAdvance50Received: c.clientAdvance50Received,
        supplierAdvance50Paid: c.supplierAdvance50Paid,
        currentExecutionStep: c.currentExecutionStep,
        staffAllocated: c.staffAllocated,
        amcActive: c.amcActive,
        amcLogsCount: c.amcMaintenanceLogs?.length || 0,
      })),
      currentlySelectedClient: {
        id: workflowData.id,
        clientName: workflowData.clientName,
        activeStage: workflowActiveStage,
        activeStageTitle: workflowProcessStages[workflowActiveStage - 1]?.title,
        channel: workflowData.channel,
        leadStatus: workflowData.leadStatus,
        leadNotes: workflowData.leadNotes,
        siteVisitStatus: workflowData.siteVisitStatus,
        dispatchedRoles: workflowData.dispatchedRoles,
        certificationsChecked: workflowData.certificationsChecked,
        siteRequirementsSummary: workflowData.siteRequirementsSummary,
        boqTotalValueQAR: workflowData.boqTotalValue,
        bpStatus: workflowData.bpStatus,
        bpRevisionNotes: workflowData.bpRevisionNotes,
        poIssuedToSuppliers: workflowData.poIssuedToSuppliers,
        clientAdvance50Received: workflowData.clientAdvance50Received,
        supplierAdvance50Paid: workflowData.supplierAdvance50Paid,
        projectPlanCreated: workflowData.projectPlanCreated,
        materialInspectedOnSite: workflowData.materialInspectedOnSite,
        currentExecutionStep: workflowData.currentExecutionStep,
        staffAllocated: workflowData.staffAllocated,
        amcActive: workflowData.amcActive,
        amcLogs: workflowData.amcMaintenanceLogs,
      },
      vaultDocuments: documentList,
      timelineActivityLogs: notesList,
    };

    try {
      const historyPayload = newHistory
        .filter((m) => m.id !== 'welcome-0')
        .map((m) => ({
          role: m.sender === 'user' ? 'user' : 'model',
          text: m.text,
        }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historyPayload.slice(0, -1),
          message: userMsg,
          model: 'gemini-2.5-flash',
          role: 'journey_lifecycle_assistant',
          projectContext: projectContextPayload,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server responded with HTTP ${res.status}`);
      }

      const data = await res.json();
      const replyText = data.reply || 'No response generated.';

      setChatMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: replyText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      console.warn('Gemini chat API fallback triggered:', err);
      // Construct an intelligent, data-accurate fallback response if API is unreachable
      let dynamicFallback = `### 📊 Amazetec Executive Business & Commercial Report\n\n`;
      dynamicFallback += `* **Total Active Client Projects:** ${clientProfiles.length} projects in portfolio\n`;
      dynamicFallback += `* **Total Pipeline BOQ Valuation:** **QAR ${totalPipelineValue.toLocaleString()}**\n`;
      dynamicFallback += `* **50% Advance Cashflow Collected:** **QAR ${advancesCollected.toLocaleString()}** (${Math.round((advancesCollected / (totalPipelineValue * 0.5 || 1)) * 100)}% of target deposits)\n`;
      dynamicFallback += `* **Outstanding 50% Advance Pending:** **QAR ${advancesPending.toLocaleString()}**\n\n`;
      
      dynamicFallback += `#### 🏢 Client Portfolio Breakdown:\n`;
      clientProfiles.forEach((c, idx) => {
        dynamicFallback += `${idx + 1}. **${c.clientName}** — QAR ${c.boqTotalValue.toLocaleString()}\n`;
        dynamicFallback += `   * Channel: ${c.channel} | Status: **${c.leadStatus}** | BP: **${c.bpStatus}**\n`;
        dynamicFallback += `   * 50% Advance: ${c.clientAdvance50Received ? '✅ Collected (QAR ' + (c.boqTotalValue * 0.5).toLocaleString() + ')' : '⏳ Pending Collection'}\n`;
        dynamicFallback += `   * Execution: **${c.currentExecutionStep}** | 1-Yr AMC: ${c.amcActive ? '✅ Active' : '❌ Inactive'}\n`;
      });

      dynamicFallback += `\n#### 🎯 Strategic Recommendations:\n`;
      dynamicFallback += `1. Follow up on pending 50% deposits to accelerate hardware procurement.\n`;
      dynamicFallback += `2. Ensure MOI-SSD documentation is submitted before final commissioning.\n`;
      dynamicFallback += `3. Transition completed installations to 1-Year AMC maintenance agreements.`;

      setChatMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: dynamicFallback,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // 6 End-to-End Stages Definition
  const workflowProcessStages = [
    {
      num: 1,
      title: '1. Lead Acquisition',
      subtitle: 'LinkedIn (B2B), Referrals & Freelance Platforms',
      badge: workflowData.leadStatus,
      icon: <Users className="w-5 h-5 text-teal-700" />,
    },
    {
      num: 2,
      title: '2. Site Visit & Cert Check',
      subtitle: 'ELV Engineers, ET Technicians, TT & MEA/MOI Review',
      badge: workflowData.siteVisitStatus,
      icon: <MapPin className="w-5 h-5 text-teal-700" />,
    },
    {
      num: 3,
      title: '3. BOQ, Pricing & BP',
      subtitle: 'Itemized BOQ, Supplier Quotes & WhatsApp/Email BP',
      badge: workflowData.bpStatus,
      icon: <FileText className="w-5 h-5 text-teal-700" />,
    },
    {
      num: 4,
      title: '4. PO & 50% Advance',
      subtitle: 'Supplier Purchase Order & 50% Client/Supplier Payments',
      badge: workflowData.clientAdvance50Received ? '50% Collected' : 'Pending Payment',
      icon: <DollarSign className="w-5 h-5 text-teal-700" />,
    },
    {
      num: 5,
      title: '5. Execution & Staffing',
      subtitle: 'Project Plan, Piping, Installation & PS/Contract/Daily Staff',
      badge: workflowData.currentExecutionStep,
      icon: <Wrench className="w-5 h-5 text-teal-700" />,
    },
    {
      num: 6,
      title: '6. Post-Project & 1-Yr AMC',
      subtitle: '1-Year Annual Maintenance, Fixes, Updates & Repainting',
      badge: workflowData.amcActive ? '1-Yr AMC Active' : 'No AMC',
      icon: <ShieldCheck className="w-5 h-5 text-teal-700" />,
    },
  ];

  return (
    <div className="min-h-screen bg-[#eaf4f0] p-3 sm:p-5 md:p-6 font-sans text-slate-800 relative">
      
      {/* Toast Notification Banner */}
      {actionNotification && (
        <div className="fixed top-4 right-4 z-50 bg-teal-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-teal-700 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
          <span className="text-xs sm:text-sm font-bold">{actionNotification}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* ========================================================================= */}
        {/* HEADER & CLIENT PROJECT SELECTOR BAR                                       */}
        {/* ========================================================================= */}
        <div className="bg-white/95 backdrop-blur-md p-4 sm:p-5 rounded-3xl border border-teal-100 shadow-2xs space-y-4">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
            
            {/* Title & Client Selector */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="w-10 h-10 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-black shadow-md shadow-teal-200">
                <ClipboardList className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-lg font-black tracking-tight text-slate-900">
                  Client & Project Tracker
                </h1>
                <p className="text-[11px] font-semibold text-teal-700">
                  Active Client: <span className="text-slate-900 font-extrabold">{workflowData.clientName}</span> ({workflowData.channel})
                </p>
              </div>
            </div>

            {/* Client Profile Selector Cards & New Lead Button */}
            <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto">
              <select
                value={selectedClientId}
                onChange={(e) => {
                  setSelectedClientId(e.target.value);
                  triggerNotification('Switched active client profile.');
                }}
                className="bg-slate-50 border border-slate-300 text-slate-800 text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer"
              >
                {clientProfiles.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.clientName} — QAR {c.boqTotalValue.toLocaleString()} ({c.leadStatus})
                  </option>
                ))}
              </select>

              <button
                onClick={() => setIsNewLeadModalOpen(true)}
                className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-teal-200 transition cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4" /> Add New Client Project
              </button>
            </div>
          </div>

          {/* Primary View Switcher Tabs */}
          <div className="flex items-center gap-2 border-t border-slate-100 pt-3 overflow-x-auto">
            <button
              onClick={() => setActivePortalTab('workflow')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                activePortalTab === 'workflow'
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-200'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Layers className="w-4 h-4" /> 6-Stage Process Journey
            </button>
            <button
              onClick={() => setActivePortalTab('matrix')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                activePortalTab === 'matrix'
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-200'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ClipboardList className="w-4 h-4" /> Stakeholder Gate Matrix
            </button>
            <button
              onClick={() => setActivePortalTab('vault')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                activePortalTab === 'vault'
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-200'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Paperclip className="w-4 h-4" /> Project Vault ({documentList.length})
            </button>
            <button
              onClick={() => setActivePortalTab('notes')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                activePortalTab === 'notes'
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-200'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <MessageSquare className="w-4 h-4" /> Case Activity & Logs ({notesList.length})
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* UNIFIED 6-STAGE VISUAL LIFECYCLE STEPPER BAR                              */}
        {/* ========================================================================= */}
        <div className="bg-[#f0f7f4] rounded-2xl p-5 sm:p-6 border border-teal-200/80 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-teal-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2b9e8b] animate-pulse" />
              <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-teal-900">
                Lifecycle Stage Progression: {workflowData.clientName}
              </h3>
            </div>
            <span className="text-[11px] font-extrabold text-teal-800 bg-white px-3 py-1 rounded-full border border-teal-200 shadow-2xs">
              Active Stage {workflowActiveStage} of 6
            </span>
          </div>

          {/* Connected 6-Stage Timeline Nodes */}
          <div className="relative py-2 max-w-5xl mx-auto">
            <div className="absolute top-[28px] left-[5%] right-[5%] h-[3px] bg-slate-300 z-0" />
            <div
              className="absolute top-[28px] left-[5%] h-[3px] bg-[#2b9e8b] transition-all duration-300 z-0"
              style={{ width: `${((workflowActiveStage - 1) / 5) * 90}%` }}
            />

            <div className="relative z-10 grid grid-cols-6 gap-2 text-center">
              {workflowProcessStages.map((stg) => {
                const isCurrentActive = stg.num === workflowActiveStage;
                const isPassed = stg.num < workflowActiveStage;
                return (
                  <button
                    key={stg.num}
                    onClick={() => setWorkflowActiveStage(stg.num)}
                    className="flex flex-col items-center group cursor-pointer focus:outline-none"
                  >
                    {/* Top Stage Icon */}
                    <div className={`mb-2 transition-colors ${
                      isCurrentActive || isPassed ? 'text-[#2b9e8b]' : 'text-slate-400'
                    }`}>
                      {stg.icon}
                    </div>

                    {/* Stage Numbered Node */}
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm transition-all duration-200 ${
                        isCurrentActive
                          ? 'bg-[#2b9e8b] text-white shadow-md shadow-teal-300 ring-4 ring-teal-100 scale-110'
                          : isPassed
                          ? 'bg-[#2b9e8b] text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-400'
                      }`}
                    >
                      {isPassed ? <Check className="w-4 h-4" /> : stg.num}
                    </div>

                    {/* Bottom Stage Label */}
                    <span className={`block text-[10px] font-extrabold mt-2 line-clamp-2 leading-tight ${
                      isCurrentActive ? 'text-teal-900 font-black' : isPassed ? 'text-slate-900' : 'text-slate-400'
                    }`}>
                      {stg.title.split('.')[1]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* VIEW 1: 6-STAGE INTERACTIVE WORKFLOW WORKSPACE                             */}
        {/* ========================================================================= */}
        {activePortalTab === 'workflow' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            
            {/* Stage Quick Selection Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {workflowProcessStages.map((stg) => {
                const isActive = workflowActiveStage === stg.num;
                return (
                  <button
                    key={stg.num}
                    onClick={() => setWorkflowActiveStage(stg.num)}
                    className={`p-3.5 rounded-2xl text-left border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between h-28 ${
                      isActive
                        ? 'bg-teal-700 text-white border-teal-800 shadow-lg shadow-teal-200 scale-102 ring-2 ring-teal-400'
                        : 'bg-white hover:bg-teal-50/50 border-slate-200 text-slate-800 hover:border-teal-300 shadow-2xs'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className={`p-2 rounded-xl ${isActive ? 'bg-teal-800 text-teal-200' : 'bg-teal-50 text-teal-700'}`}>
                        {stg.icon}
                      </div>
                      <span
                        className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          isActive
                            ? 'bg-teal-950 text-teal-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {stg.badge}
                      </span>
                    </div>

                    <div>
                      <h4 className={`text-xs font-black truncate ${isActive ? 'text-white' : 'text-slate-900'}`}>
                        {stg.title}
                      </h4>
                      <p className={`text-[10px] line-clamp-1 mt-0.5 ${isActive ? 'text-teal-100' : 'text-slate-500'}`}>
                        {stg.subtitle}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Stage Detailed Panel Body */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-6">
              
              {/* STAGE 1: LEAD ACQUISITION & QUALIFICATION */}
              {workflowActiveStage === 1 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <Users className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 1: Lead Acquisition & Qualification</h2>
                        <p className="text-xs text-slate-500">Capture and qualify enterprise leads across acquisition channels</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 text-xs font-black rounded-xl">
                      Channel: {workflowData.channel}
                    </span>
                  </div>

                  {/* Channel Breakdown Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    {/* LinkedIn B2B */}
                    <div
                      onClick={() => {
                        setWorkflowData((prev) => ({ ...prev, channel: 'LinkedIn (B2B)' }));
                        triggerNotification('Lead Channel set to LinkedIn (B2B)');
                      }}
                      className={`p-4 rounded-2xl border transition cursor-pointer ${
                        workflowData.channel === 'LinkedIn (B2B)'
                          ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-300'
                          : 'bg-slate-50/60 border-slate-200 hover:border-teal-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-extrabold text-xs text-teal-900">LinkedIn (B2B)</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800">Primary Channel</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        High-value enterprise and commercial infrastructure leads acquired via targeted B2B outreach.
                      </p>
                      <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-teal-700 pt-2 border-t border-teal-100">
                        <span>Quality Rating: High</span>
                        <span>{workflowData.channel === 'LinkedIn (B2B)' ? 'Selected' : 'Click to Select'}</span>
                      </div>
                    </div>

                    {/* Referrals */}
                    <div
                      onClick={() => {
                        setWorkflowData((prev) => ({ ...prev, channel: 'Referrals' }));
                        triggerNotification('Lead Channel set to Referrals');
                      }}
                      className={`p-4 rounded-2xl border transition cursor-pointer ${
                        workflowData.channel === 'Referrals'
                          ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-300'
                          : 'bg-slate-50/60 border-slate-200 hover:border-teal-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-extrabold text-xs text-slate-900">Referrals</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800">Word of Mouth</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Direct recommendations from existing satisfied clients, friends, and industry acquaintances.
                      </p>
                      <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-teal-700 pt-2 border-t border-slate-200">
                        <span>Conversion Rate: 85%</span>
                        <span>{workflowData.channel === 'Referrals' ? 'Selected' : 'Click to Select'}</span>
                      </div>
                    </div>

                    {/* Freelance Platforms */}
                    <div
                      onClick={() => {
                        setWorkflowData((prev) => ({ ...prev, channel: 'Upwork / Fiverr' }));
                        triggerNotification('Lead Channel set to Upwork / Fiverr');
                      }}
                      className={`p-4 rounded-2xl border transition cursor-pointer ${
                        workflowData.channel === 'Upwork / Fiverr'
                          ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-300'
                          : 'bg-slate-50/60 border-slate-200 hover:border-teal-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-extrabold text-xs text-slate-900">Freelance Platforms</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">Upwork & Fiverr</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Inbound digital project requests, RFPs, and consultancy contracts from global freelance platforms.
                      </p>
                      <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-teal-700 pt-2 border-t border-slate-200">
                        <span>Avg Project: QAR 150K</span>
                        <span>{workflowData.channel === 'Upwork / Fiverr' ? 'Selected' : 'Click to Select'}</span>
                      </div>
                    </div>

                  </div>

                  {/* Interactive Lead Qualification Form */}
                  <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
                    <h3 className="font-bold text-slate-900 text-sm">Lead Qualification & Requirement Log</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block text-[11px] font-extrabold text-slate-600 mb-1">Lead Client Entity</label>
                        <input
                          type="text"
                          value={workflowData.clientName}
                          onChange={(e) => setWorkflowData({ ...workflowData, clientName: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-extrabold text-slate-600 mb-1">Target Project Value (QAR)</label>
                        <input
                          type="number"
                          value={workflowData.boqTotalValue}
                          onChange={(e) => setWorkflowData({ ...workflowData, boqTotalValue: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-[11px] font-extrabold text-slate-600 mb-1">Lead Scope & Requirements</label>
                        <textarea
                          rows={2}
                          value={workflowData.leadNotes}
                          onChange={(e) => setWorkflowData({ ...workflowData, leadNotes: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-700">Qualification Status:</span>
                        {(['Acquired', 'In Progress', 'Qualified'] as const).map((st) => (
                          <button
                            key={st}
                            onClick={() => {
                              setWorkflowData({ ...workflowData, leadStatus: st });
                              triggerNotification(`Lead status changed to ${st}`);
                            }}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                              workflowData.leadStatus === st
                                ? 'bg-teal-700 text-white shadow-2xs'
                                : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>

                      <button
                        onClick={() => {
                          setWorkflowActiveStage(2);
                          triggerNotification('Proceeded to Stage 2: Technical Site Survey & Verification');
                        }}
                        className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                      >
                        Proceed to Stage 2: Site Survey <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* STAGE 2: SITE VISIT & CERTIFICATIONS CHECK */}
              {workflowActiveStage === 2 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <MapPin className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 2: Technical Site Visit & Regulatory Audit</h2>
                        <p className="text-xs text-slate-500">Dispatch technical teams and verify MOI SSD, MEA, and Civil Defence standards</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 text-xs font-black rounded-xl">
                      Status: {workflowData.siteVisitStatus}
                    </span>
                  </div>

                  {/* Dispatched Staff Roles & Certifications */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Dispatched Roles */}
                    <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider">Dispatched Team Roles</h3>
                      <div className="space-y-2 text-xs font-semibold">
                        {[
                          { role: 'ELV Engineer', desc: 'Lead security architect for CCTV, ANPR & server sizing' },
                          { role: 'Technician (ET)', desc: 'Site cabling, conduit path & mounting point specialist' },
                          { role: 'Technical Team (TT)', desc: 'Field measurement & rack power audit team' },
                        ].map((item) => {
                          const isChecked = workflowData.dispatchedRoles.includes(item.role as DispatchedRoleType);
                          return (
                            <label key={item.role} className="flex items-start gap-2.5 cursor-pointer bg-white p-2.5 rounded-xl border border-slate-200">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => {
                                  const updated = isChecked
                                    ? workflowData.dispatchedRoles.filter((r) => r !== item.role)
                                    : [...workflowData.dispatchedRoles, item.role as DispatchedRoleType];
                                  setWorkflowData({ ...workflowData, dispatchedRoles: updated });
                                }}
                                className="mt-0.5 rounded text-teal-600 focus:ring-teal-500"
                              />
                              <div>
                                <span className="text-slate-900 font-extrabold block">{item.role}</span>
                                <span className="text-[10px] text-slate-500 block">{item.desc}</span>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Certifications Audit Checklist */}
                    <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider">Regulatory Compliance Audit</h3>
                      <div className="space-y-2 text-xs font-semibold">
                        {[
                          { code: 'MOI', name: 'MOI SSD Approved Cameras & SAN Retention (120 Days)' },
                          { code: 'MEA', name: 'MEA Electrical & Fiber Conduit Cabling Compliance' },
                          { code: 'Civil Defence', name: 'Civil Defence Fire-Safe Server Rack Sizing' },
                        ].map((cert) => {
                          const isChecked = workflowData.certificationsChecked.includes(cert.code as any);
                          return (
                            <label key={cert.code} className="flex items-start gap-2.5 cursor-pointer bg-white p-2.5 rounded-xl border border-slate-200">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => {
                                  const updated = isChecked
                                    ? workflowData.certificationsChecked.filter((c) => c !== cert.code)
                                    : [...workflowData.certificationsChecked, cert.code as any];
                                  setWorkflowData({ ...workflowData, certificationsChecked: updated });
                                }}
                                className="mt-0.5 rounded text-teal-600 focus:ring-teal-500"
                              />
                              <div>
                                <span className="text-teal-900 font-extrabold block">{cert.code} Certification</span>
                                <span className="text-[10px] text-slate-500 block">{cert.name}</span>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                  </div>

                  {/* Site Visit Summary Notes */}
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                    <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider">Site Visit Engineering Summary</h3>
                    <textarea
                      rows={2}
                      value={workflowData.siteRequirementsSummary}
                      onChange={(e) => setWorkflowData({ ...workflowData, siteRequirementsSummary: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setWorkflowActiveStage(1)}
                      className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition"
                    >
                      Back to Stage 1
                    </button>
                    <button
                      onClick={() => {
                        setWorkflowData({ ...workflowData, siteVisitStatus: 'Completed', boqCreated: true });
                        setWorkflowActiveStage(3);
                        triggerNotification('Site Survey Completed! Proceeded to Stage 3: BOQ & Business Proposal');
                      }}
                      className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                    >
                      Complete Survey & Proceed to Stage 3 <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE 3: BOQ, SUPPLIER PRICING & BUSINESS PROPOSAL */}
              {workflowActiveStage === 3 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <FileText className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 3: BOQ Creation, Supplier Quotes & Business Proposal (BP)</h2>
                        <p className="text-xs text-slate-500">Aggregate supplier quotes and dispatch instant Business Proposals via WhatsApp and Email</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 text-xs font-black rounded-xl">
                      BP Status: {workflowData.bpStatus}
                    </span>
                  </div>

                  {/* Financial & Margin Overview */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-teal-50 rounded-2xl border border-teal-200 text-xs space-y-1">
                      <span className="text-[10px] font-extrabold text-teal-800 uppercase">Calculated BOQ Value</span>
                      <p className="text-xl font-black text-slate-900">QAR {workflowData.boqTotalValue.toLocaleString()}</p>
                      <p className="text-[10px] text-teal-700 font-semibold">Includes 128 Cameras, NVR, Switches & Labor</p>
                    </div>

                    <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs space-y-1">
                      <span className="text-[10px] font-extrabold text-emerald-800 uppercase">Estimated Gross Profit Margin</span>
                      <p className="text-xl font-black text-emerald-900">QAR {(workflowData.boqTotalValue * 0.134).toLocaleString()} (13.4%)</p>
                      <p className="text-[10px] text-emerald-700 font-semibold">Exceeds standard 12% engineering margin target</p>
                    </div>

                    <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 text-xs space-y-1">
                      <span className="text-[10px] font-extrabold text-purple-800 uppercase">Supplier Quote Aggregation</span>
                      <p className="text-xl font-black text-purple-900">{workflowData.supplierQuotesGathered ? 'Quotes Locked' : 'Pending Quotes'}</p>
                      <p className="text-[10px] text-purple-700 font-semibold">Hikvision Doha, BFT Qatar & Belden Cable</p>
                    </div>
                  </div>

                  {/* Business Proposal Dispatch Simulator */}
                  <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
                    <h3 className="font-bold text-slate-900 text-sm">Business Proposal (BP) Dispatch Hub</h3>
                    <p className="text-xs text-slate-600">
                      Send official PDF Business Proposal directly to client decision makers with revision tracking.
                    </p>

                    <div className="flex flex-wrap items-center gap-3">
                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, bpStatus: 'Sent via WhatsApp' });
                          triggerNotification('Business Proposal sent via WhatsApp to client!');
                        }}
                        className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm transition cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4" /> Send BP via WhatsApp
                      </button>

                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, bpStatus: 'Sent via Email' });
                          triggerNotification('Business Proposal emailed to client!');
                        }}
                        className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm transition cursor-pointer"
                      >
                        <Mail className="w-4 h-4" /> Send BP via Official Email
                      </button>

                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, bpStatus: 'Approved' });
                          triggerNotification('Business Proposal marked as APPROVED by Client!');
                        }}
                        className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm transition cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Mark BP as Client Approved
                      </button>
                    </div>

                    {workflowData.bpRevisionNotes && (
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 font-medium">
                        <span className="font-extrabold">Client Feedback / Revision Note:</span> {workflowData.bpRevisionNotes}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setWorkflowActiveStage(2)}
                      className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition"
                    >
                      Back to Stage 2
                    </button>
                    <button
                      onClick={() => {
                        setWorkflowActiveStage(4);
                        triggerNotification('Proceeded to Stage 4: Purchase Order & 50% Advance Escrow');
                      }}
                      className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                    >
                      Proceed to Stage 4: PO & 50% Advance <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE 4: PO & 50% ADVANCE PAYMENT RULE */}
              {workflowActiveStage === 4 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <DollarSign className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 4: Purchase Order & 50% Advance Payment Governance</h2>
                        <p className="text-xs text-slate-500">Strict escrow rule: Collect 50% Client Advance and disburse 50% Supplier Deposit before procurement release</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 text-xs font-black rounded-xl">
                      Escrow: {workflowData.clientAdvance50Received ? '50% Collected' : 'Pending Collection'}
                    </span>
                  </div>

                  {/* Financial 50% Escrow Rule Controls */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    {/* Supplier Purchase Order (PO) */}
                    <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 shadow-2xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-slate-900">1. Supplier Purchase Order</span>
                        <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-full ${workflowData.poIssuedToSuppliers ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                          {workflowData.poIssuedToSuppliers ? 'PO Issued' : 'Draft'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">
                        Official PO issued to hardware manufacturers (Hikvision / BFT) for camera equipment and gate barriers.
                      </p>
                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, poIssuedToSuppliers: !workflowData.poIssuedToSuppliers });
                          triggerNotification('Toggled Supplier Purchase Order state.');
                        }}
                        className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
                      >
                        {workflowData.poIssuedToSuppliers ? 'Cancel PO' : 'Issue Supplier PO'}
                      </button>
                    </div>

                    {/* Client 50% Advance Payment */}
                    <div className="p-5 rounded-2xl border border-emerald-200 bg-emerald-50/50 shadow-2xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-emerald-900">2. Client 50% Advance</span>
                        <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-full ${workflowData.clientAdvance50Received ? 'bg-emerald-200 text-emerald-900' : 'bg-amber-100 text-amber-800'}`}>
                          {workflowData.clientAdvance50Received ? 'QAR ' + (workflowData.boqTotalValue * 0.5).toLocaleString() + ' Paid' : 'Pending'}
                        </span>
                      </div>
                      <p className="text-xs text-emerald-800">
                        50% deposit collected from client upon BP acceptance (QAR {(workflowData.boqTotalValue * 0.5).toLocaleString()}).
                      </p>
                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, clientAdvance50Received: !workflowData.clientAdvance50Received });
                          triggerNotification('Toggled Client 50% Advance Payment status.');
                        }}
                        className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                      >
                        {workflowData.clientAdvance50Received ? 'Mark as Unpaid' : 'Record 50% Client Advance Received'}
                      </button>
                    </div>

                    {/* Supplier 50% Advance Payment */}
                    <div className="p-5 rounded-2xl border border-teal-200 bg-teal-50/50 shadow-2xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-teal-900">3. Supplier 50% Advance</span>
                        <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-full ${workflowData.supplierAdvance50Paid ? 'bg-teal-200 text-teal-900' : 'bg-amber-100 text-amber-800'}`}>
                          {workflowData.supplierAdvance50Paid ? '50% Paid to Supplier' : 'Pending'}
                        </span>
                      </div>
                      <p className="text-xs text-teal-800">
                        50% advance disbursed to hardware suppliers to initiate manufacturing & air freight dispatch.
                      </p>
                      <button
                        onClick={() => {
                          setWorkflowData({ ...workflowData, supplierAdvance50Paid: !workflowData.supplierAdvance50Paid });
                          triggerNotification('Toggled Supplier 50% Advance Payment status.');
                        }}
                        className="w-full py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                      >
                        {workflowData.supplierAdvance50Paid ? 'Mark as Unpaid' : 'Record 50% Paid to Supplier'}
                      </button>
                    </div>

                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setWorkflowActiveStage(3)}
                      className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition"
                    >
                      Back to Stage 3
                    </button>
                    <button
                      onClick={() => {
                        setWorkflowActiveStage(5);
                        triggerNotification('Proceeded to Stage 5: Field Execution & Staff Allocation');
                      }}
                      className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                    >
                      Proceed to Stage 5: Execution <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE 5: EXECUTION & STAFF ALLOCATION */}
              {workflowActiveStage === 5 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <Wrench className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 5: Field Execution & Staff Allocation</h2>
                        <p className="text-xs text-slate-500">Manage 4 construction subphases and allocate permanent ELV staff, contract staff, and daily workers</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-teal-50 border border-teal-300 text-teal-900 text-xs font-black rounded-xl">
                      Phase: {workflowData.currentExecutionStep}
                    </span>
                  </div>

                  {/* 4 Execution Subphases Selector */}
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm mb-3">Project Execution Subphases:</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { name: 'Initial Setup', desc: 'Site mobilization, CAD drawing review & safety briefing' },
                        { name: 'Piping & Conduit', desc: 'EMT conduit layout, tray installation & cable pulling' },
                        { name: 'Installation', desc: 'Camera mounting, rack staging, power supply & switch config' },
                        { name: 'Testing & Commissioning', desc: 'Fluke fiber certification, VMS setup & MOI inspection' },
                      ].map((st) => {
                        const isCurrent = workflowData.currentExecutionStep === st.name;
                        return (
                          <div
                            key={st.name}
                            onClick={() => {
                              setWorkflowData({ ...workflowData, currentExecutionStep: st.name as ProjectExecutionStep });
                              triggerNotification(`Execution Subphase set to ${st.name}`);
                            }}
                            className={`p-3.5 rounded-2xl border transition cursor-pointer ${
                              isCurrent
                                ? 'bg-teal-700 text-white border-teal-800 shadow-md ring-2 ring-teal-300'
                                : 'bg-slate-50 border-slate-200 text-slate-800 hover:border-teal-300'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-black text-xs">{st.name}</span>
                              {isCurrent && <CheckCircle className="w-4 h-4 text-teal-200" />}
                            </div>
                            <p className={`text-[10px] leading-snug ${isCurrent ? 'text-teal-100' : 'text-slate-500'}`}>
                              {st.desc}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Staffing Allocation Dashboard */}
                  <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
                    <h3 className="font-bold text-slate-900 text-sm">Site Staffing Allocation Breakdown</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      
                      {/* Permanent Staff (PS) */}
                      <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-xs text-slate-900">Permanent Staff (PS)</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800">ELV Certified</span>
                        </div>
                        <p className="text-[11px] text-slate-500">Core engineering leadership & MOI certified site engineers.</p>
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-xs font-bold text-slate-700">Allocated Engineers:</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    permanentStaffCount: Math.max(1, prev.staffAllocated.permanentStaffCount - 1),
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-slate-200 font-bold text-xs"
                            >
                              -
                            </button>
                            <span className="font-black text-sm text-teal-900">{workflowData.staffAllocated.permanentStaffCount}</span>
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    permanentStaffCount: prev.staffAllocated.permanentStaffCount + 1,
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-teal-600 text-white font-bold text-xs"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Contract Staff */}
                      <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-xs text-slate-900">Contract Staff</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800">Project Duration</span>
                        </div>
                        <p className="text-[11px] text-slate-500">Specialized cable pullers, fiber splicers & rack technicians.</p>
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-xs font-bold text-slate-700">Allocated Technicians:</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    contractStaffCount: Math.max(0, prev.staffAllocated.contractStaffCount - 1),
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-slate-200 font-bold text-xs"
                            >
                              -
                            </button>
                            <span className="font-black text-sm text-slate-900">{workflowData.staffAllocated.contractStaffCount}</span>
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    contractStaffCount: prev.staffAllocated.contractStaffCount + 1,
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-teal-600 text-white font-bold text-xs"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Daily Wage Laborers */}
                      <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-xs text-slate-900">Daily Wage Laborers</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">Flexible Workforce</span>
                        </div>
                        <p className="text-[11px] text-slate-500">Site preparation, material handling & conduit mounting support.</p>
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-xs font-bold text-slate-700">Allocated Workers:</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    dailyWageCount: Math.max(0, prev.staffAllocated.dailyWageCount - 1),
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-slate-200 font-bold text-xs"
                            >
                              -
                            </button>
                            <span className="font-black text-sm text-slate-900">{workflowData.staffAllocated.dailyWageCount}</span>
                            <button
                              onClick={() =>
                                setWorkflowData((prev) => ({
                                  ...prev,
                                  staffAllocated: {
                                    ...prev.staffAllocated,
                                    dailyWageCount: prev.staffAllocated.dailyWageCount + 1,
                                  },
                                }))
                              }
                              className="w-6 h-6 rounded bg-teal-600 text-white font-bold text-xs"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setWorkflowActiveStage(4)}
                      className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition"
                    >
                      Back to Stage 4
                    </button>
                    <button
                      onClick={() => {
                        setWorkflowActiveStage(6);
                        triggerNotification('Proceeded to Stage 6: Post-Project & 1-Year AMC');
                      }}
                      className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                    >
                      Proceed to Stage 6: 1-Year AMC <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE 6: HANDOVER & 1-YEAR AMC */}
              {workflowActiveStage === 6 && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-teal-100 rounded-2xl text-teal-800">
                        <ShieldCheck className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">Stage 6: MOI Handover & 1-Year Annual Maintenance Contract (AMC)</h2>
                        <p className="text-xs text-slate-500">Provide 1 year free/contracted maintenance including system updates, fixes & repainting</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-black rounded-xl border border-emerald-200">
                      AMC Active (12 Months)
                    </span>
                  </div>

                  {/* AMC Status Card */}
                  <div className="p-5 rounded-2xl border border-emerald-200 bg-emerald-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <h3 className="font-bold text-slate-900 text-sm">1-Year AMC Contract Active</h3>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        Validity: {workflowData.amcStartDate || '2026-12-01'} to {workflowData.amcEndDate || '2027-11-30'} (Coverage: Replacement, Fixes, Firmware Updates & Repainting).
                      </p>
                    </div>
                    <button
                      onClick={() => setIsAMCLogModalOpen(true)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-2xs transition cursor-pointer shrink-0"
                    >
                      <Plus className="w-4 h-4" /> Add Maintenance Log
                    </button>
                  </div>

                  {/* Maintenance Log History Table */}
                  <div className="space-y-3">
                    <h3 className="font-bold text-slate-900 text-sm">AMC Maintenance & Service History</h3>
                    <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                      <table className="w-full text-left text-xs text-slate-700">
                        <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-extrabold border-b border-slate-200">
                          <tr>
                            <th className="p-3">Date</th>
                            <th className="p-3">Service Type</th>
                            <th className="p-3">Maintenance Details</th>
                            <th className="p-3">Performed By</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {workflowData.amcMaintenanceLogs.length > 0 ? (
                            workflowData.amcMaintenanceLogs.map((log, idx) => (
                              <tr key={idx} className="hover:bg-slate-50/80">
                                <td className="p-3 font-bold text-slate-900 whitespace-nowrap">{log.date}</td>
                                <td className="p-3">
                                  <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-full ${
                                    log.type === 'Fix' ? 'bg-amber-100 text-amber-800' : log.type === 'System Update' ? 'bg-sky-100 text-sky-800' : 'bg-purple-100 text-purple-800'
                                  }`}>
                                    {log.type}
                                  </span>
                                </td>
                                <td className="p-3 text-slate-700 leading-snug">{log.notes}</td>
                                <td className="p-3 font-semibold text-slate-800 whitespace-nowrap">{log.performedBy}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={4} className="p-6 text-center text-slate-500 text-xs">
                                No maintenance logs recorded yet. Click "Add Maintenance Log" above to record service visits.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setWorkflowActiveStage(5)}
                      className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition"
                    >
                      Back to Stage 5
                    </button>
                    <button
                      onClick={() => {
                        triggerNotification('Entire End-to-End Workflow successfully verified and synchronized!');
                      }}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Workflow Fully Complete
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: STAKEHOLDER GATE SIGN-OFF MATRIX                                   */}
        {/* ========================================================================= */}
        {activePortalTab === 'matrix' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-teal-700" /> Stakeholder Gate Approval & Responsibility Matrix
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Multi-role governance covering Business Analysts, ELV Engineers, Procurement Leads, PMs, MOI Auditors & AMC Techs
                  </p>
                </div>
                <button
                  onClick={() => {
                    triggerNotification('Exporting Lead Acquisition & Project Journey Matrix Summary...');
                    window.print();
                  }}
                  className="px-3.5 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-bold rounded-xl flex items-center gap-2 transition cursor-pointer"
                >
                  <Download className="w-4 h-4 text-teal-700" /> Export Journey Summary
                </button>
              </div>

              {/* Stakeholder Gate Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-2xs">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-extrabold border-b border-slate-200">
                    <tr>
                      <th className="p-3.5">Stage & Title</th>
                      <th className="p-3.5">Key Gate Deliverable</th>
                      <th className="p-3.5">Assigned Roles</th>
                      <th className="p-3.5">Compliance Standard</th>
                      <th className="p-3.5">Gate Status</th>
                      <th className="p-3.5 text-right">Action Gate Sign-off</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {/* Stage 1 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 1</span>
                        Lead Acquisition Channels
                      </td>
                      <td className="p-3.5 text-slate-800">LinkedIn B2B / Referral Qualification & Budget Check</td>
                      <td className="p-3.5 font-semibold text-slate-900">Business Analyst (BA)</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-extrabold text-slate-700">Channel ROI Audit</span></td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold">
                          {workflowData.leadStatus}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, leadStatus: 'Qualified' }));
                            triggerNotification('Stage 1 Gate approved by Business Analyst.');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 1
                        </button>
                      </td>
                    </tr>

                    {/* Stage 2 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 2</span>
                        Site Visit & Cert Check
                      </td>
                      <td className="p-3.5 text-slate-800">Dispatched ELV / ET / TT Site Survey & Cert Verification</td>
                      <td className="p-3.5 font-semibold text-slate-900">ELV Engineers, ET Techs, TT Team</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-extrabold">MOI SSD & MEA Certs</span></td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold">
                          {workflowData.siteVisitStatus}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, siteVisitStatus: 'Completed' }));
                            triggerNotification('Stage 2 Gate approved by Lead ELV Engineer.');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 2
                        </button>
                      </td>
                    </tr>

                    {/* Stage 3 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 3</span>
                        BOQ, Supplier Quotes & BP
                      </td>
                      <td className="p-3.5 text-slate-800">Itemized BOQ, Supplier Quotes & WhatsApp/Email BP Dispatch</td>
                      <td className="p-3.5 font-semibold text-slate-900">Procurement Lead & BA</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-teal-100 text-teal-800 rounded text-[10px] font-extrabold">13.4% Target Margin</span></td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-sky-100 text-sky-800 rounded-full text-[10px] font-extrabold">
                          {workflowData.bpStatus}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, bpStatus: 'Approved' }));
                            triggerNotification('Stage 3 BP Approved by Client!');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 3
                        </button>
                      </td>
                    </tr>

                    {/* Stage 4 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 4</span>
                        PO & 50% Advance Rule
                      </td>
                      <td className="p-3.5 text-slate-800">Supplier PO Issued & 50% Client Advance Collection</td>
                      <td className="p-3.5 font-semibold text-slate-900">Project Manager & Finance</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded text-[10px] font-extrabold">50% Escrow Rule</span></td>
                      <td className="p-3.5">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold ${workflowData.clientAdvance50Received ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                          {workflowData.clientAdvance50Received ? '50% Received' : 'Pending Escrow'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, clientAdvance50Received: true, supplierAdvance50Paid: true }));
                            triggerNotification('Stage 4 50% Advance Escrow verified by Finance.');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 4
                        </button>
                      </td>
                    </tr>

                    {/* Stage 5 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 5</span>
                        Execution & Staff Allocation
                      </td>
                      <td className="p-3.5 text-slate-800">4-Phase Construction (Setup, Conduit, Install, Testing)</td>
                      <td className="p-3.5 font-semibold text-slate-900">PM, Site Engineers & Technicians</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-purple-100 text-purple-800 rounded text-[10px] font-extrabold">PS / Contract / Labor</span></td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-purple-100 text-purple-800 rounded-full text-[10px] font-extrabold">
                          {workflowData.currentExecutionStep}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, currentExecutionStep: 'Testing & Commissioning' }));
                            triggerNotification('Stage 5 Execution Phase updated by PM.');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 5
                        </button>
                      </td>
                    </tr>

                    {/* Stage 6 */}
                    <tr className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900">
                        <span className="block text-[10px] text-teal-800 font-extrabold uppercase">Stage 6</span>
                        Handover & 1-Year AMC
                      </td>
                      <td className="p-3.5 text-slate-800">MOI SSD Handover & 1-Year Annual Maintenance Contract</td>
                      <td className="p-3.5 font-semibold text-slate-900">AMC Specialist & Lead Engineers</td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-extrabold">12-Month Coverage</span></td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold">
                          {workflowData.amcActive ? 'Active AMC' : 'No AMC'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setWorkflowData((prev) => ({ ...prev, amcActive: true }));
                            triggerNotification('Stage 6 AMC Contract activated.');
                          }}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Sign-off Stage 6
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: PROJECT VAULT & DOCUMENTS REPOSITORY                              */}
        {/* ========================================================================= */}
        {activePortalTab === 'vault' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Paperclip className="w-5 h-5 text-teal-700" /> Project Vault & Compliance Documents
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Centralized repository for MOI schematics, BOQs, Fluke test reports & payment certificates
                </p>
              </div>
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm transition cursor-pointer"
              >
                <Upload className="w-4 h-4" /> Upload Document
              </button>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-2xl">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-extrabold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Document Name</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">File Size</th>
                    <th className="p-3.5">Upload Date</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {documentList.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 font-bold text-slate-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-teal-700 shrink-0" />
                        <span>{doc.name}</span>
                      </td>
                      <td className="p-3.5"><span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-extrabold text-slate-700">{doc.type}</span></td>
                      <td className="p-3.5 text-slate-500">{doc.size}</td>
                      <td className="p-3.5 text-slate-500">{doc.date}</td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold">
                          {doc.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => triggerNotification(`Downloading ${doc.name}...`)}
                          className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          Download
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: CASE ACTIVITY & SITE LOGS                                          */}
        {/* ========================================================================= */}
        {activePortalTab === 'notes' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-teal-700" /> Case Activity & Site Log History
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Chronological site engineer logs, client meeting summaries, and technical milestone records
                </p>
              </div>
            </div>

            {/* Quick Log Entry */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <h3 className="font-bold text-slate-900 text-xs">Record New Site Activity Log</h3>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <select
                  value={noteCategory}
                  onChange={(e) => setNoteCategory(e.target.value)}
                  className="bg-white border border-slate-300 text-slate-800 text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer shrink-0"
                >
                  <option value="Site Log">Site Log</option>
                  <option value="Survey Audit">Survey Audit</option>
                  <option value="MOI Approval">MOI Approval</option>
                  <option value="Client Comms">Client Comms</option>
                  <option value="AMC Maintenance">AMC Maintenance</option>
                </select>
                <input
                  type="text"
                  placeholder="Enter site log or activity details..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  className="flex-1 bg-white border border-slate-300 text-slate-800 text-xs rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
                <button
                  onClick={handleAddNote}
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer shrink-0 justify-center"
                >
                  <Send className="w-3.5 h-3.5" /> Log Entry
                </button>
              </div>
            </div>

            {/* Timeline Log List */}
            <div className="space-y-3">
              {notesList.map((note) => (
                <div key={note.id} className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 transition space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-extrabold text-slate-900">{note.author}</span>
                    <span className="text-[10px] text-slate-400 font-semibold">{note.date}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 bg-teal-100 text-teal-800 font-bold rounded text-[10px]">{note.category}</span>
                    <p className="text-xs text-slate-700 leading-snug">{note.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* FLOATING AI ASSISTANT CHAT DRAWER                                         */}
      {/* ========================================================================= */}
      <div className="fixed bottom-6 right-6 z-40">
        {!isChatOpen ? (
          <button
            onClick={() => setIsChatOpen(true)}
            className="w-14 h-14 bg-gradient-to-br from-teal-700 to-teal-900 hover:from-teal-600 hover:to-teal-800 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-105 transition cursor-pointer relative border-2 border-white"
            title="Open Amazetec AI Journey & Business Assistant"
          >
            <Bot className="w-7 h-7 text-emerald-200" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full border-2 border-white animate-ping" />
          </button>
        ) : (
          <div
            className={`${
              isChatExpanded
                ? 'w-[95vw] sm:w-[680px] h-[680px] max-h-[90vh]'
                : 'w-[92vw] sm:w-[460px] h-[540px]'
            } bg-white rounded-3xl shadow-2xl border border-teal-200 overflow-hidden flex flex-col transition-all duration-200 animate-in slide-in-from-bottom-5`}
          >
            {/* Chat Drawer Header */}
            <div className="p-3.5 bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 text-white flex items-center justify-between shrink-0 shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-teal-700/60 border border-teal-500/40 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-emerald-300" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-extrabold text-xs text-white">Amazetec Journey Assistant</h3>
                    <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 text-[9px] font-bold rounded border border-emerald-400/30">Gemini 3.7</span>
                  </div>
                  <p className="text-[10px] text-teal-200 font-medium">Full-Lifecycle & Commercial Intelligence</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleClearChat}
                  title="Clear conversation"
                  className="p-1.5 text-teal-300 hover:text-white hover:bg-teal-700/50 rounded-lg transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setIsChatExpanded(!isChatExpanded)}
                  title={isChatExpanded ? 'Minimize drawer' : 'Expand drawer'}
                  className="p-1.5 text-teal-300 hover:text-white hover:bg-teal-700/50 rounded-lg transition cursor-pointer"
                >
                  {isChatExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => setIsChatOpen(false)}
                  title="Close Assistant"
                  className="p-1.5 text-teal-300 hover:text-white hover:bg-teal-700/50 rounded-lg transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Prompt Suggestion Chips */}
            <div className="bg-teal-50/70 border-b border-teal-100/80 px-3 py-2 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
              <button
                onClick={() => handleSendChat('Give me an overall report of the business side with total pipeline, collected advances, and stage breakdowns.')}
                disabled={isChatLoading}
                className="px-2.5 py-1 bg-white hover:bg-teal-100/70 text-teal-900 border border-teal-200 rounded-full text-[10px] font-bold whitespace-nowrap transition cursor-pointer shadow-2xs shrink-0 flex items-center gap-1"
              >
                <span>📊 Overall Business Report</span>
              </button>
              <button
                onClick={() => handleSendChat(`Summarize the financial & 50% advance collection status for ${workflowData.clientName}.`)}
                disabled={isChatLoading}
                className="px-2.5 py-1 bg-white hover:bg-teal-100/70 text-teal-900 border border-teal-200 rounded-full text-[10px] font-bold whitespace-nowrap transition cursor-pointer shadow-2xs shrink-0 flex items-center gap-1"
              >
                <span>💰 50% Advances & Cashflow</span>
              </button>
              <button
                onClick={() => handleSendChat('Audit MOI-SSD compliance, site surveys, and certifications across active projects.')}
                disabled={isChatLoading}
                className="px-2.5 py-1 bg-white hover:bg-teal-100/70 text-teal-900 border border-teal-200 rounded-full text-[10px] font-bold whitespace-nowrap transition cursor-pointer shadow-2xs shrink-0 flex items-center gap-1"
              >
                <span>🛡️ MOI-SSD Compliance</span>
              </button>
              <button
                onClick={() => handleSendChat('Show our total staffing allocation across permanent, contract, and daily wage labor.')}
                disabled={isChatLoading}
                className="px-2.5 py-1 bg-white hover:bg-teal-100/70 text-teal-900 border border-teal-200 rounded-full text-[10px] font-bold whitespace-nowrap transition cursor-pointer shadow-2xs shrink-0 flex items-center gap-1"
              >
                <span>👥 Staffing Breakdown</span>
              </button>
            </div>

            {/* Chat Messages Scroll Container */}
            <div className="flex-1 p-3.5 overflow-y-auto space-y-3.5 bg-slate-50/80 text-xs">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[92%] p-3.5 rounded-2xl relative group ${
                      msg.sender === 'user'
                        ? 'bg-teal-700 text-white rounded-br-none font-medium shadow-xs'
                        : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-none shadow-xs font-normal'
                    }`}
                  >
                    {msg.sender === 'ai' ? (
                      <div className="space-y-1.5">
                        <div className="text-slate-800 leading-relaxed text-xs [&>h3]:font-black [&>h3]:text-sm [&>h3]:text-teal-950 [&>h3]:mb-1.5 [&>h4]:font-extrabold [&>h4]:text-xs [&>h4]:text-slate-900 [&>h4]:mt-2 [&>h4]:mb-1 [&>ul]:list-disc [&>ul]:pl-4 [&>ul]:space-y-1 [&>ol]:list-decimal [&>ol]:pl-4 [&>ol]:space-y-1 [&>p]:mb-1.5 [&>p:last-child]:mb-0">
                          <ReactMarkdown>{msg.text}</ReactMarkdown>
                        </div>
                        <div className="flex items-center justify-between pt-1 border-t border-slate-100 mt-2 text-[10px] text-slate-400">
                          <span className="text-[9px] font-semibold text-teal-700">Amazetec AI Engine</span>
                          <button
                            onClick={() => handleCopyChat(msg.id, msg.text)}
                            className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer transition flex items-center gap-1"
                            title="Copy reply text"
                          >
                            {copiedChatId === msg.id ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span className="text-[9px] text-emerald-600 font-bold">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span className="text-[9px]">Copy</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    )}
                  </div>
                  <span className="text-[9px] text-slate-400 mt-1 px-1.5 font-medium">{msg.time}</span>
                </div>
              ))}

              {isChatLoading && (
                <div className="flex items-start gap-2">
                  <div className="p-3 bg-white border border-teal-200 rounded-2xl rounded-bl-none shadow-xs text-xs flex items-center gap-2 text-teal-800">
                    <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
                    <span className="font-bold text-[11px]">Gemini is analyzing business & lifecycle data...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input & Send Area */}
            <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
              <input
                type="text"
                placeholder="Ask about business reports, stages, BOQ, advance payment..."
                value={inputChat}
                onChange={(e) => setInputChat(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendChat();
                  }
                }}
                disabled={isChatLoading}
                className="flex-1 bg-slate-100 border border-slate-200 text-xs rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium disabled:opacity-50"
              />
              <button
                onClick={() => handleSendChat()}
                disabled={!inputChat.trim() || isChatLoading}
                className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:bg-slate-300 text-white rounded-xl font-bold text-xs transition cursor-pointer shrink-0 flex items-center gap-1.5 shadow-xs disabled:cursor-not-allowed"
              >
                {isChatLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: ADD NEW CLIENT PROJECT MODAL                                     */}
      {/* ========================================================================= */}
      {isNewLeadModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-teal-700" /> Onboard New Client Project
              </h3>
              <button onClick={() => setIsNewLeadModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewLead} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Client / Company Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Al Hitmi Commercial Complex"
                  value={newClientName}
                  onChange={(e) => setNewClientName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Acquisition Channel</label>
                  <select
                    value={newClientChannel}
                    onChange={(e) => setNewClientChannel(e.target.value as LeadChannelType)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    <option value="LinkedIn (B2B)">LinkedIn (B2B)</option>
                    <option value="Referrals">Referrals</option>
                    <option value="Upwork / Fiverr">Upwork / Fiverr</option>
                    <option value="Direct Inbound">Direct Inbound</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Estimated Value (QAR)</label>
                  <input
                    type="number"
                    value={newClientValue}
                    onChange={(e) => setNewClientValue(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Project Scope Notes</label>
                <textarea
                  rows={2}
                  placeholder="Brief description of requirements (CCTV, Gate Barriers, Access Control)..."
                  value={newClientNotes}
                  onChange={(e) => setNewClientNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewLeadModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-md transition cursor-pointer"
                >
                  Create Client Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: UPLOAD DOCUMENT MODAL                                            */}
      {/* ========================================================================= */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Upload className="w-5 h-5 text-teal-700" /> Upload Document to Vault
              </h3>
              <button onClick={() => setIsUploadModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadDocument} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Document File Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MOI_Approved_Floor_Plan_v3.pdf"
                  value={docNameInput}
                  onChange={(e) => setDocNameInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Document Category</label>
                <select
                  value={docTypeInput}
                  onChange={(e) => setDocTypeInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer"
                >
                  <option value="MOI Approval">MOI Approval</option>
                  <option value="Testing Report">Testing Report</option>
                  <option value="BOQ & Contract">BOQ & Contract</option>
                  <option value="Compliance">Compliance</option>
                  <option value="Billing">Billing</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-md transition cursor-pointer"
                >
                  Upload File
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: ADD AMC MAINTENANCE LOG MODAL                                    */}
      {/* ========================================================================= */}
      {isAMCLogModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" /> Record AMC Service Log
              </h3>
              <button onClick={() => setIsAMCLogModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddAMCLog} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Service Type</label>
                  <select
                    value={amcLogType}
                    onChange={(e) => setAmcLogType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    <option value="Fix">Fix / Component Replacement</option>
                    <option value="System Update">System Update / Patch</option>
                    <option value="Repainting">Outdoor Repainting</option>
                    <option value="Inspection">Routine Inspection</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Performed By</label>
                  <input
                    type="text"
                    value={amcLogTech}
                    onChange={(e) => setAmcLogTech(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Service Details & Notes *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe maintenance work performed..."
                  value={amcLogNotes}
                  onChange={(e) => setAmcLogNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAMCLogModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition cursor-pointer"
                >
                  Record Service Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
