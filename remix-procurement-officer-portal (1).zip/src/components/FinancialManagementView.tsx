import React, { useState, useMemo } from 'react';
import {
  ProjectBudgetRecord,
  ClientInvoiceRecord,
  ProjectExpenseRecord,
} from '../types';
import { useAppData } from '../context/useAppData';
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  FileCheck2,
  AlertCircle,
  Plus,
  Search,
  CheckCircle2,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Building2,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface FinancialManagementViewProps {
  budgets: ProjectBudgetRecord[];
  invoices: ClientInvoiceRecord[];
  expenses: ProjectExpenseRecord[];
  onUpdateBudgets: (data: ProjectBudgetRecord[]) => void;
  onUpdateInvoices: (data: ClientInvoiceRecord[]) => void;
  onUpdateExpenses: (data: ProjectExpenseRecord[]) => void;
  onOpenQuickAdd: () => void;
}

export const FinancialManagementView: React.FC<FinancialManagementViewProps> = ({
  budgets,
  invoices,
  expenses,
  onUpdateBudgets,
  onUpdateInvoices,
  onUpdateExpenses,
}) => {
  const { setIsGeminiIntelligenceOpen, setGeminiIntelligenceMode } = useAppData();
  const [activeTab, setActiveTab] = useState<'variance' | 'invoices' | 'expenses'>('variance');
  const [isAddInvoiceOpen, setIsAddInvoiceOpen] = useState(false);
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);

  // Financial KPIs
  const kpis = useMemo(() => {
    const totalContractedRevenue = budgets.reduce((sum, b) => sum + b.totalBudgetQAR, 0);
    const totalActualCosts = budgets.reduce((sum, b) => sum + b.totalActualQAR, 0);
    const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.amountQAR, 0);
    const totalCollected = invoices.filter(inv => inv.status === 'Paid').reduce((sum, inv) => sum + inv.paidAmountQAR, 0);
    const outstandingReceivables = totalInvoiced - totalCollected;
    const avgProfitMargin = budgets.length > 0 ? (budgets.reduce((sum, b) => sum + b.profitMarginPercent, 0) / budgets.length).toFixed(1) : '32.0';

    return {
      totalContractedRevenue,
      totalActualCosts,
      totalCollected,
      outstandingReceivables,
      avgProfitMargin,
    };
  }, [budgets, invoices]);

  // Form states
  const [newInvoice, setNewInvoice] = useState<Partial<ClientInvoiceRecord>>({
    invoiceId: `INV-2026-${String(invoices.length + 101).padStart(3, '0')}`,
    invoiceNumber: `INV-2026-${String(invoices.length + 101).padStart(3, '0')}`,
    projectId: 'PRJ-2026-01',
    projectName: 'Hamad Port Logistics Security Package',
    clientName: 'Mwani Qatar',
    amountQAR: 150000,
    paidAmountQAR: 0,
    invoiceDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
    status: 'Sent',
    notes: '2nd Fix Cabling Milestone (30%)',
  });

  const [newExpense, setNewExpense] = useState<Partial<ProjectExpenseRecord>>({
    expenseId: `EXP-2026-${String(expenses.length + 101).padStart(3, '0')}`,
    projectId: 'PRJ-2026-01',
    projectName: 'Hamad Port Logistics Security Package',
    category: 'Procurement / Freight',
    description: 'Cat6A LSZH 500m Drums (10 Rolls)',
    amountQAR: 14500,
    date: new Date().toISOString().split('T')[0],
    paidBy: 'Site Engineer Tariq',
    status: 'Approved',
    approvedBy: 'Financial Controller',
  });

  const handleAddInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInvoice.clientName) return;
    const inv: ClientInvoiceRecord = {
      invoiceId: newInvoice.invoiceId || `INV-2026-${Date.now().toString().slice(-3)}`,
      invoiceNumber: newInvoice.invoiceNumber || newInvoice.invoiceId || `INV-2026-${Date.now().toString().slice(-3)}`,
      projectId: newInvoice.projectId || 'PRJ-2026-01',
      projectName: newInvoice.projectName || 'Security Project',
      clientName: newInvoice.clientName || 'Client',
      amountQAR: newInvoice.amountQAR || 0,
      paidAmountQAR: newInvoice.paidAmountQAR || 0,
      invoiceDate: newInvoice.invoiceDate || new Date().toISOString().split('T')[0],
      dueDate: newInvoice.dueDate || new Date().toISOString().split('T')[0],
      status: newInvoice.status || 'Sent',
      notes: newInvoice.notes || '',
    };
    onUpdateInvoices([inv, ...invoices]);
    setIsAddInvoiceOpen(false);
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpense.description) return;
    const exp: ProjectExpenseRecord = {
      expenseId: newExpense.expenseId || `EXP-${Date.now().toString().slice(-4)}`,
      projectId: newExpense.projectId || 'PRJ-2026-01',
      projectName: newExpense.projectName || 'Security Project',
      category: newExpense.category || 'Procurement / Freight',
      description: newExpense.description || '',
      amountQAR: newExpense.amountQAR || 0,
      date: newExpense.date || new Date().toISOString().split('T')[0],
      paidBy: newExpense.paidBy || 'Site Team',
      status: newExpense.status || 'Pending Approval',
      approvedBy: newExpense.approvedBy,
    };
    onUpdateExpenses([exp, ...expenses]);
    setIsAddExpenseOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 rounded-full border border-emerald-400/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <DollarSign className="w-3.5 h-3.5" />
            <span>Module 7 • Financial Management & Project Accounting</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
            Project Budgets, Milestones & Cash Flow
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl">
            Real-time project cost tracking (Hardware vs Labour vs Logistics), milestone billing vs actual collections, and site expense authorizations.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => {
              setGeminiIntelligenceMode('finance-audit');
              setIsGeminiIntelligenceOpen(true);
            }}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-emerald-200" />
            <span>AI 3-Way Match & Debit Note</span>
          </button>
          <button
            onClick={() => setIsAddInvoiceOpen(true)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Generate Client Invoice</span>
          </button>
          <button
            onClick={() => setIsAddExpenseOpen(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Log Site Expense</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Contract Value</span>
            <Building2 className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-xl font-extrabold text-slate-900">
            QAR {kpis.totalContractedRevenue.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-medium">Across active projects</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Actual Costs Incurred</span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-xl font-extrabold text-slate-900">
            QAR {kpis.totalActualCosts.toLocaleString()}
          </p>
          <p className="text-[11px] text-emerald-600 font-bold">Avg Margin: {kpis.avgProfitMargin}%</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Collections (Cash-in)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl font-extrabold text-emerald-600">
            QAR {kpis.totalCollected.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-medium">Cleared milestone cheques</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Outstanding Receivables</span>
            <AlertCircle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-xl font-extrabold text-rose-600">
            QAR {kpis.outstandingReceivables.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-medium">Pending client releases</p>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('variance')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'variance'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>1. Project Cost Budget vs Actual Variance ({budgets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('invoices')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'invoices'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>2. Client Milestone Invoices ({invoices.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'expenses'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>3. Site Petty Cash & Expenses ({expenses.length})</span>
        </button>
      </div>

      {/* TAB 1: BUDGET VS ACTUAL VARIANCE */}
      {activeTab === 'variance' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">
              Project Level Profitability & Cost Breakdown
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Project & Client</th>
                  <th className="py-3 px-4 text-right">Budget (QAR)</th>
                  <th className="py-3 px-4 text-right">Actual Cost (QAR)</th>
                  <th className="py-3 px-4 text-right">Hardware (B/A)</th>
                  <th className="py-3 px-4 text-right">Labour (B/A)</th>
                  <th className="py-3 px-4 text-right">Variance</th>
                  <th className="py-3 px-4 text-center">Margin %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {budgets.map((b) => {
                  const isUnderBudget = b.varianceQAR <= 0;
                  return (
                    <tr key={b.budgetId} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-slate-900">{b.projectName}</p>
                        <p className="text-[11px] text-slate-500 font-medium">Client: {b.clientName}</p>
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        {b.totalBudgetQAR.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-700">
                        {b.totalActualQAR.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-[11px]">
                        <span className="text-slate-900 font-bold">{b.hardwareBudgetQAR.toLocaleString()}</span> / <span className="text-slate-500">{b.hardwareActualQAR.toLocaleString()}</span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-[11px]">
                        <span className="text-slate-900 font-bold">{b.labourBudgetQAR.toLocaleString()}</span> / <span className="text-slate-500">{b.labourActualQAR.toLocaleString()}</span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className={`font-bold px-2 py-0.5 rounded-md text-[11px] ${
                          isUnderBudget ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {isUnderBudget ? `-${Math.abs(b.varianceQAR).toLocaleString()} (Saving)` : `+${b.varianceQAR.toLocaleString()} (Over)`}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-indigo-50 text-indigo-800">
                          {b.profitMarginPercent}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: CLIENT INVOICES */}
      {activeTab === 'invoices' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">
              Client Milestone Invoicing & Collections
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Project & Client</th>
                  <th className="py-3 px-4">Milestone / Description</th>
                  <th className="py-3 px-4 text-right">Amount (QAR)</th>
                  <th className="py-3 px-4">Issue / Due Date</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((inv) => (
                  <tr key={inv.invoiceId} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-emerald-600">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{inv.projectName}</p>
                      <p className="text-[11px] text-slate-500 font-medium">{inv.clientName}</p>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700 font-medium">
                      {inv.notes || 'Project Milestone Payment'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-extrabold text-slate-900">
                      {inv.amountQAR.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <p className="font-medium">{inv.invoiceDate}</p>
                      <p className="text-[10px] text-slate-400">Due: {inv.dueDate}</p>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                        inv.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : inv.status === 'Overdue'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SITE EXPENSES */}
      {activeTab === 'expenses' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">
              Site Logistics, Consumables & Overtime Authorizations
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Expense ID</th>
                  <th className="py-3 px-4">Project</th>
                  <th className="py-3 px-4">Category & Description</th>
                  <th className="py-3 px-4 text-right">Amount (QAR)</th>
                  <th className="py-3 px-4">Paid By</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses.map((exp) => (
                  <tr key={exp.expenseId} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-700">
                      {exp.expenseId}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {exp.projectName}
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-800">{exp.category}</p>
                      <p className="text-[11px] text-slate-500">{exp.description}</p>
                    </td>
                    <td className="py-3.5 px-4 text-right font-extrabold text-slate-900">
                      {exp.amountQAR.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-medium">
                      {exp.paidBy}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {exp.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD INVOICE */}
      {isAddInvoiceOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Generate Milestone Invoice</h3>
              <button
                onClick={() => setIsAddInvoiceOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddInvoice} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                <input
                  type="text"
                  required
                  value={newInvoice.clientName}
                  onChange={(e) => setNewInvoice({ ...newInvoice, clientName: e.target.value })}
                  placeholder="e.g. Mwani Qatar"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newInvoice.projectName}
                  onChange={(e) => setNewInvoice({ ...newInvoice, projectName: e.target.value })}
                  placeholder="e.g. Hamad Port CCTV Upgrade"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Amount (QAR)</label>
                  <input
                    type="number"
                    required
                    value={newInvoice.amountQAR}
                    onChange={(e) => setNewInvoice({ ...newInvoice, amountQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Milestone Linked</label>
                  <input
                    type="text"
                    value={newInvoice.notes}
                    onChange={(e) => setNewInvoice({ ...newInvoice, notes: e.target.value })}
                    placeholder="e.g. 50% Material Supply"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddInvoiceOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Create Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD EXPENSE */}
      {isAddExpenseOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Record Site Expense</h3>
              <button
                onClick={() => setIsAddExpenseOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Expense Description</label>
                <input
                  type="text"
                  required
                  value={newExpense.description}
                  onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
                  placeholder="e.g. Scaffolding rental for high-bay warehouse cameras"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={newExpense.category}
                    onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Procurement / Freight">Procurement / Freight</option>
                    <option value="Site Transport / Logistics">Site Transport / Logistics</option>
                    <option value="Labour Overtime">Labour Overtime</option>
                    <option value="Tools & Consumables">Tools & Consumables</option>
                    <option value="MOI Submission & Gov Fees">MOI Submission & Gov Fees</option>
                    <option value="Client Hospitality & Meeting">Client Hospitality & Meeting</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Amount (QAR)</label>
                  <input
                    type="number"
                    required
                    value={newExpense.amountQAR}
                    onChange={(e) => setNewExpense({ ...newExpense, amountQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Paid By / Site Engineer</label>
                <input
                  type="text"
                  value={newExpense.paidBy}
                  onChange={(e) => setNewExpense({ ...newExpense, paidBy: e.target.value })}
                  placeholder="e.g. Site Supervisor Tariq"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddExpenseOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Log Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
