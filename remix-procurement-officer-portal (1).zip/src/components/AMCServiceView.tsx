import React, { useState, useMemo } from 'react';
import {
  AMCMasterRecord,
  ServiceTicketRecord,
  TechnicianSchedule,
} from '../types';
import { useAppData } from '../context/useAppData';
import {
  Wrench,
  FileCheck2,
  Calendar,
  AlertTriangle,
  Clock,
  Plus,
  Search,
  CheckCircle2,
  Phone,
  Smartphone,
  PenTool,
  Users,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface AMCServiceViewProps {
  contracts: AMCMasterRecord[];
  tickets: ServiceTicketRecord[];
  schedules: TechnicianSchedule[];
  onUpdateContracts: (data: AMCMasterRecord[]) => void;
  onUpdateTickets: (data: ServiceTicketRecord[]) => void;
  onUpdateSchedules: (data: TechnicianSchedule[]) => void;
  onOpenQuickAdd: () => void;
}

export const AMCServiceView: React.FC<AMCServiceViewProps> = ({
  contracts,
  tickets,
  schedules,
  onUpdateContracts,
  onUpdateTickets,
  onUpdateSchedules,
}) => {
  const { setIsGeminiIntelligenceOpen, setGeminiIntelligenceMode } = useAppData();
  const [activeTab, setActiveTab] = useState<'contracts' | 'tickets' | 'field-mobile' | 'schedules'>('tickets');
  const [ticketSearch, setTicketSearch] = useState('');
  const [isAddTicketOpen, setIsAddTicketOpen] = useState(false);
  const [isAddContractOpen, setIsAddContractOpen] = useState(false);

  // Field Technician Simulator state
  const [activeFieldTicketId, setActiveFieldTicketId] = useState<string>(tickets[0]?.ticketId || 'TCK-2026-501');
  const [fieldSignatureDone, setFieldSignatureDone] = useState(false);
  const [fieldPartsUsed, setFieldPartsUsed] = useState('1 x Hikvision 8-Port PoE Switch DS-3E0508P-E');
  const [fieldTechNotes, setFieldTechNotes] = useState('Replaced blown PoE switch on Floor 3 riser, verified all 7 dome camera live feeds on VMS.');

  const activeTicket = tickets.find(t => t.ticketId === activeFieldTicketId) || tickets[0];

  // Expiry alerts for AMC contracts (under 60 days)
  const expiringContracts = useMemo(() => {
    return contracts.filter(c => c.daysToExpiry <= 60 && c.status === 'Active');
  }, [contracts]);

  // Form states
  const [newTicket, setNewTicket] = useState<Partial<ServiceTicketRecord>>({
    ticketId: `TCK-${new Date().getFullYear()}-${String(tickets.length + 501).padStart(3, '0')}`,
    clientName: '',
    amcRefId: 'AMC-2026-01',
    category: 'CCTV Camera Offline',
    description: '',
    priority: 'High',
    status: 'New',
    createdDate: new Date().toISOString().split('T')[0],
    targetResolutionDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    assignedTechnician: 'Mohammed ELV Specialist',
    slaMet: 'In Progress',
    siteLocation: 'Doha Commercial District',
    workNotes: '',
  });

  const [newContract, setNewContract] = useState<Partial<AMCMasterRecord>>({
    amcId: `AMC-${new Date().getFullYear()}-${String(contracts.length + 1).padStart(2, '0')}`,
    clientName: '',
    projectName: '',
    annualValueQAR: 120000,
    contractType: 'Enterprise Comprehensive',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0],
    slaResponseTimeHours: 2,
    slaResolutionTimeHours: 12,
    status: 'Active',
    renewalReminderDate: new Date(Date.now() + 320 * 86400000).toISOString().split('T')[0],
    billingFrequency: 'Quarterly',
    moiApprovedContractor: true,
    contactPerson: 'Eng. Tariq',
    contactPhone: '+974 5500 1122',
    daysToExpiry: 365,
    renewalAlertStage: 'Healthy',
  });

  const handleAddTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicket.clientName || !newTicket.description) return;
    onUpdateTickets([newTicket as ServiceTicketRecord, ...tickets]);
    setIsAddTicketOpen(false);
  };

  const handleAddContract = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContract.clientName) return;
    onUpdateContracts([newContract as AMCMasterRecord, ...contracts]);
    setIsAddContractOpen(false);
  };

  const handleCompleteFieldTicket = () => {
    const updated = tickets.map(t => {
      if (t.ticketId === activeTicket?.ticketId) {
        return {
          ...t,
          status: 'Resolved' as const,
          workNotes: fieldTechNotes,
          partsUsed: fieldPartsUsed,
          actualResolutionDate: new Date().toISOString().split('T')[0],
          slaMet: 'Yes' as const,
        };
      }
      return t;
    });
    onUpdateTickets(updated);
    setFieldSignatureDone(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/20 rounded-full border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Wrench className="w-3.5 h-3.5" />
            <span>Module 5 • AMC & Service Management</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
            Annual Maintenance Contracts & Helpdesk
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl">
            SLA ticket dispatching, preventive maintenance schedules, 24/7 emergency response, contract renewal workflows, and mobile field technician digital job cards.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => {
              setGeminiIntelligenceMode('amc-diagnostic');
              setIsGeminiIntelligenceOpen(true);
            }}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-amber-200" />
            <span>AI Troubleshooting & SLA Defense</span>
          </button>
          <button
            onClick={() => setIsAddTicketOpen(true)}
            className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Log Emergency Ticket</span>
          </button>
          <button
            onClick={() => setIsAddContractOpen(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>New AMC Contract</span>
          </button>
        </div>
      </div>

      {/* Renewal Notification Bar if any contract expiring soon */}
      {expiringContracts.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-amber-500 text-white rounded-xl flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-xs text-amber-950">
                {expiringContracts.length} AMC Contracts in Renewal Window (&le;60 Days)
              </h4>
              <p className="text-[11px] text-amber-800">
                {expiringContracts.map(c => `${c.clientName} (${c.daysToExpiry} days left)`).join(' • ')}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('contracts')}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shrink-0"
          >
            Review Renewals
          </button>
        </div>
      )}

      {/* Sub-Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('tickets')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'tickets'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>1. Service Ticket Helpdesk ({tickets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('contracts')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'contracts'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>2. AMC Master Contracts ({contracts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('field-mobile')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'field-mobile'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>3. Mobile Field Technician View (Live Simulation)</span>
        </button>

        <button
          onClick={() => setActiveTab('schedules')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'schedules'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>4. Preventive PPM Scheduling ({schedules.length})</span>
        </button>
      </div>

      {/* TAB 1: SERVICE TICKET HELPDESK */}
      {activeTab === 'tickets' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="font-extrabold text-sm text-slate-900">
              Active Security Service Tickets & Emergency Calls
            </h3>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search ticket, client..."
                value={ticketSearch}
                onChange={(e) => setTicketSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Ticket ID</th>
                  <th className="py-3 px-4">Client & Location</th>
                  <th className="py-3 px-4">Issue Description</th>
                  <th className="py-3 px-4">Priority & SLA</th>
                  <th className="py-3 px-4">Assigned Tech</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tickets.map((tck) => {
                  let priorityColor = 'bg-slate-100 text-slate-700';
                  if (tck.priority === 'Critical') priorityColor = 'bg-rose-100 text-rose-800 font-bold';
                  if (tck.priority === 'High') priorityColor = 'bg-amber-100 text-amber-800 font-bold';
                  if (tck.priority === 'Medium') priorityColor = 'bg-blue-100 text-blue-800 font-bold';

                  return (
                    <tr key={tck.ticketId} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-indigo-600">
                        {tck.ticketId}
                      </td>
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-slate-900">{tck.clientName}</p>
                        <p className="text-[11px] text-slate-500">{tck.siteLocation}</p>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 max-w-sm">
                        <p className="font-medium">{tck.description}</p>
                        {tck.partsUsed && (
                          <p className="text-[10px] text-indigo-600 mt-0.5">Parts: {tck.partsUsed}</p>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-md text-[10px] ${priorityColor}`}>
                          {tck.priority}
                        </span>
                        <p className="text-[10px] text-slate-500 mt-1">Target: {tck.targetResolutionDate}</p>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        {tck.assignedTechnician}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                          tck.status === 'Resolved' || tck.status === 'Closed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : tck.status === 'In Progress'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {tck.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setActiveFieldTicketId(tck.ticketId);
                            setActiveTab('field-mobile');
                          }}
                          className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition cursor-pointer"
                        >
                          Field Job Card
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: AMC MASTER CONTRACTS */}
      {activeTab === 'contracts' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {contracts.map((amc) => (
            <div
              key={amc.amcId}
              className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs hover:shadow-xs transition space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                    {amc.amcId}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    amc.daysToExpiry <= 60 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {amc.daysToExpiry > 0 ? `${amc.daysToExpiry} days left` : 'Expired'}
                  </span>
                </div>

                <h4 className="font-extrabold text-sm text-slate-900">{amc.projectName}</h4>
                <p className="text-xs text-slate-500 font-medium">Client: <strong className="text-slate-700">{amc.clientName}</strong></p>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1 text-xs">
                  <p><strong className="text-slate-700">Contract Type:</strong> {amc.contractType}</p>
                  <p><strong className="text-slate-700">Billing:</strong> {amc.billingFrequency}</p>
                  <p><strong className="text-slate-700">Emergency SLA:</strong> {amc.slaResponseTimeHours} Hours Response</p>
                  <p><strong className="text-slate-700">MOI Approved:</strong> {amc.moiApprovedContractor ? 'Included ✓' : 'Excluded'}</p>
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">Annual Value</span>
                  <span className="text-base font-extrabold text-slate-900">
                    QAR {amc.annualValueQAR.toLocaleString()}
                  </span>
                </div>

                <button
                  onClick={() => {
                    alert(`Generated Renewal Quotation for ${amc.clientName} with 5% indexation.`);
                  }}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Generate Renewal Quote</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: MOBILE FIELD TECHNICIAN VIEW (LIVE SIMULATION) */}
      {activeTab === 'field-mobile' && activeTicket && (
        <div className="max-w-md mx-auto bg-slate-900 rounded-[40px] p-4 shadow-2xl border-4 border-slate-800 text-slate-900 space-y-4">
          {/* Mobile Screen Header */}
          <div className="bg-slate-950 text-white p-4 rounded-3xl space-y-2 border border-slate-800">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Amazetec Field Tech v2.4</span>
              <span className="font-bold text-emerald-400">● 5G Online</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-sm text-white">Technician Mohammed A.</h4>
                <p className="text-[10px] text-slate-400">Badge: #AZT-TECH-04 • Doha</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-xs">
                MA
              </div>
            </div>
          </div>

          {/* Active Job Card */}
          <div className="bg-white rounded-3xl p-5 space-y-4 shadow-inner">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                  {activeTicket.priority} Priority
                </span>
                <h5 className="font-extrabold text-sm text-slate-900 mt-1">{activeTicket.ticketId}</h5>
              </div>
              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-800">
                {activeTicket.status}
              </span>
            </div>

            <div className="space-y-1 text-xs">
              <p className="font-bold text-slate-900">{activeTicket.clientName}</p>
              <p className="text-slate-600 text-[11px]">{activeTicket.siteLocation}</p>
              <p className="text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-200 mt-1">
                <strong>Fault:</strong> {activeTicket.description}
              </p>
            </div>

            {/* Field Actions */}
            <div className="space-y-3 pt-2 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Spare Parts Consumed</label>
                <input
                  type="text"
                  value={fieldPartsUsed}
                  onChange={(e) => setFieldPartsUsed(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl font-medium text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Field Diagnostic & Resolution Summary</label>
                <textarea
                  rows={2}
                  value={fieldTechNotes}
                  onChange={(e) => setFieldTechNotes(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl font-medium text-xs"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-center space-y-2">
                <p className="text-[11px] font-bold text-slate-700 flex items-center justify-center gap-1">
                  <PenTool className="w-3 h-3 text-indigo-600" />
                  <span>Client Digital Signature on Glass</span>
                </p>
                <div className="h-16 bg-white border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center text-slate-400 font-cursive text-sm">
                  {fieldSignatureDone ? (
                    <span className="text-emerald-700 font-bold font-sans flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Signed by Site Facility Manager
                    </span>
                  ) : (
                    'Tap to capture signature'
                  )}
                </div>
              </div>

              <button
                onClick={handleCompleteFieldTicket}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-extrabold text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Job Card & Close SLA</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PPM SCHEDULES */}
      {activeTab === 'schedules' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {schedules.map((sch) => (
            <div key={sch.scheduleId} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">{sch.scheduleId}</h4>
                  <p className="text-[11px] text-slate-500 font-medium">Ticket / Project: {sch.ticketId || sch.projectId || 'Site PPM'}</p>
                </div>
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-100 text-blue-800">
                  {sch.status}
                </span>
              </div>

              <div className="space-y-1 text-xs text-slate-600">
                <p><strong className="text-slate-800">Scheduled Date:</strong> {sch.scheduledDate} at {sch.scheduledTime}</p>
                <p><strong className="text-slate-800">Assigned Team:</strong> {sch.technicianName}</p>
                <p className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <strong>PPM Scope:</strong> {sch.preVisitNotes}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL: ADD TICKET */}
      {isAddTicketOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Log Emergency Service Ticket</h3>
              <button
                onClick={() => setIsAddTicketOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddTicket} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                <input
                  type="text"
                  required
                  value={newTicket.clientName}
                  onChange={(e) => setNewTicket({ ...newTicket, clientName: e.target.value })}
                  placeholder="e.g. Lusail Commercial Tower B"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Issue / Fault Description</label>
                <textarea
                  rows={2}
                  required
                  value={newTicket.description}
                  onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                  placeholder="e.g. NVR 2 hard drive degraded warning, 4 perimeter cameras offline"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Priority Level</label>
                  <select
                    value={newTicket.priority}
                    onChange={(e) => setNewTicket({ ...newTicket, priority: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Critical">Critical (2h SLA)</option>
                    <option value="High">High (4h SLA)</option>
                    <option value="Medium">Medium (8h SLA)</option>
                    <option value="Low">Low (24h SLA)</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Assigned Technician</label>
                  <input
                    type="text"
                    value={newTicket.assignedTechnician}
                    onChange={(e) => setNewTicket({ ...newTicket, assignedTechnician: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddTicketOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Dispatch Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
