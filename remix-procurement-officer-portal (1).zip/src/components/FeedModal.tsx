import React, { useState } from 'react';
import {
  X,
  UploadCloud,
  FileSpreadsheet,
  FileText,
  Image as ImageIcon,
  Bot,
  Send,
  Sparkles,
  CheckCircle2,
  Database,
  Zap,
  Trash2,
  RefreshCw,
  Eye,
  ArrowRight,
  FileCode,
  FileType,
  FileSearch,
} from 'lucide-react';

interface FeedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFeedSuccess?: (summary: string) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  parsedSummary?: {
    recordType: string;
    itemCount: number;
    sample: string[];
  };
}

export interface ExtractedFile {
  id: string;
  file: File;
  name: string;
  size: number;
  typeLabel: string;
  imagePreviewUrl?: string;
  extractedText: string;
  isReading: boolean;
}

export const FeedModal: React.FC<FeedModalProps> = ({ isOpen, onClose, onFeedSuccess }) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'text' | 'ai'>('upload');

  // Multi-File Upload & Extraction State
  const [fileList, setFileList] = useState<ExtractedFile[]>([]);
  const [aiFileInstruction, setAiFileInstruction] = useState<string>('');
  const [isProcessingFiles, setIsProcessingFiles] = useState(false);
  const [fileFeedStatus, setFileFeedStatus] = useState<string | null>(null);
  const [expandedFileId, setExpandedFileId] = useState<string | null>(null);

  // Large Text Form State
  const [rawTextData, setRawTextData] = useState<string>('');
  const [dataTypeCategory, setDataTypeCategory] = useState<string>('components');
  const [isFeedingText, setIsFeedingText] = useState(false);
  const [textFeedStatus, setTextFeedStatus] = useState<string | null>(null);

  // AI Chat Assistant State
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: 'Hello! I am your Procurement & Data Ingestion AI. Paste raw quotation data, upload multiple supplier catalogs (PDF, Word, Images OCR, Excel), or prompt me to structure your bulk records with custom remarks for immediate database feeding.',
      timestamp: 'Just now',
    },
  ]);
  const [isAiThinking, setIsAiThinking] = useState(false);

  if (!isOpen) return null;

  // Process a single file object and return ExtractedFile
  const processSingleFile = (file: File): Promise<ExtractedFile> => {
    return new Promise((resolve) => {
      const id = 'file-' + Math.random().toString(36).substring(2, 9);
      const fileName = file.name.toLowerCase();
      let typeLabel = 'Document';
      let previewUrl: string | undefined = undefined;

      if (file.type.startsWith('image/') || fileName.match(/\.(png|jpg|jpeg|webp|gif|bmp)$/)) {
        typeLabel = 'Image (OCR Text)';
        previewUrl = URL.createObjectURL(file);
      } else if (fileName.endsWith('.pdf')) {
        typeLabel = 'PDF Document';
      } else if (fileName.endsWith('.docx') || fileName.endsWith('.doc')) {
        typeLabel = 'Word Document';
      } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
        typeLabel = 'Excel Spreadsheet';
      } else if (fileName.endsWith('.csv')) {
        typeLabel = 'CSV Dataset';
      } else if (fileName.endsWith('.json')) {
        typeLabel = 'JSON File';
      } else {
        typeLabel = 'Text File';
      }

      // Simulate reading and text extraction for each type
      setTimeout(() => {
        let extracted = '';
        if (typeLabel.includes('Image')) {
          extracted = `[OCR Extracted Text from ${file.name}]\n` +
            `Supplier: Qatar Security Solutions W.L.L.\n` +
            `Quotation Ref: QSS-2026-991 | Date: 2026-08-05\n` +
            `Item 1: 4MP ANPR Camera (DS-2CD7A26G0/P) - Qty: 8 - Rate: QAR 2,310.00\n` +
            `Item 2: Cat6A U/FTP Shielded Cable 305m (Belden 1855A) - Qty: 15 - Rate: QAR 850.00\n` +
            `Item 3: Cisco 48-Port PoE Switch (CBS350-48P) - Qty: 2 - Rate: QAR 10,439.00\n` +
            `MOI Qatar SSD Status: Certified & Compliant`;
        } else if (typeLabel.includes('PDF')) {
          extracted = `[PDF Extracted Text from ${file.name}]\n` +
            `Ezdan Upgrade Phase 2 BOQ Submittal\n` +
            `Section A: Active CCTV Hardware\n` +
            `- Hikvision 2MP Varifocal Dome Camera (DS-2CD2123G0-I) @ QAR 372.00 (Qty 45)\n` +
            `- Hikvision 32-Channel NVR (DS-9632NI-I8) @ QAR 4,850.00 (Qty 3)\n` +
            `- Workstation PC Dell Precision 3660 @ QAR 7,040.00 (Qty 2)\n` +
            `Section B: Passive Infrastructure\n` +
            `- Heavy-Duty Stainless Steel Pole Bracket (DS-1275ZJ-SUS) @ QAR 145.00 (Qty 20)\n` +
            `- APC Smart-UPS 1000VA LCD (SMT1000I) @ QAR 2,150.00 (Qty 4)`;
        } else if (typeLabel.includes('Word')) {
          extracted = `[Word Document Specs Extracted from ${file.name}]\n` +
            `Gulf Security Distribution Master Catalog & Discount Terms\n` +
            `NVR Enterprise Series (16Ch/32Ch/64Ch) - 12.5% Bulk Discount Applied\n` +
            `Thermal Body Temperature Surveillance Units - Approved by MOI Qatar\n` +
            `Fiber Optic Single Mode Patch Cords & Industrial DIN-Rail Switches`;
        } else if (typeLabel.includes('Excel')) {
          extracted = `[Excel Spreadsheet Data Parsed from ${file.name}]\n` +
            `CODE\tNAME\tBRAND\tMODEL\tPRICE_QAR\tMOI_STATUS\n` +
            `PRD-101\t2MP Dome Camera\tHikvision\tDS-2CD2123G0-I\t372.00\tAPPROVED\n` +
            `PRD-102\t4MP ANPR Camera\tHikvision\tDS-2CD7A26G0/P\t2310.00\tAPPROVED\n` +
            `PRD-103\tCat6A Cable 305m\tBelden\t1855A\t850.00\tAPPROVED\n` +
            `PRD-104\t48-Port Switch\tCisco\tCBS350-48P\t10439.00\tAPPROVED`;
        } else {
          const reader = new FileReader();
          reader.onload = (e) => {
            const txt = (e.target?.result as string) || '';
            resolve({
              id,
              file,
              name: file.name,
              size: file.size,
              typeLabel,
              imagePreviewUrl: previewUrl,
              extractedText: txt || `[Read Content from ${file.name}]`,
              isReading: false,
            });
          };
          reader.readAsText(file);
          return;
        }

        resolve({
          id,
          file,
          name: file.name,
          size: file.size,
          typeLabel,
          imagePreviewUrl: previewUrl,
          extractedText: extracted,
          isReading: false,
        });
      }, 600);
    });
  };

  // Multi-file handle
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles: File[] = Array.from(e.target.files);
      setFileFeedStatus(null);

      // Create placeholder loading items
      const loadingItems: ExtractedFile[] = selectedFiles.map((f: File) => ({
        id: 'loading-' + Math.random(),
        file: f,
        name: f.name,
        size: f.size,
        typeLabel: 'Processing...',
        extractedText: '',
        isReading: true,
      }));

      setFileList((prev) => [...prev, ...loadingItems]);

      // Process all files in parallel
      const processed = await Promise.all(selectedFiles.map(processSingleFile));

      // Replace loading items with processed items
      setFileList((prev) => {
        const filtered = prev.filter((item) => !item.isReading);
        return [...filtered, ...processed];
      });

      if (processed.length > 0) {
        setExpandedFileId(processed[0].id);
      }
    }
  };

  // Remove single file from batch
  const handleRemoveFile = (idToRemove: string) => {
    setFileList((prev) => {
      const item = prev.find((f) => f.id === idToRemove);
      if (item?.imagePreviewUrl) {
        URL.revokeObjectURL(item.imagePreviewUrl);
      }
      return prev.filter((f) => f.id !== idToRemove);
    });
  };

  // Clear all attached files
  const handleClearAllFiles = () => {
    fileList.forEach((f) => {
      if (f.imagePreviewUrl) URL.revokeObjectURL(f.imagePreviewUrl);
    });
    setFileList([]);
    setFileFeedStatus(null);
  };

  // Process and feed all files with AI instructions
  const handleProcessAllFiles = () => {
    if (fileList.length === 0) return;
    setIsProcessingFiles(true);

    setTimeout(() => {
      setIsProcessingFiles(false);
      const totalLines = fileList.reduce(
        (sum, f) => sum + (f.extractedText ? f.extractedText.split('\n').filter(Boolean).length : 1),
        0
      );
      const instructionText = aiFileInstruction.trim()
        ? ` with instruction/remark: "${aiFileInstruction.trim()}"`
        : '';

      setFileFeedStatus(
        `Successfully processed & fed ALL ${fileList.length} files (${totalLines} total lines of extracted data)${instructionText} into Database!`
      );

      if (onFeedSuccess) {
        onFeedSuccess(`Fed ${fileList.length} files into Database`);
      }
    }, 1200);
  };

  // Send all files text to Large Text Form
  const handleSendAllFilesToLargeForm = () => {
    const combined = fileList
      .map((f) => `=== FILE: ${f.name} (${f.typeLabel}) ===\n${f.extractedText}`)
      .join('\n\n');
    setRawTextData(combined);
    setActiveTab('text');
  };

  // Send all files text and AI remarks to AI Chat
  const handleSendAllFilesToAiChat = () => {
    const fileSummary = fileList
      .map((f, i) => `File ${i + 1}: ${f.name} (${f.typeLabel})\nText Snippet:\n${f.extractedText.slice(0, 200)}...`)
      .join('\n\n');

    const prompt = `Please process these ${fileList.length} attached files for database ingestion.\n` +
      (aiFileInstruction.trim() ? `\nUser Instructions / AI Remarks: "${aiFileInstruction.trim()}"\n\n` : '\n') +
      `Attached Files Content:\n${fileSummary}`;

    setChatInput(prompt);
    setActiveTab('ai');
  };

  // Text Form Handle
  const handleFeedTextData = () => {
    if (!rawTextData.trim()) return;
    setIsFeedingText(true);
    setTimeout(() => {
      setIsFeedingText(false);
      const lines = rawTextData.trim().split('\n').filter(Boolean).length;
      setTextFeedStatus(`Successfully ingested ${lines} data entries into ${dataTypeCategory.toUpperCase()} database!`);
      if (onFeedSuccess) onFeedSuccess(`Fed ${lines} text entries`);
    }, 1000);
  };

  // AI Chat Handle
  const handleSendChatMessage = () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: chatInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    const currentQuery = chatInput;
    setChatInput('');
    setIsAiThinking(true);

    setTimeout(() => {
      let aiText = "I have analyzed your request and structured the data for procurement feeding.";
      let summaryData;

      if (currentQuery.toLowerCase().includes('quotation') || currentQuery.toLowerCase().includes('quote')) {
        aiText = "Parsed quotation details! Extracted line items, total pricing, unit rates, and vendor terms. Ready to import into BOQ & Price History.";
        summaryData = {
          recordType: 'Vendor Quotation Records',
          itemCount: 8,
          sample: ['4MP ANPR Cameras (QAR 2,310/unit)', '48-Port Switches (QAR 10,439/unit)', 'Cat6A Shielded Cables'],
        };
      } else if (currentQuery.toLowerCase().includes('supplier') || currentQuery.toLowerCase().includes('vendor')) {
        aiText = "Supplier record processed! Updated vendor catalog, MOI registration status, contact leads, and trade categories.";
        summaryData = {
          recordType: 'Supplier Catalog Directory',
          itemCount: 4,
          sample: ['Hikvision Qatar (MOI Approved)', 'Belden Cables', 'DELL Technologies Qatar'],
        };
      } else {
        aiText = "Data structure verified against Master Security Equipment schema. Categorized into Active Components & Passive Infrastructure.";
        summaryData = {
          recordType: 'Equipment Components',
          itemCount: 12,
          sample: ['2MP Varifocal Dome Cameras', '16TB Surveillance HDDs', 'Heavy-Duty Mounting Brackets'],
        };
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        parsedSummary: summaryData,
      };

      setChatMessages((prev) => [...prev, aiMsg]);
      setIsAiThinking(false);
    }, 1100);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[88vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-indigo-900/50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-400/30 rounded-xl text-indigo-300">
              <Database className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">Data Feed & Ingestion Portal</h3>
                <span className="bg-indigo-500/20 text-indigo-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-indigo-400/30">
                  Database Feeder
                </span>
              </div>
              <p className="text-xs text-indigo-200/80">
                Read PDF, Word, Images (OCR), Excel, CSV & text files to feed your database
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Ingestion Mode Navigation Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 p-2.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 bg-slate-200/60 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'upload'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Choose File (Reader)</span>
            </button>

            <button
              onClick={() => setActiveTab('text')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'text'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Large Text Form</span>
            </button>

            <button
              onClick={() => setActiveTab('ai')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'ai'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bot className="w-3.5 h-3.5 text-indigo-600" />
              <span>AI Data Chat</span>
            </button>
          </div>

          <span className="hidden sm:inline-block text-[11px] font-semibold text-slate-400 pr-2">
            PDF • Word • Image OCR • Excel
          </span>
        </div>

        {/* Tab Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-slate-50/50">
          {/* TAB 1: FILE UPLOAD OPTION WITH ALL FILE TYPE READERS */}
          {activeTab === 'upload' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="text-center space-y-1">
                <h4 className="font-extrabold text-sm text-slate-900">Choose Files to Read & Extract Text</h4>
                <p className="text-xs text-slate-500">
                  Select multiple PDF, Word (.docx), Image (.png/.jpg OCR), Excel (.xlsx), CSV, JSON, or TXT files at once.
                </p>
              </div>

              {/* Supported Badges */}
              <div className="flex flex-wrap items-center justify-center gap-1.5 text-[10px] font-bold">
                <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-md border border-red-200">
                  📄 PDF
                </span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-md border border-blue-200">
                  📝 Word (.docx)
                </span>
                <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded-md border border-purple-200">
                  🖼️ Image (PNG/JPG OCR)
                </span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-md border border-emerald-200">
                  📊 Excel & CSV
                </span>
                <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-md border border-amber-200">
                  ⚙️ JSON & TXT
                </span>
              </div>

              {/* File Dropzone - Supports Multiple File Selection */}
              <label className="border-2 border-dashed border-indigo-200 hover:border-indigo-400 bg-indigo-50/30 hover:bg-indigo-50/60 p-6 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition text-center group">
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-indigo-100 text-indigo-600 group-hover:scale-105 transition flex items-center gap-2">
                  <FileText className="w-6 h-6 text-red-500" />
                  <ImageIcon className="w-6 h-6 text-purple-500" />
                  <FileSpreadsheet className="w-6 h-6 text-emerald-500" />
                </div>
                <div className="mt-3">
                  <span className="font-bold text-xs text-indigo-700 underline">Click to choose multiple files</span>
                  <span className="text-xs text-slate-500"> or drag & drop files here</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  You can select & attach multiple files at the same time
                </p>
                <input
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  accept=".pdf,.docx,.doc,.png,.jpg,.jpeg,.webp,.gif,.bmp,.xlsx,.xls,.csv,.json,.txt"
                  className="hidden"
                />
              </label>

              {/* Attached Files List & Reader Previews */}
              {fileList.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xs text-slate-800">
                        Attached Files ({fileList.length})
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded-full">
                        Text Extracted
                      </span>
                    </div>

                    <button
                      onClick={handleClearAllFiles}
                      className="text-[11px] font-bold text-slate-400 hover:text-rose-600 transition cursor-pointer flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear All</span>
                    </button>
                  </div>

                  {/* Individual File Cards */}
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {fileList.map((f) => {
                      const isExpanded = expandedFileId === f.id;
                      const lineCount = f.extractedText ? f.extractedText.split('\n').filter(Boolean).length : 0;

                      return (
                        <div key={f.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                          <div className="p-3 flex items-center justify-between gap-2 bg-slate-50/50">
                            <div className="flex items-center gap-2.5 min-w-0">
                              {f.imagePreviewUrl ? (
                                <img src={f.imagePreviewUrl} alt="Preview" className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0" />
                              ) : f.name.endsWith('.pdf') ? (
                                <FileText className="w-5 h-5 text-red-500 shrink-0" />
                              ) : f.name.endsWith('.docx') || f.name.endsWith('.doc') ? (
                                <FileType className="w-5 h-5 text-blue-500 shrink-0" />
                              ) : f.name.endsWith('.xlsx') || f.name.endsWith('.csv') ? (
                                <FileSpreadsheet className="w-5 h-5 text-emerald-500 shrink-0" />
                              ) : (
                                <FileCode className="w-5 h-5 text-amber-500 shrink-0" />
                              )}

                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <p className="font-bold text-xs text-slate-900 truncate">{f.name}</p>
                                  <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-indigo-50 text-indigo-700 border border-indigo-100 shrink-0">
                                    {f.typeLabel}
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-400 font-mono">
                                  {(f.size / 1024).toFixed(1)} KB • {f.isReading ? 'Reading text...' : `${lineCount} lines read`}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {!f.isReading && f.extractedText && (
                                <button
                                  onClick={() => setExpandedFileId(isExpanded ? null : f.id)}
                                  className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-lg transition flex items-center gap-1 cursor-pointer"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span>{isExpanded ? 'Hide' : 'View Text'}</span>
                                </button>
                              )}

                              <button
                                onClick={() => handleRemoveFile(f.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 transition rounded-lg cursor-pointer"
                                title="Remove file"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Expanded Text Preview */}
                          {isExpanded && f.extractedText && (
                            <div className="p-3 bg-slate-900 border-t border-slate-800 text-indigo-200 text-[11px] font-mono leading-relaxed max-h-36 overflow-y-auto whitespace-pre-wrap">
                              {f.extractedText}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* AI Instructions & Remark Note Box */}
                  <div className="p-3.5 bg-indigo-50/60 border border-indigo-200/80 rounded-2xl space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-indigo-900">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>AI Instruction / Remark Note for Attached Files</span>
                    </div>
                    <textarea
                      value={aiFileInstruction}
                      onChange={(e) => setAiFileInstruction(e.target.value)}
                      rows={2}
                      placeholder="Set instructions or notes for attached files (e.g., 'Extract unit prices into BOQ database', 'Classify as active security components', 'Compare against Hikvision reference rates')..."
                      className="w-full text-xs p-2.5 rounded-xl border border-indigo-200 bg-white text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition placeholder:text-slate-400"
                    />
                  </div>

                  {/* Batch Actions Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleSendAllFilesToLargeForm}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] rounded-xl transition flex items-center gap-1 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-slate-500" />
                        <span>Edit All in Text Form</span>
                      </button>
                      <button
                        onClick={handleSendAllFilesToAiChat}
                        className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] rounded-xl transition flex items-center gap-1 cursor-pointer"
                      >
                        <Bot className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Ask AI Chat</span>
                      </button>
                    </div>

                    <button
                      onClick={handleProcessAllFiles}
                      disabled={isProcessingFiles}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                    >
                      {isProcessingFiles ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Zap className="w-3.5 h-3.5" />
                      )}
                      <span>Feed All {fileList.length} Files with Instructions</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Status Banner */}
              {fileFeedStatus && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{fileFeedStatus}</span>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: LARGE INPUT TEXT FORM */}
          {activeTab === 'text' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">Large Input Text Form</h4>
                  <p className="text-xs text-slate-500">
                    Paste large raw text, tabular component specs, previous quotations, or supplier records.
                  </p>
                </div>

                {/* Target Category Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-600">Feed Target:</span>
                  <select
                    value={dataTypeCategory}
                    onChange={(e) => setDataTypeCategory(e.target.value)}
                    className="text-xs font-bold bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs"
                  >
                    <option value="components">Security Components & Hardware</option>
                    <option value="quotations">Past Vendor Quotations & Rates</option>
                    <option value="suppliers">Supplier & Vendor Directory</option>
                    <option value="boq">Master BOQ Line Items</option>
                  </select>
                </div>
              </div>

              {/* Large Text Area */}
              <div className="relative">
                <textarea
                  rows={10}
                  value={rawTextData}
                  onChange={(e) => setRawTextData(e.target.value)}
                  placeholder={`Paste your large dataset here...\n\nExample format:\nProduct Code | Item Description | Brand | Model | Unit Price (QAR)\nPRD-101 | 4MP Dome Camera | Hikvision | DS-2CD2143G0-I | 420.00\nPRD-102 | Cat6 Cable Box 305m | Belden | 1855A | 780.00\nPRD-103 | 24-Port Switch | Cisco | CBS350-24T | 2,150.00`}
                  className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-xs font-mono text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition shadow-inner leading-relaxed"
                />
                {rawTextData && (
                  <button
                    onClick={() => setRawTextData('')}
                    className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-lg transition"
                  >
                    Clear Text
                  </button>
                )}
              </div>

              {/* Feed Action Button */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] font-medium text-slate-400">
                  {rawTextData.trim() ? `${rawTextData.trim().split('\n').length} lines detected` : 'Ready for text ingestion'}
                </span>

                <button
                  onClick={handleFeedTextData}
                  disabled={!rawTextData.trim() || isFeedingText}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {isFeedingText ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Database className="w-4 h-4" />
                  )}
                  <span>Feed Text Data into Database</span>
                </button>
              </div>

              {textFeedStatus && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{textFeedStatus}</span>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: AI CHAT ASSISTANT FORM */}
          {activeTab === 'ai' && (
            <div className="flex flex-col h-full space-y-3">
              {/* Quick AI Prompts */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-semibold shrink-0">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span className="text-[11px] text-slate-400 shrink-0">AI Templates:</span>
                {[
                  'Extract items from pasted quote',
                  'Categorize Active vs Passive infrastructure',
                  'Format supplier prices in QAR',
                  'Structure Hikvision & Dahua specs',
                ].map((promptText, idx) => (
                  <button
                    key={idx}
                    onClick={() => setChatInput(promptText)}
                    className="bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-slate-700 text-[11px] font-semibold px-2.5 py-1 rounded-lg shrink-0 transition cursor-pointer"
                  >
                    {promptText}
                  </button>
                ))}
              </div>

              {/* Chat Thread */}
              <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-4 overflow-y-auto space-y-3 shadow-2xs">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 ${
                      msg.sender === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {msg.sender === 'ai' && (
                      <div className="p-2 bg-indigo-100 text-indigo-700 rounded-xl shrink-0 mt-0.5">
                        <Bot className="w-4 h-4" />
                      </div>
                    )}

                    <div
                      className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-indigo-600 text-white rounded-br-xs'
                          : 'bg-slate-100 text-slate-800 rounded-bl-xs'
                      }`}
                    >
                      <p className="font-medium whitespace-pre-wrap">{msg.text}</p>

                      {msg.parsedSummary && (
                        <div className="mt-2.5 p-2.5 bg-white rounded-xl border border-slate-200/80 text-slate-900 font-sans space-y-1.5">
                          <div className="flex items-center justify-between text-[11px] font-bold text-indigo-700">
                            <span>{msg.parsedSummary.recordType}</span>
                            <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px]">
                              {msg.parsedSummary.itemCount} items structured
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono space-y-0.5">
                            {msg.parsedSummary.sample.map((s, idx) => (
                              <div key={idx} className="truncate">
                                • {s}
                              </div>
                            ))}
                          </div>
                          <button
                            onClick={() => {
                              if (onFeedSuccess) onFeedSuccess(`Fed ${msg.parsedSummary?.recordType}`);
                            }}
                            className="w-full mt-1 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] rounded-lg transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Confirm & Import to Database</span>
                          </button>
                        </div>
                      )}

                      <span className={`text-[9px] block mt-1 ${msg.sender === 'user' ? 'text-indigo-200 text-right' : 'text-slate-400'}`}>
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ))}

                {isAiThinking && (
                  <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 bg-indigo-50 p-2.5 rounded-xl w-fit animate-pulse">
                    <Bot className="w-4 h-4 animate-spin" />
                    <span>AI is parsing and structuring dataset for database ingestion...</span>
                  </div>
                )}
              </div>

              {/* Chat Input Bar */}
              <div className="flex items-center gap-2 shrink-0">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                  placeholder="Ask AI to process, format, or feed dataset (e.g. 'Format this quote into active BOQ')..."
                  className="flex-1 p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition shadow-2xs"
                />
                <button
                  onClick={handleSendChatMessage}
                  disabled={!chatInput.trim() || isAiThinking}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-3 sm:px-5 border-t border-slate-200 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>Database Feeding Engine Active</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition cursor-pointer text-xs"
          >
            Close Feed Window
          </button>
        </div>
      </div>
    </div>
  );
};


