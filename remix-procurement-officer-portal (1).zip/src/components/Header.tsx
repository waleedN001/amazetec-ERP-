import React from 'react';
import { Building2, PanelLeft, PanelLeftClose } from 'lucide-react';
import { ViewMode } from '../types';

interface HeaderProps {
  viewMode?: ViewMode;
  onViewModeChange?: (mode: ViewMode) => void;
  onExportMasterExcel: () => void;
  onOpenQuickAdd?: () => void;
  onOpenFeed?: () => void;
  onOpenGeminiChat?: () => void;
  onOpenGeminiIntelligence?: () => void;
  globalSearch?: string;
  onGlobalSearchChange?: (search: string) => void;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isSidebarOpen = true,
  onToggleSidebar,
}) => {
  return (
    <header className="bg-white border-b border-slate-200 px-4 md:px-6 py-3 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-20 shadow-2xs">
      <div className="flex items-center gap-3">
        {onToggleSidebar && (
          <button
            id="header-sidebar-toggle-btn"
            onClick={onToggleSidebar}
            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 rounded-xl transition cursor-pointer flex items-center justify-center shadow-2xs"
            title={isSidebarOpen ? 'Hide Sidebar' : 'Show Sidebar'}
          >
            {isSidebarOpen ? (
              <PanelLeftClose className="w-4 h-4" />
            ) : (
              <PanelLeft className="w-4 h-4 text-indigo-600" />
            )}
          </button>
        )}

        <div className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-indigo-600" />
          <h2 className="font-bold text-slate-900 text-base tracking-tight">
            Amazetec Master ERP Portal
          </h2>
        </div>
      </div>

      {/* System Status Pill */}
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200/80 rounded-full text-2xs font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          Qatar ELV & Security ERP • Live
        </span>
      </div>
    </header>
  );
};


