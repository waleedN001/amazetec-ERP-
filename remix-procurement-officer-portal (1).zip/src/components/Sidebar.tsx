import React from 'react';
import {
  ShoppingBag,
  History,
  MessageSquareText,
  ShieldCheck,
  Users,
  Briefcase,
  LayoutDashboard,
  ShieldAlert,
  Milestone,
  Scale,
  ClipboardList,
  Target,
  Wrench,
  Package,
  DollarSign,
  Globe,
  PanelLeftClose,
  Sparkles,
} from 'lucide-react';
import { RoleTab, ProcurementSubModule } from '../types';

interface SidebarProps {
  activeTab: RoleTab;
  onTabChange: (tab: RoleTab) => void;
  activeSubModule?: ProcurementSubModule;
  onSubModuleChange?: (sub: ProcurementSubModule) => void;
  totalProjects?: number;
  activeEmployees?: number;
  isOpen?: boolean;
  onToggle?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  activeSubModule = 'kpi',
  onSubModuleChange,
  isOpen = true,
  onToggle,
}) => {
  const primaryModules: { id: RoleTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: <LayoutDashboard className="w-4 h-4 text-indigo-600" /> },
    { id: 'sales', label: '1. Sales & Tenders CRM', icon: <Target className="w-4 h-4 text-purple-600" /> },
    { id: 'procurement', label: '2. Procurement & SCM', icon: <ShoppingBag className="w-4 h-4 text-emerald-600" /> },
    { id: 'catalog', label: '3. Security Product Catalog', icon: <ShieldCheck className="w-4 h-4 text-indigo-600" /> },
    { id: 'projects', label: '4. Project Management', icon: <Briefcase className="w-4 h-4 text-blue-600" /> },
    { id: 'moi', label: '5. MOI SSD Compliance', icon: <ShieldCheck className="w-4 h-4 text-teal-600" />, badge: 'MOI' },
    { id: 'amc', label: '6. AMC & Service Helpdesk', icon: <Wrench className="w-4 h-4 text-amber-600" /> },
    { id: 'inventory', label: '7. Inventory & Price History', icon: <Package className="w-4 h-4 text-rose-600" /> },
    { id: 'finance', label: '8. Financial Control', icon: <DollarSign className="w-4 h-4 text-emerald-600" /> },
    { id: 'client-portal', label: '9. Client VIP Portal', icon: <Globe className="w-4 h-4 text-indigo-600" /> },
  ];

  const secondaryModules: { id: RoleTab; label: string; icon: React.ReactNode }[] = [
    { id: 'journey', label: 'Project Lifecycle Map', icon: <Milestone className="w-4 h-4 text-teal-600" /> },
    { id: 'hr', label: 'HR & Personnel', icon: <Users className="w-4 h-4 text-amber-600" /> },
    { id: 'administrator', label: 'Admin Settings', icon: <ShieldAlert className="w-4 h-4 text-slate-700" /> },
  ];

  return (
    <aside
      id="main-sidebar"
      className={`${
        isOpen ? 'w-64 translate-x-0' : 'w-0 -translate-x-full overflow-hidden'
      } transition-all duration-300 ease-in-out bg-white border-r border-slate-200 flex flex-col h-full select-none shrink-0 shadow-xs z-30 relative`}
    >
      {/* Brand Header with Collapse Toggle */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-sm shadow-indigo-200 shrink-0">
            A
          </div>
          <div className="min-w-0">
            <h1 className="font-bold text-base tracking-tight text-slate-900 leading-tight truncate">AMAZETEC</h1>
            <p className="text-[10px] font-semibold text-indigo-600 tracking-wider uppercase truncate">Master ERP Portal</p>
          </div>
        </div>

        {onToggle && (
          <button
            id="sidebar-close-toggle-btn"
            onClick={onToggle}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
            title="Hide Sidebar"
          >
            <PanelLeftClose className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Role & Worksheet Navigation */}
      <div className="p-3 overflow-y-auto flex-1 space-y-5 scrollbar-thin">
        {/* Core CRM & ERP Modules */}
        <div>
          <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-3 mb-2">Core CRM & ERP Modules</p>
          <nav className="space-y-1">
            {primaryModules.map((dept) => {
              const isDeptActive = activeTab === dept.id;
              return (
                <button
                  key={dept.id}
                  id={`nav-btn-${dept.id}`}
                  onClick={() => {
                    onTabChange(dept.id);
                    if (dept.id === 'procurement' && onSubModuleChange) {
                      onSubModuleChange('scm_pipeline');
                    }
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-bold text-xs transition cursor-pointer ${
                    isDeptActive
                      ? 'bg-indigo-50 text-indigo-700 shadow-2xs border border-indigo-100'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {dept.icon}
                    <span className="truncate">{dept.label}</span>
                  </div>
                  {dept.badge ? (
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-extrabold bg-teal-100 text-teal-800 shrink-0">
                      {dept.badge}
                    </span>
                  ) : isDeptActive ? (
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-extrabold bg-indigo-200/80 text-indigo-800 shrink-0">
                      Active
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Operations & Personnel */}
        <div>
          <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-3 mb-2">Operations & Personnel</p>
          <nav className="space-y-1">
            {secondaryModules.map((dept) => {
              const isDeptActive = activeTab === dept.id;
              return (
                <button
                  key={dept.id}
                  id={`nav-btn-${dept.id}`}
                  onClick={() => onTabChange(dept.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-bold text-xs transition cursor-pointer ${
                    isDeptActive
                      ? 'bg-indigo-50 text-indigo-700 shadow-2xs border border-indigo-100'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {dept.icon}
                    <span className="truncate">{dept.label}</span>
                  </div>
                  {isDeptActive && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-extrabold bg-indigo-200/80 text-indigo-800 shrink-0">
                      Active
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </aside>
  );
};

