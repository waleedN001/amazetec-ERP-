import React, { useState } from 'react';
import {
  ProjectOverview,
  AMCMasterRecord,
  ServiceTicketRecord,
  MOIDIARecord,
} from '../types';
import {
  ShieldCheck,
  Building2,
  Download,
  CheckCircle2,
  Clock,
  Wrench,
  Plus,
  Award,
} from 'lucide-react';

interface ClientPortalViewProps {
  projects: ProjectOverview[];
  amcContracts: AMCMasterRecord[];
  tickets: ServiceTicketRecord[];
  diaRecords: MOIDIARecord[];
  onOpenQuickAdd: () => void;
}

export const ClientPortalView: React.FC<ClientPortalViewProps> = ({
  projects,
  amcContracts,
  tickets,
  diaRecords,
}) => {
  const [selectedClient, setSelectedClient] = useState<string>('Mwani Qatar');
  const [isLogTicketOpen, setIsLogTicketOpen] = useState(false);
  const [ticketLoggedNotice, setTicketLoggedNotice] = useState(false);

  // Client data slice
  const clientProjects = projects.filter(p => p.clientName.toLowerCase().includes(selectedClient.toLowerCase()) || selectedClient.toLowerCase().includes(p.clientName.toLowerCase()));
  const clientContracts = amcContracts.filter(c => c.clientName.toLowerCase().includes(selectedClient.toLowerCase()) || selectedClient.toLowerCase().includes(c.clientName.toLowerCase()));
  const clientTickets = tickets.filter(t => t.clientName.toLowerCase().includes(selectedClient.toLowerCase()) || selectedClient.toLowerCase().includes(t.clientName.toLowerCase()));
  const clientCertificates = diaRecords.filter(d => d.status === 'Approved');

  const handleCreateClientTicket = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLogTicketOpen(false);
    setTicketLoggedNotice(true);
    setTimeout(() => setTicketLoggedNotice(false), 4000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner with Client Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 rounded-full border border-indigo-400/30 text-indigo-300 text-xs font-bold uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5" />
            <span>Module 8 • Client Self-Service Experience</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
            Amazetec VIP Client Security Portal
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl">
            Simulated client-facing dashboard allowing authorized stakeholders to track live installation milestones, download MOI approval certificates, review AMC tickets, and generate weekly executive summaries.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="bg-slate-800 px-3.5 py-2 rounded-2xl border border-slate-700">
            <label className="text-[10px] font-bold text-slate-400 block uppercase mb-1">Simulate Client View:</label>
            <select
              value={selectedClient}
              onChange={(e) => setSelectedClient(e.target.value)}
              className="bg-transparent text-white text-xs font-extrabold focus:outline-hidden cursor-pointer"
            >
              <option value="Mwani Qatar" className="bg-slate-900">Mwani Qatar (Hamad Port)</option>
              <option value="Qatar Hospitality Group" className="bg-slate-900">Qatar Hospitality Group (West Bay)</option>
              <option value="Lusail Real Estate" className="bg-slate-900">Lusail Real Estate Development</option>
              <option value="Doha Festival Oasis" className="bg-slate-900">Doha Festival Oasis Properties</option>
            </select>
          </div>

          <button
            onClick={() => setIsLogTicketOpen(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Log Support Request</span>
          </button>
        </div>
      </div>

      {ticketLoggedNotice && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-3 text-emerald-900 text-xs font-bold shadow-2xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>Support Ticket successfully dispatched to Amazetec 24/7 Security NOC with 2-hour SLA response!</span>
        </div>
      )}

      {/* Main Grid: Live Projects & Milestones */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Projects Progress */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-indigo-600" />
                <span>Live Project Execution Status for {selectedClient}</span>
              </h3>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                Real-Time Sync
              </span>
            </div>

            {clientProjects.length > 0 ? (
              <div className="space-y-4">
                {clientProjects.map((proj) => (
                  <div key={proj.id} className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                          {proj.id}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900 mt-1">{proj.projectName}</h4>
                        <p className="text-xs text-slate-500">Project Manager: {proj.projectManager} • Target Handover: {proj.plannedEndDate}</p>
                      </div>
                      <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-100 text-blue-800">
                        {proj.status}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-extrabold text-slate-700">
                        <span>Overall Execution Milestones</span>
                        <span className="text-indigo-600">68% Complete</span>
                      </div>
                      <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                        <div className="bg-indigo-600 h-full rounded-full transition-all duration-500" style={{ width: '68%' }} />
                      </div>
                    </div>

                    {/* Checkpoints */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px]">
                      <div className="p-2 bg-white rounded-xl border border-slate-200 text-emerald-800 font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>1st Fix Done</span>
                      </div>
                      <div className="p-2 bg-white rounded-xl border border-slate-200 text-emerald-800 font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Fluke Test Pass</span>
                      </div>
                      <div className="p-2 bg-white rounded-xl border border-slate-200 text-indigo-800 font-semibold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>CCTV Mounting</span>
                      </div>
                      <div className="p-2 bg-white rounded-xl border border-slate-200 text-slate-400 font-semibold flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>MOI DIA Gate</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs bg-slate-50 rounded-2xl">
                No active construction projects logged for {selectedClient}.
              </div>
            )}
          </div>

          {/* AMC SLA & Active Support Tickets */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Wrench className="w-5 h-5 text-amber-600" />
                <span>Active Service Tickets & AMC Support</span>
              </h3>
              <button
                onClick={() => setIsLogTicketOpen(true)}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                + Submit New Ticket
              </button>
            </div>

            <div className="space-y-3">
              {clientTickets.length > 0 ? (
                clientTickets.map((tck) => (
                  <div key={tck.ticketId} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-indigo-600">{tck.ticketId}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                          {tck.priority} Priority
                        </span>
                      </div>
                      <p className="font-bold text-slate-900 mt-1">{tck.description}</p>
                      <p className="text-slate-500 text-[11px]">Reported: {tck.createdDate} • Assigned: {tck.assignedTechnician}</p>
                    </div>

                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 shrink-0">
                      {tck.status}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 text-center py-4">All systems normal. No active tickets.</p>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: MOI Certificate Vault & Executive PDF Downloads */}
        <div className="lg:col-span-4 space-y-6">
          {/* Certificate Vault */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-600" />
                <span>MOI-SSD Security Certificate Vault</span>
              </h3>
              <p className="text-xs text-slate-500">Official Ministry of Interior approval certificates.</p>
            </div>

            <div className="space-y-3">
              {clientCertificates.map((cert) => (
                <div key={cert.diaId} className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-emerald-600 text-white">
                      OFFICIAL CERTIFICATE
                    </span>
                    <span className="text-[10px] font-bold text-emerald-800">Active Valid</span>
                  </div>
                  <h5 className="font-extrabold text-xs text-slate-900">{cert.projectName}</h5>
                  <p className="font-mono text-xs text-emerald-950 font-bold">{cert.certificateNumber}</p>
                  <p className="text-[10px] text-slate-600">Expiry Date: {cert.certificateExpiryDate || '2027-08-19'}</p>

                  <button
                    onClick={() => alert(`Downloading official MOI Certificate ${cert.certificateNumber} (PDF)...`)}
                    className="w-full py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Signed PDF</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Automated Reports Generation */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-indigo-800 space-y-4">
            <div>
              <h4 className="font-extrabold text-sm text-white flex items-center gap-2">
                <Download className="w-4 h-4 text-indigo-300" />
                <span>Executive Reports & Audit Packs</span>
              </h4>
              <p className="text-xs text-indigo-200 mt-1">One-click compliance pack generator for facility managers.</p>
            </div>

            <div className="space-y-2 text-xs">
              <button
                onClick={() => alert('Generating Weekly Project Execution Status Report (PDF)...')}
                className="w-full py-2.5 px-3 bg-indigo-800/60 hover:bg-indigo-700 rounded-xl font-bold transition flex items-center justify-between text-left cursor-pointer border border-indigo-700"
              >
                <span>Weekly Status & Milestone PDF</span>
                <Download className="w-3.5 h-3.5 text-indigo-300" />
              </button>

              <button
                onClick={() => alert('Generating MOI-SSD 120-Day Storage & RAID Compliance Audit (PDF)...')}
                className="w-full py-2.5 px-3 bg-indigo-800/60 hover:bg-indigo-700 rounded-xl font-bold transition flex items-center justify-between text-left cursor-pointer border border-indigo-700"
              >
                <span>MOI SSD Compliance Audit Pack</span>
                <Download className="w-3.5 h-3.5 text-indigo-300" />
              </button>

              <button
                onClick={() => alert('Generating Annual AMC SLA & PPM Preventive Maintenance Log (PDF)...')}
                className="w-full py-2.5 px-3 bg-indigo-800/60 hover:bg-indigo-700 rounded-xl font-bold transition flex items-center justify-between text-left cursor-pointer border border-indigo-700"
              >
                <span>Annual AMC Maintenance Log</span>
                <Download className="w-3.5 h-3.5 text-indigo-300" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL: LOG CLIENT SUPPORT TICKET */}
      {isLogTicketOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Submit Security NOC Support Ticket</h3>
              <button
                onClick={() => setIsLogTicketOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateClientTicket} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Client Entity</label>
                <input
                  type="text"
                  disabled
                  value={selectedClient}
                  className="w-full px-3 py-2 border border-slate-200 bg-slate-100 rounded-xl font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Issue / Fault Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe the CCTV, access control, or NVR issue at your facility..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Severity / Urgency</label>
                <select className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white">
                  <option>Critical (Camera down on critical gate / server alarm - 2h SLA)</option>
                  <option>High (Multiple cameras blurred / PTZ error - 4h SLA)</option>
                  <option>Standard (Routine check / footage retrieval assistance - 24h SLA)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsLogTicketOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Send to Amazetec NOC
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
