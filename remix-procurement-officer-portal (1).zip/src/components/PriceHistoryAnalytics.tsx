import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Zap,
  MapPin,
  Filter,
  TrendingDown,
  TrendingUp,
  Percent,
  Layers,
  FolderOpen,
  FileText,
  Tag,
  History as HistoryIcon,
} from 'lucide-react';
import { PriceHistoryRecord, SupplierRecord } from '../types';

interface PriceHistoryAnalyticsProps {
  priceHistory: PriceHistoryRecord[];
  suppliers: SupplierRecord[];
  onOpenQuickAdd: () => void;
  selectedFilter: string;
  onFilterChange: (filter: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  componentClass?: string;
  onComponentClassChange?: (cls: string) => void;
  location?: string;
  onLocationChange?: (loc: string) => void;
  moi?: string;
  onMoiChange?: (moi: string) => void;
  project?: string;
  onProjectChange?: (project: string) => void;
  quotation?: string;
  onQuotationChange?: (quotation: string) => void;
  brand?: string;
  onBrandChange?: (brand: string) => void;
  revision?: string;
  onRevisionChange?: (revision: string) => void;
}

export const PriceHistoryAnalytics: React.FC<PriceHistoryAnalyticsProps> = ({
  priceHistory,
  suppliers,
  onOpenQuickAdd,
  selectedFilter,
  onFilterChange,
  searchQuery,
  onSearchChange,
  componentClass = 'All',
  onComponentClassChange,
  location = 'All',
  onLocationChange,
  moi = 'All',
  onMoiChange,
  project = 'All',
  onProjectChange,
  quotation = 'All',
  onQuotationChange,
  brand = 'All',
  onBrandChange,
  revision = 'All',
  onRevisionChange,
}) => {
  // Compute analytics
  const totalRecords = priceHistory.length;
  const decreases = priceHistory.filter((p) => p.changeType === 'Decrease');
  const increases = priceHistory.filter((p) => p.changeType === 'Increase');
  const totalSavingsQAR = decreases.reduce((sum, item) => sum + Math.abs(Number(item.priceChange) || 0), 0);
  const avgSavingsPct =
    decreases.length > 0
      ? decreases.reduce((sum, item) => sum + Math.abs(Number(item.percentChange) || 0), 0) / decreases.length
      : 0;

  // Extract unique values for filters
  const uniqueProjects = Array.from(new Set(priceHistory.map(p => p.projectName).filter(Boolean)));
  const uniqueQuotations = Array.from(new Set(priceHistory.map(p => p.quotationName).filter(Boolean)));
  const uniqueBrands = Array.from(new Set(priceHistory.map(p => p.brand).filter(Boolean)));
  const uniqueRevisions = Array.from(new Set(priceHistory.map(p => p.revisionNumber).filter(Boolean)));

  return (
    <div className="space-y-3">
      {/* Top Intelligence Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-2xs font-extrabold uppercase text-slate-400">Total Tracked SKUs</span>
            <div className="text-lg font-black text-slate-900">{totalRecords} Models</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
            <Layers className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-2xs font-extrabold uppercase text-slate-400">Negotiated Savings</span>
            <div className="text-lg font-black text-emerald-600">QAR {totalSavingsQAR.toLocaleString()}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <TrendingDown className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-2xs font-extrabold uppercase text-slate-400">Avg. Discount Secured</span>
            <div className="text-lg font-black text-indigo-600">{avgSavingsPct.toFixed(1)}%</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Percent className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-2xs font-extrabold uppercase text-slate-400">Price Increases (Inflation)</span>
            <div className="text-lg font-black text-rose-600">{increases.length} Items</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <TrendingUp className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Box */}
        <div className="relative w-full md:w-80 lg:w-96">
          <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by brand, model, specification, reason..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50/80 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
          />
        </div>

        {/* Filter Options & Dropdowns */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-end">
          {/* Active / Passive Component Type Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <Zap className={`w-3.5 h-3.5 shrink-0 ${componentClass === 'Active' ? 'text-amber-500' : componentClass === 'Passive' ? 'text-blue-500' : 'text-slate-400'}`} />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Type:</span>
            <select
              value={componentClass}
              onChange={(e) => onComponentClassChange && onComponentClassChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1"
            >
              <option value="All">All (Active & Passive)</option>
              <option value="Active">⚡ Active Components</option>
              <option value="Passive">🛠️ Passive Infrastructure</option>
            </select>
          </div>

          {/* Location Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <MapPin className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Location:</span>
            <select
              value={location}
              onChange={(e) => onLocationChange && onLocationChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1"
            >
              <option value="All">All Qatar</option>
              <option value="Doha">Doha</option>
              <option value="Lusail">Lusail</option>
              <option value="Al Rayyan">Al Rayyan</option>
              <option value="Al Wakrah">Al Wakrah</option>
              <option value="Al Khor">Al Khor</option>
              <option value="Ras Laffan">Ras Laffan</option>
            </select>
          </div>

          {/* MOI Approval Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <ShieldCheck className={`w-3.5 h-3.5 shrink-0 ${moi === 'Yes' ? 'text-emerald-600' : moi === 'No' ? 'text-rose-500' : 'text-slate-400'}`} />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">MOI:</span>
            <select
              value={moi}
              onChange={(e) => onMoiChange && onMoiChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1 w-24"
            >
              <option value="All">All Statuses</option>
              <option value="Yes">Approved Only</option>
              <option value="No">Non-Approved</option>
            </select>
          </div>

          {/* Project Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <FolderOpen className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider hidden lg:inline">Project:</span>
            <select
              value={project}
              onChange={(e) => onProjectChange && onProjectChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1 max-w-[100px] truncate"
            >
              <option value="All">All Projects</option>
              {uniqueProjects.map((p, idx) => <option key={idx} value={p as string}>{p}</option>)}
            </select>
          </div>

          {/* Quotation Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <FileText className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider hidden lg:inline">Quotation:</span>
            <select
              value={quotation}
              onChange={(e) => onQuotationChange && onQuotationChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1 max-w-[100px] truncate"
            >
              <option value="All">All Quotations</option>
              {uniqueQuotations.map((q, idx) => <option key={idx} value={q as string}>{q}</option>)}
            </select>
          </div>

          {/* Brand Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <Tag className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider hidden lg:inline">Brand:</span>
            <select
              value={brand}
              onChange={(e) => onBrandChange && onBrandChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1 max-w-[80px] truncate"
            >
              <option value="All">All Brands</option>
              {uniqueBrands.map((b, idx) => <option key={idx} value={b as string}>{b}</option>)}
            </select>
          </div>

          {/* Revision Filter */}
          <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-700 rounded-xl px-3 py-1.5 text-xs font-semibold shadow-2xs transition">
            <HistoryIcon className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider hidden lg:inline">Rev:</span>
            <select
              value={revision}
              onChange={(e) => onRevisionChange && onRevisionChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none cursor-pointer pr-1 max-w-[70px] truncate"
            >
              <option value="All">All Revs</option>
              {uniqueRevisions.map((r, idx) => <option key={idx} value={r as string}>{r}</option>)}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
