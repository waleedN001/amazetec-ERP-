import React, { useState, useMemo } from 'react';
import {
  ClipboardList,
  CheckCircle2,
  AlertCircle,
  Clock,
  Building2,
  FileCheck,
  Send,
  ShoppingCart,
  Truck,
  PackageCheck,
  Search,
  Filter,
  Plus,
  ArrowRight,
  ChevronRight,
  MapPin,
  User,
  Calendar,
  Layers,
  ShieldCheck,
  Edit3,
  Trash2,
  Check,
  LayoutGrid,
  Table as TableIcon,
  BadgeCheck,
  FileSpreadsheet,
  X,
  FileText,
  Sparkles,
} from 'lucide-react';
import { PurchaseRequisition } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';
import { useAppData } from '../context/useAppData';

interface PurchaseRequisitionsViewProps {
  requisitions: PurchaseRequisition[];
  onUpdateRequisitions: (data: PurchaseRequisition[]) => void;
  onOpenQuickAdd: () => void;
  onFloatRFQ?: (pr: PurchaseRequisition) => void;
}

type PRStage = 'Requested' | 'Approved' | 'Ordered' | 'Delivered';

const STAGES: {
  id: PRStage;
  label: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
}[] = [
  {
    id: 'Requested',
    label: 'Requested',
    shortDesc: 'Site PR Raised & Logged',
    icon: ClipboardList,
    color: 'text-amber-600',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    borderColor: 'border-amber-300',
  },
  {
    id: 'Approved',
    label: 'Approved',
    shortDesc: 'Technical & PM Vetting Passed',
    icon: ShieldCheck,
    color: 'text-blue-600',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-700',
    borderColor: 'border-blue-300',
  },
  {
    id: 'Ordered',
    label: 'Ordered',
    shortDesc: 'Formal PO Placed with Vendor',
    icon: ShoppingCart,
    color: 'text-indigo-600',
    badgeBg: 'bg-indigo-50',
    badgeText: 'text-indigo-700',
    borderColor: 'border-indigo-300',
  },
  {
    id: 'Delivered',
    label: 'Delivered',
    shortDesc: 'Received & Inspected on Site',
    icon: PackageCheck,
    color: 'text-emerald-600',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700',
    borderColor: 'border-emerald-300',
  },
];

// Helper to determine stage from record
export function getRequisitionStage(pr: PurchaseRequisition): PRStage {
  if (pr.stage) {
    if (['Requested', 'Approved', 'Ordered', 'Delivered'].includes(pr.stage)) {
      return pr.stage as PRStage;
    }
  }
  // Fallback based on status
  if (pr.status === 'PO Issued') return 'Ordered';
  if (pr.status === 'Vetted & Approved' || pr.status === 'RFQ Floated') return 'Approved';
  if (pr.status === 'Pending Review') return 'Requested';
  return 'Requested';
}

export const PurchaseRequisitionsView: React.FC<PurchaseRequisitionsViewProps> = ({
  requisitions,
  onUpdateRequisitions,
  onOpenQuickAdd,
  onFloatRFQ,
}) => {
  const { convertPRToPO, setActiveTab, setProcurementSubModule } = useAppData();
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStageFilter, setSelectedStageFilter] = useState<'All' | PRStage>('All');
  const [selectedPriorityFilter, setSelectedPriorityFilter] = useState<'All' | 'Urgent' | 'High' | 'Medium' | 'Low'>('All');
  const [editingPR, setEditingPR] = useState<PurchaseRequisition | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [notification, setNotification] = useState<{ message: string; poNumber: string } | null>(null);

  const handleConvertPO = (prId: string) => {
    const newPO = convertPRToPO(prId);
    if (newPO) {
      setNotification({
        message: `Successfully converted ${prId} to Purchase Order ${newPO.poNumber}!`,
        poNumber: newPO.poNumber,
      });
      setTimeout(() => setNotification(null), 5000);
    }
  };

  // New Requisition Form State
  const [newPR, setNewPR] = useState<Partial<PurchaseRequisition>>({
    prId: `PR-2026-00${requisitions.length + 1}`,
    boqId: 'BOQ-001',
    projectName: 'Ezdan Real Estate Phase 2 Upgrade',
    siteLocation: 'Al Wakra Ezdan Village 14',
    requestedBy: 'Eng. Tariq Al-Mansoor',
    dateRequested: new Date().toISOString().split('T')[0],
    requiredDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    priority: 'High',
    itemDescription: '',
    quantity: 10,
    unit: 'Units',
    estimatedBudgetQAR: 25000,
    technicalVetting: 'Verified with Specs',
    consultantApprovalNeeded: 'Yes',
    status: 'Pending Review',
    stage: 'Requested',
    remarks: '',
  });

  // Stage advancement handler
  const handleUpdateStage = (prId: string, newStage: PRStage) => {
    const updated = requisitions.map((item) => {
      if (item.prId === prId) {
        let updatedStatus = item.status;
        if (newStage === 'Requested') updatedStatus = 'Pending Review';
        else if (newStage === 'Approved') updatedStatus = 'Vetted & Approved';
        else if (newStage === 'Ordered') updatedStatus = 'PO Issued';
        else if (newStage === 'Delivered') updatedStatus = 'PO Issued';

        return {
          ...item,
          stage: newStage,
          status: updatedStatus,
        };
      }
      return item;
    });
    onUpdateRequisitions(updated);
  };

  // Advance to next sequential stage
  const handleAdvanceNextStage = (pr: PurchaseRequisition) => {
    const current = getRequisitionStage(pr);
    const currentIndex = STAGES.findIndex((s) => s.id === current);
    if (currentIndex < STAGES.length - 1) {
      const nextStage = STAGES[currentIndex + 1].id;
      handleUpdateStage(pr.prId, nextStage);
    }
  };

  // Delete Requisition
  const handleDeletePR = (prId: string) => {
    if (window.confirm(`Are you sure you want to delete requisition ${prId}?`)) {
      onUpdateRequisitions(requisitions.filter((r) => r.prId !== prId));
    }
  };

  // Save Edited Requisition
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPR) return;
    const updated = requisitions.map((r) => (r.prId === editingPR.prId ? editingPR : r));
    onUpdateRequisitions(updated);
    setEditingPR(null);
  };

  // Create New Requisition
  const handleCreatePR = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPR.itemDescription || !newPR.projectName) return;
    const prToAdd: PurchaseRequisition = {
      prId: newPR.prId || `PR-2026-${Math.floor(100 + Math.random() * 900)}`,
      boqId: newPR.boqId || 'BOQ-001',
      projectName: newPR.projectName || 'General ELV Project',
      siteLocation: newPR.siteLocation || 'Doha Site',
      requestedBy: newPR.requestedBy || 'Site Engineer',
      dateRequested: newPR.dateRequested || new Date().toISOString().split('T')[0],
      requiredDate: newPR.requiredDate || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      priority: (newPR.priority as any) || 'Medium',
      itemDescription: newPR.itemDescription,
      quantity: Number(newPR.quantity) || 1,
      unit: newPR.unit || 'Units',
      estimatedBudgetQAR: Number(newPR.estimatedBudgetQAR) || 0,
      technicalVetting: (newPR.technicalVetting as any) || 'Verified with Specs',
      consultantApprovalNeeded: (newPR.consultantApprovalNeeded as any) || 'Yes',
      status: (newPR.status as any) || 'Pending Review',
      stage: (newPR.stage as any) || 'Requested',
      remarks: newPR.remarks || '',
    };
    onUpdateRequisitions([prToAdd, ...requisitions]);
    setIsCreateModalOpen(false);
    setNewPR({
      prId: `PR-2026-00${requisitions.length + 2}`,
      boqId: 'BOQ-001',
      projectName: 'Ezdan Real Estate Phase 2 Upgrade',
      siteLocation: 'Al Wakra Ezdan Village 14',
      requestedBy: 'Eng. Tariq Al-Mansoor',
      dateRequested: new Date().toISOString().split('T')[0],
      requiredDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      priority: 'High',
      itemDescription: '',
      quantity: 10,
      unit: 'Units',
      estimatedBudgetQAR: 25000,
      technicalVetting: 'Verified with Specs',
      consultantApprovalNeeded: 'Yes',
      status: 'Pending Review',
      stage: 'Requested',
      remarks: '',
    });
  };

  // Metrics calculation
  const stageCounts = useMemo(() => {
    const counts = {
      Requested: 0,
      Approved: 0,
      Ordered: 0,
      Delivered: 0,
      totalBudget: 0,
    };
    requisitions.forEach((r) => {
      const stage = getRequisitionStage(r);
      counts[stage] = (counts[stage] || 0) + 1;
      counts.totalBudget += Number(r.estimatedBudgetQAR) || 0;
    });
    return counts;
  }, [requisitions]);

  // Filtered requisitions list
  const filteredRequisitions = useMemo(() => {
    return requisitions.filter((r) => {
      const stage = getRequisitionStage(r);
      if (selectedStageFilter !== 'All' && stage !== selectedStageFilter) return false;
      if (selectedPriorityFilter !== 'All' && r.priority !== selectedPriorityFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchPR = r.prId.toLowerCase().includes(q);
        const matchBOQ = r.boqId.toLowerCase().includes(q);
        const matchProject = r.projectName.toLowerCase().includes(q);
        const matchSite = r.siteLocation.toLowerCase().includes(q);
        const matchRequester = r.requestedBy.toLowerCase().includes(q);
        const matchItem = r.itemDescription.toLowerCase().includes(q);
        return matchPR || matchBOQ || matchProject || matchSite || matchRequester || matchItem;
      }
      return true;
    });
  }, [requisitions, selectedStageFilter, selectedPriorityFilter, searchQuery]);

  // Table Columns Definition
  const prColumns: ColumnDef[] = [
    { key: 'prId', label: 'PR Number', type: 'readonly' },
    {
      key: 'stage',
      label: 'Current Stage',
      type: 'select',
      options: ['Requested', 'Approved', 'Ordered', 'Delivered'],
    },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'siteLocation', label: 'Site Location', type: 'text' },
    { key: 'requestedBy', label: 'Requested By', type: 'text' },
    { key: 'itemDescription', label: 'Item Description', type: 'text' },
    { key: 'quantity', label: 'Quantity', type: 'number' },
    { key: 'unit', label: 'Unit', type: 'text' },
    { key: 'estimatedBudgetQAR', label: 'Est. Budget (QAR)', type: 'currency' },
    { key: 'priority', label: 'Priority', type: 'select', options: ['Urgent', 'High', 'Medium', 'Low'] },
    {
      key: 'technicalVetting',
      label: 'Technical Vetting',
      type: 'select',
      options: ['Verified with Specs', 'Pending Specs Check', 'Non-Compliant (Hold)'],
    },
    { key: 'consultantApprovalNeeded', label: 'Consultant MAS Needed', type: 'select', options: ['Yes', 'No'] },
    {
      key: 'status',
      label: 'Workflow Status',
      type: 'select',
      options: ['Pending Review', 'Vetted & Approved', 'RFQ Floated', 'PO Issued', 'Rejected'],
    },
  ];

  return (
    <div className="space-y-4">
      {/* Notification Toast */}
      {notification && (
        <div className="bg-indigo-900 text-white border border-indigo-700 rounded-2xl p-4 flex items-center justify-between shadow-lg animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3 text-xs font-semibold">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{notification.message}</span>
          </div>
          <button
            onClick={() => {
              setActiveTab('procurement');
              setProcurementSubModule('po_logistics');
            }}
            className="bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/20"
          >
            <span>View PO {notification.poNumber}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 2. Controls Toolbar: Search, Filters & View Mode Switcher */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by PR #, project, item, engineer..."
              className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Stage Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setSelectedStageFilter('All')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedStageFilter === 'All'
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({requisitions.length})
            </button>
            {STAGES.map((st) => (
              <button
                key={st.id}
                onClick={() => setSelectedStageFilter(st.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  selectedStageFilter === st.id
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st.label} ({stageCounts[st.id] || 0})
              </button>
            ))}
          </div>

          {/* Priority Filter */}
          <select
            value={selectedPriorityFilter}
            onChange={(e) => setSelectedPriorityFilter(e.target.value as any)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="All">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>

        {/* Action & View Mode Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-2xs transition cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Raise New PR</span>
          </button>

          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('cards')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Cards & Steppers</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Spreadsheet Table</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Main Content: Cards with Visual Progress Steppers */}
      {viewMode === 'cards' ? (
        <div className="space-y-4">
          {filteredRequisitions.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center">
              <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="text-base font-bold text-slate-800">No Purchase Requisitions Found</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                No purchase requisitions match your active search or filters. Adjust your search criteria or raise a new PR.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedStageFilter('All');
                  setSelectedPriorityFilter('All');
                }}
                className="mt-4 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredRequisitions.map((pr) => {
                const currentStage = getRequisitionStage(pr);
                const currentStageIndex = STAGES.findIndex((s) => s.id === currentStage);
                const isUrgent = pr.priority === 'Urgent';
                const isHigh = pr.priority === 'High';

                return (
                  <div
                    key={pr.prId}
                    className="bg-white border border-slate-200/90 hover:border-indigo-300 rounded-3xl p-5 shadow-2xs transition-all hover:shadow-md relative overflow-hidden"
                  >
                    {/* Top Row: Identification, Badges, Budget, Priority */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <span className="px-3 py-1 bg-slate-900 text-white rounded-xl text-xs font-black tracking-tight">
                          {pr.prId}
                        </span>

                        <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-extrabold flex items-center gap-1">
                          <Layers className="w-3 h-3" />
                          {pr.boqId}
                        </span>

                        <span
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold ${
                            pr.priority === 'Urgent'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : pr.priority === 'High'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : pr.priority === 'Medium'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {pr.priority} Priority
                        </span>

                        <span
                          className={`px-2.5 py-1 rounded-xl text-xs font-medium ${
                            pr.technicalVetting === 'Verified with Specs'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : pr.technicalVetting === 'Pending Specs Check'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {pr.technicalVetting}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-2xs font-semibold text-slate-400 uppercase tracking-wider">Estimated Budget</div>
                          <div className="text-base font-black text-slate-900">
                            QAR {Number(pr.estimatedBudgetQAR).toLocaleString()}
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-1 pl-2 border-l border-slate-200">
                          <button
                            onClick={() => setEditingPR(pr)}
                            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition cursor-pointer"
                            title="Edit Requisition Details"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeletePR(pr.prId)}
                            className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition cursor-pointer"
                            title="Delete Requisition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Middle Details Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
                      {/* Left: Project & Location */}
                      <div className="space-y-1.5">
                        <h4 className="font-bold text-slate-900 text-sm">{pr.projectName}</h4>
                        <div className="flex items-center gap-1.5 text-xs text-slate-600">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{pr.siteLocation}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                          <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">Raised by: <strong className="text-slate-700">{pr.requestedBy}</strong></span>
                        </div>
                      </div>

                      {/* Middle: Item Specification & Quantity */}
                      <div className="space-y-1.5 md:col-span-2 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/60">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider">Item Description</span>
                            <p className="text-xs font-semibold text-slate-800 mt-0.5 line-clamp-2">
                              {pr.itemDescription}
                            </p>
                          </div>
                          <div className="text-right shrink-0 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                            <div className="text-2xs text-slate-400 font-medium">Quantity</div>
                            <div className="text-xs font-black text-indigo-600">
                              {pr.quantity} {pr.unit}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/50 text-2xs text-slate-500">
                          <div className="flex items-center gap-3">
                            <span>Requested: <strong className="text-slate-700">{pr.dateRequested}</strong></span>
                            <span>Required on Site: <strong className="text-slate-700">{pr.requiredDate}</strong></span>
                          </div>
                          <div>
                            Consultant Approval Needed: <strong className={pr.consultantApprovalNeeded === 'Yes' ? 'text-amber-600' : 'text-slate-600'}>{pr.consultantApprovalNeeded}</strong>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* ========================================================================= */}
                    {/* VISUAL PROGRESS STEPPER: Requested -> Approved -> Ordered -> Delivered */}
                    {/* ========================================================================= */}
                    <div className="mt-2 pt-4 pb-2 border-t border-slate-100">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-2xs font-extrabold uppercase tracking-wider text-slate-400">
                            Procurement Stage Pipeline
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-2xs font-bold ${STAGES[currentStageIndex]?.badgeBg} ${STAGES[currentStageIndex]?.color}`}>
                            Current: {currentStage} (Stage {currentStageIndex + 1} of 4)
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* 1-Click Convert to PO Button */}
                          {pr.stage !== 'Ordered' && pr.stage !== 'Delivered' && (
                            <button
                              onClick={() => handleConvertPO(pr.prId)}
                              title="1-Click: Automatically generate legally binding Purchase Order"
                              className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
                            >
                              <FileText className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Convert to PO</span>
                            </button>
                          )}

                          {/* Quick Advance Button */}
                          {currentStageIndex < STAGES.length - 1 && (
                            <button
                              onClick={() => handleAdvanceNextStage(pr)}
                              className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition cursor-pointer"
                            >
                              <span>Advance to {STAGES[currentStageIndex + 1].label}</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                          {currentStageIndex === STAGES.length - 1 && (
                            <span className="flex items-center gap-1 text-2xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                              <BadgeCheck className="w-3.5 h-3.5" />
                              Completed on Site
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Visual Stepper Track */}
                      <div className="relative px-2 py-3 bg-slate-50/90 border border-slate-200/80 rounded-2xl">
                        {/* Connecting Line */}
                        <div className="absolute top-1/2 left-8 right-8 -translate-y-1/2 h-1 bg-slate-200 rounded-full z-0">
                          <div
                            className="h-full bg-gradient-to-r from-amber-500 via-blue-500 via-indigo-600 to-emerald-500 rounded-full transition-all duration-500"
                            style={{
                              width: `${(currentStageIndex / (STAGES.length - 1)) * 100}%`,
                            }}
                          />
                        </div>

                        {/* 4 Stepper Nodes */}
                        <div className="relative z-10 grid grid-cols-4 gap-2">
                          {STAGES.map((stageItem, idx) => {
                            const isCompleted = idx < currentStageIndex;
                            const isCurrent = idx === currentStageIndex;
                            const isUpcoming = idx > currentStageIndex;
                            const StageIcon = stageItem.icon;

                            return (
                              <button
                                key={stageItem.id}
                                onClick={() => handleUpdateStage(pr.prId, stageItem.id)}
                                className="flex flex-col items-center text-center group cursor-pointer focus:outline-none"
                                title={`Click to set stage to ${stageItem.label}`}
                              >
                                {/* Circle Node */}
                                <div
                                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 shadow-2xs ${
                                    isCompleted
                                      ? 'bg-emerald-500 text-white ring-4 ring-emerald-100 hover:scale-110'
                                      : isCurrent
                                      ? 'bg-indigo-600 text-white ring-4 ring-indigo-200 ring-offset-1 scale-110 shadow-md animate-pulse-subtle'
                                      : 'bg-white text-slate-400 border-2 border-slate-300 hover:border-indigo-400 hover:text-indigo-600'
                                  }`}
                                >
                                  {isCompleted ? (
                                    <Check className="w-5 h-5 stroke-[3]" />
                                  ) : (
                                    <StageIcon className="w-4 h-4" />
                                  )}
                                </div>

                                {/* Label */}
                                <div className="mt-2 text-center">
                                  <div
                                    className={`text-xs font-bold transition ${
                                      isCurrent
                                      ? 'text-indigo-900 font-black'
                                      : isCompleted
                                      ? 'text-slate-800'
                                      : 'text-slate-400'
                                    }`}
                                  >
                                    {stageItem.label}
                                  </div>
                                  <div
                                    className={`text-2xs hidden sm:block truncate max-w-[120px] ${
                                      isCurrent
                                      ? 'text-indigo-600 font-semibold'
                                      : isCompleted
                                      ? 'text-emerald-600'
                                      : 'text-slate-400'
                                    }`}
                                  >
                                    {isCompleted ? 'Completed' : isCurrent ? 'Active Stage' : 'Pending'}
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Card Footer: Remarks & Quick Status Selector */}
                    {pr.remarks && (
                      <div className="mt-3 pt-2 text-2xs text-slate-500 italic bg-slate-50 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                        <span className="font-semibold not-italic text-slate-600">Note:</span> {pr.remarks}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* 4. Table View with Stage Selection Column */
        <EditableTable
          title="Purchase Requisitions (PR) Workflow"
          subtitle="Site-level material requests verified against BOQ line items, MOI compliance, and project budgets"
          columns={prColumns}
          data={filteredRequisitions}
          onUpdateData={onUpdateRequisitions}
          onAddRow={onOpenQuickAdd}
          badge="Table 1A"
          badgeColor="bg-blue-50 text-blue-700 border-blue-200"
        />
      )}

      {/* 5. Modal: Edit Requisition */}
      {editingPR && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-black text-base text-slate-900">
                  Edit Purchase Requisition ({editingPR.prId})
                </h3>
                <p className="text-xs text-slate-500">Update item specifications, budget, or move lifecycle stage</p>
              </div>
              <button
                onClick={() => setEditingPR(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Project Name</label>
                  <input
                    type="text"
                    value={editingPR.projectName}
                    onChange={(e) => setEditingPR({ ...editingPR, projectName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">BOQ Reference</label>
                  <input
                    type="text"
                    value={editingPR.boqId}
                    onChange={(e) => setEditingPR({ ...editingPR, boqId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Item Description & Specifications</label>
                  <textarea
                    rows={2}
                    value={editingPR.itemDescription}
                    onChange={(e) => setEditingPR({ ...editingPR, itemDescription: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Quantity</label>
                  <input
                    type="number"
                    value={editingPR.quantity}
                    onChange={(e) => setEditingPR({ ...editingPR, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Unit</label>
                  <input
                    type="text"
                    value={editingPR.unit}
                    onChange={(e) => setEditingPR({ ...editingPR, unit: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Estimated Budget (QAR)</label>
                  <input
                    type="number"
                    value={editingPR.estimatedBudgetQAR}
                    onChange={(e) => setEditingPR({ ...editingPR, estimatedBudgetQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Lifecycle Stage</label>
                  <select
                    value={getRequisitionStage(editingPR)}
                    onChange={(e) => setEditingPR({ ...editingPR, stage: e.target.value as PRStage })}
                    className="w-full px-3 py-2 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900"
                  >
                    <option value="Requested">Stage 1: Requested</option>
                    <option value="Approved">Stage 2: Approved</option>
                    <option value="Ordered">Stage 3: Ordered</option>
                    <option value="Delivered">Stage 4: Delivered</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Priority</label>
                  <select
                    value={editingPR.priority}
                    onChange={(e) => setEditingPR({ ...editingPR, priority: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="Urgent">Urgent</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Technical Vetting</label>
                  <select
                    value={editingPR.technicalVetting}
                    onChange={(e) => setEditingPR({ ...editingPR, technicalVetting: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="Verified with Specs">Verified with Specs</option>
                    <option value="Pending Specs Check">Pending Specs Check</option>
                    <option value="Non-Compliant (Hold)">Non-Compliant (Hold)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Remarks & Notes</label>
                  <input
                    type="text"
                    value={editingPR.remarks}
                    onChange={(e) => setEditingPR({ ...editingPR, remarks: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingPR(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. Modal: Create New Requisition */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-black text-base text-slate-900">
                  Raise New Site Purchase Requisition
                </h3>
                <p className="text-xs text-slate-500">Log material request for engineering vetting and procurement</p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePR} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">PR ID</label>
                  <input
                    type="text"
                    value={newPR.prId}
                    onChange={(e) => setNewPR({ ...newPR, prId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-indigo-700"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">BOQ ID Reference</label>
                  <input
                    type="text"
                    value={newPR.boqId}
                    onChange={(e) => setNewPR({ ...newPR, boqId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Project Name</label>
                  <input
                    type="text"
                    value={newPR.projectName}
                    onChange={(e) => setNewPR({ ...newPR, projectName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Site Location</label>
                  <input
                    type="text"
                    value={newPR.siteLocation}
                    onChange={(e) => setNewPR({ ...newPR, siteLocation: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Item Description & Specifications</label>
                  <textarea
                    rows={2}
                    value={newPR.itemDescription}
                    onChange={(e) => setNewPR({ ...newPR, itemDescription: e.target.value })}
                    placeholder="e.g., 4MP AcuSense Dome Cameras with 120-Day Storage..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Quantity</label>
                  <input
                    type="number"
                    value={newPR.quantity}
                    onChange={(e) => setNewPR({ ...newPR, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Unit</label>
                  <input
                    type="text"
                    value={newPR.unit}
                    onChange={(e) => setNewPR({ ...newPR, unit: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Estimated Budget (QAR)</label>
                  <input
                    type="number"
                    value={newPR.estimatedBudgetQAR}
                    onChange={(e) => setNewPR({ ...newPR, estimatedBudgetQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Initial Stage</label>
                  <select
                    value={newPR.stage}
                    onChange={(e) => setNewPR({ ...newPR, stage: e.target.value as PRStage })}
                    className="w-full px-3 py-2 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900"
                  >
                    <option value="Requested">Stage 1: Requested</option>
                    <option value="Approved">Stage 2: Approved</option>
                    <option value="Ordered">Stage 3: Ordered</option>
                    <option value="Delivered">Stage 4: Delivered</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Priority</label>
                  <select
                    value={newPR.priority}
                    onChange={(e) => setNewPR({ ...newPR, priority: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="Urgent">Urgent</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Requested By</label>
                  <input
                    type="text"
                    value={newPR.requestedBy}
                    onChange={(e) => setNewPR({ ...newPR, requestedBy: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
                >
                  Create Requisition
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
