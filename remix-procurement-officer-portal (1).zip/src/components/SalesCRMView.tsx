import React, { useState, useMemo } from 'react';
import {
  TenderRecord,
  ProposalContract,
  ActivityLog,
  LeadRecord,
  BOQRecord,
  DropdownMaster,
} from '../types';
import { useAppData } from '../context/useAppData';
import {
  TrendingUp,
  Target,
  FileCheck2,
  Calendar,
  Phone,
  Mail,
  Building2,
  Plus,
  Search,
  Filter,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  UserCheck,
  ShieldCheck,
  Briefcase,
  Users,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

interface SalesCRMViewProps {
  tenders: TenderRecord[];
  proposals: ProposalContract[];
  activityLogs: ActivityLog[];
  leads: LeadRecord[];
  boqs: BOQRecord[];
  dropdowns: DropdownMaster[];
  onUpdateTenders: (data: TenderRecord[]) => void;
  onUpdateProposals: (data: ProposalContract[]) => void;
  onUpdateActivityLogs: (data: ActivityLog[]) => void;
  onUpdateLeads: (data: LeadRecord[]) => void;
  onOpenQuickAdd: () => void;
  onNavigateToBOQ?: () => void;
}

export const SalesCRMView: React.FC<SalesCRMViewProps> = ({
  tenders,
  proposals,
  activityLogs,
  leads,
  boqs,
  onUpdateTenders,
  onUpdateProposals,
  onUpdateActivityLogs,
  onUpdateLeads,
  onOpenQuickAdd,
  onNavigateToBOQ,
}) => {
  const { setIsGeminiIntelligenceOpen, setGeminiIntelligenceMode } = useAppData();
  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'tenders_proposals' | 'activities' | 'boq-summary'>('pipeline');
  const [tenderProposalFilter, setTenderProposalFilter] = useState<'all' | 'tenders' | 'proposals'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sectorFilter, setSectorFilter] = useState<string>('All');
  const [isAddTenderOpen, setIsAddTenderOpen] = useState(false);
  const [isAddProposalOpen, setIsAddProposalOpen] = useState(false);
  const [isAddActivityOpen, setIsAddActivityOpen] = useState(false);

  // New Tender State
  const [newTender, setNewTender] = useState<Partial<TenderRecord>>({
    tenderId: `TND-${new Date().getFullYear()}-${String(tenders.length + 1).padStart(3, '0')}`,
    tenderName: '',
    clientName: '',
    source: 'Monaqasat (Qatar Tender Portal)',
    sector: 'Government',
    submissionDeadline: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    estimatedValueQAR: 500000,
    status: 'In Progress',
    assignedSales: 'Ahmed Al-Kuwari',
    documents: ['RFP_Specification.pdf'],
    notes: '',
  });

  // New Proposal State
  const [newProposal, setNewProposal] = useState<Partial<ProposalContract>>({
    proposalId: `PROP-2026-${String(proposals.length + 1).padStart(3, '0')}`,
    clientName: '',
    projectName: '',
    relatedQuotationId: `QT-2026-${String(proposals.length + 1).padStart(3, '0')}`,
    proposalDate: new Date().toISOString().split('T')[0],
    contractValueQAR: 350000,
    paymentTerms: '30% Advance, 60% On Delivery, 10% Handover',
    status: 'Draft',
    projectManager: 'Eng. Tareq Mansoor',
    validUntil: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
    scopeSummary: 'Supply, installation and MOI-SSD approval of security surveillance system.',
  });

  // New Activity State
  const [newActivity, setNewActivity] = useState<Partial<ActivityLog>>({
    activityId: `ACT-${Date.now().toString().slice(-4)}`,
    relatedTo: '',
    activityType: 'Call',
    date: new Date().toISOString().split('T')[0],
    description: '',
    followUpRequired: true,
    followUpDate: new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
    assignedTo: 'Ahmed Al-Kuwari',
    outcome: '',
  });

  // KPI Calculations
  const stats = useMemo(() => {
    const totalPipelineValue = leads.reduce((sum, l) => sum + (l.leadValue || 0), 0) +
      tenders.filter(t => t.status === 'In Progress' || t.status === 'Technical Vetting' || t.status === 'Submitted')
        .reduce((sum, t) => sum + t.estimatedValueQAR, 0);

    const wonTendersValue = tenders.filter(t => t.status === 'Won').reduce((sum, t) => sum + t.estimatedValueQAR, 0);
    const wonProposalsValue = proposals.filter(p => p.status === 'Signed').reduce((sum, p) => sum + p.contractValueQAR, 0);
    const activeTendersCount = tenders.filter(t => t.status === 'In Progress' || t.status === 'Technical Vetting' || t.status === 'Submitted').length;
    const qualifiedLeadsCount = leads.filter(l => l.qualified === 'Yes').length;

    return {
      totalPipelineValue,
      wonRevenue: wonTendersValue + wonProposalsValue,
      activeTendersCount,
      qualifiedLeadsCount,
    };
  }, [leads, tenders, proposals]);

  const handleAddTender = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTender.tenderName || !newTender.clientName) return;
    const record = newTender as TenderRecord;
    onUpdateTenders([record, ...tenders]);
    setIsAddTenderOpen(false);
    setNewTender({
      tenderId: `TND-${new Date().getFullYear()}-${String(tenders.length + 2).padStart(3, '0')}`,
      tenderName: '',
      clientName: '',
      source: 'Monaqasat (Qatar Tender Portal)',
      sector: 'Government',
      submissionDeadline: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      estimatedValueQAR: 500000,
      status: 'In Progress',
      assignedSales: 'Ahmed Al-Kuwari',
      documents: ['RFP_Specification.pdf'],
      notes: '',
    });
  };

  const handleAddProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProposal.projectName || !newProposal.clientName) return;
    const record = newProposal as ProposalContract;
    onUpdateProposals([record, ...proposals]);
    setIsAddProposalOpen(false);
    setNewProposal({
      proposalId: `PROP-2026-${String(proposals.length + 2).padStart(3, '0')}`,
      clientName: '',
      projectName: '',
      relatedQuotationId: `QT-2026-${String(proposals.length + 2).padStart(3, '0')}`,
      proposalDate: new Date().toISOString().split('T')[0],
      contractValueQAR: 350000,
      paymentTerms: '30% Advance, 60% On Delivery, 10% Handover',
      status: 'Draft',
      projectManager: 'Eng. Tareq Mansoor',
      validUntil: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      scopeSummary: 'Supply, installation and MOI-SSD approval of security surveillance system.',
    });
  };

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActivity.relatedTo || !newActivity.description) return;
    const record = newActivity as ActivityLog;
    onUpdateActivityLogs([record, ...activityLogs]);
    setIsAddActivityOpen(false);
    setNewActivity({
      activityId: `ACT-${Date.now().toString().slice(-4)}`,
      relatedTo: '',
      activityType: 'Call',
      date: new Date().toISOString().split('T')[0],
      description: '',
      followUpRequired: true,
      followUpDate: new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
      assignedTo: 'Ahmed Al-Kuwari',
      outcome: '',
    });
  };

  const filteredTenders = tenders.filter(t => {
    const matchesSearch = t.tenderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.tenderId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = sectorFilter === 'All' || t.sector === sectorFilter;
    return matchesSearch && matchesSector;
  });

  const filteredProposals = proposals.filter(p =>
    p.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.proposalId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Top Executive Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 rounded-full border border-indigo-400/30 text-indigo-300 text-xs font-bold uppercase tracking-wider">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Module 1 • Lead & Sales CRM</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
              Sales Pipeline & Qatar Tender Management
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              End-to-end sales lifecycle tracking from Monaqasat tender identification, RFP vetting, BOQ pricing, client proposals, to signed MOI security contracts.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => {
                setGeminiIntelligenceMode('sales-proposal');
                setIsGeminiIntelligenceOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>Draft Tender Proposal (AI)</span>
            </button>
            <button
              onClick={() => setIsAddTenderOpen(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Log New Tender</span>
            </button>
            <button
              onClick={() => setIsAddActivityOpen(true)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border border-slate-700"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Log Activity / Visit</span>
            </button>
          </div>
        </div>

        {/* Executive Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-800/50 rounded-2xl p-3.5 border border-slate-700/50">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Pipeline Value</p>
            <p className="text-xl font-extrabold text-white mt-1">
              QAR {stats.totalPipelineValue.toLocaleString()}
            </p>
            <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1 mt-1">
              <ArrowUpRight className="w-3 h-3" /> Weighted Deals
            </p>
          </div>

          <div className="bg-slate-800/50 rounded-2xl p-3.5 border border-slate-700/50">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Won Contracts (YTD)</p>
            <p className="text-xl font-extrabold text-emerald-400 mt-1">
              QAR {stats.wonRevenue.toLocaleString()}
            </p>
            <p className="text-[10px] text-slate-400 font-medium mt-1">
              Executed & Signed
            </p>
          </div>

          <div className="bg-slate-800/50 rounded-2xl p-3.5 border border-slate-700/50">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Active Tenders</p>
            <p className="text-xl font-extrabold text-indigo-300 mt-1">
              {stats.activeTendersCount} Tenders
            </p>
            <p className="text-[10px] text-indigo-400 font-medium mt-1">
              Monaqasat & Direct RFPs
            </p>
          </div>

          <div className="bg-slate-800/50 rounded-2xl p-3.5 border border-slate-700/50">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Qualified B2B Leads</p>
            <p className="text-xl font-extrabold text-amber-300 mt-1">
              {stats.qualifiedLeadsCount} Leads
            </p>
            <p className="text-[10px] text-slate-400 font-medium mt-1">
              MOI ELV Opportunities
            </p>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('pipeline')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeSubTab === 'pipeline'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Target className="w-4 h-4" />
          <span>1. Leads Pipeline & Qualification</span>
        </button>

        <button
          onClick={() => setActiveSubTab('tenders_proposals')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeSubTab === 'tenders_proposals'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>2. Tenders, Proposals & Contracts ({tenders.length + proposals.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('activities')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeSubTab === 'activities'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>3. Activity & Follow-up Logs ({activityLogs.length})</span>
        </button>

        <button
          onClick={() => {
            if (onNavigateToBOQ) onNavigateToBOQ();
            else setActiveSubTab('boq-summary');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeSubTab === 'boq-summary'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>4. BOQs & Costing Engine ({boqs.length})</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search tenders, clients, leads..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9.5 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs font-bold text-slate-600">Sector:</span>
            <select
              value={sectorFilter}
              onChange={(e) => setSectorFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
            >
              <option value="All">All Sectors</option>
              <option value="Government">Government</option>
              <option value="Enterprise">Enterprise</option>
              <option value="Commercial">Commercial</option>
              <option value="Hospitality">Hospitality</option>
              <option value="Residential">Residential</option>
            </select>
          </div>
        </div>
      </div>

      {/* TAB 1: LEADS PIPELINE */}
      {activeSubTab === 'pipeline' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {['Qualification', 'Proposal', 'Negotiation', 'Won'].map((stageName) => {
              const stageLeads = leads.filter(l => {
                if (stageName === 'Qualification') return l.stage === 'Qualification' || l.stage === 'Lead Generation' || l.stage === 'Assessment';
                if (stageName === 'Proposal') return l.stage === 'Proposal';
                if (stageName === 'Negotiation') return l.stage === 'Negotiation';
                if (stageName === 'Won') return l.stage === 'Won' || l.stage === 'Closing';
                return false;
              });

              const totalStageValue = stageLeads.reduce((acc, l) => acc + (l.leadValue || 0), 0);

              return (
                <div key={stageName} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col min-h-[400px]">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                    <div>
                      <h4 className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
                        {stageName}
                      </h4>
                      <span className="text-[10px] text-slate-400 font-semibold">
                        QAR {totalStageValue.toLocaleString()}
                      </span>
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-700">
                      {stageLeads.length}
                    </span>
                  </div>

                  <div className="space-y-3 flex-1 overflow-y-auto">
                    {stageLeads.map((lead) => (
                      <div
                        key={lead.id}
                        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition space-y-2 cursor-pointer"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <h5 className="font-bold text-xs text-slate-900 leading-tight">{lead.companyName}</h5>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-100 shrink-0">
                            {lead.sector}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                          <span>{lead.contactPerson}</span>
                          <span className="font-bold text-slate-900">QAR {(lead.leadValue || 0).toLocaleString()}</span>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                          <span>Assigned: {lead.assignedTo}</span>
                          <span className="font-semibold text-emerald-600">{lead.probability}% Prob.</span>
                        </div>
                      </div>
                    ))}

                    {stageLeads.length === 0 && (
                      <div className="text-center py-8 text-xs text-slate-400">
                        No deals in this stage
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: TENDERS, PROPOSALS & CONTRACTS (COMBINED) */}
      {activeSubTab === 'tenders_proposals' && (
        <div className="space-y-6">
          {/* Sub-view Switcher & Quick Actions */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl w-full sm:w-auto overflow-x-auto">
              <button
                onClick={() => setTenderProposalFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  tenderProposalFilter === 'all'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Combined ({tenders.length + proposals.length})
              </button>
              <button
                onClick={() => setTenderProposalFilter('tenders')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  tenderProposalFilter === 'tenders'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Qatar Tenders & Bids ({tenders.length})
              </button>
              <button
                onClick={() => setTenderProposalFilter('proposals')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  tenderProposalFilter === 'proposals'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Proposals & Contracts ({proposals.length})
              </button>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                onClick={() => setIsAddTenderOpen(true)}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Tender</span>
              </button>
              <button
                onClick={() => setIsAddProposalOpen(true)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Proposal / Contract</span>
              </button>
            </div>
          </div>

          {/* Section 1: Qatar Tenders & Monaqasat Bids */}
          {(tenderProposalFilter === 'all' || tenderProposalFilter === 'tenders') && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-indigo-50 text-indigo-700 rounded-lg flex items-center justify-center border border-indigo-200">
                    <Building2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900">
                      Active Qatar Tenders & Monaqasat Bids
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Official portal and enterprise RFPs undergoing technical vetting and submission
                    </p>
                  </div>
                </div>
                <span className="text-xs text-slate-500 font-medium bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                  {filteredTenders.length} Active Bids
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Tender ID & Name</th>
                      <th className="py-3 px-4">Client / Authority</th>
                      <th className="py-3 px-4">Source & Sector</th>
                      <th className="py-3 px-4">Deadline</th>
                      <th className="py-3 px-4">Est. Value (QAR)</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Assigned Sales</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredTenders.map((tender) => {
                      const deadlineDate = new Date(tender.submissionDeadline);
                      const today = new Date();
                      const daysLeft = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 3600 * 24));

                      let statusColor = 'bg-slate-100 text-slate-700';
                      if (tender.status === 'Won') statusColor = 'bg-emerald-100 text-emerald-800 font-bold';
                      if (tender.status === 'In Progress') statusColor = 'bg-blue-100 text-blue-800 font-bold';
                      if (tender.status === 'Submitted') statusColor = 'bg-amber-100 text-amber-800 font-bold';
                      if (tender.status === 'Technical Vetting') statusColor = 'bg-purple-100 text-purple-800 font-bold';

                      return (
                        <tr key={tender.tenderId} className="hover:bg-slate-50/80 transition">
                          <td className="py-3.5 px-4">
                            <p className="font-bold text-slate-900">{tender.tenderName}</p>
                            <p className="text-[11px] text-indigo-600 font-mono">{tender.tenderId}</p>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-700">
                            {tender.clientName}
                          </td>
                          <td className="py-3.5 px-4">
                            <p className="text-slate-800 font-medium">{tender.source}</p>
                            <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-md">
                              {tender.sector}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <p className="font-semibold text-slate-800">{tender.submissionDeadline}</p>
                            <span className={`text-[10px] font-bold ${daysLeft <= 5 ? 'text-rose-600' : 'text-slate-500'}`}>
                              {daysLeft > 0 ? `${daysLeft} days remaining` : 'Deadline passed'}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 font-extrabold text-slate-900">
                            QAR {tender.estimatedValueQAR.toLocaleString()}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`px-2.5 py-1 rounded-full text-[11px] ${statusColor}`}>
                              {tender.status}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 font-medium">
                            {tender.assignedSales}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={() => {
                                const newStatus = tender.status === 'In Progress' ? 'Submitted' : tender.status === 'Submitted' ? 'Won' : 'In Progress';
                                const updated = tenders.map(t => t.tenderId === tender.tenderId ? { ...t, status: newStatus as any } : t);
                                onUpdateTenders(updated);
                              }}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                            >
                              Cycle Status
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 2: Client Proposals & Contracts */}
          {(tenderProposalFilter === 'all' || tenderProposalFilter === 'proposals') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-emerald-50 text-emerald-700 rounded-lg flex items-center justify-center border border-emerald-200">
                    <FileText className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900">
                      Client Commercial Proposals & Contracts
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Issued quotations, negotiated scopes, and signed project agreements
                    </p>
                  </div>
                </div>
                <span className="text-xs text-slate-500 font-medium bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                  {filteredProposals.length} Contracts
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {filteredProposals.map((prop) => (
                  <div
                    key={prop.proposalId}
                    className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs hover:shadow-xs transition space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                          {prop.proposalId}
                        </span>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          prop.status === 'Signed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : prop.status === 'Negotiating'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {prop.status}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-sm text-slate-900 leading-snug">
                        {prop.projectName}
                      </h4>
                      <p className="text-xs text-slate-600 font-medium">
                        Client: {prop.clientName}
                      </p>

                      <p className="text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        {prop.scopeSummary}
                      </p>
                    </div>

                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500 font-medium">Contract Value</span>
                        <span className="text-base font-extrabold text-slate-900">
                          QAR {prop.contractValueQAR.toLocaleString()}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-500 space-y-1">
                        <p><span className="font-semibold text-slate-700">Payment:</span> {prop.paymentTerms}</p>
                        <p><span className="font-semibold text-slate-700">Assigned PM:</span> {prop.projectManager}</p>
                        <p><span className="font-semibold text-slate-700">Valid Until:</span> {prop.validUntil}</p>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <button
                          onClick={() => {
                            const newStatus = prop.status === 'Draft' ? 'Sent' : prop.status === 'Sent' ? 'Negotiating' : prop.status === 'Negotiating' ? 'Signed' : 'Draft';
                            const updated = proposals.map(p => p.proposalId === prop.proposalId ? { ...p, status: newStatus as any } : p);
                            onUpdateProposals(updated);
                          }}
                          className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition cursor-pointer"
                        >
                          Update Status ({prop.status})
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: ACTIVITY & FOLLOW-UPS */}
      {activeSubTab === 'activities' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-sm text-slate-900">
              Sales Interaction & Client Follow-up History
            </h3>
            <button
              onClick={() => setIsAddActivityOpen(true)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Interaction</span>
            </button>
          </div>

          <div className="space-y-3">
            {activityLogs.map((act) => (
              <div
                key={act.activityId}
                className="p-4 rounded-xl border border-slate-200 hover:border-indigo-200 transition bg-slate-50/50 space-y-2"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-indigo-100 text-indigo-800">
                      {act.activityType}
                    </span>
                    <h5 className="font-bold text-xs text-slate-900">{act.relatedTo}</h5>
                  </div>
                  <span className="text-[11px] text-slate-500 font-medium">
                    {act.date} • Logged by <strong className="text-slate-700">{act.assignedTo}</strong>
                  </span>
                </div>

                <p className="text-xs text-slate-700">
                  {act.description}
                </p>

                {act.outcome && (
                  <div className="text-[11px] bg-white p-2 rounded-lg border border-slate-200 text-emerald-800 font-medium">
                    <strong>Outcome:</strong> {act.outcome}
                  </div>
                )}

                {act.followUpRequired && act.followUpDate && (
                  <div className="flex items-center gap-2 text-[11px] text-amber-700 font-semibold pt-1">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Follow-up Scheduled for: {act.followUpDate}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: BOQ SUMMARY */}
      {activeSubTab === 'boq-summary' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center space-y-4">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl mx-auto flex items-center justify-center">
            <FileCheck2 className="w-6 h-6" />
          </div>
          <h3 className="font-extrabold text-base text-slate-900">
            Master BOQ Costing Engine
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Access detailed bill of quantities, material vs labor breakdown, target margin calculations, and official MOI-SSD quotation format.
          </p>
          <button
            onClick={() => onNavigateToBOQ && onNavigateToBOQ()}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition inline-flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <span>Open Master BOQ Costing</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* MODAL: ADD TENDER */}
      {isAddTenderOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Log New Qatar Tender / RFP</h3>
              <button
                onClick={() => setIsAddTenderOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddTender} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Tender Name / Package</label>
                <input
                  type="text"
                  required
                  value={newTender.tenderName}
                  onChange={(e) => setNewTender({ ...newTender, tenderName: e.target.value })}
                  placeholder="e.g. Lusail Commercial Tower B Security Package"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                  <input
                    type="text"
                    required
                    value={newTender.clientName}
                    onChange={(e) => setNewTender({ ...newTender, clientName: e.target.value })}
                    placeholder="e.g. Al Rayyan Real Estate"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tender Source</label>
                  <select
                    value={newTender.source}
                    onChange={(e) => setNewTender({ ...newTender, source: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Monaqasat (Qatar Tender Portal)">Monaqasat (Qatar Portal)</option>
                    <option value="Direct Client RFP">Direct Client RFP</option>
                    <option value="Ashghal / Kahramaa">Ashghal / Kahramaa</option>
                    <option value="Partner Subcontract">Partner Subcontract</option>
                    <option value="Referral">Referral</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Sector</label>
                  <select
                    value={newTender.sector}
                    onChange={(e) => setNewTender({ ...newTender, sector: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Government">Government</option>
                    <option value="Enterprise">Enterprise</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Hospitality">Hospitality</option>
                    <option value="Residential">Residential</option>
                    <option value="Healthcare">Healthcare</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Submission Deadline</label>
                  <input
                    type="date"
                    required
                    value={newTender.submissionDeadline}
                    onChange={(e) => setNewTender({ ...newTender, submissionDeadline: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Estimated Value (QAR)</label>
                  <input
                    type="number"
                    required
                    value={newTender.estimatedValueQAR}
                    onChange={(e) => setNewTender({ ...newTender, estimatedValueQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Assigned Sales</label>
                  <input
                    type="text"
                    value={newTender.assignedSales}
                    onChange={(e) => setNewTender({ ...newTender, assignedSales: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Notes & Scope</label>
                <textarea
                  rows={2}
                  value={newTender.notes}
                  onChange={(e) => setNewTender({ ...newTender, notes: e.target.value })}
                  placeholder="Key requirements, camera counts, storage specifications..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddTenderOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save Tender Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD PROPOSAL */}
      {isAddProposalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Create Client Proposal / Contract</h3>
              <button
                onClick={() => setIsAddProposalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddProposal} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newProposal.projectName}
                  onChange={(e) => setNewProposal({ ...newProposal, projectName: e.target.value })}
                  placeholder="e.g. Al Sadd Commercial Center CCTV & ANPR Upgrade"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                  <input
                    type="text"
                    required
                    value={newProposal.clientName}
                    onChange={(e) => setNewProposal({ ...newProposal, clientName: e.target.value })}
                    placeholder="e.g. Al Sadd Hospitality Group"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Related Quotation ID</label>
                  <input
                    type="text"
                    value={newProposal.relatedQuotationId}
                    onChange={(e) => setNewProposal({ ...newProposal, relatedQuotationId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Contract Value (QAR)</label>
                  <input
                    type="number"
                    required
                    value={newProposal.contractValueQAR}
                    onChange={(e) => setNewProposal({ ...newProposal, contractValueQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Status</label>
                  <select
                    value={newProposal.status}
                    onChange={(e) => setNewProposal({ ...newProposal, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Draft">Draft</option>
                    <option value="Sent">Sent</option>
                    <option value="Negotiating">Negotiating</option>
                    <option value="Signed">Signed</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Assigned Project Manager</label>
                  <input
                    type="text"
                    value={newProposal.projectManager}
                    onChange={(e) => setNewProposal({ ...newProposal, projectManager: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Valid Until</label>
                  <input
                    type="date"
                    required
                    value={newProposal.validUntil}
                    onChange={(e) => setNewProposal({ ...newProposal, validUntil: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Payment Terms</label>
                <input
                  type="text"
                  value={newProposal.paymentTerms}
                  onChange={(e) => setNewProposal({ ...newProposal, paymentTerms: e.target.value })}
                  placeholder="e.g. 30% Advance, 60% On Delivery, 10% Handover"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Scope Summary</label>
                <textarea
                  rows={2}
                  value={newProposal.scopeSummary}
                  onChange={(e) => setNewProposal({ ...newProposal, scopeSummary: e.target.value })}
                  placeholder="Brief summary of deliverables and engineering scope..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddProposalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save Proposal Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD ACTIVITY */}
      {isAddActivityOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Log Sales Activity / Interaction</h3>
              <button
                onClick={() => setIsAddActivityOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddActivity} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Related Client / Tender / Lead</label>
                <input
                  type="text"
                  required
                  value={newActivity.relatedTo}
                  onChange={(e) => setNewActivity({ ...newActivity, relatedTo: e.target.value })}
                  placeholder="e.g. Qatar Hospitality Group (West Bay Hotel)"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Activity Type</label>
                  <select
                    value={newActivity.activityType}
                    onChange={(e) => setNewActivity({ ...newActivity, activityType: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                  >
                    <option value="Call">Call</option>
                    <option value="Meeting">Meeting</option>
                    <option value="Email">Email</option>
                    <option value="Site Visit">Site Visit</option>
                    <option value="Consultant Technical Review">Consultant Review</option>
                    <option value="MOI Pre-check">MOI Pre-check</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={newActivity.date}
                    onChange={(e) => setNewActivity({ ...newActivity, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Description / Discussion Summary</label>
                <textarea
                  rows={3}
                  required
                  value={newActivity.description}
                  onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })}
                  placeholder="Summary of meeting or phone conversation..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Outcome / Next Action</label>
                <input
                  type="text"
                  value={newActivity.outcome}
                  onChange={(e) => setNewActivity({ ...newActivity, outcome: e.target.value })}
                  placeholder="e.g. Client requested revised AMC clause in proposal"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-center">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="followUpCheck"
                    checked={newActivity.followUpRequired}
                    onChange={(e) => setNewActivity({ ...newActivity, followUpRequired: e.target.checked })}
                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="followUpCheck" className="font-bold text-slate-700">Follow-up Needed?</label>
                </div>
                {newActivity.followUpRequired && (
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Follow-up Date</label>
                    <input
                      type="date"
                      value={newActivity.followUpDate}
                      onChange={(e) => setNewActivity({ ...newActivity, followUpDate: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddActivityOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save Activity Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
