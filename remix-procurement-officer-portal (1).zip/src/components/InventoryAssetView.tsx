import React, { useState, useMemo } from 'react';
import {
  InventoryItemRecord,
  ProjectAssetAssignment,
  MaterialSubmittal,
  PurchaseOrder,
  LogisticsShipment,
  SupplierRecord,
  BOQRecord,
  PriceHistoryRecord,
} from '../types';
import {
  Package,
  Barcode,
  Building2,
  AlertTriangle,
  Search,
  Plus,
  ArrowRight,
  CheckCircle2,
  Layers,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  FileCheck2,
  FileCheck,
  Truck,
  History,
  Database,
  TrendingDown,
  TrendingUp,
  Tag,
  Coins,
  ArrowUpDown,
} from 'lucide-react';
import { MaterialSubmittalsView } from './MaterialSubmittalsView';
import { PurchaseOrdersView } from './PurchaseOrdersView';
import { LogisticsCustomsView } from './LogisticsCustomsView';
import { PriceHistoryAnalytics } from './PriceHistoryAnalytics';
import { SerializedDeploymentsView } from './SerializedDeploymentsView';
import { EditableTable, ColumnDef } from './EditableTable';

interface InventoryAssetViewProps {
  inventoryItems: InventoryItemRecord[];
  projectAssets: ProjectAssetAssignment[];
  materialSubmittals: MaterialSubmittal[];
  purchaseOrders: PurchaseOrder[];
  shipments: LogisticsShipment[];
  suppliers: SupplierRecord[];
  boqs: BOQRecord[];
  priceHistory?: PriceHistoryRecord[];
  onUpdateInventory: (data: InventoryItemRecord[]) => void;
  onUpdateProjectAssets: (data: ProjectAssetAssignment[]) => void;
  onUpdateMaterialSubmittals: (data: MaterialSubmittal[]) => void;
  onUpdatePurchaseOrders: (data: PurchaseOrder[]) => void;
  onUpdateShipments: (data: LogisticsShipment[]) => void;
  onUpdateSuppliers: (data: SupplierRecord[]) => void;
  onUpdatePriceHistory?: (data: PriceHistoryRecord[]) => void;
  onOpenQuickAdd: () => void;
}

export const InventoryAssetView: React.FC<InventoryAssetViewProps> = ({
  inventoryItems,
  projectAssets,
  materialSubmittals,
  purchaseOrders,
  shipments,
  suppliers,
  boqs,
  priceHistory = [],
  onUpdateInventory,
  onUpdateProjectAssets,
  onUpdateMaterialSubmittals,
  onUpdatePurchaseOrders,
  onUpdateShipments,
  onUpdateSuppliers,
  onUpdatePriceHistory,
  onOpenQuickAdd,
}) => {
  const [activeTab, setActiveTab] = useState<'warehouse' | 'price-history' | 'serialized-deployments' | 'submittals_po_supplier'>('warehouse');
  const [search, setSearch] = useState('');
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [isLogPriceOpen, setIsLogPriceOpen] = useState(false);
  const [selectedSkuForPrice, setSelectedSkuForPrice] = useState<InventoryItemRecord | null>(null);

  // Price History Filters
  const [priceFilter, setPriceFilter] = useState<string>('all');
  const [priceSearch, setPriceSearch] = useState<string>('');
  const [priceComponentClass, setPriceComponentClass] = useState<string>('All');
  const [priceLocation, setPriceLocation] = useState<string>('All');
  const [priceMoi, setPriceMoi] = useState<string>('All');
  const [priceProject, setPriceProject] = useState<string>('All');
  const [priceQuotation, setPriceQuotation] = useState<string>('All');
  const [priceBrand, setPriceBrand] = useState<string>('All');
  const [priceRevision, setPriceRevision] = useState<string>('All');

  const [newItem, setNewItem] = useState<Partial<InventoryItemRecord>>({
    itemId: `INV-${Date.now().toString().slice(-4)}`,
    brand: 'Hikvision',
    model: 'DS-2CD2387G2P-LSU/SL',
    category: 'CCTV Cameras',
    description: '8MP Panoramic ColorVu Turret Network Camera',
    warehouseLocation: 'Doha Central Warehouse (Industrial Area St. 24)',
    quantityOnHand: 24,
    minimumStockLevel: 6,
    reorderQuantity: 20,
    reorderStatus: 'Sufficient',
    status: 'In Stock',
    unitCostQAR: 450,
    totalValueQAR: 10800,
    preferredSupplier: 'Al-Anwar Security Supplies',
    moiApproved: 'Yes',
  });

  const [newPriceEntry, setNewPriceEntry] = useState<Partial<PriceHistoryRecord>>({
    productCode: 'SEC-CAM-001',
    productName: '8MP Panoramic ColorVu Turret Camera',
    brand: 'Hikvision',
    model: 'DS-2CD2387G2P-LSU/SL',
    category: 'Cameras & VMS',
    supplier: 'Al-Anwar Security Supplies',
    oldPrice: 520,
    newPrice: 450,
    moiApproved: 'Yes',
    componentClass: 'Active',
    cityLocation: 'Doha',
    projectName: 'Ezdan Real Estate Phase 2 Upgrade',
    reason: 'Vendor Volume Discount Agreement (PO #2026-088)',
    notes: 'Unit price logged to database and utilized across warehouse inventory and BOQs',
  });

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.model) return;
    const computedTotal = (newItem.quantityOnHand || 0) * (newItem.unitCostQAR || 0);
    const itemToSave: InventoryItemRecord = {
      itemId: newItem.itemId || `INV-${Date.now().toString().slice(-4)}`,
      brand: newItem.brand || 'Generic',
      model: newItem.model || '',
      category: newItem.category || 'CCTV Cameras',
      description: newItem.description || '',
      warehouseLocation: newItem.warehouseLocation || 'Doha Central Warehouse',
      quantityOnHand: newItem.quantityOnHand || 0,
      minimumStockLevel: newItem.minimumStockLevel || 5,
      reorderQuantity: newItem.reorderQuantity || 10,
      reorderStatus: (newItem.quantityOnHand || 0) <= (newItem.minimumStockLevel || 5) ? 'Low Stock' : 'Sufficient',
      status: newItem.status || 'In Stock',
      unitCostQAR: newItem.unitCostQAR || 0,
      totalValueQAR: computedTotal,
      preferredSupplier: newItem.preferredSupplier || 'Authorized Distributor',
      moiApproved: newItem.moiApproved || 'Yes',
      serialNumber: newItem.serialNumber,
    };
    onUpdateInventory([itemToSave, ...inventoryItems]);
    setIsAddItemOpen(false);
  };

  const handleSavePriceLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPriceEntry.productName || !onUpdatePriceHistory) return;
    const oldP = Number(newPriceEntry.oldPrice) || 0;
    const newP = Number(newPriceEntry.newPrice) || 0;
    const diff = newP - oldP;
    const pct = oldP > 0 ? ((newP - oldP) / oldP) * 100 : 0;
    const changeType: 'Decrease' | 'Increase' | 'Unchanged' = diff < 0 ? 'Decrease' : diff > 0 ? 'Increase' : 'Unchanged';

    const record: PriceHistoryRecord = {
      id: `PH-${Date.now().toString().slice(-5)}`,
      productCode: newPriceEntry.productCode || `SEC-SKU-${Date.now().toString().slice(-4)}`,
      productName: newPriceEntry.productName || '',
      brand: newPriceEntry.brand || 'Generic',
      model: newPriceEntry.model || '',
      category: newPriceEntry.category || 'Cameras & VMS',
      supplier: newPriceEntry.supplier || 'Authorized Supplier',
      oldPrice: oldP,
      newPrice: newP,
      priceChange: diff,
      percentChange: Number(pct.toFixed(2)),
      changeType,
      effectiveDate: new Date().toISOString().split('T')[0],
      reason: newPriceEntry.reason || 'Quarterly price adjustment logged into database',
      moiApproved: (newPriceEntry.moiApproved as any) || 'Yes',
      componentClass: (newPriceEntry.componentClass as any) || 'Active',
      cityLocation: (newPriceEntry.cityLocation as any) || 'Doha',
      projectName: newPriceEntry.projectName || 'Warehouse Procurement Database',
      quotationName: newPriceEntry.quotationName || 'Standard Catalogue',
      revisionNumber: newPriceEntry.revisionNumber || 'R0',
      notes: newPriceEntry.notes || 'Logged into centralized ERP Price History Database',
    };

    onUpdatePriceHistory([record, ...priceHistory]);

    // Also update any matching inventory item's unitCostQAR to utilize the newly logged price!
    if (newPriceEntry.model) {
      const updatedInventory = inventoryItems.map((inv) => {
        if (inv.model.toLowerCase() === newPriceEntry.model?.toLowerCase()) {
          const newTotal = inv.quantityOnHand * newP;
          return { ...inv, unitCostQAR: newP, totalValueQAR: newTotal };
        }
        return inv;
      });
      onUpdateInventory(updatedInventory);
    }

    setIsLogPriceOpen(false);
    setSelectedSkuForPrice(null);
  };

  const handlePriceUpdate = (data: PriceHistoryRecord[]) => {
    if (!onUpdatePriceHistory) return;
    const recalculated = data.map((item) => {
      const oldP = Number(item.oldPrice) || 0;
      const newP = Number(item.newPrice) || 0;
      const diff = newP - oldP;
      const pct = oldP > 0 ? ((newP - oldP) / oldP) * 100 : 0;
      return {
        ...item,
        priceChange: diff,
        percentChange: Number(pct.toFixed(2)),
        changeType: (diff < 0 ? 'Decrease' : diff > 0 ? 'Increase' : 'Unchanged') as 'Decrease' | 'Increase' | 'Unchanged',
      };
    });
    onUpdatePriceHistory(recalculated);
  };

  // Filtered Price History
  const filteredPriceHistory = useMemo(() => {
    return priceHistory.filter((item) => {
      if (priceFilter === 'Decrease' && item.changeType !== 'Decrease') return false;
      if (priceFilter === 'Increase' && item.changeType !== 'Increase') return false;
      if (priceFilter === 'moi' && item.moiApproved !== 'Yes') return false;

      if (priceComponentClass !== 'All') {
        if (priceComponentClass === 'Active' && item.componentClass === 'Passive') return false;
        if (priceComponentClass === 'Passive' && item.componentClass !== 'Passive') return false;
      }

      if (priceLocation !== 'All' && item.cityLocation && item.cityLocation !== priceLocation && item.cityLocation !== 'All Qatar') {
        return false;
      }

      if (priceProject !== 'All' && item.projectName && item.projectName !== priceProject) {
        return false;
      }

      if (priceQuotation !== 'All' && item.quotationName && item.quotationName !== priceQuotation) {
        return false;
      }

      if (priceBrand !== 'All' && item.brand && item.brand !== priceBrand) {
        return false;
      }

      if (priceRevision !== 'All' && item.revisionNumber && item.revisionNumber !== priceRevision) {
        return false;
      }

      if (priceMoi === 'Yes' && item.moiApproved !== 'Yes') return false;
      if (priceMoi === 'No' && item.moiApproved === 'Yes') return false;

      if (priceSearch.trim()) {
        const q = priceSearch.toLowerCase();
        const matchCode = item.productCode?.toLowerCase().includes(q);
        const matchName = item.productName?.toLowerCase().includes(q);
        const matchBrand = item.brand?.toLowerCase().includes(q);
        const matchSupplier = item.supplier?.toLowerCase().includes(q);
        const matchProject = item.projectName?.toLowerCase().includes(q);
        const matchReason = item.reason?.toLowerCase().includes(q);
        if (!matchCode && !matchName && !matchBrand && !matchSupplier && !matchProject && !matchReason) return false;
      }

      return true;
    });
  }, [priceHistory, priceFilter, priceSearch, priceComponentClass, priceLocation, priceMoi, priceProject, priceQuotation, priceBrand, priceRevision]);

  const priceCols: ColumnDef[] = [
    { key: 'productCode', label: 'Item Code', type: 'text' },
    { key: 'productName', label: 'Security Item / Model', type: 'text' },
    { key: 'category', label: 'Category', type: 'select', options: ['Cables & Containment', 'Controllers & Access', 'Cameras & VMS', 'Panels & Racks', 'Accessories & Hardware', 'Labor & Engineering'] },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'componentClass', label: 'Class', type: 'select', options: ['Active', 'Passive'] },
    { key: 'supplier', label: 'Supplier / Vendor', type: 'text' },
    { key: 'oldPrice', label: 'Old Unit (QAR)', type: 'currency' },
    { key: 'newPrice', label: 'Latest Unit (QAR)', type: 'currency' },
    { key: 'priceChange', label: 'Variance (QAR)', type: 'currency', isFormula: true, formulaLabel: '=New - Old' },
    { key: 'percentChange', label: '% Change', type: 'percent', isFormula: true, formulaLabel: '=((New-Old)/Old)*100' },
    { key: 'changeType', label: 'Trend', type: 'select', options: ['Decrease', 'Increase', 'Unchanged'] },
    { key: 'moiApproved', label: 'MOI SSD', type: 'select', options: ['Yes', 'No', 'Pending'] },
    { key: 'effectiveDate', label: 'Logged Date', type: 'date' },
    { key: 'reason', label: 'Reason / PO Reference', type: 'text' },
    { key: 'notes', label: 'Database Utilization Notes', type: 'text' },
  ];

  const filteredItems = inventoryItems.filter(item =>
    item.model.toLowerCase().includes(search.toLowerCase()) ||
    item.brand.toLowerCase().includes(search.toLowerCase()) ||
    item.description.toLowerCase().includes(search.toLowerCase()) ||
    item.itemId.toLowerCase().includes(search.toLowerCase())
  );

  const filteredAssets = projectAssets.filter(asset =>
    asset.serialNumber.toLowerCase().includes(search.toLowerCase()) ||
    asset.productName.toLowerCase().includes(search.toLowerCase()) ||
    asset.projectName.toLowerCase().includes(search.toLowerCase())
  );

  const totalStockValueQAR = inventoryItems.reduce((sum, item) => sum + item.totalValueQAR, 0);
  const lowStockCount = inventoryItems.filter(item => item.quantityOnHand <= item.minimumStockLevel).length;
  const totalTrackedPrices = priceHistory.length;

  return (
    <div className="space-y-6 pb-12">
      {/* Sub-Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('warehouse')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'warehouse'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>1. Warehouse Stock Inventory ({inventoryItems.length} SKUs)</span>
        </button>

        <button
          onClick={() => setActiveTab('price-history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'price-history'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>2. Price History Database & Logs ({priceHistory.length} Logged SKUs)</span>
        </button>

        <button
          onClick={() => setActiveTab('serialized-deployments')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'serialized-deployments'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Barcode className="w-4 h-4" />
          <span>3. Serialized Assets & Site Deployments ({projectAssets.length} Units)</span>
        </button>

        <button
          onClick={() => setActiveTab('submittals_po_supplier')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'submittals_po_supplier'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>4. Submittals, PO & Vendors</span>
        </button>
      </div>

      {/* TAB 1: WAREHOUSE STOCK */}
      {activeTab === 'warehouse' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">
                  Central & Regional Warehouse Stock Registry
                </h3>
                <p className="text-2xs text-slate-500 mt-0.5">
                  Unit costs and valuations synchronized with logged database prices
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search SKU, brand, model..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-teal-500/20"
                  />
                </div>
                <button
                  onClick={() => setIsAddItemOpen(true)}
                  className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Hardware</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Item ID / Brand</th>
                    <th className="py-3 px-4">Model & Description</th>
                    <th className="py-3 px-4">Location</th>
                    <th className="py-3 px-4 text-center">Qty on Hand</th>
                    <th className="py-3 px-4 text-center">Safety Level</th>
                    <th className="py-3 px-4 text-right">Unit Cost (QAR)</th>
                    <th className="py-3 px-4 text-right">Total Value (QAR)</th>
                    <th className="py-3 px-4">Database Price Log</th>
                    <th className="py-3 px-4">MOI Appr.</th>
                    <th className="py-3 px-4">Stock Status</th>
                    <th className="py-3 px-4 text-center">Price Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredItems.map((item) => {
                    const isLow = item.quantityOnHand <= item.minimumStockLevel;
                    const matchingPriceLog = priceHistory.find(
                      p => p.model?.toLowerCase() === item.model.toLowerCase() ||
                           p.productName?.toLowerCase().includes(item.model.toLowerCase())
                    );

                    return (
                      <tr key={item.itemId} className="hover:bg-slate-50/80 transition">
                        <td className="py-3.5 px-4">
                          <span className="font-mono font-bold text-teal-600 block">{item.itemId}</span>
                          <span className="text-[10px] text-slate-500 font-semibold">{item.brand}</span>
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-bold text-slate-900">{item.model}</p>
                          <p className="text-[11px] text-slate-500 max-w-xs truncate">{item.description}</p>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 font-medium">
                          {item.warehouseLocation}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span className={`font-extrabold text-sm ${isLow ? 'text-rose-600' : 'text-slate-900'}`}>
                            {item.quantityOnHand}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-center text-slate-500 font-medium">
                          {item.minimumStockLevel}
                        </td>
                        <td className="py-3.5 px-4 text-right font-medium text-slate-700">
                          {item.unitCostQAR.toLocaleString()}
                        </td>
                        <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                          {item.totalValueQAR.toLocaleString()}
                        </td>
                        <td className="py-3.5 px-4">
                          {matchingPriceLog ? (
                            <div className="space-y-0.5">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                                <Database className="w-3 h-3" />
                                QAR {matchingPriceLog.newPrice}
                              </span>
                              {matchingPriceLog.priceChange !== 0 && (
                                <span className={`block text-[10px] font-semibold ${matchingPriceLog.priceChange < 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                  {matchingPriceLog.priceChange < 0 ? '↓' : '↑'} {matchingPriceLog.percentChange}%
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-400 italic">No custom log</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            item.moiApproved === 'Yes' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.moiApproved}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            isLow ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {item.reorderStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <button
                            onClick={() => {
                              setSelectedSkuForPrice(item);
                              setNewPriceEntry({
                                productCode: `SKU-${item.itemId}`,
                                productName: `${item.brand} ${item.model}`,
                                brand: item.brand,
                                model: item.model,
                                category: item.category,
                                supplier: item.preferredSupplier,
                                oldPrice: item.unitCostQAR,
                                newPrice: item.unitCostQAR,
                                moiApproved: (item.moiApproved as any) || 'Yes',
                                componentClass: 'Active',
                                cityLocation: 'Doha',
                                projectName: 'Central Warehouse Registry',
                                reason: `Updated unit price log for SKU ${item.itemId}`,
                                notes: 'Utilized across warehouse valuation and procurement quoting',
                              });
                              setIsLogPriceOpen(true);
                            }}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 border border-slate-200 rounded-lg text-2xs font-bold transition cursor-pointer"
                            title="Log new price in database"
                          >
                            Log Price
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PRICE HISTORY DATABASE & LOGS */}
      {activeTab === 'price-history' && (
        <div className="space-y-5">
          {/* Price History Database Info Header */}
          <div className="bg-indigo-900 text-white p-4 rounded-2xl border border-indigo-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-700/80 rounded-xl flex items-center justify-center shrink-0 border border-indigo-500/30">
                <Database className="w-5 h-5 text-indigo-200" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white">Centralized Price History Database</h4>
                <p className="text-xs text-indigo-200">
                  Every PO, vendor negotiation, and revised quote is logged in our database and utilized directly across inventory unit costs, BOQ takeoffs, and quotation matrices.
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedSkuForPrice(null);
                setIsLogPriceOpen(true);
              }}
              className="px-4 py-2 bg-white text-indigo-900 hover:bg-indigo-50 rounded-xl text-xs font-black transition cursor-pointer shrink-0 shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log New Price Record</span>
            </button>
          </div>

          <PriceHistoryAnalytics
            priceHistory={priceHistory}
            suppliers={suppliers}
            onOpenQuickAdd={() => setIsLogPriceOpen(true)}
            selectedFilter={priceFilter}
            onFilterChange={setPriceFilter}
            searchQuery={priceSearch}
            onSearchChange={setPriceSearch}
            componentClass={priceComponentClass}
            onComponentClassChange={setPriceComponentClass}
            location={priceLocation}
            onLocationChange={setPriceLocation}
            moi={priceMoi}
            onMoiChange={setPriceMoi}
            project={priceProject}
            onProjectChange={setPriceProject}
            quotation={priceQuotation}
            onQuotationChange={setPriceQuotation}
            brand={priceBrand}
            onBrandChange={setPriceBrand}
            revision={priceRevision}
            onRevisionChange={setPriceRevision}
          />

          <EditableTable
            title="Price History & Variance Database Logs (Latest vs Old)"
            subtitle="Automated variance calculation: Price Change = New - Old, % Change = ((New - Old) / Old) * 100"
            columns={priceCols}
            data={filteredPriceHistory}
            onUpdateData={handlePriceUpdate}
            onAddRow={() => setIsLogPriceOpen(true)}
            badge="Table 4"
            badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
            enableSelection={false}
          />
        </div>
      )}

      {/* TAB 3: SERIALIZED ASSETS & PROJECT SITE DEPLOYMENTS (COMBINED) */}
      {activeTab === 'serialized-deployments' && (
        <SerializedDeploymentsView
          projectAssets={projectAssets}
          inventoryItems={inventoryItems}
          onUpdateProjectAssets={onUpdateProjectAssets}
          onOpenQuickAdd={onOpenQuickAdd}
        />
      )}

      {/* TAB 4: PROCUREMENT & VENDORS */}
      {activeTab === 'submittals_po_supplier' && (
        <div className="space-y-8 p-4">
          <MaterialSubmittalsView
            submittals={materialSubmittals}
            onUpdateSubmittals={onUpdateMaterialSubmittals}
            onOpenQuickAdd={onOpenQuickAdd}
          />
          <PurchaseOrdersView
            purchaseOrders={purchaseOrders}
            suppliers={suppliers}
            boqs={boqs}
            onUpdatePurchaseOrders={onUpdatePurchaseOrders}
            onOpenQuickAdd={onOpenQuickAdd}
          />
          <LogisticsCustomsView
            shipments={shipments}
            onUpdateShipments={onUpdateShipments}
            onOpenQuickAdd={onOpenQuickAdd}
          />
          <EditableTable
            title="Supplier Database (MOI Approved Vendors)"
            subtitle="Active suppliers, MOI compliance status, country of origin, payment terms & ratings"
            columns={[
              { key: 'code', label: 'Code', type: 'readonly' },
              { key: 'name', label: 'Supplier Name', type: 'text' },
              { key: 'country', label: 'Country', type: 'text' },
              { key: 'contactPerson', label: 'Contact', type: 'text' },
              { key: 'phone', label: 'Phone', type: 'text' },
              { key: 'email', label: 'Email', type: 'text' },
              { key: 'moiApproved', label: 'MOI Approved', type: 'select', options: ['Yes', 'No', 'Pending'] },
              { key: 'products', label: 'Products', type: 'text' },
              { key: 'creditTerms', label: 'Credit Terms', type: 'text' },
              { key: 'paymentTerms', label: 'Payment Terms', type: 'text' },
              { key: 'deliveryLeadTime', label: 'Lead Time', type: 'text' },
              { key: 'rating', label: 'Rating (1-5)', type: 'number' },
              { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive', 'Onboarding', 'Suspended', 'Pending Approval'] },
            ]}
            data={suppliers}
            onUpdateData={onUpdateSuppliers}
            badge="Table 3"
            badgeColor="bg-purple-50 text-purple-700 border-purple-200"
          />
        </div>
      )}

      {/* MODAL: LOG NEW PRICE ENTRY TO DATABASE */}
      {isLogPriceOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-xl shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  Log Price Entry into Central Database
                </h3>
                <p className="text-2xs text-slate-500">
                  This price is saved in the database and automatically utilized for inventory valuation and SCM quotes.
                </p>
              </div>
              <button
                onClick={() => {
                  setIsLogPriceOpen(false);
                  setSelectedSkuForPrice(null);
                }}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePriceLog} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Item Code / SKU</label>
                  <input
                    type="text"
                    required
                    value={newPriceEntry.productCode}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, productCode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={newPriceEntry.category}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, category: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  >
                    <option value="Cameras & VMS">Cameras & VMS</option>
                    <option value="Cables & Containment">Cables & Containment</option>
                    <option value="Controllers & Access">Controllers & Access</option>
                    <option value="Panels & Racks">Panels & Racks</option>
                    <option value="Accessories & Hardware">Accessories & Hardware</option>
                    <option value="Labor & Engineering">Labor & Engineering</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Product Description / Model</label>
                <input
                  type="text"
                  required
                  value={newPriceEntry.productName}
                  onChange={(e) => setNewPriceEntry({ ...newPriceEntry, productName: e.target.value })}
                  placeholder="e.g. 8MP Panoramic ColorVu Turret Camera"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Brand</label>
                  <input
                    type="text"
                    value={newPriceEntry.brand}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, brand: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Model Code</label>
                  <input
                    type="text"
                    value={newPriceEntry.model}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, model: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Supplier</label>
                  <input
                    type="text"
                    value={newPriceEntry.supplier}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, supplier: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Old Price (QAR)</label>
                  <input
                    type="number"
                    value={newPriceEntry.oldPrice}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, oldPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-indigo-700 block mb-1">New Price (QAR)</label>
                  <input
                    type="number"
                    value={newPriceEntry.newPrice}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, newPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-white border border-indigo-300 rounded-xl font-extrabold text-indigo-700"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Variance (QAR)</label>
                  <div className={`px-3 py-2 rounded-xl font-extrabold text-xs ${
                    ((newPriceEntry.newPrice || 0) - (newPriceEntry.oldPrice || 0)) < 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-800'
                  }`}>
                    {((newPriceEntry.newPrice || 0) - (newPriceEntry.oldPrice || 0)).toLocaleString()} QAR
                  </div>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">MOI Approved</label>
                  <select
                    value={newPriceEntry.moiApproved}
                    onChange={(e) => setNewPriceEntry({ ...newPriceEntry, moiApproved: e.target.value as any })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl"
                  >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Reason / PO Ref / Justification</label>
                <input
                  type="text"
                  value={newPriceEntry.reason}
                  onChange={(e) => setNewPriceEntry({ ...newPriceEntry, reason: e.target.value })}
                  placeholder="e.g. Volume discount from distributor, updated catalog price"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsLogPriceOpen(false);
                    setSelectedSkuForPrice(null);
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Save to Price Database & Utilize</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD HARDWARE ITEM */}
      {isAddItemOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Add Inventory Hardware Item</h3>
              <button
                onClick={() => setIsAddItemOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddItem} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Item ID</label>
                  <input
                    type="text"
                    required
                    value={newItem.itemId}
                    onChange={(e) => setNewItem({ ...newItem, itemId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Brand</label>
                  <input
                    type="text"
                    required
                    value={newItem.brand}
                    onChange={(e) => setNewItem({ ...newItem, brand: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Model Name / Number</label>
                <input
                  type="text"
                  required
                  value={newItem.model}
                  onChange={(e) => {
                    const modelVal = e.target.value;
                    // Check if price exists in priceHistory database
                    const existingPrice = priceHistory.find(p => p.model?.toLowerCase() === modelVal.toLowerCase());
                    if (existingPrice) {
                      setNewItem({
                        ...newItem,
                        model: modelVal,
                        unitCostQAR: existingPrice.newPrice,
                        preferredSupplier: existingPrice.supplier || newItem.preferredSupplier,
                        brand: existingPrice.brand || newItem.brand,
                      });
                    } else {
                      setNewItem({ ...newItem, model: modelVal });
                    }
                  }}
                  placeholder="e.g. DS-2CD2387G2P-LSU/SL"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Item Description</label>
                <input
                  type="text"
                  required
                  value={newItem.description}
                  onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                  placeholder="e.g. 8MP Panoramic ColorVu Turret Network Camera"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Initial Qty</label>
                  <input
                    type="number"
                    value={newItem.quantityOnHand}
                    onChange={(e) => setNewItem({ ...newItem, quantityOnHand: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Safety Min Qty</label>
                  <input
                    type="number"
                    value={newItem.minimumStockLevel}
                    onChange={(e) => setNewItem({ ...newItem, minimumStockLevel: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Unit Cost (QAR)</label>
                  <input
                    type="number"
                    value={newItem.unitCostQAR}
                    onChange={(e) => setNewItem({ ...newItem, unitCostQAR: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddItemOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save Hardware Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
