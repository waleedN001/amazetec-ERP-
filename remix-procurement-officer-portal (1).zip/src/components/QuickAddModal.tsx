import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Building2,
  Calendar,
  DollarSign,
  Package,
  Layers,
  FileCheck,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Truck,
  Sparkles,
  Link as LinkIcon,
  Tag,
  Clock,
  ArrowRight,
  Info
} from 'lucide-react';
import { useAppData } from '../context/useAppData';
import { getProjectContext, getProductContext, getVendorContext } from '../services/relationalEngine';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddRecord?: (type: string, record: any) => void;
}

type RecordType =
  | 'pr'
  | 'po'
  | 'submittal'
  | 'lead'
  | 'boq'
  | 'supplier'
  | 'price'
  | 'shipment'
  | 'reconciliation'
  | 'tender'
  | 'ticket';

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onAddRecord,
}) => {
  const {
    projects,
    suppliers,
    equipmentMaster,
    boqs,
    purchaseRequisitions,
    purchaseOrders,
    handleAddRecord: addRecordContext,
  } = useAppData();

  const [activeType, setActiveType] = useState<RecordType>('pr');
  const [showAutoFillNotice, setShowAutoFillNotice] = useState(false);
  const [autoFilledFields, setAutoFilledFields] = useState<string[]>([]);

  // PR Form State
  const [prProject, setPrProject] = useState(projects[0]?.projectName || '');
  const [prBoqId, setPrBoqId] = useState(boqs[0]?.boqId || 'BOQ-001');
  const [prLocation, setPrLocation] = useState('Doha West Bay Site');
  const [prItemCode, setPrItemCode] = useState('');
  const [prItemDesc, setPrItemDesc] = useState('');
  const [prQty, setPrQty] = useState(10);
  const [prBudget, setPrBudget] = useState(25000);
  const [prPriority, setPrPriority] = useState<'Urgent' | 'High' | 'Medium' | 'Low'>('High');
  const [prTechnicalVetting, setPrTechnicalVetting] = useState<'Verified with Specs' | 'Pending Specs Check' | 'Non-Compliant (Hold)'>('Verified with Specs');
  const [prConsultantApproval, setPrConsultantApproval] = useState<'Yes' | 'No'>('Yes');

  // PO Form State
  const [poPRId, setPoPRId] = useState(purchaseRequisitions[0]?.prId || '');
  const [poProject, setPoProject] = useState(projects[0]?.projectName || '');
  const [poSupplier, setPoSupplier] = useState(suppliers[0]?.name || '');
  const [poAmount, setPoAmount] = useState(35000);
  const [poTerms, setPoTerms] = useState('30 Days Net on GRN');
  const [poDeliveryDate, setPoDeliveryDate] = useState(new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]);
  const [poLocation, setPoLocation] = useState('Doha Central Warehouse');

  // Submittal Form State
  const [submittalProductCode, setSubmittalProductCode] = useState(equipmentMaster[0]?.code || '');
  const [submittalProject, setSubmittalProject] = useState(projects[0]?.projectName || '');
  const [submittalBrand, setSubmittalBrand] = useState('Hikvision');
  const [submittalModel, setSubmittalModel] = useState('DS-2CD2143G2-IS');
  const [submittalCategory, setSubmittalCategory] = useState('CCTV Cameras (Active)');
  const [submittalSupplier, setSubmittalSupplier] = useState(suppliers[0]?.name || '');
  const [submittalMoi, setSubmittalMoi] = useState<'Yes' | 'No' | 'N/A'>('Yes');

  // Relational Auto-fill Trigger: Project Selection
  const handleProjectSelect = (projectName: string) => {
    setPrProject(projectName);
    const ctx = getProjectContext(projectName, projects);
    if (ctx) {
      setPrLocation(`Site: ${ctx.projectName} (${ctx.client})`);
      const matchingBoq = boqs.find((b) => b.projectName.toLowerCase() === projectName.toLowerCase());
      if (matchingBoq) {
        setPrBoqId(matchingBoq.boqId);
      }
      setAutoFilledFields(['Site Location', 'Client Reference', 'Associated BOQ']);
      setShowAutoFillNotice(true);
      setTimeout(() => setShowAutoFillNotice(false), 3500);
    }
  };

  // Relational Auto-fill Trigger: Product Catalog Code
  const handleProductSelect = (code: string) => {
    setPrItemCode(code);
    const prod = getProductContext(code, equipmentMaster);
    if (prod) {
      setPrItemDesc(`${prod.brand} ${prod.model} - ${prod.name}`);
      setPrBudget(prod.unitPrice * prQty);
      setAutoFilledFields(['Item Description', 'Brand/Model Specs', 'Estimated Budget (QAR)']);
      setShowAutoFillNotice(true);
      setTimeout(() => setShowAutoFillNotice(false), 3500);
    }
  };

  // Relational Auto-fill Trigger: Vendor Selection
  const handleVendorSelect = (vendorName: string) => {
    setPoSupplier(vendorName);
    const vCtx = getVendorContext(vendorName, suppliers);
    if (vCtx) {
      setPoTerms(vCtx.paymentTerms || '30 Days Net on GRN');
      setAutoFilledFields(['Vendor Payment Terms', 'Credit Terms']);
      setShowAutoFillNotice(true);
      setTimeout(() => setShowAutoFillNotice(false), 3500);
    }
  };

  // Relational Auto-fill Trigger: Select PR for PO Generation
  const handlePRSelectForPO = (prId: string) => {
    setPoPRId(prId);
    const targetPR = purchaseRequisitions.find((p) => p.prId === prId);
    if (targetPR) {
      setPoProject(targetPR.projectName);
      setPoAmount(targetPR.estimatedBudgetQAR || 25000);
      setPoLocation(targetPR.siteLocation);
      setAutoFilledFields(['Project Name', 'PO Amount (QAR)', 'Delivery Location']);
      setShowAutoFillNotice(true);
      setTimeout(() => setShowAutoFillNotice(false), 3500);
    }
  };

  // Relational Auto-fill Trigger: Select Product for Material Submittal
  const handleProductSelectForSubmittal = (code: string) => {
    setSubmittalProductCode(code);
    const prod = getProductContext(code, equipmentMaster);
    if (prod) {
      setSubmittalBrand(prod.brand);
      setSubmittalModel(prod.model);
      setSubmittalCategory(prod.category);
      setSubmittalMoi(prod.moiApproved === 'Yes' ? 'Yes' : 'No');
      setAutoFilledFields(['Brand', 'Model Code', 'Category', 'MOI Compliance Certificate']);
      setShowAutoFillNotice(true);
      setTimeout(() => setShowAutoFillNotice(false), 3500);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (activeType === 'pr') {
      const newPR = {
        prId: `PR-2026-${String(purchaseRequisitions.length + 1).padStart(3, '0')}`,
        boqId: prBoqId,
        projectName: prProject,
        siteLocation: prLocation,
        requestedBy: 'Site Engineer (Automated)',
        dateRequested: new Date().toISOString().split('T')[0],
        requiredDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
        priority: prPriority,
        itemDescription: prItemDesc || 'ELV Security Hardware Package',
        quantity: Number(prQty),
        unit: 'Units',
        estimatedBudgetQAR: Number(prBudget),
        technicalVetting: prTechnicalVetting,
        consultantApprovalNeeded: prConsultantApproval,
        status: 'Pending Review' as const,
        stage: 'Requested' as const,
        remarks: 'Created via Intelligent Auto-Fill Portal',
      };
      if (onAddRecord) onAddRecord('purchaseRequisitions', newPR);
      else addRecordContext('purchaseRequisitions', newPR);
    } else if (activeType === 'po') {
      const newPO = {
        poNumber: `PO-2026-${String(purchaseOrders.length + 1).padStart(4, '0')}`,
        prId: poPRId || 'PR-2026-001',
        boqId: 'BOQ-001',
        projectName: poProject,
        supplier: poSupplier,
        issueDate: new Date().toISOString().split('T')[0],
        deliveryDueDate: poDeliveryDate,
        totalAmountQAR: Number(poAmount),
        paymentTerms: poTerms,
        deliveryLocation: poLocation,
        turnaroundHours: 24,
        authorizedBy: 'Procurement Manager',
        budgetAllocated: 'Yes' as const,
        materialSubmittalApproved: 'Yes' as const,
        status: 'Issued to Vendor' as const,
        lineItemsCount: 1,
        remarks: 'Issued via Unified Rapid PO Generator',
      };
      if (onAddRecord) onAddRecord('purchaseOrders', newPO);
      else addRecordContext('purchaseOrders', newPO);
    } else if (activeType === 'submittal') {
      const newSubmittal = {
        submittalId: `MAS-2026-${String(equipmentMaster.length + 1).padStart(3, '0')}`,
        boqId: 'BOQ-001',
        projectName: submittalProject,
        category: submittalCategory,
        itemDescription: `${submittalBrand} ${submittalModel} Security Component`,
        brand: submittalBrand,
        model: submittalModel,
        supplier: submittalSupplier,
        datasheetRef: `DS-${submittalProductCode || 'GEN-01'}`,
        dateSubmitted: new Date().toISOString().split('T')[0],
        consultantName: 'KEO International Consultants',
        approvalStatus: 'Under Review' as const,
        moiCertificateAttached: submittalMoi,
        complianceNotes: 'Automated relational submittal package generated for consultant signoff.',
      };
      if (onAddRecord) onAddRecord('materialSubmittals', newSubmittal);
      else addRecordContext('materialSubmittals', newSubmittal);
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Unified Intelligent Data Entry
                <span className="text-xs bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded-full font-normal border border-indigo-500/30">
                  Relational Auto-Fill
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Single source of truth: selections instantly cascade across projects, vendors, and catalog items.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dynamic Type Switcher Pills */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex gap-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveType('pr')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeType === 'pr'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Purchase Requisition (PR)
          </button>
          <button
            type="button"
            onClick={() => setActiveType('po')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeType === 'po'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            Purchase Order (PO)
          </button>
          <button
            type="button"
            onClick={() => setActiveType('submittal')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeType === 'submittal'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Material Submittal
          </button>
        </div>

        {/* Live Relational Feedback Banner */}
        {showAutoFillNotice && (
          <div className="bg-indigo-50 border-y border-indigo-100 px-6 py-2 flex items-center justify-between text-xs text-indigo-700 animate-in fade-in duration-150">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>
                <strong>Smart Auto-Fill:</strong> Populated {autoFilledFields.join(', ')} from central database.
              </span>
            </div>
            <span className="text-[10px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full font-medium">
              Zero Manual Entry
            </span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {activeType === 'pr' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Select Project <span className="text-indigo-600">* (Cascades Location & BOQ)</span>
                  </label>
                  <select
                    value={prProject}
                    onChange={(e) => handleProjectSelect(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.projectName}>
                        {p.projectName} ({p.clientName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product from Catalog <span className="text-indigo-600">* (Cascades Specs & Price)</span>
                  </label>
                  <select
                    value={prItemCode}
                    onChange={(e) => handleProductSelect(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  >
                    <option value="">-- Choose Catalog Equipment --</option>
                    {equipmentMaster.map((eq) => (
                      <option key={eq.code} value={eq.code}>
                        [{eq.code}] {eq.brand} {eq.name} (QAR {eq.unitPrice})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Item Description & Technical Specifications
                </label>
                <input
                  type="text"
                  value={prItemDesc}
                  onChange={(e) => setPrItemDesc(e.target.value)}
                  placeholder="e.g. 4MP Varifocal Motorized Dome Camera (MOI Approved)"
                  className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Quantity</label>
                  <input
                    type="number"
                    value={prQty}
                    onChange={(e) => {
                      const q = Number(e.target.value);
                      setPrQty(q);
                      const prod = getProductContext(prItemCode, equipmentMaster);
                      if (prod) setPrBudget(prod.unitPrice * q);
                    }}
                    min="1"
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Estimated Budget (QAR)</label>
                  <input
                    type="number"
                    value={prBudget}
                    onChange={(e) => setPrBudget(Number(e.target.value))}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-medium text-emerald-700"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={prPriority}
                    onChange={(e) => setPrPriority(e.target.value as any)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  >
                    <option value="Urgent">Urgent (48 hrs)</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Technical Vetting</label>
                  <select
                    value={prTechnicalVetting}
                    onChange={(e) => setPrTechnicalVetting(e.target.value as any)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  >
                    <option value="Verified with Specs">Verified with Specs</option>
                    <option value="Pending Specs Check">Pending Specs Check</option>
                    <option value="Non-Compliant (Hold)">Non-Compliant (Hold)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Site Delivery Location</label>
                  <input
                    type="text"
                    value={prLocation}
                    onChange={(e) => setPrLocation(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:outline-hidden text-slate-600"
                  />
                </div>
              </div>
            </>
          )}

          {activeType === 'po' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Select Source PR <span className="text-emerald-600">* (Cascades Project & Budget)</span>
                  </label>
                  <select
                    value={poPRId}
                    onChange={(e) => handlePRSelectForPO(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    {purchaseRequisitions.map((pr) => (
                      <option key={pr.prId} value={pr.prId}>
                        [{pr.prId}] {pr.projectName} - {pr.itemDescription.substring(0, 30)}...
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Approved Supplier <span className="text-emerald-600">* (Cascades Payment Terms)</span>
                  </label>
                  <select
                    value={poSupplier}
                    onChange={(e) => handleVendorSelect(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    {suppliers.map((s) => (
                      <option key={s.code} value={s.name}>
                        {s.name} ({s.paymentTerms})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Total PO Amount (QAR)</label>
                  <input
                    type="number"
                    value={poAmount}
                    onChange={(e) => setPoAmount(Number(e.target.value))}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold text-emerald-800"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Terms</label>
                  <input
                    type="text"
                    value={poTerms}
                    onChange={(e) => setPoTerms(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Due Date</label>
                  <input
                    type="date"
                    value={poDeliveryDate}
                    onChange={(e) => setPoDeliveryDate(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Destination</label>
                  <input
                    type="text"
                    value={poLocation}
                    onChange={(e) => setPoLocation(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>
            </>
          )}

          {activeType === 'submittal' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Catalog Product <span className="text-purple-600">* (Cascades Specs & MOI Status)</span>
                  </label>
                  <select
                    value={submittalProductCode}
                    onChange={(e) => handleProductSelectForSubmittal(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  >
                    {equipmentMaster.map((eq) => (
                      <option key={eq.code} value={eq.code}>
                        [{eq.brand}] {eq.model} - {eq.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Project</label>
                  <select
                    value={submittalProject}
                    onChange={(e) => setSubmittalProject(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.projectName}>
                        {p.projectName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Brand</label>
                  <input
                    type="text"
                    value={submittalBrand}
                    onChange={(e) => setSubmittalBrand(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-700"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Model Number</label>
                  <input
                    type="text"
                    value={submittalModel}
                    onChange={(e) => setSubmittalModel(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-700"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">MOI Approved?</label>
                  <select
                    value={submittalMoi}
                    onChange={(e) => setSubmittalMoi(e.target.value as any)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  >
                    <option value="Yes">Yes (Pre-Approved)</option>
                    <option value="No">No (Consultant Review)</option>
                    <option value="N/A">N/A (Passive/Consumable)</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2 text-xs font-semibold text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all ${
                activeType === 'pr'
                  ? 'bg-indigo-600 hover:bg-indigo-700'
                  : activeType === 'po'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-purple-600 hover:bg-purple-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              Save & Auto-Cascade Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
