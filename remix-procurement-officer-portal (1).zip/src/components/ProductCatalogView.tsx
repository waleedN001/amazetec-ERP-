import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  Search,
  PlusCircle,
  Filter,
  Layers,
  MapPin,
  Clock,
  Truck,
  CheckCircle2,
  XCircle,
  Sparkles,
  Tag,
  Building2,
  Calendar,
  AlertCircle,
  Zap,
  Wrench,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Cpu,
  Radio,
  Check,
  LayoutGrid,
  FileSpreadsheet,
  ShoppingCart,
  Camera,
  Eye,
  Wifi,
  Video,
  Shield,
  Bell,
  Cpu as CpuIcon,
  Server,
  Network,
  BatteryCharging,
  Package,
  HardDrive,
  Monitor,
  ArrowRight,
  CheckCircle,
  Globe,
  Plus,
  Minus,
  ChevronRight,
  ChevronLeft,
  X,
  Trash2,
  FileText,
  Download,
  Share2,
  BadgeCheck,
  Award,
  SlidersHorizontal,
  ArrowUpDown,
  ExternalLink,
  PhoneCall,
  Info,
  Table,
  List,
  Copy,
  Maximize2,
  PanelLeft,
  AlignJustify,
  FolderOpen
} from 'lucide-react';
import { SecurityProductCatalogItem } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';
import { OfficialQuotationView, sampleOfficialQuotationData, QuotationLineItem } from './OfficialQuotationView';
import { rawEquipmentData } from '../data/equipmentDatabase';

interface ProductCatalogViewProps {
  catalog: SecurityProductCatalogItem[];
  onUpdateCatalog: (data: SecurityProductCatalogItem[]) => void;
  onOpenQuickAdd: () => void;
  onAddToBOQ?: (item: SecurityProductCatalogItem, qty: number) => void;
  hideDefaultCartButtons?: boolean;
  onCartCountChange?: (count: number) => void;
  bindTriggers?: (triggers: {
    openCart: () => void;
    openOfficialQuotation: () => void;
  }) => void;
}

export const ProductCatalogView: React.FC<ProductCatalogViewProps> = ({
  catalog,
  onUpdateCatalog,
  onOpenQuickAdd,
  onAddToBOQ,
  hideDefaultCartButtons,
  onCartCountChange,
  bindTriggers,
}) => {
  const [viewMode, setViewMode] = useState<'store' | 'pricelist' | 'guide'>('store');
  const [storeLayout, setStoreLayout] = useState<'card' | 'table'>('table');
  const [categoryLayout, setCategoryLayout] = useState<'side' | 'bar'>('bar');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [selectedMoi, setSelectedMoi] = useState<string>('All');
  const [selectedComponentClass, setSelectedComponentClass] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'priceAsc' | 'priceDesc' | 'brand'>('featured');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Table view state: row quantities, row selection, pagination, copy feedback
  const [rowQuantities, setRowQuantities] = useState<Record<string, number>>({});
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [tablePage, setTablePage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(25);
  const [copiedModel, setCopiedModel] = useState<string | null>(null);

  // Cart / BOQ Quote Modal
  const [cartItems, setCartItems] = useState<{ item: SecurityProductCatalogItem; qty: number; marginPct: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isOfficialQuotationModalOpen, setIsOfficialQuotationModalOpen] = useState<boolean>(false);
  const [addedNotice, setAddedNotice] = useState<string | null>(null);

  // Product Detail Quick View Modal
  const [quickViewItem, setQuickViewItem] = useState<SecurityProductCatalogItem | null>(null);

  const [activeGuideTab, setActiveGuideTab] = useState<string>('CCTV Surveillance Systems');

  useEffect(() => {
    if (bindTriggers) {
      bindTriggers({
        openCart: () => setIsCartOpen(true),
        openOfficialQuotation: () => setIsOfficialQuotationModalOpen(true),
      });
    }
  }, [bindTriggers]);

  useEffect(() => {
    if (onCartCountChange) {
      onCartCountChange(cartItems.reduce((a, b) => a + b.qty, 0));
    }
  }, [cartItems, onCartCountChange]);

  // Unified list combining curated catalog + mapped equipment database (PDF price list)
  const fullPriceList = useMemo(() => {
    const catalogModels = new Set(catalog.map((i) => i.model.toLowerCase()));
    
    // Map rawEquipmentData into catalog items
    const mappedRawItems: SecurityProductCatalogItem[] = rawEquipmentData.map((raw, idx) => {
      let sysCat: SecurityProductCatalogItem['category'] = 'DOME AND BULLET CAMERAS - AUTO-IRIS';
      const c = (raw.category || '').toLowerCase();
      const n = (raw.name || '').toLowerCase();
      const m = (raw.model || '').toLowerCase();

      if (n.includes('ptz') || c.includes('ptz') || m.includes('ptz')) {
        sysCat = 'PTZ CAMERAS';
      } else if (n.includes('kpoi') || c.includes('kpoi') || m.includes('kpoi') || m.includes('kp')) {
        sysCat = 'KPOI CAMERAS';
      } else if (n.includes('failover') || c.includes('failover') || n.includes('san') || n.includes('cluster') || n.includes('redundant')) {
        sysCat = 'FAILOVER STORAGE';
      } else if (n.includes('hdd') || n.includes('hard disk') || c.includes('storage') || n.includes('storage') || m.includes('st16000') || n.includes('seagate')) {
        sysCat = 'STORAGE';
      } else if (n.includes('server') || n.includes('vms') || n.includes('nvr') || n.includes('decoder') || n.includes('dvr') || n.includes('controller') || n.includes('processor')) {
        sysCat = 'VMS AND SERVER';
      } else if (n.includes('monitor') || n.includes('workstation') || n.includes('display') || n.includes('video wall') || n.includes('screen') || n.includes('kvm')) {
        sysCat = 'WORKSTATION AND MONITORS';
      } else if (n.includes('anpr') || c.includes('anpr') || n.includes('lpr') || m.includes('lpr') || n.includes('license')) {
        sysCat = 'ANPR SYSTEM';
      } else if (c.includes('switch') || c.includes('networking') || n.includes('switch') || n.includes('router') || n.includes('poe') || n.includes('ethernet') || n.includes('transceiver') || n.includes('extender') || n.includes('media convert')) {
        sysCat = 'NETWORKSWITCHES';
      } else if (c.includes('battery') || c.includes('ups') || n.includes('ups') || n.includes('battery')) {
        sysCat = 'UPS AND BATTERY';
      } else if (c.includes('access') || c.includes('barrier') || c.includes('gate') || n.includes('reader') || n.includes('terminal') || n.includes('bollard') || n.includes('lock')) {
        sysCat = 'ACCESS CONTROL SYSTEM';
      } else if (c.includes('service') || c.includes('amc') || n.includes('maintenance') || n.includes('installation') || n.includes('contract')) {
        sysCat = 'PROFESSIONAL SERVICES';
      } else if (c.includes('accessory') || c.includes('cable') || n.includes('housing') || n.includes('enclosure') || n.includes('mount') || n.includes('bracket') || c.includes('passive') || n.includes('flood') || n.includes('illuminator') || n.includes('lens')) {
        sysCat = 'PASSIVE COMPONENTS';
      }

      return {
        id: `PDF-${raw.code || idx + 1}`,
        category: sysCat,
        componentClass: 'Active',
        productType: raw.name,
        brand: raw.brand || 'Generic',
        model: raw.model || raw.code || `MOD-${idx}`,
        description: `${raw.name} - Model ${raw.model}. Official Qatar Price List Record.`,
        moiApproved: raw.moiApproved === 'Yes' ? 'Yes' : 'No',
        moiCertificateNo: raw.moiApproved === 'Yes' ? `MOI-SSD-${raw.brand}-CERT` : undefined,
        cityLocation: 'Doha',
        unitPriceQAR: raw.unitPrice || 500,
        timeUnitPeriod: 'Per Unit',
        supplyDeliveryTime: 'Ex-Stock Doha / 7 Days Lead',
        warrantyPeriod: '1 Year Warranty',
        stockAvailability: 'In Stock (Doha Warehouse)',
        notes: `Supplier: ${raw.brand}. Official PDF Price List entry.`,
      };
    });

    // Filter out duplicates if already in catalog
    const uniqueMapped = mappedRawItems.filter((m) => !catalogModels.has(m.model.toLowerCase()));
    return [...catalog, ...uniqueMapped];
  }, [catalog]);

  // Official Categories list matching Qatar Security Quotation BOQ
  const categories = [
    'All',
    'DOME AND BULLET CAMERAS - AUTO-IRIS',
    'PTZ CAMERAS',
    'STORAGE',
    'FAILOVER STORAGE',
    'VMS AND SERVER',
    'WORKSTATION AND MONITORS',
    'ANPR SYSTEM',
    'NETWORKSWITCHES',
    'PASSIVE COMPONENTS',
    'KPOI CAMERAS',
    'UPS AND BATTERY',
    'ACCESS CONTROL SYSTEM',
    'PROFESSIONAL SERVICES',
  ];

  const [selectedSidebarId, setSelectedSidebarId] = useState<string>('All');
  const [subKeyword, setSubKeyword] = useState<string>('');

  // Store Left Navigation Categories (Exact 13 Quotation Categories)
  const leftSidebarCategories: { id: string; name: string; icon: React.ReactNode; cat: string; subKeyword?: string }[] = [
    { id: 'dome_bullet', name: 'Dome & Bullet (Auto-Iris)', icon: <Camera className="w-4 h-4 text-amber-500" />, cat: 'DOME AND BULLET CAMERAS - AUTO-IRIS' },
    { id: 'ptz', name: 'PTZ Cameras', icon: <Video className="w-4 h-4 text-indigo-500" />, cat: 'PTZ CAMERAS' },
    { id: 'storage', name: 'Primary Storage', icon: <HardDrive className="w-4 h-4 text-emerald-500" />, cat: 'STORAGE' },
    { id: 'failover_storage', name: 'Failover Storage', icon: <Server className="w-4 h-4 text-rose-500" />, cat: 'FAILOVER STORAGE' },
    { id: 'vms_server', name: 'VMS & Servers', icon: <CpuIcon className="w-4 h-4 text-cyan-500" />, cat: 'VMS AND SERVER' },
    { id: 'workstation_monitors', name: 'Workstations & Monitors', icon: <Monitor className="w-4 h-4 text-blue-500" />, cat: 'WORKSTATION AND MONITORS' },
    { id: 'anpr', name: 'ANPR System', icon: <Tag className="w-4 h-4 text-purple-500" />, cat: 'ANPR SYSTEM' },
    { id: 'switches', name: 'Network Switches', icon: <Network className="w-4 h-4 text-sky-500" />, cat: 'NETWORKSWITCHES' },
    { id: 'passive', name: 'Passive Components', icon: <Wrench className="w-4 h-4 text-slate-500" />, cat: 'PASSIVE COMPONENTS' },
    { id: 'kpoi', name: 'KPOI Cameras', icon: <Shield className="w-4 h-4 text-yellow-500" />, cat: 'KPOI CAMERAS' },
    { id: 'ups', name: 'UPS & Battery', icon: <BatteryCharging className="w-4 h-4 text-yellow-600" />, cat: 'UPS AND BATTERY' },
    { id: 'access', name: 'Access Control System', icon: <ShieldCheck className="w-4 h-4 text-teal-500" />, cat: 'ACCESS CONTROL SYSTEM' },
    { id: 'services', name: 'Professional Services', icon: <BookOpen className="w-4 h-4 text-indigo-600" />, cat: 'PROFESSIONAL SERVICES' },
  ];

  // Dynamic Item Counts for Left Sidebar Categories
  const categoryItemCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    leftSidebarCategories.forEach((item) => {
      counts[item.id] = fullPriceList.filter((p) => {
        if (p.category !== item.cat) return false;
        if (item.subKeyword) {
          const k = item.subKeyword.toLowerCase();
          const matchType = (p.productType || '').toLowerCase().includes(k);
          const matchDesc = (p.description || '').toLowerCase().includes(k);
          const matchModel = (p.model || '').toLowerCase().includes(k);
          return matchType || matchDesc || matchModel;
        }
        return true;
      }).length;
    });
    return counts;
  }, [fullPriceList]);

  const cities = ['All', 'Doha', 'Lusail', 'Al Rayyan', 'Al Wakrah', 'Al Khor', 'Ras Laffan', 'All Qatar'];

  // All distinct brands for filtering
  const brandsList = useMemo(() => {
    const setB = new Set<string>();
    setB.add('All');
    fullPriceList.forEach((i) => {
      if (i.brand) setB.add(i.brand);
    });
    return Array.from(setB).slice(0, 30); // Top 30 brands
  }, [fullPriceList]);

  // Filtered & Sorted dataset
  const filteredItems = useMemo(() => {
    let list = fullPriceList.filter((item) => {
      if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
      if (selectedBrand !== 'All' && item.brand !== selectedBrand) return false;
      if (selectedCity !== 'All' && item.cityLocation !== selectedCity) return false;
      if (selectedMoi === 'Yes' && item.moiApproved !== 'Yes') return false;
      if (selectedMoi === 'No' && item.moiApproved !== 'No') return false;
      if (selectedComponentClass !== 'All' && item.componentClass !== selectedComponentClass) return false;

      // Sub-keyword filtering (e.g. switches vs UPS)
      if (subKeyword) {
        const k = subKeyword.toLowerCase();
        const matchType = (item.productType || '').toLowerCase().includes(k);
        const matchDesc = (item.description || '').toLowerCase().includes(k);
        const matchModel = (item.model || '').toLowerCase().includes(k);
        if (!matchType && !matchDesc && !matchModel) return false;
      }

      // Price range
      if (priceRange === 'under500' && item.unitPriceQAR >= 500) return false;
      if (priceRange === '500-2000' && (item.unitPriceQAR < 500 || item.unitPriceQAR > 2000)) return false;
      if (priceRange === '2000plus' && item.unitPriceQAR < 2000) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchBrand = item.brand.toLowerCase().includes(q);
        const matchModel = item.model.toLowerCase().includes(q);
        const matchType = item.productType.toLowerCase().includes(q);
        const matchDesc = (item.description || '').toLowerCase().includes(q);
        const matchCat = (item.category || '').toLowerCase().includes(q);
        return matchBrand || matchModel || matchType || matchDesc || matchCat;
      }
      return true;
    });

    // Sort by category first to group the table by "departing part" (department/category)
    list = [...list].sort((a, b) => {
      const catCompare = (a.category || '').localeCompare(b.category || '');
      if (catCompare !== 0) return catCompare;

      if (sortBy === 'priceAsc') {
        return a.unitPriceQAR - b.unitPriceQAR;
      } else if (sortBy === 'priceDesc') {
        return b.unitPriceQAR - a.unitPriceQAR;
      } else if (sortBy === 'brand') {
        return a.brand.localeCompare(b.brand);
      }
      return 0; // featured or fallback
    });

    return list;
  }, [fullPriceList, selectedCategory, selectedBrand, selectedCity, selectedMoi, selectedComponentClass, priceRange, sortBy, searchQuery, subKeyword]);

  // Statistics
  const stats = useMemo(() => {
    const totalItems = fullPriceList.length;
    const activeCount = fullPriceList.filter((i) => i.componentClass === 'Active' || !i.componentClass).length;
    const passiveCount = fullPriceList.filter((i) => i.componentClass === 'Passive').length;
    const moiApprovedCount = fullPriceList.filter((i) => i.moiApproved === 'Yes').length;
    const avgPrice = totalItems > 0 ? Math.round(fullPriceList.reduce((acc, curr) => acc + (curr.unitPriceQAR || 0), 0) / totalItems) : 0;
    return {
      totalItems,
      activeCount,
      passiveCount,
      moiApprovedCount,
      avgPrice,
    };
  }, [fullPriceList]);

  const handleAddToCart = (product: SecurityProductCatalogItem, quantity = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((c) => c.item.id === product.id);
      if (existing) {
        return prev.map((c) => (c.item.id === product.id ? { ...c, qty: c.qty + quantity } : c));
      }
      return [...prev, { item: product, qty: quantity, marginPct: 15 }];
    });
    if (onAddToBOQ) {
      onAddToBOQ(product, quantity);
    }
    setAddedNotice(`Added "${product.brand} ${product.model}" (${quantity}x) to BOQ Cart`);
    setTimeout(() => setAddedNotice(null), 3000);
  };

  const handleRemoveFromCart = (id: string) => {
    setCartItems((prev) => prev.filter((c) => c.item.id !== id));
  };

  const handleUpdateCartQty = (id: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveFromCart(id);
      return;
    }
    setCartItems((prev) => prev.map((c) => (c.item.id === id ? { ...c, qty: newQty } : c)));
  };

  // Row quantity state management for Table View
  const getRowQty = (id: string) => rowQuantities[id] || 1;
  const setRowQty = (id: string, qty: number) => {
    const safeQty = Math.max(1, Math.min(9999, isNaN(qty) ? 1 : qty));
    setRowQuantities((prev) => ({ ...prev, [id]: safeQty }));
  };

  // Model copy to clipboard helper
  const handleCopyModel = (model: string) => {
    navigator.clipboard?.writeText(model);
    setCopiedModel(model);
    setTimeout(() => setCopiedModel(null), 2000);
  };

  // Reset pagination when any filter changes
  useEffect(() => {
    setTablePage(1);
  }, [selectedCategory, selectedBrand, selectedCity, selectedMoi, selectedComponentClass, priceRange, sortBy, searchQuery, subKeyword]);

  // Paginated Items for Table View
  const totalPages = Math.ceil(filteredItems.length / (itemsPerPage === -1 ? filteredItems.length || 1 : itemsPerPage)) || 1;
  const paginatedTableItems = useMemo(() => {
    if (itemsPerPage === -1) return filteredItems;
    const start = (tablePage - 1) * itemsPerPage;
    return filteredItems.slice(start, start + itemsPerPage);
  }, [filteredItems, tablePage, itemsPerPage]);

  // Table Row Selection
  const toggleSelectAll = () => {
    if (selectedRowIds.length === paginatedTableItems.length && paginatedTableItems.length > 0) {
      setSelectedRowIds([]);
    } else {
      setSelectedRowIds(paginatedTableItems.map((i) => i.id));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedRowIds((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]));
  };

  const handleAddSelectedToCart = () => {
    if (selectedRowIds.length === 0) return;
    const selectedItems = filteredItems.filter((i) => selectedRowIds.includes(i.id));
    setCartItems((prev) => {
      let updated = [...prev];
      selectedItems.forEach((product) => {
        const qty = getRowQty(product.id);
        const existing = updated.find((c) => c.item.id === product.id);
        if (existing) {
          updated = updated.map((c) => (c.item.id === product.id ? { ...c, qty: c.qty + qty } : c));
        } else {
          updated.push({ item: product, qty, marginPct: 15 });
        }
        if (onAddToBOQ) {
          onAddToBOQ(product, qty);
        }
      });
      return updated;
    });
    setAddedNotice(`Added ${selectedItems.length} selected items to BOQ Cart`);
    setSelectedRowIds([]);
    setTimeout(() => setAddedNotice(null), 3000);
  };

  // Standard Unit resolver (Mtr, Pc, Lot, Set, Nos, Lic, Roll, Pkg)
  const getStandardUnit = (product: SecurityProductCatalogItem): string => {
    const rawUnit = (product.timeUnitPeriod || (product as any).unit || '').trim().toLowerCase();
    const desc = (product.description || '').toLowerCase();
    const name = (product.productType || '').toLowerCase();
    const cat = (product.category || '').toLowerCase();

    if (
      rawUnit.includes('mtr') ||
      rawUnit.includes('meter') ||
      rawUnit.includes('m') ||
      desc.includes('per meter') ||
      desc.includes('cat6') ||
      desc.includes('fiber') ||
      name.includes('cable') ||
      name.includes('wire') ||
      name.includes('fiber') ||
      cat.includes('cabling')
    ) {
      return 'Mtr';
    }
    if (
      rawUnit.includes('lot') ||
      name.includes('service') ||
      name.includes('installation') ||
      cat.includes('services') ||
      name.includes('amc') ||
      name.includes('turnkey') ||
      desc.includes('turnkey') ||
      desc.includes('scope of work')
    ) {
      return 'Lot';
    }
    if (
      rawUnit.includes('set') ||
      name.includes('bracket') ||
      name.includes('pair') ||
      name.includes('kit') ||
      name.includes('set') ||
      desc.includes('kit') ||
      desc.includes('set') ||
      name.includes('housing')
    ) {
      return 'Set';
    }
    if (
      rawUnit.includes('lic') ||
      name.includes('license') ||
      name.includes('base license') ||
      desc.includes('license') ||
      name.includes('software')
    ) {
      return 'Lic';
    }
    if (rawUnit.includes('roll') || desc.includes('roll') || name.includes('roll')) {
      return 'Roll';
    }
    if (rawUnit.includes('pkg') || rawUnit.includes('pack') || desc.includes('pack of')) {
      return 'Pkg';
    }
    if (rawUnit.includes('nos') || rawUnit.includes('no.') || rawUnit.includes('nos.')) {
      return 'Nos';
    }
    if (rawUnit.includes('pc') || rawUnit.includes('pcs') || rawUnit.includes('piece')) {
      return 'Pc';
    }
    return 'Pc';
  };

  const handleExportTableCSV = () => {
    const headers = ['Serial Number', 'Model', 'Name', 'Description', 'Brand', 'Unit', 'MOI Approved', 'Location'];
    const rows = filteredItems.map((item, idx) => [
      idx + 1,
      `"${(item.model || '').replace(/"/g, '""')}"`,
      `"${(item.productType || '').replace(/"/g, '""')}"`,
      `"${(item.description || '').replace(/"/g, '""')}"`,
      `"${(item.brand || '').replace(/"/g, '""')}"`,
      `"${getStandardUnit(item)}"`,
      item.moiApproved || 'Standard',
      `"${(item.cityLocation || 'Doha').replace(/"/g, '""')}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Security_Product_Catalog_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Render Category/Type-specific thumbnail for Picture column
  const renderProductThumbnail = (product: SecurityProductCatalogItem) => {
    const cat = (product.category || '').toUpperCase();
    const isCCTV = cat.includes('DOME') || cat.includes('BULLET') || cat.includes('PTZ') || cat.includes('CCTV') || cat.includes('KPOI');
    const isAccess = cat.includes('ACCESS');
    const isStorage = cat.includes('STORAGE');
    const isVMS = cat.includes('VMS') || cat.includes('SERVER');
    const isANPR = cat.includes('ANPR');
    const isNetwork = cat.includes('SWITCH') || cat.includes('NETWORK');
    const isUPS = cat.includes('UPS') || cat.includes('BATTERY');
    const isMonitor = cat.includes('WORKSTATION') || cat.includes('MONITOR');
    const isService = cat.includes('PROFESSIONAL') || cat.includes('SERVICE');

    return (
      <div
        onClick={() => setQuickViewItem(product)}
        className="relative group cursor-pointer w-12 h-12 rounded-xl bg-gradient-to-br from-slate-50 to-orange-50/40 border border-slate-200/90 flex items-center justify-center p-1 hover:border-orange-400 hover:shadow-xs transition-all shrink-0 select-none"
        title="Click to view full specs & image"
      >
        <div className="w-8 h-8 rounded-lg bg-white shadow-2xs border border-slate-200/70 flex items-center justify-center">
          {isCCTV ? (
            <Video className="w-4 h-4 text-indigo-600" />
          ) : isAccess ? (
            <Shield className="w-4 h-4 text-teal-600" />
          ) : isStorage ? (
            <HardDrive className="w-4 h-4 text-emerald-600" />
          ) : isVMS ? (
            <CpuIcon className="w-4 h-4 text-cyan-600" />
          ) : isANPR ? (
            <Tag className="w-4 h-4 text-purple-600" />
          ) : isNetwork ? (
            <Network className="w-4 h-4 text-sky-600" />
          ) : isUPS ? (
            <BatteryCharging className="w-4 h-4 text-amber-600" />
          ) : isMonitor ? (
            <Monitor className="w-4 h-4 text-blue-600" />
          ) : isService ? (
            <BookOpen className="w-4 h-4 text-indigo-600" />
          ) : (
            <Wrench className="w-4 h-4 text-slate-600" />
          )}
        </div>
        <div className="absolute inset-0 bg-slate-900/60 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
          <Eye className="w-3.5 h-3.5 text-amber-300" />
        </div>
      </div>
    );
  };

  // Systems Architecture Guide Dataset
  const systemComponentGuides: Record<
    string,
    {
      title: string;
      activeMOI: string[];
      activeNonMOI: string[];
      passiveInfrastructure: string[];
      moiStandardRule: string;
    }
  > = {
    'CCTV Surveillance Systems': {
      title: 'CCTV Surveillance Systems',
      activeMOI: [
        '4MP / 8MP IP Fixed Dome & Bullet Cameras with DarkFighter / WizMind low-light tech',
        '25x / 32x Optical Zoom Outdoor PTZ Cameras with Forensic WDR & IP67/IK10 rating',
        '32-ch / 64-ch 4K Network Video Recorders (NVR) with RAID 5/10 redundant power',
        'Video Management Software (VMS) Workstation with AI Analytics & Smart Search',
      ],
      activeNonMOI: [
        'Commercial Wi-Fi / Cloud Smart Cameras (EZVIZ, Tapo, Tuya)',
        'Standard 4-ch / 8-ch Analog / IP NVRs without RAID or 120-day capacity',
        'Standalone motion detection alarms & SOHO monitors',
      ],
      passiveInfrastructure: [
        'Cat6A U/FTP LSZH Shielded Network Cable (305m rolls)',
        'Heavy-Duty Stainless Steel Pole & Corner Mounting Brackets',
        'IP67 Weatherproof PVC Junction Boxes with PG13.5 Cable Glands',
        '24-Port Cat6A Keystone Patch Panels & Server Rack Cable Management',
        'Outdoor EMT / PVC Rigid Conduits & Metallic Cable Trays',
      ],
      moiStandardRule: 'Qatar MOI SSD Mandate: Minimum 4MP resolution, 120 days continuous video storage archive, 30fps recording at key entry/exit points, RAID 5 data redundancy.',
    },
    'Access Control Systems': {
      title: 'Access Control Systems',
      activeMOI: [
        '4-Door / 8-Door Enterprise Networked Access Control Controllers (iSTAR, Lenel, Software House)',
        'Multi-Biometric Face & Palm Recognition Verification Terminals (ZKTeco, Suprema)',
        'Dual-Technology Seos / DESFire / Bluetooth Mobile NFC Readers (HID Signo)',
        'Centralized Access Control Management Server Software with Audit Logs',
      ],
      activeNonMOI: [
        'Standalone RFID Keypads & Pin Code Entry Locks',
        'Basic 1-Door Standalone Access Controllers without Network Logs',
        'Battery-operated Smart Door Handles',
      ],
      passiveInfrastructure: [
        '600lbs / 1200lbs Heavy-Duty Electromagnetic Locks (Maglocks) with ZL Brackets',
        'Electric Mortise Strikes & Heavy-Duty Door Closers',
        'Touchless Infrared Request-to-Exit Push Buttons',
        'Green Emergency Break Glass Units with protective flip covers',
        '8-Core Shielded Alarm Cable (100m) & 12V DC Backup Battery Power Supply Units',
      ],
      moiStandardRule: 'Qatar MOI SSD & Civil Defence (QCDD) Mandate: Access doors must integrate with Fire Alarm for automatic release during emergencies.',
    },
  };

  // Columns for Table view
  const tableColumns: ColumnDef[] = [
    { key: 'id', label: 'Item ID', type: 'readonly' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model No.', type: 'text' },
    { key: 'productType', label: 'Product Name / Specification', type: 'text' },
    {
      key: 'category',
      label: 'System Category',
      type: 'select',
      options: categories.filter((c) => c !== 'All'),
    },
    {
      key: 'moiApproved',
      label: 'MOI Approved',
      type: 'select',
      options: ['Yes', 'No', 'Pending'],
    },
    { key: 'unitPriceQAR', label: 'Unit Price (QAR)', type: 'currency' },
    { key: 'supplyDeliveryTime', label: 'Supply Lead Time', type: 'text' },
    { key: 'stockAvailability', label: 'Stock Status', type: 'text' },
    { key: 'notes', label: 'Application Notes', type: 'text' },
  ];

  // Cart total calculations
  const cartSubtotalQAR = cartItems.reduce((acc, c) => acc + c.item.unitPriceQAR * c.qty, 0);
  const cartTotalWithMargin = cartItems.reduce((acc, c) => {
    const itemPrice = c.item.unitPriceQAR * (1 + c.marginPct / 100);
    return acc + itemPrice * c.qty;
  }, 0);

  return (
    <div className="space-y-6 pb-12 font-sans relative">
      {/* Toast Notice */}
      {addedNotice && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-orange-500 flex items-center gap-3 animate-bounce">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-bold">{addedNotice}</span>
        </div>
      )}

      {/* CLEAN E-STORE HEADER & SEARCH BAR */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        {/* Top Search & Cart Row */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Search Box */}
          <div className="flex-1 w-full">
            <div className="flex items-center border-2 border-orange-500 rounded-2xl overflow-hidden shadow-xs bg-slate-50 focus-within:bg-white transition">
              <select
                value={selectedCategory}
                onChange={(e) => {
                  const val = e.target.value;
                  setSelectedCategory(val);
                  if (val === 'All') {
                    setSelectedSidebarId('All');
                    setSubKeyword('');
                  } else {
                    const match = leftSidebarCategories.find((s) => s.cat === val);
                    if (match) {
                      setSelectedSidebarId(match.id);
                      setSubKeyword(match.subKeyword || '');
                    } else {
                      setSelectedSidebarId('All');
                      setSubKeyword('');
                    }
                  }
                }}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-3.5 py-2.5 border-r border-slate-200 focus:outline-none cursor-pointer max-w-[180px] truncate"
              >
                <option value="All">All Categories</option>
                {categories.filter((c) => c !== 'All').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>

              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Search item name, model (e.g. DS-2CD, C3KX), brand, or specification..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-3 pr-3 py-2.5 text-xs font-medium text-slate-900 bg-transparent focus:outline-none placeholder:text-slate-400"
                />
              </div>

              <button
                onClick={() => {}}
                className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs px-6 py-2.5 flex items-center gap-2 transition cursor-pointer shrink-0"
              >
                <Search className="w-4 h-4" />
                <span>Search</span>
              </button>
            </div>
          </div>

          {/* Moved View Toggles to top right */}
          <div className="flex items-center gap-3 shrink-0">
            {/* View Mode Toggle: Card View vs Table View */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-2xs">
              <button
                type="button"
                onClick={() => setStoreLayout('card')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  storeLayout === 'card'
                    ? 'bg-white text-orange-600 shadow-xs border border-orange-200 font-black'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
                title="Card View (Grid layout)"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Card View</span>
              </button>

              <button
                type="button"
                onClick={() => setStoreLayout('table')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  storeLayout === 'table'
                    ? 'bg-white text-orange-600 shadow-xs border border-orange-200 font-black'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
                title="Table View (List with Serial, Model, Picture, Name, Description, Brand, Unit, Quantity)"
              >
                <Table className="w-3.5 h-3.5" />
                <span>Table View</span>
              </button>
            </div>

            {/* Category View Toggle: Side View vs Bar View */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 px-1.5">Category:</span>
              <button
                type="button"
                onClick={() => setCategoryLayout('side')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  categoryLayout === 'side'
                    ? 'bg-white text-orange-600 shadow-xs border border-orange-200 font-black'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
                title="Category in Side View (Left vertical category sidebar)"
              >
                <PanelLeft className="w-3.5 h-3.5" />
                <span>Side View</span>
              </button>

              <button
                type="button"
                onClick={() => setCategoryLayout('bar')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  categoryLayout === 'bar'
                    ? 'bg-white text-orange-600 shadow-xs border border-orange-200 font-black'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
                title="Category in Bar View (Horizontal top category bar)"
              >
                <AlignJustify className="w-3.5 h-3.5" />
                <span>Bar View</span>
              </button>
            </div>
            
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs font-bold text-slate-700">
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center gap-1.5 mr-1">
              <Filter className="w-4 h-4 text-orange-500" />
              <span>{filteredItems.length.toLocaleString()} Products</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Sort */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-medium">Sort:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
              >
                <option value="featured">Featured / Popular</option>
                <option value="priceAsc">Price: Low to High</option>
                <option value="priceDesc">Price: High to Low</option>
                <option value="brand">Brand A-Z</option>
              </select>
            </div>

            {/* Brand */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-medium">Brand:</span>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
              >
                {brandsList.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            {/* Active / Passive */}
            <select
              value={selectedComponentClass}
              onChange={(e) => setSelectedComponentClass(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-xs text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="All">Type: Active & Passive</option>
              <option value="Active">⚡ Active Electronics Only</option>
              <option value="Passive">🛠️ Passive Infrastructure Only</option>
            </select>

            {/* MOI Approval */}
            <select
              value={selectedMoi}
              onChange={(e) => setSelectedMoi(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-xs text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="All">MOI Approval: All</option>
              <option value="Yes">MOI Approved Only</option>
              <option value="No">Non-MOI / Standard</option>
            </select>

            {/* Price Range */}
            <select
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-xs text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="All">Price: All Ranges</option>
              <option value="under500">Under QAR 500</option>
              <option value="500-2000">QAR 500 - 2,000</option>
              <option value="2000plus">QAR 2,000 & Above</option>
            </select>
          </div>
        </div>
      </div>

      {/* MAIN E-STORE CONTENT AREA */}
      {viewMode === 'store' && (
        <div className="space-y-4">
          {/* CATEGORY BAR VIEW (Top horizontal ribbon when Bar View is active) */}
          {categoryLayout === 'bar' && (
            <div className="w-full bg-white rounded-2xl border border-slate-200 p-3 shadow-2xs space-y-2.5">
              <div className="flex items-center justify-between px-1">
                <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <AlignJustify className="w-3.5 h-3.5 text-orange-500" /> CATEGORIES
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  {selectedSidebarId === 'All' && selectedCategory === 'All'
                    ? `All Categories (${fullPriceList.length} items)`
                    : `Filtered Category: ${selectedCategory}`}
                </span>
              </div>

              {/* Horizontal Scrollable Category Pills */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1.5 pt-0.5 scrollbar-thin">
                <button
                  onClick={() => {
                    setSelectedSidebarId('All');
                    setSelectedCategory('All');
                    setSubKeyword('');
                  }}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 ${
                    selectedSidebarId === 'All' && selectedCategory === 'All'
                      ? 'bg-orange-500 text-white shadow-xs font-black'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900 border border-slate-200/80'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>All Products</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                      selectedSidebarId === 'All' && selectedCategory === 'All'
                        ? 'bg-orange-600 text-white'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {fullPriceList.length}
                  </span>
                </button>

                {leftSidebarCategories.map((item) => {
                  const isSelected = selectedSidebarId === item.id;
                  const count = categoryItemCounts[item.id] || 0;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setSelectedSidebarId(item.id);
                        setSelectedCategory(item.cat);
                        setSubKeyword(item.subKeyword || '');
                      }}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 ${
                        isSelected
                          ? 'bg-orange-500 text-white shadow-xs font-black'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900 border border-slate-200/80'
                      }`}
                    >
                      <span className={isSelected ? 'text-white' : ''}>{item.icon}</span>
                      <span>{item.name}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                          isSelected
                            ? 'bg-orange-600 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Flexible Container for Side View and Content */}
          <div className={`flex flex-col ${categoryLayout === 'side' ? 'lg:flex-row' : ''} gap-6 items-start`}>
            {/* Left Categories Vertical Navigation (when Side View is active) */}
            {categoryLayout === 'side' && (
              <div className="w-full lg:w-64 bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden shrink-0">
                <div className="p-3.5 bg-slate-100/80 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <SlidersHorizontal className="w-4 h-4 text-orange-500" /> CATEGORIES FOR YOU
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">Index</span>
                </div>

                <div className="p-2 space-y-1">
                  <button
                    onClick={() => {
                      setSelectedSidebarId('All');
                      setSelectedCategory('All');
                      setSubKeyword('');
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-bold text-xs transition cursor-pointer text-left ${
                      selectedSidebarId === 'All' && selectedCategory === 'All'
                        ? 'bg-orange-50 text-orange-700 font-black border border-orange-200'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>All Products</span>
                    <span className="text-[10px] text-slate-400 font-mono">{fullPriceList.length}</span>
                  </button>

                  {leftSidebarCategories.map((item) => {
                    const isSelected = selectedSidebarId === item.id;
                    const count = categoryItemCounts[item.id] || 0;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setSelectedSidebarId(item.id);
                          setSelectedCategory(item.cat);
                          setSubKeyword(item.subKeyword || '');
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer text-left ${
                          isSelected
                            ? 'bg-orange-50 text-orange-700 font-bold border border-orange-200 shadow-2xs'
                            : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          {item.icon}
                          <span className="truncate">{item.name}</span>
                        </div>
                        <span className={`text-[10px] font-mono shrink-0 ml-1 ${isSelected ? 'text-orange-600 font-bold' : 'text-slate-400'}`}>
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Price Range Filter in Sidebar */}
                <div className="p-3.5 border-t border-slate-100 space-y-2">
                  <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">PRICE RANGE (QAR)</p>
                  <div className="space-y-1">
                    {[
                      { id: 'All', label: 'All Price Ranges' },
                      { id: 'under500', label: 'Under QAR 500' },
                      { id: '500-2000', label: 'QAR 500 - 2,000' },
                      { id: '2000plus', label: 'QAR 2,000 & Above' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() => setPriceRange(p.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                          priceRange === p.id
                            ? 'bg-orange-100/80 text-orange-900 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Right Main Content (Cards Grid or Table View) */}
            <div className="flex-1 w-full space-y-4 min-w-0">
            {/* Feedback notification when copied or added */}
            {copiedModel && (
              <div className="p-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl flex items-center justify-between shadow-lg">
                <span className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" /> Model "{copiedModel}" copied to clipboard!
                </span>
                <button onClick={() => setCopiedModel(null)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* 1. CARD VIEW LAYOUT */}
            {storeLayout === 'card' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4">
                {filteredItems.slice(0, 48).map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group hover:border-orange-300"
                  >
                    <div className="p-4 space-y-3">
                      {/* Card Header Badges */}
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                          {product.brand}
                        </span>

                        <div className="flex items-center gap-1">
                          {product.moiApproved === 'Yes' ? (
                            <span className="text-[9px] font-extrabold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-0.5">
                              <ShieldCheck className="w-3 h-3 text-emerald-600" /> MOI Approved
                            </span>
                          ) : (
                            <span className="text-[9px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
                              Standard
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Visual Product Representation Box with Quick View button */}
                      <div className="w-full h-32 bg-gradient-to-br from-slate-50 to-indigo-50/30 rounded-xl border border-slate-100 flex items-center justify-center p-3 relative group-hover:bg-orange-50/30 transition-colors">
                        <div className="text-center space-y-1">
                          <div className="w-12 h-12 mx-auto rounded-full bg-white shadow-2xs border border-slate-200/80 flex items-center justify-center text-slate-700 group-hover:scale-110 transition-transform">
                            {product.category.includes('CCTV') || product.category.includes('DOME') || product.category.includes('BULLET') ? (
                              <Video className="w-6 h-6 text-indigo-600" />
                            ) : product.category.includes('Access') ? (
                              <Shield className="w-6 h-6 text-teal-600" />
                            ) : product.category.includes('ANPR') ? (
                              <CpuIcon className="w-6 h-6 text-purple-600" />
                            ) : product.category.includes('Cabling') || product.category.includes('Networking') || product.category.includes('SWITCH') ? (
                              <Server className="w-6 h-6 text-blue-600" />
                            ) : product.category.includes('STORAGE') ? (
                              <HardDrive className="w-6 h-6 text-emerald-600" />
                            ) : (
                              <Package className="w-6 h-6 text-orange-500" />
                            )}
                          </div>
                          <span className="text-[10px] font-extrabold text-slate-400 block tracking-wider uppercase font-mono">
                            {product.model}
                          </span>
                        </div>

                        {/* Quick View Hover Button */}
                        <button
                          onClick={() => setQuickViewItem(product)}
                          className="absolute inset-x-3 bottom-2 bg-slate-900/90 hover:bg-slate-900 text-white font-bold text-[10px] py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Info className="w-3 h-3 text-amber-400" /> Quick Specs
                        </button>
                      </div>

                      {/* Title & Description */}
                      <div>
                        <h3 className="font-bold text-xs text-slate-900 leading-snug line-clamp-2 group-hover:text-orange-600 transition-colors">
                          {product.productType}
                        </h3>
                        <p className="text-[10px] text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                          {product.description}
                        </p>
                      </div>
                    </div>

                    {/* Card Footer Price & Action */}
                    <div className="p-4 bg-slate-50/80 border-t border-slate-100 space-y-2">
                      <div className="flex items-baseline justify-between">
                        <div>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Unit Price</p>
                          <p className="text-base font-black text-slate-900 font-mono tracking-tight">
                            QAR {(product.unitPriceQAR || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </p>
                        </div>

                        <span className="text-[10px] text-slate-500 font-semibold bg-white px-2 py-0.5 rounded border border-slate-200">
                          {product.cityLocation || 'Doha'}
                        </span>
                      </div>

                      <button
                        onClick={() => handleAddToCart(product, 1)}
                        className="w-full bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-extrabold text-xs py-2 rounded-xl transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add to BOQ Cart</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 2. TABLE VIEW LAYOUT (Requested Columns: Serial number, Model, Picture, Name, Description, Brand, Unit, Quantity) */}
            {storeLayout === 'table' && (
              <div className="space-y-3">
                {/* Table Actions Bar: Batch selection, export, pagination control */}
                <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    {selectedRowIds.length > 0 ? (
                      <div className="flex items-center gap-2 bg-orange-50 text-orange-800 px-3 py-1.5 rounded-xl border border-orange-200 font-bold">
                        <span>{selectedRowIds.length} item(s) selected</span>
                        <button
                          onClick={handleAddSelectedToCart}
                          className="bg-orange-500 hover:bg-orange-600 text-white px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" /> Add Selected to Cart
                        </button>
                        <button
                          onClick={() => setSelectedRowIds([])}
                          className="text-slate-400 hover:text-slate-700 ml-1 text-xs underline cursor-pointer"
                        >
                          Clear
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-slate-500 font-medium">
                        <Table className="w-4 h-4 text-orange-500" />
                        <span>Security Equipment Table Matrix</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3 ml-auto">
                    {/* Rows per page */}
                    <div className="flex items-center gap-1.5 text-slate-600 font-medium">
                      <span>Rows:</span>
                      <select
                        value={itemsPerPage}
                        onChange={(e) => {
                          setItemsPerPage(Number(e.target.value));
                          setTablePage(1);
                        }}
                        className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 cursor-pointer focus:outline-none"
                      >
                        <option value={15}>15</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                        <option value={-1}>All ({filteredItems.length})</option>
                      </select>
                    </div>

                    {/* Export Table CSV */}
                    <button
                      onClick={handleExportTableCSV}
                      className="flex items-center gap-1.5 text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl font-bold transition cursor-pointer border border-slate-200"
                      title="Export current table data to CSV file"
                    >
                      <Download className="w-3.5 h-3.5 text-slate-600" />
                      <span>Export CSV</span>
                    </button>
                  </div>
                </div>

                {/* The Main Table Component */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
                  <div className="overflow-x-auto max-h-[720px] overflow-y-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      {/* Table Header with Requested Columns */}
                      <thead className="bg-slate-50/90 backdrop-blur-sm sticky top-0 z-10 border-b border-slate-200 text-slate-600 font-extrabold uppercase tracking-wider text-[11px]">
                        <tr>
                          {/* 1. Serial Number Column */}
                          <th className="py-3 px-3 w-16 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <input
                                type="checkbox"
                                checked={paginatedTableItems.length > 0 && selectedRowIds.length === paginatedTableItems.length}
                                onChange={toggleSelectAll}
                                className="w-3.5 h-3.5 text-orange-500 rounded border-slate-300 focus:ring-orange-500 cursor-pointer"
                                title="Select / Deselect all rows on page"
                              />
                              <span>S.No</span>
                            </div>
                          </th>

                          {/* 2. Model Column */}
                          <th className="py-3 px-3 w-36">
                            <span>Model</span>
                          </th>

                          {/* 3. Picture Column */}
                          <th className="py-3 px-2 w-16 text-center">
                            <span>Picture</span>
                          </th>

                          {/* 4. Name Column */}
                          <th className="py-3 px-3 min-w-[200px]">
                            <span>Name / Product</span>
                          </th>

                          {/* 5. Description Column */}
                          <th className="py-3 px-3 min-w-[260px]">
                            <span>Description</span>
                          </th>

                          {/* 6. Brand Column */}
                          <th className="py-3 px-3 w-28">
                            <span>Brand</span>
                          </th>

                          {/* 7. Unit Column (Mtr, Pc, Lot, Set, Nos, Lic, Roll, Pkg - No Price) */}
                          <th className="py-3 px-3 w-24 text-center">
                            <span>Unit</span>
                          </th>

                          {/* 8. Quantity Column */}
                          <th className="py-3 px-3 w-48 text-center">
                            <span>Quantity & Action</span>
                          </th>
                        </tr>
                      </thead>

                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {paginatedTableItems.map((product, idx) => {
                          const serialNumber = (tablePage - 1) * (itemsPerPage === -1 ? 0 : itemsPerPage) + idx + 1;
                          const isSelected = selectedRowIds.includes(product.id);
                          const qty = getRowQty(product.id);
                          const inCartItem = cartItems.find((c) => c.item.id === product.id);
                          const isNewCategory = idx === 0 || product.category !== paginatedTableItems[idx - 1].category;

                          return (
                            <React.Fragment key={product.id}>
                              {isNewCategory && (
                                <tr className="bg-slate-100/80 border-y border-slate-200 shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)]">
                                  <td colSpan={8} className="py-2.5 px-4 font-black text-xs text-slate-800 uppercase tracking-wider">
                                    <div className="flex items-center gap-2">
                                      <div className="bg-orange-500 w-1.5 h-4 rounded-full"></div>
                                      <FolderOpen className="w-4 h-4 text-slate-500" />
                                      {product.category || 'UNCATEGORIZED / GENERAL ITEMS'}
                                    </div>
                                  </td>
                                </tr>
                              )}
                              <tr
                                className={`hover:bg-orange-50/30 transition-colors ${
                                  isSelected ? 'bg-orange-50/50' : idx % 2 === 1 ? 'bg-slate-50/30' : 'bg-white'
                                }`}
                              >
                                {/* 1. Serial number */}
                                <td className="py-3 px-3 text-center align-middle">
                                <div className="flex items-center justify-center gap-2">
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={() => toggleSelectRow(product.id)}
                                    className="w-3.5 h-3.5 text-orange-500 rounded border-slate-300 focus:ring-orange-500 cursor-pointer"
                                  />
                                  <span className="font-mono font-bold text-slate-500 text-xs">
                                    {serialNumber}
                                  </span>
                                </div>
                              </td>

                              {/* 2. Model */}
                              <td className="py-3 px-3 align-middle font-mono font-bold text-slate-900 text-xs">
                                <div className="flex items-center gap-1.5 group">
                                  <span className="bg-slate-100 group-hover:bg-orange-100 group-hover:text-orange-900 px-2 py-1 rounded-md text-[11px] font-black tracking-wide truncate max-w-[130px]" title={product.model}>
                                    {product.model}
                                  </span>
                                  <button
                                    onClick={() => handleCopyModel(product.model)}
                                    className="text-slate-300 hover:text-slate-700 opacity-0 group-hover:opacity-100 transition-opacity p-0.5 cursor-pointer"
                                    title="Copy model number"
                                  >
                                    <Copy className="w-3 h-3" />
                                  </button>
                                </div>
                              </td>

                              {/* 3. Picture */}
                              <td className="py-3 px-2 text-center align-middle">
                                <div className="flex justify-center">
                                  {renderProductThumbnail(product)}
                                </div>
                              </td>

                              {/* 4. Name */}
                              <td className="py-3 px-3 align-middle">
                                <div className="space-y-1">
                                  <div
                                    onClick={() => setQuickViewItem(product)}
                                    className="font-bold text-slate-900 hover:text-orange-600 cursor-pointer transition-colors text-xs leading-snug"
                                    title="Click to view full specs"
                                  >
                                    {product.productType}
                                  </div>
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    {product.moiApproved === 'Yes' ? (
                                      <span className="text-[9px] font-extrabold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-200 flex items-center gap-0.5">
                                        <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" /> MOI Approved
                                      </span>
                                    ) : (
                                      <span className="text-[9px] font-medium bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                                        Standard
                                      </span>
                                    )}

                                    {product.componentClass && (
                                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                        product.componentClass === 'Active'
                                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                                      }`}>
                                        {product.componentClass}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </td>

                              {/* 5. Description */}
                              <td className="py-3 px-3 align-middle text-slate-600 text-xs">
                                <p className="line-clamp-2 leading-relaxed text-[11px]" title={product.description}>
                                  {product.description || 'Standard surveillance component per Qatar MOI specifications.'}
                                </p>
                              </td>

                              {/* 6. Brand */}
                              <td className="py-3 px-3 align-middle">
                                <span className="inline-block bg-slate-100 text-slate-800 font-extrabold text-[10px] uppercase px-2 py-0.5 rounded-md border border-slate-200 tracking-wider truncate max-w-[100px]" title={product.brand}>
                                  {product.brand}
                                </span>
                              </td>

                              {/* 7. Unit (Mtr, Pc, Lot, Set, Nos, Lic, Roll, Pkg - No Price) */}
                              <td className="py-3 px-3 align-middle text-center">
                                <span className="inline-block bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-xs px-2.5 py-1 rounded-lg border border-slate-200 font-mono tracking-wide">
                                  {getStandardUnit(product)}
                                </span>
                              </td>

                              {/* 8. Quantity & Add to Cart */}
                              <td className="py-3 px-3 align-middle text-center">
                                <div className="flex flex-col items-center gap-1.5">
                                  <div className="flex items-center justify-center gap-1">
                                    <div className="flex items-center bg-slate-100 border border-slate-200 rounded-lg overflow-hidden">
                                      <button
                                        type="button"
                                        onClick={() => setRowQty(product.id, qty - 1)}
                                        className="w-6 h-6 flex items-center justify-center hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                                        title="Decrease quantity"
                                      >
                                        <Minus className="w-3 h-3" />
                                      </button>
                                      <input
                                        type="number"
                                        min="1"
                                        max="9999"
                                        value={qty}
                                        onChange={(e) => setRowQty(product.id, parseInt(e.target.value) || 1)}
                                        className="w-10 h-6 text-center font-mono font-bold text-xs bg-white text-slate-900 border-x border-slate-200 focus:outline-none"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => setRowQty(product.id, qty + 1)}
                                        className="w-6 h-6 flex items-center justify-center hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                                        title="Increase quantity"
                                      >
                                        <Plus className="w-3 h-3" />
                                      </button>
                                    </div>

                                    <button
                                      type="button"
                                      onClick={() => handleAddToCart(product, qty)}
                                      className="bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-extrabold text-[11px] px-2.5 py-1 rounded-lg transition flex items-center gap-1 shadow-2xs cursor-pointer shrink-0"
                                      title="Add quantity to BOQ Cart"
                                    >
                                      <Plus className="w-3 h-3" />
                                      <span>Add</span>
                                    </button>
                                  </div>

                                  {inCartItem && (
                                    <span className="text-[9px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                                      <Check className="w-2.5 h-2.5 text-emerald-600" /> In Cart ({inCartItem.qty})
                                    </span>
                                  )}
                                </div>
                              </td>
                            </tr>
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Table Footer with Pagination */}
                  {itemsPerPage !== -1 && totalPages > 1 && (
                    <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <span className="text-slate-500 font-medium">
                        Showing {(tablePage - 1) * itemsPerPage + 1} -{' '}
                        {Math.min(tablePage * itemsPerPage, filteredItems.length)} of {filteredItems.length} products
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setTablePage((p) => Math.max(1, p - 1))}
                          disabled={tablePage === 1}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white font-bold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" /> Prev
                        </button>

                        {/* Page Numbers */}
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                          let pageNum = i + 1;
                          if (totalPages > 5 && tablePage > 3) {
                            pageNum = Math.min(totalPages, tablePage - 2 + i);
                          }
                          return (
                            <button
                              key={pageNum}
                              onClick={() => setTablePage(pageNum)}
                              className={`w-7 h-7 rounded-lg text-xs font-bold transition cursor-pointer ${
                                tablePage === pageNum
                                  ? 'bg-orange-500 text-white font-black shadow-xs'
                                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                              }`}
                            >
                              {pageNum}
                            </button>
                          );
                        })}

                        <button
                          onClick={() => setTablePage((p) => Math.min(totalPages, p + 1))}
                          disabled={tablePage === totalPages}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white font-bold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
                        >
                          Next <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {filteredItems.length === 0 && (
              <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
                <Package className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-sm font-bold text-slate-800">No matching products found</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Try clearing your search query or selecting "All Categories" to view available equipment items.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedBrand('All');
                    setPriceRange('All');
                  }}
                  className="bg-orange-500 text-white font-bold text-xs px-4 py-2 rounded-xl cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      )}

      {/* VIEW MODE 2: MASTER EQUIPMENT PRICE LIST SPREADSHEET TABLE */}
      {viewMode === 'pricelist' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-slate-900 to-emerald-950 p-5 rounded-2xl text-white border border-emerald-800/60 shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                <h2 className="text-lg font-black text-white">Master Equipment & Security PDF Price List</h2>
              </div>
              <p className="text-xs text-emerald-200/80 mt-1 max-w-2xl">
                Integrated database of {fullPriceList.length.toLocaleString()} security products, ANPR cameras, batteries, switches, decoders, and accessories with official QAR unit rates.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="bg-emerald-500/20 text-emerald-300 font-mono font-bold text-xs px-3 py-1.5 rounded-xl border border-emerald-400/30">
                {filteredItems.length.toLocaleString()} Records Active
              </span>
            </div>
          </div>

          <EditableTable
            title="Official Qatar Security Price List Database"
            subtitle="Editable master equipment price list. Search model numbers, brands, or unit rates directly."
            columns={tableColumns}
            data={filteredItems}
            onUpdateData={onUpdateCatalog}
            onAddRow={onOpenQuickAdd}
            badge="PDF Price List"
            badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
          />
        </div>
      )}

      {/* VIEW MODE 3: ACTIVE VS PASSIVE ARCHITECTURE GUIDE */}
      {viewMode === 'guide' && (
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 p-6 rounded-2xl border border-indigo-800/60 text-slate-100 shadow-md space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-indigo-800/50">
            <div>
              <div className="flex items-center gap-2">
                <Cpu className="w-6 h-6 text-amber-400" />
                <h2 className="text-lg font-black text-white">
                  Active vs. Passive Security Systems Architecture Reference
                </h2>
              </div>
              <p className="text-xs text-indigo-200/80 mt-1">
                Technical guide for Qatar ELV security sub-systems. Compare powered active units (MOI Approved vs. Non-MOI) against universal mandatory passive infrastructure.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-indigo-300 font-semibold bg-indigo-900/60 px-3 py-1.5 rounded-lg border border-indigo-700/50 self-start sm:self-auto">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Qatar MOI SSD Compliant Specs</span>
            </div>
          </div>

          {/* Sub-system selection tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 select-none">
            {Object.keys(systemComponentGuides).map((sysKey) => {
              const isSelected = activeGuideTab === sysKey;
              return (
                <button
                  key={sysKey}
                  onClick={() => setActiveGuideTab(sysKey)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                      : 'bg-indigo-950/80 text-indigo-200 hover:bg-indigo-900 border border-indigo-800/40'
                  }`}
                >
                  <Radio className={`w-3.5 h-3.5 ${isSelected ? 'text-slate-950' : 'text-amber-400'}`} />
                  <span>{sysKey}</span>
                </button>
              );
            })}
          </div>

          {/* Active vs Passive Breakdown Cards for selected system */}
          {systemComponentGuides[activeGuideTab] && (
            <div className="space-y-4 pt-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Active Components Box */}
                <div className="bg-slate-900/90 p-5 rounded-2xl border border-amber-500/30 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-amber-500/20">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-amber-400" />
                      <h3 className="text-sm font-bold text-amber-300">
                        ⚡ Active Components (Powered Electronics)
                      </h3>
                    </div>
                    <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-400/30">
                      Client/Engineering Choice
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Powered devices that capture video, process biometric signals, analyze data, or execute automated motor control logic. Selected based on client budget and MOI compliance requirements.
                  </p>

                  <div className="space-y-3 pt-2">
                    <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-500/30">
                      <p className="text-xs font-extrabold text-emerald-300 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Sub-Type 1: MOI SSD Approved Active Units
                      </p>
                      <ul className="mt-2 space-y-1.5 text-xs text-emerald-100/90">
                        {systemComponentGuides[activeGuideTab].activeMOI.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-emerald-400 mt-0.5">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-amber-950/30 p-3 rounded-xl border border-amber-500/30">
                      <p className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5">
                        <XCircle className="w-4 h-4 text-amber-400" /> Sub-Type 2: Non-MOI / Standard Active Units
                      </p>
                      <ul className="mt-2 space-y-1.5 text-xs text-amber-100/80">
                        {systemComponentGuides[activeGuideTab].activeNonMOI.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-amber-400 mt-0.5">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Passive Components Box */}
                <div className="bg-slate-900/90 p-5 rounded-2xl border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
                    <div className="flex items-center gap-2">
                      <Wrench className="w-5 h-5 text-cyan-400" />
                      <h3 className="text-sm font-bold text-cyan-300">
                        🛠️ Passive Components (Universal Infrastructure)
                      </h3>
                    </div>
                    <span className="text-[10px] font-bold bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded border border-cyan-400/30">
                      100% Mandatory / Universal
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Physical infrastructure, cabling, containment, mounting brackets, magnetic locks, and junction boxes. These are <strong className="text-white">MUST-HAVE / IDENTICAL</strong> regardless of whether active components are MOI-approved or non-MOI.
                  </p>

                  <div className="bg-cyan-950/40 p-3 rounded-xl border border-cyan-500/30 space-y-2 pt-2">
                    <p className="text-xs font-extrabold text-cyan-300 flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-cyan-400" /> Must-Have Infrastructure & Accessories
                    </p>
                    <ul className="space-y-1.5 text-xs text-cyan-100/90">
                      {systemComponentGuides[activeGuideTab].passiveInfrastructure.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <span className="text-cyan-400 font-bold mt-0.5">✔</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* MOI Rule Footnote */}
              <div className="bg-indigo-950/90 p-4 rounded-2xl border border-indigo-700/50 flex items-start gap-2.5 text-xs text-indigo-200">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-extrabold text-white">Qatar MOI SSD Regulatory Note: </span>
                  <span>{systemComponentGuides[activeGuideTab].moiStandardRule}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* QUICK VIEW SPECS MODAL */}
      {quickViewItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in duration-200">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                  {quickViewItem.brand}
                </span>
                <h3 className="font-extrabold text-base text-slate-900 mt-1">
                  {quickViewItem.productType}
                </h3>
                <p className="text-xs text-slate-500 font-mono font-bold">
                  Model No: {quickViewItem.model}
                </p>
              </div>

              <button
                onClick={() => setQuickViewItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">System Category</span>
                <span className="font-bold text-slate-800">{quickViewItem.category}</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">MOI Approval Status</span>
                <span className={`font-extrabold ${quickViewItem.moiApproved === 'Yes' ? 'text-emerald-600' : 'text-slate-600'}`}>
                  {quickViewItem.moiApproved === 'Yes' ? '🛡️ MOI SSD Approved' : 'Standard Component'}
                </span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Unit Price (QAR)</span>
                <span className="font-black text-slate-900 font-mono text-sm">
                  QAR {(quickViewItem.unitPriceQAR || 0).toLocaleString()}
                </span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Supply Lead Time</span>
                <span className="font-bold text-slate-800">{quickViewItem.supplyDeliveryTime || '7 Days Lead'}</span>
              </div>
            </div>

            <div className="bg-indigo-50/50 p-3.5 rounded-xl border border-indigo-100 text-xs text-slate-700 space-y-1">
              <span className="font-extrabold text-indigo-900 block">Description & Specs:</span>
              <p className="leading-relaxed text-slate-600">{quickViewItem.description}</p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  handleAddToCart(quickViewItem, 1);
                  setQuickViewItem(null);
                }}
                className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-extrabold text-xs py-2.5 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add to BOQ Quote Cart</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BOQ QUOTE CART SLIDE-OVER DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base tracking-tight text-white">BOQ Quotation Cart</h3>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cartItems.length === 0 ? (
                <div className="text-center py-16 space-y-3">
                  <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-600">Your BOQ Quotation cart is empty</p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    Click "Add to BOQ Cart" on any product in the store grid to build a live custom quotation.
                  </p>
                </div>
              ) : (
                cartItems.map(({ item, qty, marginPct }) => (
                  <div key={item.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[9px] font-black uppercase text-indigo-600 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-100">
                          {item.brand}
                        </span>
                        <h4 className="font-bold text-xs text-slate-900 mt-0.5 line-clamp-1">{item.productType}</h4>
                        <p className="text-[10px] text-slate-500 font-mono">{item.model}</p>
                      </div>

                      <button
                        onClick={() => handleRemoveFromCart(item.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleUpdateCartQty(item.id, qty - 1)}
                          className="w-6 h-6 rounded bg-slate-200 font-bold text-slate-700 hover:bg-slate-300 flex items-center justify-center cursor-pointer"
                        >
                          -
                        </button>
                        <span className="font-mono font-bold w-6 text-center">{qty}</span>
                        <button
                          onClick={() => handleUpdateCartQty(item.id, qty + 1)}
                          className="w-6 h-6 rounded bg-slate-200 font-bold text-slate-700 hover:bg-slate-300 flex items-center justify-center cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <div className="text-right">
                        <p className="text-[9px] text-slate-400 font-semibold">Subtotal (Cost)</p>
                        <p className="font-mono font-black text-slate-900 text-xs">
                          QAR {(item.unitPriceQAR * qty).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Drawer Footer Summary */}
            {cartItems.length > 0 && (
              <div className="p-5 bg-slate-50 border-t border-slate-200 space-y-3">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600 font-medium">
                    <span>Base Cost Total:</span>
                    <span className="font-mono font-bold text-slate-900">QAR {cartSubtotalQAR.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 font-medium">
                    <span>Standard Margin (+15%):</span>
                    <span className="font-mono font-bold text-emerald-600">
                      QAR {(cartSubtotalQAR * 0.15).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
                    <span>Client Quote Total:</span>
                    <span className="font-mono text-indigo-600 text-base">
                      QAR {(cartSubtotalQAR * 1.15).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsOfficialQuotationModalOpen(true);
                    }}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs py-3 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <FileText className="w-4 h-4" />
                    <span>📄 View & Print Official Quotation Sheet</span>
                  </button>

                  <button
                    onClick={() => setCartItems([])}
                    className="w-full bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-2 rounded-xl transition cursor-pointer"
                  >
                    Clear Cart
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* OFFICIAL QUOTATION FULL MODAL (QATAR SPECIFICATION FORMAT) */}
      {isOfficialQuotationModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 md:p-6 overflow-y-auto">
          <div className="bg-white w-full max-w-7xl rounded-2xl shadow-2xl overflow-hidden my-auto relative max-h-[95vh] flex flex-col">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-sm tracking-wide">
                  Qatar Official BOQ Quotation Document
                </h3>
              </div>
              <button
                onClick={() => setIsOfficialQuotationModalOpen(false)}
                className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-2 md:p-4 bg-slate-100">
              <OfficialQuotationView
                onClose={() => setIsOfficialQuotationModalOpen(false)}
                initialItems={
                  cartItems.length > 0
                    ? cartItems.map((c, idx) => ({
                        id: `cart-q-${idx}`,
                        sNo: idx + 1,
                        section: (c.item.category || 'CCTV Surveillance Systems').toUpperCase(),
                        modelBrand: `${c.item.brand} ${c.item.model}`,
                        description: c.item.productType + (c.item.notes ? ` (${c.item.notes})` : ''),
                        unit: 'Nos.',
                        qty: c.qty,
                        unitPriceQAR: Math.round(c.item.unitPriceQAR * (1 + c.marginPct / 100)),
                      }))
                    : sampleOfficialQuotationData
                }
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
