import React from 'react';
import {
  TrendingUp,
  Users,
  ShieldCheck,
  ShoppingBag,
  Briefcase,
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  DollarSign,
  Activity,
  Award,
  Layers,
  MapPin,
  FileText,
  Wrench,
  Target,
  Globe,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

interface MasterDashboardProps {
  dataState: any;
  onNavigateTab: (tab: any) => void;
}

export const MasterDashboard: React.FC<MasterDashboardProps> = ({
  dataState,
  onNavigateTab,
}) => {
  const {
    employees,
    leads,
    projects,
    suppliers,
    equipmentMaster,
    contracts,
    conversions,
    priceHistory,
    executionPhases,
    boqs,
  } = dataState;

  const [selectedStage, setSelectedStage] = React.useState<number | null>(null);
  const [stage2UnitTime, setStage2UnitTime] = React.useState<string>('1 Month');

  // Static stage definitions for the dashboard overview
  const workflowProcessStages = [
    { num: 1, title: '1. Lead Acquisition', icon: <Users className="w-5 h-5 text-teal-700" /> },
    { num: 2, title: '2. Site Visit & Cert Check', icon: <MapPin className="w-5 h-5 text-teal-700" /> },
    { num: 3, title: '3. BOQ, Pricing & BP', icon: <FileText className="w-5 h-5 text-teal-700" /> },
    { num: 4, title: '4. PO & 50% Advance', icon: <DollarSign className="w-5 h-5 text-teal-700" /> },
    { num: 5, title: '5. Execution & Staffing', icon: <Wrench className="w-5 h-5 text-teal-700" /> },
    { num: 6, title: '6. Post-Project & 1-Yr AMC', icon: <ShieldCheck className="w-5 h-5 text-teal-700" /> },
  ];
  const activeStage = selectedStage || 0; // 0 for Master Overview

  // Key KPI Calculations
  const totalEmployees = employees.length;
  const totalLeads = leads.length;
  const totalProjects = projects.length;
  const completedProjects = projects.filter((p: any) => p.status === 'Completed').length;
  const ongoingProjects = projects.filter((p: any) => p.status === 'Ongoing').length;
  const activeSuppliers = suppliers.filter((s: any) => s.status === 'Active').length;

  const totalPipelineValue = leads.reduce((sum: number, l: any) => sum + (Number(l.leadValue) || 0), 0);
  const totalContractValue = projects.reduce((sum: number, p: any) => sum + (Number(p.contractValue) || 0), 0);

  // Lead Conversion calculation
  const totalWonLeads = leads.filter((l: any) => l.stage === 'Won' || l.status === 'Won').length;
  const conversionRate = totalLeads > 0 ? ((totalWonLeads || 5) / totalLeads) * 100 : 13.0;

  // Chart Data Preparation
  const chartLeadStages = [
    { name: 'Proposal', count: leads.filter((l: any) => l.stage === 'Proposal').length || 4 },
    { name: 'Assessment', count: leads.filter((l: any) => l.stage === 'Assessment').length || 3 },
    { name: 'Negotiation', count: leads.filter((l: any) => l.stage === 'Negotiation').length || 2 },
    { name: 'Won', count: totalWonLeads || 1 },
  ];

  const projectStatusData = [
    { name: 'Completed', value: completedProjects || 5, color: '#10B981' },
    { name: 'Ongoing', value: ongoingProjects || 3, color: '#6366F1' },
    { name: 'Planned', value: projects.filter((p: any) => p.status === 'Planned').length || 1, color: '#F59E0B' },
    { name: 'Tender', value: projects.filter((p: any) => p.status === 'Tender').length || 2, color: '#8B5CF6' },
  ];

  return (
    <div className="space-y-6 pb-8">
      {/* Executive Welcome & Key Summary */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-wrap justify-between items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
              QATAR OPERATIONS MASTER SHEET
            </span>
            <span className="text-xs text-slate-400 font-mono">Confidential - Internal Use</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight">Amazetec Executive Master Dashboard</h1>
          <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
            Real-time operational dashboard dynamically connected across Administrator, HR, Business Analyst, Procurement, and Project Management worksheets.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right bg-white/5 border border-white/10 p-3 rounded-xl backdrop-blur-xs">
            <p className="text-[10px] uppercase tracking-widest text-indigo-300 font-bold">Total Confirmed Value</p>
            <p className="text-xl font-black font-mono text-emerald-400">
              QAR {totalContractValue.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* Lifecycle Stage Progression - Global Overview */}
      <div className="bg-white p-6 rounded-2xl border border-teal-100 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedStage(null)}
              className="flex items-center gap-1.5 bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-200 transition"
            >
              Executive Dashboard
            </button>
            <span className="w-2.5 h-2.5 rounded-full bg-[#2b9e8b] animate-pulse" />
            <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-teal-900">
              LIFECYCLE STAGE PROGRESSION: MASTER OVERVIEW
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <select className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500">
              <option>Al Rayyan Hotel & Towers W.L.L. — QAR 450,000 (Qualified)</option>
              {projects.map((p: any) => (
                <option key={p.id}>{p.projectName}</option>
              ))}
            </select>
            <button className="flex items-center gap-1.5 bg-[#00796b] text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-[#00695c] transition">
              <Layers className="w-3.5 h-3.5" /> Add New Client Project
            </button>
          </div>
        </div>

        <div className="relative py-2 max-w-5xl mx-auto">
          <div className="absolute top-[28px] left-[5%] right-[5%] h-[3px] bg-slate-200 z-0" />
          <div className="relative z-10 grid grid-cols-6 gap-2 text-center">
            {workflowProcessStages.map((stg) => (
              <div
                key={stg.num}
                className="flex flex-col items-center cursor-pointer group"
                onClick={() => setSelectedStage(stg.num === selectedStage ? null : stg.num)}
              >
                <div className="mb-2 text-[#2b9e8b]">{stg.icon}</div>
                <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm transition ${stg.num === activeStage ? 'bg-[#2b9e8b] text-white shadow-md' : 'bg-slate-100 text-slate-400 group-hover:bg-teal-50'}`}>
                  {stg.num}
                </div>
                <span className="block text-[10px] font-extrabold mt-2 text-slate-600 line-clamp-2 leading-tight">
                  {stg.title.split('. ')[1]}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Content Panel */}
      {selectedStage !== null ? (
        <div className="bg-white p-6 rounded-2xl border border-teal-200 shadow-sm animate-in fade-in zoom-in duration-300 space-y-6">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <span className="text-[10px] uppercase font-black px-2.5 py-1 bg-teal-50 text-teal-700 rounded-lg border border-teal-200">
                Stage {selectedStage} Executive Breakdown
              </span>
              <h2 className="text-xl font-black text-teal-900 mt-1">
                {workflowProcessStages.find(s => s.num === selectedStage)?.title}
              </h2>
            </div>
            <button
              onClick={() => setSelectedStage(null)}
              className="text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg transition cursor-pointer"
            >
              ← Back to Master Overview
            </button>
          </div>

          {selectedStage === 1 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Leads This Week</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">14 Leads</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">↑ +25% vs last week</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Closed / Won Leads</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">5 Leads</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">Conversion: 35.7%</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Contact Frequency</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">3.4 Touches</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">Avg calls/emails per lead</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Business Value Increase</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">+QAR 1.45M</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">New pipeline addition</p>
                </div>
              </div>

              <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100">
                <h4 className="font-bold text-indigo-900 text-sm mb-2">Stage 1 Deal Execution Pipeline</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="text-slate-400 border-b border-indigo-100 font-semibold">
                        <th className="pb-2">Client / Lead Name</th>
                        <th className="pb-2">Contact Person</th>
                        <th className="pb-2">Touches</th>
                        <th className="pb-2">Pipeline Value</th>
                        <th className="pb-2 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-indigo-100/50">
                      {leads.map((l: any) => (
                        <tr key={l.id} className="hover:bg-white/60">
                          <td className="py-2.5 font-bold text-slate-800">{l.clientName || l.projectName}</td>
                          <td className="py-2.5 text-slate-600">{l.contactPerson || 'Waleed M.'}</td>
                          <td className="py-2.5 font-mono text-indigo-600 font-semibold">3 Calls / 2 Emails</td>
                          <td className="py-2.5 font-mono font-bold text-slate-900">QAR {(Number(l.leadValue) || 250000).toLocaleString()}</td>
                          <td className="py-2.5 text-right">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700">
                              {l.stage || 'Qualified'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {selectedStage === 2 && (
            <div className="space-y-5">
              <div className="flex flex-wrap justify-between items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Site Visit & Certification Check Statistics</h4>
                  <p className="text-xs text-slate-500">Filter site audit metrics across custom unit time intervals.</p>
                </div>
                <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-200">
                  {['1 Week', '1 Month', '1 Quarter', '1 Year', '2 Years', '3 Years'].map((timeOpt) => (
                    <button
                      key={timeOpt}
                      onClick={() => setStage2UnitTime(timeOpt)}
                      className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${stage2UnitTime === timeOpt ? 'bg-teal-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'}`}
                    >
                      {timeOpt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Scheduled Visits</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">24</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Unit Time: {stage2UnitTime}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Completed</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">19</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Fully Audited</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Pending</p>
                  <p className="text-2xl font-black text-amber-600 mt-1">3</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">In Progress</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-center">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Canceled / Closed</p>
                  <p className="text-2xl font-black text-rose-600 mt-1">2</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Rescheduled</p>
                </div>
                <div className="bg-teal-50 p-4 rounded-xl border border-teal-200 text-center">
                  <p className="text-[10px] text-teal-700 font-bold uppercase">Successful Rate</p>
                  <p className="text-2xl font-black text-teal-900 mt-1">94.7%</p>
                  <p className="text-[10px] text-teal-700 mt-0.5">Value: QAR 3.8M (28.5%)</p>
                </div>
              </div>
            </div>
          )}

          {selectedStage === 3 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">BOQs Received</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">28 BOQs</p>
                  <p className="text-[11px] text-slate-500 mt-1">Processed via AI CAD Takeoff</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Quotations & Pricing</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">28 Completed</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">100% Master Price aligned</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Business Proposals (BP)</p>
                  <p className="text-2xl font-black text-amber-600 mt-1">22 Sent</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">Official QAR Commercial Submittal</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Successful Follow-ups</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">11 Won (39.2%)</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">High conversion yield</p>
                </div>
              </div>
            </div>
          )}

          {selectedStage === 4 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">PO & Final VC Received</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">12 POs Secured</p>
                  <p className="text-[11px] text-slate-500 mt-1">Official Client Purchase Orders</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">50% Advance Payment</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">QAR 2,150,000</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">Cleared in Bank Account</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Product Orders</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">100% Dispatched</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">Hikvision, Seagate & Belden</p>
                </div>
              </div>

              <div className="bg-slate-900 text-white p-5 rounded-2xl">
                <h4 className="font-bold text-sm mb-3">Execution Steps & Performance KPIs</h4>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
                  <div className="bg-slate-800 p-3 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Planning Speed</span>
                    <span className="text-base font-bold text-emerald-400">100% (2 Days)</span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Work Quality</span>
                    <span className="text-base font-bold text-indigo-400">98.4% ISO</span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Bug/Issue Speed</span>
                    <span className="text-base font-bold text-amber-400">&lt; 4 Hours</span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Client Response</span>
                    <span className="text-base font-bold text-emerald-400">99.2% SLA</span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Reporting Sync</span>
                    <span className="text-base font-bold text-indigo-400">Real-time</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {selectedStage === 5 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Active Projects</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">{ongoingProjects} Ongoing</p>
                  <p className="text-[11px] text-indigo-600 font-semibold mt-1">{completedProjects} Fully Completed</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Staff Deployed</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">{totalEmployees} Engineers & Techs</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">100% QID & MOI Badge Verified</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Site Safety & Compliance</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">Zero Incidents</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">HSE Standard Maintained</p>
                </div>
              </div>
            </div>
          )}

          {selectedStage === 6 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">1-Year AMC Contracts</p>
                  <p className="text-2xl font-black text-indigo-600 mt-1">14 Active</p>
                  <p className="text-[11px] text-slate-500 mt-1">Preventive & Corrective Support</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Completed Cycles</p>
                  <p className="text-2xl font-black text-emerald-600 mt-1">42 Cycles</p>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">Quarterly audits done</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Upcoming Services</p>
                  <p className="text-2xl font-black text-amber-600 mt-1">6 Scheduled</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">For next week execution</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Contract Expiration</p>
                  <p className="text-2xl font-black text-slate-900 mt-1">Q3/Q4 2026</p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-1">Renewal pipeline open</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200">
                  <h4 className="font-bold text-emerald-900 text-sm mb-2">Fixed Issues (Recent Maintenance)</h4>
                  <ul className="text-xs text-emerald-800 space-y-1.5 list-disc pl-4">
                    <li>Recalibrated 34 PTZ cameras at Ezdan Tower per MOI security spec.</li>
                    <li>Updated NVR RAID firmware and replaced failing sector drive at Al Rayyan.</li>
                    <li>Re-patched fiber optic SFP transceiver modules on core switches.</li>
                  </ul>
                </div>
                <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200">
                  <h4 className="font-bold text-amber-900 text-sm mb-2">Potential Emerging Issues Monitored</h4>
                  <ul className="text-xs text-amber-800 space-y-1.5 list-disc pl-4">
                    <li>High ambient temperature sensor alert in Server Room Rack 2.</li>
                    <li>UPS battery aging threshold reached at Site B (scheduled Q3 replacement).</li>
                    <li>Firmware patch required for biometric access control readers.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Top Stats Row (Bento Grid Style) */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs hover:border-indigo-300 transition">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Lead Conversion Rate</p>
            <div className="flex justify-between items-baseline mt-1">
              <p className="text-2xl font-black text-indigo-600">{conversionRate.toFixed(1)}%</p>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                +14% vs Target
              </span>
            </div>
            <div className="h-1.5 w-full bg-slate-100 mt-2 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-600" style={{ width: `${Math.min(conversionRate * 3, 100)}%` }} />
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs hover:border-amber-300 transition">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Active BOQs & Revisions</p>
            <div className="flex justify-between items-baseline mt-1">
              <p className="text-2xl font-black text-amber-600">{boqs.length} <span className="text-xs font-normal text-slate-400">BOQ Rev</span></p>
              <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                3 Pending Review
              </span>
            </div>
            <div className="flex gap-1 mt-2">
              <div className="w-4 h-1.5 bg-amber-500 rounded-full"></div>
              <div className="w-4 h-1.5 bg-amber-500 rounded-full"></div>
              <div className="w-4 h-1.5 bg-slate-200 rounded-full"></div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs hover:border-emerald-300 transition">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Employee Attendance & Health</p>
            <div className="flex justify-between items-baseline mt-1">
              <p className="text-2xl font-black text-emerald-600">92.0%</p>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                {totalEmployees} Staff Active
              </span>
            </div>
            <p className="text-[11px] text-emerald-600 mt-1 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> All ELV Engineers On Site
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs hover:border-rose-300 transition">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Procurement Price Savings</p>
            <div className="flex justify-between items-baseline mt-1">
              <p className="text-2xl font-black text-rose-600">-4.5% Avg</p>
              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
                Negotiated
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1 font-semibold">
              Hikvision & Seagate volume discount applied
            </p>
          </div>
        </div>
      )}


      {/* Main Bento Grid Structure */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">

        {/* BA Module: Lead Sources & Pipeline */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm tracking-tight">Business Analyst: Lead Sources</h3>
              </div>
              <button
                onClick={() => onNavigateTab('ba')}
                className="text-[10px] px-2 py-0.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-full font-bold uppercase transition cursor-pointer"
              >
                View Sheet →
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">Live opportunities captured by ELV, Referral, and Tenders.</p>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Ezdan Properties & KPOI</span>
                  <span className="font-bold text-slate-900">QAR 12.49M</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full w-[85%]" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Argentine Laborhood</span>
                  <span className="font-bold text-slate-900">QAR 2.66M</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="bg-indigo-400 h-full w-[45%]" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Fiber Optic & Al Jazeera</span>
                  <span className="font-bold text-slate-900">QAR 2.44M</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="bg-indigo-300 h-full w-[30%]" />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 flex justify-between items-center text-xs">
            <span className="font-bold text-slate-400 uppercase text-[10px]">TOTAL PIPELINE VALUE</span>
            <span className="font-mono font-bold text-indigo-600 text-sm">
              QAR {totalPipelineValue.toLocaleString()}
            </span>
          </div>
        </div>

        {/* PM Module: Project Execution Tracker */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm tracking-tight">Project Execution Tracker (Master View)</h3>
              </div>
              <button
                onClick={() => onNavigateTab('pm')}
                className="text-[10px] px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold transition cursor-pointer"
              >
                Formula: <code className="text-indigo-600 font-mono">=SUM(MILESTONES)</code>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100 font-semibold">
                    <th className="pb-2">Project</th>
                    <th className="pb-2">Lead PM</th>
                    <th className="pb-2">Contract Value</th>
                    <th className="pb-2">Phases</th>
                    <th className="pb-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-xs">
                  {projects.slice(0, 4).map((prj: any) => (
                    <tr key={prj.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 font-bold text-slate-800">{prj.projectName}</td>
                      <td className="py-2.5 text-slate-500">{prj.projectManager}</td>
                      <td className="py-2.5 font-mono font-semibold text-slate-900">
                        QAR {Number(prj.contractValue).toLocaleString()}
                      </td>
                      <td className="py-2.5">
                        <div className="flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                          <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                          <span className="w-2 h-2 rounded-full bg-slate-200"></span>
                        </div>
                      </td>
                      <td className="py-2.5 text-right">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            prj.status === 'Completed'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          }`}
                        >
                          {prj.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-xs">
            <span className="text-slate-500 font-medium">
              Showing 4 of {totalProjects} Projects in Execution
            </span>
            <button
              onClick={() => onNavigateTab('pm')}
              className="text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1"
            >
              Open PM Sheet →
            </button>
          </div>
        </div>

        {/* HR Module: Salary Brackets & Staff */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-600" />
              <h3 className="font-bold text-slate-900 text-sm tracking-tight">HR: Salary Brackets & Staff Summary</h3>
            </div>
            <button
              onClick={() => onNavigateTab('hr')}
              className="text-[10px] px-2 py-0.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-full font-bold uppercase transition cursor-pointer"
            >
              HR Sheet →
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Total Staff</p>
              <p className="text-xl font-bold text-slate-900">{totalEmployees} Employees</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Leadership, Engineers, Techs</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Active Contracts</p>
              <p className="text-xl font-bold text-indigo-600">{contracts.length} Contracts</p>
              <p className="text-[10px] text-slate-500 mt-0.5">MOI & QID verified</p>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="font-semibold text-slate-700">Managing Director (MD)</span>
              <span className="font-mono text-slate-900">Basic QAR 25,000 / Gross QAR 40,000</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="font-semibold text-slate-700">Chief Operating Officer (COO)</span>
              <span className="font-mono text-slate-900">Basic QAR 20,000 / Gross QAR 32,000</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="font-semibold text-slate-700">ELV Site Engineer</span>
              <span className="font-mono text-slate-900">Basic QAR 8,500 / Gross QAR 14,500</span>
            </div>
          </div>
        </div>

        {/* Procurement Module: Dark Slate Aesthetic Card */}
        <div className="lg:col-span-4 bg-slate-900 text-white p-5 rounded-2xl shadow-md border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-sm tracking-tight text-white">Procurement Officer Summary</h3>
                <p className="text-[10px] text-slate-400">Latest Price Revisions & Suppliers</p>
              </div>
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-xs font-mono font-bold text-white shadow-xs">
                PRO
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 p-2.5 bg-slate-800/80 rounded-xl border border-slate-700/50">
                <div className="w-9 h-9 bg-emerald-500/20 rounded-lg flex items-center justify-center text-emerald-400 text-xs font-mono font-bold">
                  -3.4%
                </div>
                <div>
                  <p className="text-xs font-bold text-white">2MP Varifocal Dome Camera</p>
                  <p className="text-[10px] text-slate-400">Hikvision • Old QAR 385 → New QAR 372</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2.5 bg-slate-800/80 rounded-xl border border-slate-700/50">
                <div className="w-9 h-9 bg-emerald-500/20 rounded-lg flex items-center justify-center text-emerald-400 text-xs font-mono font-bold">
                  -3.3%
                </div>
                <div>
                  <p className="text-xs font-bold text-white">16TB NVR HDD</p>
                  <p className="text-[10px] text-slate-400">SEAGATE • Old QAR 2900 → New QAR 2805</p>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('procurement')}
            className="w-full mt-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-center text-xs font-bold text-white uppercase tracking-wider transition cursor-pointer"
          >
            Manage Procurement & Supplier Sheet →
          </button>
        </div>

        {/* Administrator Module: Equipment & KYC */}
        <div className="lg:col-span-3 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm tracking-tight">Admin Dashboard</h3>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 mb-3">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Equipment Store</p>
              <p className="text-lg font-bold text-slate-900">5 Store Categories</p>
              <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                ✅ Stock Sufficient (Cameras, HDDs, Switches)
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>MOI Approved Items</span>
                <span className="font-bold text-slate-900">100% Compliant</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>KYC Support Queries</span>
                <span className="font-bold text-indigo-600">3 Open</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 mt-3">
            <button
              onClick={() => onNavigateTab('administrator')}
              className="w-full text-[11px] font-bold text-indigo-600 hover:text-indigo-800 text-center cursor-pointer"
            >
              Open Administrator Sheet →
            </button>
          </div>
        </div>

      </div>

      {/* Operational Alerts & Notifications */}
      <div className="bg-amber-50/80 border border-amber-200/80 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 text-amber-700 rounded-xl">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="font-bold text-amber-900">Master Operations Alerts (4 Action Items)</p>
            <p className="text-amber-700 mt-0.5">
              • 3 BOQs pending CEO approval • 1 Project awaiting DIA Inspection (Ezdan) • 2 Employee contracts expiring in 60 days.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('pm')}
          className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
        >
          Review Pending Items
        </button>
      </div>
    </div>
  );
};
