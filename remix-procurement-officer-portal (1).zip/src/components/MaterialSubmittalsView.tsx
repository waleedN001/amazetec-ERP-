import React, { useState } from 'react';
import {
  FileCheck2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Building2,
  ShieldCheck,
  Printer,
  X,
  Plus,
  Eye,
  BadgeCheck,
  Award,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { MaterialSubmittal } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';

interface MaterialSubmittalsViewProps {
  submittals: MaterialSubmittal[];
  onUpdateSubmittals: (data: MaterialSubmittal[]) => void;
  onOpenQuickAdd: () => void;
}

export const MaterialSubmittalsView: React.FC<MaterialSubmittalsViewProps> = ({
  submittals,
  onUpdateSubmittals,
  onOpenQuickAdd,
}) => {
  const [selectedSubmittal, setSelectedSubmittal] = useState<MaterialSubmittal | null>(null);
  const [isTransmittalOpen, setIsTransmittalOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  const submittalColumns: ColumnDef[] = [
    { key: 'submittalId', label: 'Submittal Ref', type: 'readonly' },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'category', label: 'Category', type: 'text' },
    { key: 'itemDescription', label: 'Equipment Description', type: 'text' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model No.', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'consultantName', label: 'Supervising Consultant', type: 'text' },
    { key: 'dateSubmitted', label: 'Submitted Date', type: 'date' },
    {
      key: 'approvalStatus',
      label: 'Consultant Status',
      type: 'select',
      options: [
        'Approved (Code A)',
        'Approved with Comments (Code B)',
        'Revise & Resubmit (Code C)',
        'Rejected (Code D)',
        'Under Review',
      ],
    },
    { key: 'approvalDate', label: 'Approval Date', type: 'date' },
    { key: 'moiCertificateAttached', label: 'MOI Cert Attached', type: 'select', options: ['Yes', 'No', 'N/A'] },
  ];

  const handleUpdateStatus = (submittalId: string, status: MaterialSubmittal['approvalStatus']) => {
    const updated = submittals.map((s) => {
      if (s.submittalId === submittalId) {
        return {
          ...s,
          approvalStatus: status,
          approvalDate: status.startsWith('Approved') ? new Date().toISOString().split('T')[0] : s.approvalDate,
        };
      }
      return s;
    });
    onUpdateSubmittals(updated);
    setNotification(`Submittal ${submittalId} marked as ${status}`);
    setTimeout(() => setNotification(null), 3500);
    if (selectedSubmittal?.submittalId === submittalId) {
      setSelectedSubmittal((prev) => (prev ? { ...prev, approvalStatus: status } : null));
    }
  };

  const approvedCount = submittals.filter(
    (s) => s.approvalStatus === 'Approved (Code A)' || s.approvalStatus === 'Approved with Comments (Code B)'
  ).length;
  const underReviewCount = submittals.filter((s) => s.approvalStatus === 'Under Review').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-5 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-emerald-900/40">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-emerald-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-emerald-600/30">
            <FileCheck2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base tracking-tight text-white">
                Material Submittal (MAS / MAR) & Consultant Approvals
              </h3>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-2xs px-2 py-0.5 rounded-full font-semibold">
                MOI-SSD Verified
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Technical datasheets, physical samples, and Qatar MOI-SSD compliance certificates submitted to supervising consultants (KEO, AEB, EHAF).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl font-bold">
            {approvedCount} Code A / B Approved
          </span>
          <span className="px-3 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-xl font-bold">
            {underReviewCount} In Review
          </span>
          <button
            onClick={onOpenQuickAdd}
            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition flex items-center gap-1 shadow-sm cursor-pointer ml-2"
          >
            <Plus className="w-4 h-4" />
            <span>New MAS</span>
          </button>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-2.5 text-xs text-emerald-800 font-semibold animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Quick Action Submittal Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {submittals.slice(0, 3).map((sub) => {
          const isApproved =
            sub.approvalStatus === 'Approved (Code A)' || sub.approvalStatus === 'Approved with Comments (Code B)';

          return (
            <div
              key={sub.submittalId}
              className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs hover:shadow-md transition space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">
                    {sub.submittalId}
                  </span>
                  <span
                    className={`text-2xs font-bold px-2 py-0.5 rounded-full ${
                      isApproved
                        ? 'bg-emerald-100 text-emerald-800'
                        : sub.approvalStatus === 'Under Review'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {sub.approvalStatus}
                  </span>
                </div>

                <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{sub.itemDescription}</h4>
                <div className="mt-1 flex items-center justify-between text-2xs text-slate-500">
                  <span>Brand: <strong className="text-slate-800">{sub.brand} {sub.model}</strong></span>
                  <span>Consultant: <strong className="text-slate-800">{sub.consultantName}</strong></span>
                </div>
                <div className="mt-2 text-2xs text-slate-500 line-clamp-1">
                  Project: <strong className="text-slate-700">{sub.projectName}</strong>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    setSelectedSubmittal(sub);
                    setIsTransmittalOpen(true);
                  }}
                  className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3 h-3 text-slate-500" />
                  <span>Transmittal</span>
                </button>
                {!isApproved && (
                  <button
                    onClick={() => handleUpdateStatus(sub.submittalId, 'Approved (Code A)')}
                    className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white text-2xs font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Approve (Code A)</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Submittals Table */}
      <EditableTable
        title="Material Approval Submittals (MAS) Registry"
        subtitle="Tracking formal approvals from Qatar Engineering Consultants (KEO, AEB, EHAF) with MOI certificates"
        columns={submittalColumns}
        data={submittals}
        onUpdateData={onUpdateSubmittals}
        onAddRow={onOpenQuickAdd}
        badge="Table 1B"
        badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
      />

      {/* ========================================================================= */}
      {/* CONSULTANT TRANSMITTAL & SPECIFICATION SHEET MODAL */}
      {/* ========================================================================= */}
      {isTransmittalOpen && selectedSubmittal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-300 my-auto flex flex-col">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl shrink-0">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-sm">
                  Material Approval Submittal Transmittal — {selectedSubmittal.submittalId}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Sheet</span>
                </button>
                <button
                  onClick={() => setIsTransmittalOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-8 space-y-6 text-xs text-slate-800 font-sans">
              <div className="border-b border-slate-200 pb-4 flex justify-between items-start">
                <div>
                  <h2 className="text-base font-extrabold text-slate-900">
                    MATERIAL APPROVAL TRANSMITTAL FORM (MAS / MAR)
                  </h2>
                  <p className="text-2xs text-slate-500 uppercase tracking-wider">
                    Project: {selectedSubmittal.projectName}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    {selectedSubmittal.submittalId}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Supervising Consultant</span>
                  <p className="font-bold text-slate-900 mt-0.5">{selectedSubmittal.consultantName}</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Main Contractor / Integrator</span>
                  <p className="font-bold text-slate-900 mt-0.5">Amazetec Security & ELV Systems W.L.L.</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Date Submitted</span>
                  <p className="font-semibold text-slate-800 mt-0.5">{selectedSubmittal.dateSubmitted}</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Current Status</span>
                  <p className="font-bold text-emerald-700 mt-0.5">{selectedSubmittal.approvalStatus}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-2xs">
                  Equipment Technical Details
                </h4>
                <div className="border border-slate-200 rounded-xl p-3 bg-white space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Description:</span>
                    <strong className="text-slate-900">{selectedSubmittal.itemDescription}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Brand & Model:</span>
                    <strong className="text-slate-900">{selectedSubmittal.brand} - {selectedSubmittal.model}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Supplier:</span>
                    <strong className="text-slate-900">{selectedSubmittal.supplier}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">MOI-SSD Certificate Attached:</span>
                    <strong className="text-emerald-700">{selectedSubmittal.moiCertificateAttached}</strong>
                  </div>
                </div>
              </div>

              {/* Stamp Actions */}
              <div className="border-t border-slate-200 pt-4 flex flex-wrap items-center justify-between gap-3">
                <span className="text-2xs font-bold text-slate-500">Consultant Action Stamp:</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleUpdateStatus(selectedSubmittal.submittalId, 'Approved (Code A)')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition shadow-xs"
                  >
                    Code A (Approved)
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedSubmittal.submittalId, 'Approved with Comments (Code B)')}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition"
                  >
                    Code B (With Comments)
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedSubmittal.submittalId, 'Revise & Resubmit (Code C)')}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold transition"
                  >
                    Code C (Revise)
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
