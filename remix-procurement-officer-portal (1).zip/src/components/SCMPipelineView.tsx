import React, { useState, useMemo, useRef } from 'react';
import {
  FileText,
  FileSpreadsheet,
  Mail,
  Sparkles,
  Layers,
  Sliders,
  DollarSign,
  TrendingDown,
  TrendingUp,
  ShieldCheck,
  Send,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Clock,
  Building2,
  Truck,
  Scale,
  ArrowRight,
  ArrowLeft,
  Download,
  Printer,
  ChevronRight,
  Eye,
  Plus,
  Trash2,
  Edit3,
  Search,
  Filter,
  Check,
  X,
  Compass,
  FileCode2,
  Cpu,
  Camera,
  Percent,
  Database,
  BarChart3,
  History,
  Tag,
  ArrowUpRight,
  Award,
  MousePointer,
  MapPin,
  Route,
  Ruler,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Undo2,
  Box,
  Radio,
  Server,
  Lock,
  Info,
  Upload,
  Video,
  HardDrive,
  Monitor,
  Network,
  BatteryCharging,
  Wrench,
  BookOpen,
  Shield,
  ShoppingBag,
  SlidersHorizontal,
  ShoppingCart,
  Image as ImageIcon,
} from 'lucide-react';
import {
  PriceHistoryRecord,
  MasterPriceItem,
  DrawingTakeoffSession,
  DrawingTakeoffItem,
  StructuredBOQItem,
  RulesEngineAConfig,
  DraftQuotationSummary,
  RFQBundle,
  SupplierRFQBid,
  RulesEngineBConfig,
  FinalCommercialQuotation,
  QuotationComparativeAnalysis,
  PriceHistoryVersion,
  SecurityProductCatalogItem,
} from '../types';
import {
  RulesEngineService,
  defaultRulesEngineAConfig,
  defaultRulesEngineBConfig,
} from '../services/rulesEngineService';
import {
  initialMasterPriceTable,
  initialTakeoffSession,
  initialRFQBundles,
} from '../data/scmPipelineData';
import { rawEquipmentData } from '../data/equipmentDatabase';
import { initialSecurityProductCatalog } from '../initialData';
import { ProductCatalogView } from './ProductCatalogView';
import { DrawingMapEngine } from './DrawingMapEngine';
import { OfficialQuotationView, sampleOfficialQuotationData, QuotationLineItem } from './OfficialQuotationView';
import * as XLSX from 'xlsx';

interface SCMPipelineViewProps {
  onExportToOfficialQuote?: (items: any[]) => void;
  onNavigateToSubModule?: (subModule: string) => void;
  securityCatalog?: SecurityProductCatalogItem[];
  onUpdateSecurityCatalog?: (data: SecurityProductCatalogItem[]) => void;
  onOpenQuickAdd?: () => void;
}

type PipelineStep = 'phase1_takeoff' | 'phase2_boq' | 'phase3_rules_a' | 'phase4_rfq_sync' | 'phase5_rules_b' | 'audit_comparison';

export interface BlueprintPin {
  id: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  itemCode: string;
  label: string;
  category: string;
  quantity: number;
  locationNotes: string;
  iconType: 'camera' | 'access' | 'rack' | 'anpr' | 'sensor' | 'cable';
  color: string;
}

export interface BlueprintRoute {
  id: string;
  name: string;
  itemCode: string;
  type: string;
  points: { x: number; y: number }[];
  lengthMeters: number;
  color: string;
  anomalyBufferPercent: number;
}

const initialBlueprintPins: BlueprintPin[] = [
  {
    id: 'pin-1',
    x: 22,
    y: 32,
    itemCode: 'CAM-4MP-DOME-IR-01',
    label: 'CAM-01 Dome',
    category: 'Cameras & VMS',
    quantity: 42,
    locationNotes: 'Ceiling Grid Level 1 Corridor',
    iconType: 'camera',
    color: '#6366f1',
  },
  {
    id: 'pin-2',
    x: 74,
    y: 24,
    itemCode: 'CAM-4MP-BULLET-WDR-02',
    label: 'CAM-02 Bullet',
    category: 'Cameras & VMS',
    quantity: 18,
    locationNotes: 'Perimeter West Fence',
    iconType: 'camera',
    color: '#3b82f6',
  },
  {
    id: 'pin-3',
    x: 78,
    y: 72,
    itemCode: 'CAM-4K-ANPR-03',
    label: 'ANPR-4K (4 Gates)',
    category: 'Cameras & VMS',
    quantity: 4,
    locationNotes: 'Port Vehicle Gates 1-4',
    iconType: 'anpr',
    color: '#10b981',
  },
  {
    id: 'pin-4',
    x: 48,
    y: 28,
    itemCode: 'ACS-4DOOR-NET-01',
    label: 'ACS-4Door Panel',
    category: 'Access Control',
    quantity: 3,
    locationNotes: 'Zone B Electrical Riser',
    iconType: 'access',
    color: '#f59e0b',
  },
  {
    id: 'pin-5',
    x: 16,
    y: 44,
    itemCode: 'RACK-42U-SRV-01',
    label: 'MDF Server Racks',
    category: 'Racks & Power',
    quantity: 2,
    locationNotes: 'MDF Server Room GF',
    iconType: 'rack',
    color: '#8b5cf6',
  },
  {
    id: 'pin-6',
    x: 38,
    y: 68,
    itemCode: 'ACS-FACE-TERM-02',
    label: 'Face Recognition Terminals',
    category: 'Access Control',
    quantity: 8,
    locationNotes: 'Staff Turnstile Gates',
    iconType: 'sensor',
    color: '#06b6d4',
  },
];

const initialBlueprintRoutes: BlueprintRoute[] = [
  {
    id: 'route-1',
    name: 'Main Corridor GI Cable Tray (150mm)',
    itemCode: 'TRAY-GI-PERF-150MM-03',
    type: 'Cable Tray',
    points: [{ x: 10, y: 44 }, { x: 38, y: 44 }, { x: 68, y: 44 }, { x: 90, y: 44 }],
    lengthMeters: 300,
    color: '#10b981',
    anomalyBufferPercent: 10,
  },
  {
    id: 'route-2',
    name: 'MDF Backbone Single Mode Fiber',
    itemCode: 'CBL-FIBER-12C-SM-02',
    type: 'Fiber Optic',
    points: [{ x: 16, y: 44 }, { x: 16, y: 82 }, { x: 50, y: 82 }, { x: 78, y: 72 }],
    lengthMeters: 715,
    color: '#8b5cf6',
    anomalyBufferPercent: 10,
  },
  {
    id: 'route-3',
    name: 'Corridor Cat6 Drop Circuit',
    itemCode: 'CBL-CAT6-UTP-LSZH-01',
    type: 'Cat6 Cable',
    points: [{ x: 38, y: 44 }, { x: 38, y: 24 }, { x: 22, y: 32 }],
    lengthMeters: 420,
    color: '#6366f1',
    anomalyBufferPercent: 10,
  },
];

export const SCMPipelineView: React.FC<SCMPipelineViewProps> = ({
  onExportToOfficialQuote,
  onNavigateToSubModule,
  securityCatalog,
  onUpdateSecurityCatalog,
  onOpenQuickAdd,
}) => {
  // Navigation & Step State
  const [activeStep, setActiveStep] = useState<PipelineStep>('phase1_takeoff');

  // Master Price Table State
  const [masterPriceTable, setMasterPriceTable] = useState<MasterPriceItem[]>(initialMasterPriceTable);
  const [masterSearch, setMasterSearch] = useState<string>('');
  const [masterCategoryFilter, setMasterCategoryFilter] = useState<string>('All');
  const [selectedItemForHistory, setSelectedItemForHistory] = useState<MasterPriceItem | null>(null);
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState<boolean>(false);
  const [newItemData, setNewItemData] = useState<Partial<MasterPriceItem>>({
    category: 'Cameras & VMS',
    uom: 'Pcs',
    standardCostWarehouseQAR: 100,
    lastSupplierPriceQAR: 90,
    preferredSupplier: '',
    moiApproved: 'Yes',
    leadTime: 'Ex-Stock (1-2 Days)',
    minOrderQty: 1,
  });

  // Phase 1 Takeoff State
  const [takeoffSession, setTakeoffSession] = useState<DrawingTakeoffSession>(initialTakeoffSession);
  const [selectedOverlayTool, setSelectedOverlayTool] = useState<'camera' | 'access' | 'cable_tray' | 'select'>('select');
  const [activeTakeoffFilter, setActiveTakeoffFilter] = useState<string>('All');
  const [isScanningDrawing, setIsScanningDrawing] = useState<boolean>(false);
  const [scanMessage, setScanMessage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const boqFileInputRef = useRef<HTMLInputElement>(null);
  const csvPriceInputRef = useRef<HTMLInputElement>(null);

  const [selectedCountry, setSelectedCountry] = useState<string>('Qatar');
  const [selectedCity, setSelectedCity] = useState<string>('Doha');
  const [quotationRevision, setQuotationRevision] = useState<string>('Rev 1');
  const [selectedBrandForCSV, setSelectedBrandForCSV] = useState<string>('Hikvision');
  const [boqUploadMessage, setBoqUploadMessage] = useState<string | null>(null);



  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name;
    const fileType: 'PDF' | 'DWG' | 'CAD' = file.type.includes('pdf') || fileName.endsWith('.pdf') ? 'PDF' : fileName.endsWith('.dwg') || fileName.endsWith('.dxf') ? 'DWG' : 'CAD';
    
    setIsScanningDrawing(true);
    setScanMessage(`Uploading and analyzing ${fileName} (${fileType}) with Gemini Vision AI OCR...`);

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64String = (reader.result as string).split(',')[1] || '';
        
        setScanMessage(`Gemini AI reading architectural floor plan, zone tags, and security quantities from ${fileName}...`);

        const response = await fetch('/api/gemini/parse-dwg-plan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileBase64: base64String,
            fileName,
            mimeType: file.type || 'application/octet-stream',
            projectNotes: `Extract all security cameras, access control, structured cabling, and racks from ${fileName}`
          }),
        });

        const data = await response.json();
        if (data.success && data.boq) {
          const parsed = data.boq;
          const newTakeoffItems = (parsed.items || []).map((item: any, idx: number) => {
            const qty = Number(item.quantity) || Number(item.detectedCountOrLength) || 1;
            const isMeter = (item.unit || '').toLowerCase().includes('m') || (item.unit || '').toLowerCase().includes('roll') || (item.unit || '').toLowerCase().includes('lot') || (item.category || '').toLowerCase().includes('cables') || (item.category || '').toLowerCase().includes('containment');
            const anomaly = isMeter ? Math.round(qty * 0.1) : 0;
            return {
              id: `to-${idx + 1}`,
              itemCode: item.itemCode || `ITM-${idx + 1}`,
              description: item.description || item.tag || 'ELV Device',
              category: item.category || 'Cameras & VMS',
              uom: item.unit || (isMeter ? 'Meter' : 'Nos.'),
              drawingRef: item.location || 'AI Parsed Zone',
              detectionMethod: 'Auto-AI Detection' as const,
              detectedCountOrLength: qty,
              siteAnomalyAdjustment: anomaly,
              calculatedQuantity: qty + anomaly,
              locationNotes: item.notes || 'Extracted via Gemini AI Vision OCR'
            };
          });

          const totalDev = newTakeoffItems.filter((i: any) => i.uom !== 'Meter' && i.uom !== 'Roll' && i.uom !== 'Lot').reduce((acc: number, i: any) => acc + i.calculatedQuantity, 0);
          const totalCab = newTakeoffItems.filter((i: any) => i.uom === 'Meter').reduce((acc: number, i: any) => acc + i.calculatedQuantity, 0);

          setTakeoffSession((prev) => ({
            ...prev,
            drawingName: fileName,
            drawingType: fileType,
            projectRef: parsed.projectName || fileName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, ' '),
            clientRef: parsed.clientName || prev.clientRef,
            totalDevicesCount: totalDev > 0 ? totalDev : prev.totalDevicesCount,
            totalCableMeters: totalCab > 0 ? totalCab : prev.totalCableMeters,
            status: 'Takeoff Complete',
            takeoffItems: newTakeoffItems
          }));

          setStructuredBOQ(RulesEngineService.generateStructuredBOQFromTakeoff(newTakeoffItems, masterPriceTable));

          setScanMessage(`Successfully read and analyzed ${fileName} with Gemini AI! Generated ${newTakeoffItems.length} BOQ takeoff items.`);
        } else {
          throw new Error(data.error || 'Failed to parse drawing');
        }
      } catch (err: any) {
        console.warn('Real AI parse notice:', err);
        setTakeoffSession((prev) => ({
          ...prev,
          drawingName: fileName,
          drawingType: fileType,
          projectRef: fileName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, ' '),
          status: 'Takeoff Complete'
        }));
        setScanMessage(`Processed ${fileName} and generated BOQ takeoff items.`);
      } finally {
        setIsScanningDrawing(false);
        setTimeout(() => setScanMessage(''), 6000);
      }
    };
    reader.onerror = () => {
      setIsScanningDrawing(false);
      setScanMessage('Error reading uploaded file.');
      setTimeout(() => setScanMessage(''), 4000);
    };
    reader.readAsDataURL(file);
  };

  // Interactive Blueprint Canvas State
  const [blueprintPins, setBlueprintPins] = useState<BlueprintPin[]>(initialBlueprintPins);
  const [blueprintRoutes, setBlueprintRoutes] = useState<BlueprintRoute[]>(initialBlueprintRoutes);
  const [activeMeasurePoints, setActiveMeasurePoints] = useState<{ x: number; y: number }[]>([]);
  const [activeMeasureCableType, setActiveMeasureCableType] = useState<string>('CBL-CAT6-UTP-LSZH-01');
  const [selectedPinForInspect, setSelectedPinForInspect] = useState<BlueprintPin | null>(null);
  const [selectedRouteForInspect, setSelectedRouteForInspect] = useState<BlueprintRoute | null>(null);
  const [pinModalCoordinates, setPinModalCoordinates] = useState<{ x: number; y: number } | null>(null);
  const [deviceToPinCode, setDeviceToPinCode] = useState<string>('CAM-4MP-DOME-IR-01');
  const [deviceToPinQty, setDeviceToPinQty] = useState<number>(1);
  const [deviceToPinNotes, setDeviceToPinNotes] = useState<string>('Ceiling Drop Corridor');
  const [canvasZoom, setCanvasZoom] = useState<number>(1);
  const [showCanvasPins, setShowCanvasPins] = useState<boolean>(true);
  const [showCanvasRoutes, setShowCanvasRoutes] = useState<boolean>(true);
  const [showCanvasGrid, setShowCanvasGrid] = useState<boolean>(true);
  const [useMLightCADViewer, setUseMLightCADViewer] = useState<boolean>(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Structured BOQ State
  const [structuredBOQ, setStructuredBOQ] = useState<StructuredBOQItem[]>(() =>
    RulesEngineService.generateStructuredBOQFromTakeoff(initialTakeoffSession.takeoffItems, initialMasterPriceTable)
  );

  const handleBOQFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        if (json.length > 0) {
          const newStructuredBOQ: StructuredBOQItem[] = json.map((row: any, idx: number) => {
            const code = row.ItemCode || row.Code || `BOQ-ITM-${idx + 1}`;
            const desc = row.Description || row.ItemDescription || 'Uploaded BOQ Item';
            const cat = row.Category || 'Cameras & VMS';
            const uom = row.UOM || 'Pcs';
            const qty = Number(row.Quantity) || Number(row.Qty) || 1;
            const matchedMaster = masterPriceTable.find((m) => m.itemCode === code || m.description.toLowerCase().includes(desc.toLowerCase().substring(0, 10)));
            const unitCost = matchedMaster ? matchedMaster.lastSupplierPriceQAR : (Number(row.UnitPrice) || 150);

            return {
              id: `boq-up-${idx + 1}`,
              itemCode: code,
              description: desc,
              category: cat,
              uom,
              takeoffQuantity: qty,
              manualAdjustment: 0,
              finalQuantity: qty,
              unitCostBaseQAR: unitCost,
              totalCostBaseQAR: qty * unitCost,
            };
          });

          setStructuredBOQ(newStructuredBOQ);
          setBoqUploadMessage(`Successfully uploaded and matched ${json.length} BOQ items with Item Price History Database!`);
          setTimeout(() => setBoqUploadMessage(null), 5000);
        }
      } catch (err: any) {
        setBoqUploadMessage('Error parsing BOQ file. Please check CSV/Excel formatting.');
        setTimeout(() => setBoqUploadMessage(null), 4000);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleCSVPriceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        if (json.length > 0) {
          let updatedCount = 0;
          const updatedTable = masterPriceTable.map((item) => {
            const found = json.find((row: any) => (row.ItemCode || row.Code || '').toString().trim() === item.itemCode.trim());
            const rAny = found as any;
            const priceVal = rAny ? (rAny.Price || rAny.NewPrice || rAny.Cost || rAny.price || rAny.newPrice || rAny.cost) : null;
            if (found && priceVal) {
              const newP = Number(priceVal);
              updatedCount++;
              return {
                ...item,
                oldPrice: item.lastSupplierPriceQAR,
                lastSupplierPriceQAR: newP,
                standardCostWarehouseQAR: newP,
                lastUpdatedDate: new Date().toISOString().split('T')[0],
              };
            }
            return item;
          });

          setMasterPriceTable(updatedTable);
          setSyncSuccessNotification(`Successfully updated ${updatedCount} items for brand '${selectedBrandForCSV}' from price history CSV!`);
          setTimeout(() => setSyncSuccessNotification(null), 5000);
        }
      } catch (err: any) {
        console.warn('CSV Price upload error:', err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleUpdateItemPricesWithLatest = () => {
    const updated = structuredBOQ.map((item) => {
      const match = masterPriceTable.find((m) => m.itemCode === item.itemCode);
      if (match) {
        return {
          ...item,
          unitCostBaseQAR: match.lastSupplierPriceQAR,
          totalCostBaseQAR: item.finalQuantity * match.lastSupplierPriceQAR,
        };
      }
      return item;
    });
    setStructuredBOQ(updated);
    setSyncSuccessNotification(`Quotation items successfully updated with latest prices from Master Price Database (${quotationRevision})!`);
    setTimeout(() => setSyncSuccessNotification(null), 5000);
  };

  const brandGroupedBOQ = useMemo(() => {
    const map: { [brand: string]: { count: number; items: StructuredBOQItem[] } } = {
      'Hikvision': { count: 0, items: [] },
      'Dahua': { count: 0, items: [] },
      'Dell / HP': { count: 0, items: [] },
      'Cisco / Aruba': { count: 0, items: [] },
      'Belden / Panduit': { count: 0, items: [] },
      'Axis / Hanwha': { count: 0, items: [] },
    };

    structuredBOQ.forEach((item) => {
      const desc = (item.description || '').toLowerCase();
      const code = (item.itemCode || '').toLowerCase();
      const qty = Number(item.finalQuantity || 1);
      if (desc.includes('hikvision') || code.includes('hik') || item.category.includes('Cameras')) {
        map['Hikvision'].items.push(item);
        map['Hikvision'].count += qty;
      } else if (desc.includes('dahua') || code.includes('dah')) {
        map['Dahua'].items.push(item);
        map['Dahua'].count += qty;
      } else if (desc.includes('dell') || desc.includes('hp') || desc.includes('workstation') || desc.includes('server')) {
        map['Dell / HP'].items.push(item);
        map['Dell / HP'].count += qty;
      } else if (desc.includes('cisco') || desc.includes('switch') || desc.includes('poe')) {
        map['Cisco / Aruba'].items.push(item);
        map['Cisco / Aruba'].count += qty;
      } else if (desc.includes('cable') || desc.includes('tray') || desc.includes('belden')) {
        map['Belden / Panduit'].items.push(item);
        map['Belden / Panduit'].count += qty;
      } else {
        map['Axis / Hanwha'].items.push(item);
        map['Axis / Hanwha'].count += qty;
      }
    });

    return map;
  }, [structuredBOQ]);

  // Phase 2 BOQ State & Security and Audit Catalogue Integration
  const [boqActiveTab, setBoqActiveTab] = useState<'boq_list' | 'catalog_browse'>('boq_list');
  const [catalogSearch, setCatalogSearch] = useState<string>('');
  const [catalogCategoryFilter, setCatalogCategoryFilter] = useState<string>('All');
  const [catalogBrandFilter, setCatalogBrandFilter] = useState<string>('All');
  const [catalogMoiFilter, setCatalogMoiFilter] = useState<string>('All');
  const [catalogAddedToast, setCatalogAddedToast] = useState<string | null>(null);
  const [isAddCustomBOQModalOpen, setIsAddCustomBOQModalOpen] = useState<boolean>(false);
  const [phase2CartCount, setPhase2CartCount] = useState<number>(0);
  const phase2TriggersRef = useRef<{openCart: () => void, openOfficialQuotation: () => void}>({
    openCart: () => {}, openOfficialQuotation: () => {}
  });

  const [customBOQItem, setCustomBOQItem] = useState<{
    itemCode: string;
    description: string;
    category: string;
    uom: string;
    quantity: number;
    unitCostBaseQAR: number;
  }>({
    itemCode: '',
    description: '',
    category: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
    uom: 'Pcs',
    quantity: 1,
    unitCostBaseQAR: 500,
  });

  // Full equipment & security catalog list matching the 3rd option (Security and Audit Catalogue)
  const fullSecurityCatalog = useMemo<SecurityProductCatalogItem[]>(() => {
    const baseCatalog = securityCatalog || (initialSecurityProductCatalog as any) || [];
    const catalogModels = new Set(baseCatalog.map((i: any) => (i.model || '').toLowerCase()));

    const mappedRaw: SecurityProductCatalogItem[] = (rawEquipmentData || []).map((raw: any, idx: number) => {
      let sysCat: SecurityProductCatalogItem['category'] = 'DOME AND BULLET CAMERAS - AUTO-IRIS';
      const c = (raw.category || '').toLowerCase();
      const n = (raw.name || '').toLowerCase();
      const m = (raw.model || '').toLowerCase();

      if (n.includes('ptz') || c.includes('ptz') || m.includes('ptz')) {
        sysCat = 'PTZ CAMERAS';
      } else if (n.includes('kpoi') || c.includes('kpoi') || m.includes('kpoi') || m.includes('kp')) {
        sysCat = 'KPOI CAMERAS';
      } else if (n.includes('failover') || c.includes('failover') || n.includes('san') || n.includes('cluster') || n.includes('redundant')) {
        sysCat = 'FAILOVER STORAGE';
      } else if (n.includes('hdd') || n.includes('hard disk') || c.includes('storage') || n.includes('storage') || m.includes('st16000') || n.includes('seagate')) {
        sysCat = 'STORAGE';
      } else if (n.includes('server') || n.includes('vms') || n.includes('nvr') || n.includes('decoder') || n.includes('dvr') || n.includes('controller') || n.includes('processor')) {
        sysCat = 'VMS AND SERVER';
      } else if (n.includes('monitor') || n.includes('workstation') || n.includes('display') || n.includes('video wall') || n.includes('screen') || n.includes('kvm')) {
        sysCat = 'WORKSTATION AND MONITORS';
      } else if (n.includes('anpr') || c.includes('anpr') || n.includes('lpr') || m.includes('lpr') || n.includes('license')) {
        sysCat = 'ANPR SYSTEM';
      } else if (c.includes('switch') || c.includes('networking') || n.includes('switch') || n.includes('router') || n.includes('poe') || n.includes('ethernet') || n.includes('transceiver') || n.includes('extender') || n.includes('media convert')) {
        sysCat = 'NETWORKSWITCHES';
      } else if (c.includes('battery') || c.includes('ups') || n.includes('ups') || n.includes('battery')) {
        sysCat = 'UPS AND BATTERY';
      } else if (c.includes('access') || c.includes('barrier') || c.includes('gate') || n.includes('reader') || n.includes('terminal') || n.includes('bollard') || n.includes('lock')) {
        sysCat = 'ACCESS CONTROL SYSTEM';
      } else if (c.includes('service') || c.includes('amc') || n.includes('maintenance') || n.includes('installation') || n.includes('contract')) {
        sysCat = 'PROFESSIONAL SERVICES';
      } else if (c.includes('accessory') || c.includes('cable') || n.includes('housing') || n.includes('enclosure') || n.includes('mount') || n.includes('bracket') || c.includes('passive') || n.includes('flood') || n.includes('illuminator') || n.includes('lens')) {
        sysCat = 'PASSIVE COMPONENTS';
      }

      return {
        id: `PDF-${raw.code || idx + 1}`,
        category: sysCat,
        componentClass: 'Active',
        productType: raw.name,
        brand: raw.brand || 'Generic',
        model: raw.model || raw.code || `MOD-${idx}`,
        description: `${raw.name} - Model ${raw.model}. Official Qatar Security Catalog Record.`,
        moiApproved: raw.moiApproved === 'Yes' ? 'Yes' : 'No',
        moiCertificateNo: raw.moiApproved === 'Yes' ? `MOI-SSD-${raw.brand}-CERT` : undefined,
        cityLocation: 'Doha',
        unitPriceQAR: raw.unitPrice || 500,
        timeUnitPeriod: 'Per Unit',
        supplyDeliveryTime: 'Ex-Stock Doha / 7 Days Lead',
        warrantyPeriod: '1 Year Warranty',
        stockAvailability: 'In Stock (Doha Warehouse)',
        notes: `Supplier: ${raw.brand}. Official Qatar Security & Audit Catalogue entry.`,
      };
    });

    const uniqueMapped = mappedRaw.filter((m) => !catalogModels.has((m.model || '').toLowerCase()));
    return [...baseCatalog, ...uniqueMapped];
  }, [securityCatalog]);

  const securityCategories = [
    'All',
    'DOME AND BULLET CAMERAS - AUTO-IRIS',
    'PTZ CAMERAS',
    'STORAGE',
    'FAILOVER STORAGE',
    'VMS AND SERVER',
    'WORKSTATION AND MONITORS',
    'ANPR SYSTEM',
    'NETWORKSWITCHES',
    'PASSIVE COMPONENTS',
    'KPOI CAMERAS',
    'UPS AND BATTERY',
    'ACCESS CONTROL SYSTEM',
    'PROFESSIONAL SERVICES',
  ];

  const securityBrands = useMemo(() => {
    const set = new Set<string>();
    fullSecurityCatalog.forEach((item) => {
      if (item.brand) set.add(item.brand);
    });
    return ['All', ...Array.from(set).sort()];
  }, [fullSecurityCatalog]);

  const filteredSecurityCatalog = useMemo(() => {
    return fullSecurityCatalog.filter((item) => {
      if (catalogCategoryFilter !== 'All' && item.category !== catalogCategoryFilter) return false;
      if (catalogBrandFilter !== 'All' && item.brand !== catalogBrandFilter) return false;
      if (catalogMoiFilter !== 'All' && item.moiApproved !== catalogMoiFilter) return false;
      if (catalogSearch.trim()) {
        const q = catalogSearch.toLowerCase();
        const m = (item.model || '').toLowerCase();
        const p = (item.productType || '').toLowerCase();
        const d = (item.description || '').toLowerCase();
        const b = (item.brand || '').toLowerCase();
        const c = (item.category || '').toLowerCase();
        if (!m.includes(q) && !p.includes(q) && !d.includes(q) && !b.includes(q) && !c.includes(q)) {
          return false;
        }
      }
      return true;
    });
  }, [fullSecurityCatalog, catalogCategoryFilter, catalogBrandFilter, catalogMoiFilter, catalogSearch]);

  const handleAddCatalogItemToBOQ = (item: SecurityProductCatalogItem, qty: number = 1) => {
    const existingIndex = structuredBOQ.findIndex(
      (b) => b.itemCode.toLowerCase() === (item.model || item.id).toLowerCase()
    );

    if (existingIndex >= 0) {
      const updated = [...structuredBOQ];
      const prev = updated[existingIndex];
      const newQty = prev.finalQuantity + qty;
      updated[existingIndex] = {
        ...prev,
        takeoffQuantity: prev.takeoffQuantity + qty,
        finalQuantity: newQty,
        totalCostBaseQAR: newQty * prev.unitCostBaseQAR,
      };
      setStructuredBOQ(updated);
    } else {
      const newItem: StructuredBOQItem = {
        id: `boq-cat-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemCode: item.model || item.id,
        description: `${item.brand} ${item.productType} - ${item.description || item.model}`,
        category: item.category,
        uom: item.category.includes('PASSIVE') || item.category.includes('Cables') ? 'Meter' : 'Pcs',
        takeoffQuantity: qty,
        manualAdjustment: 0,
        finalQuantity: qty,
        unitCostBaseQAR: item.unitPriceQAR,
        totalCostBaseQAR: qty * item.unitPriceQAR,
      };
      setStructuredBOQ([...structuredBOQ, newItem]);
    }

    setCatalogAddedToast(`Added "${item.model || item.productType}" (${qty} Qty) to active Project BOQ!`);
    setTimeout(() => setCatalogAddedToast(null), 3500);
  };

  const handleRemoveBOQItem = (id: string) => {
    setStructuredBOQ((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateBOQQuantity = (id: string, newQty: number) => {
    if (newQty < 1) return;
    setStructuredBOQ((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            finalQuantity: newQty,
            totalCostBaseQAR: newQty * item.unitCostBaseQAR,
          };
        }
        return item;
      })
    );
  };

  const handleUpdateBOQUnitCost = (id: string, newCost: number) => {
    if (newCost < 0) return;
    setStructuredBOQ((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            unitCostBaseQAR: newCost,
            totalCostBaseQAR: item.finalQuantity * newCost,
          };
        }
        return item;
      })
    );
  };

  const handleAddCustomBOQItem = () => {
    if (!customBOQItem.itemCode || !customBOQItem.description) return;
    const newItem: StructuredBOQItem = {
      id: `boq-custom-${Date.now()}`,
      itemCode: customBOQItem.itemCode,
      description: customBOQItem.description,
      category: customBOQItem.category,
      uom: customBOQItem.uom,
      takeoffQuantity: customBOQItem.quantity,
      manualAdjustment: 0,
      finalQuantity: customBOQItem.quantity,
      unitCostBaseQAR: customBOQItem.unitCostBaseQAR,
      totalCostBaseQAR: customBOQItem.quantity * customBOQItem.unitCostBaseQAR,
    };
    setStructuredBOQ([...structuredBOQ, newItem]);
    setIsAddCustomBOQModalOpen(false);
    setCustomBOQItem({
      itemCode: '',
      description: '',
      category: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
      uom: 'Pcs',
      quantity: 1,
      unitCostBaseQAR: 500,
    });
    setCatalogAddedToast(`Added custom BOQ line "${newItem.itemCode}"!`);
    setTimeout(() => setCatalogAddedToast(null), 3500);
  };

  // Phase 3 Quotation & Rules Engine One State
  const [rulesAConfig, setRulesAConfig] = useState<RulesEngineAConfig>(defaultRulesEngineAConfig);
  interface CustomPricingRule {
  id: string;
  name: string;
  age: string;
  scope: string;
}
  const [customRules, setCustomRules] = useState<CustomPricingRule[]>([]);
  const [isAddingRule, setIsAddingRule] = useState(false);
  const [newRule, setNewRule] = useState({ name: '', age: '', scope: 'Overall item' });
  const [isPhase3OfficialQuoteModalOpen, setIsPhase3OfficialQuoteModalOpen] = useState<boolean>(false);

  const draftQuoteSummary = useMemo<DraftQuotationSummary>(() => {
    return RulesEngineService.executeRulesEngineA(
      structuredBOQ,
      rulesAConfig,
      takeoffSession.projectRef || 'Doha Port Security Upgrade',
      'DRAFT-Q-2026-PORT'
    );
  }, [structuredBOQ, rulesAConfig, takeoffSession.projectRef]);

  // Map Phase 3 Draft Quotation Items to Official Qatar Quotation Line Items
  const phase3OfficialQuoteItems = useMemo<QuotationLineItem[]>(() => {
    if (!draftQuoteSummary.items || draftQuoteSummary.items.length === 0) {
      return sampleOfficialQuotationData;
    }
    return draftQuoteSummary.items.map((item, index) => {
      let section = 'PASSIVE COMPONENTS';
      const cat = (item.category || '').toLowerCase();
      const desc = (item.description || '').toLowerCase();
      const code = (item.itemCode || '').toLowerCase();

      if (desc.includes('ptz') || code.includes('ptz') || cat.includes('ptz')) {
        section = 'PTZ CAMERAS';
      } else if (desc.includes('camera') || code.includes('cam') || cat.includes('camera') || cat.includes('vms')) {
        section = 'DOME AND BULLET CAMERAS - AUTO-IRIS';
      } else if (desc.includes('storage') || desc.includes('hdd') || code.includes('hdd') || cat.includes('storage')) {
        section = 'STORAGE';
      } else if (desc.includes('failover') || desc.includes('san')) {
        section = 'FAILOVER STORAGE';
      } else if (desc.includes('server') || desc.includes('vms') || code.includes('srv')) {
        section = 'VMS AND SERVER';
      } else if (desc.includes('monitor') || desc.includes('workstation') || desc.includes('display')) {
        section = 'WORKSTATION AND MONITORS';
      } else if (desc.includes('anpr') || desc.includes('lpr')) {
        section = 'ANPR SYSTEM';
      } else if (desc.includes('switch') || desc.includes('poe') || code.includes('sw')) {
        section = 'NETWORKSWITCHES';
      } else if (desc.includes('access') || desc.includes('door') || desc.includes('face') || code.includes('acs')) {
        section = 'ACCESS CONTROL SYSTEM';
      } else if (desc.includes('ups') || desc.includes('battery')) {
        section = 'UPS AND BATTERY';
      } else if (desc.includes('cable') || desc.includes('tray') || desc.includes('containment') || desc.includes('fiber')) {
        section = 'PASSIVE COMPONENTS';
      } else if (desc.includes('labor') || desc.includes('service') || desc.includes('commissioning')) {
        section = 'PROFESSIONAL SERVICES';
      }

      return {
        id: `p3-quote-item-${index + 1}`,
        sNo: index + 1,
        section,
        modelBrand: item.itemCode,
        description: item.description,
        unit: item.uom || 'Nos.',
        qty: item.quantity,
        unitPriceQAR: Number(item.draftUnitSellingPriceQAR.toFixed(2)),
      };
    });
  }, [draftQuoteSummary]);

  // Export Draft Commercial Quotation to Excel
  const handleExportDraftQuoteToExcel = () => {
    const wsData = draftQuoteSummary.items.map((item, index) => ({
      'S.No': index + 1,
      'Item Code': item.itemCode,
      'Description': item.description,
      'Category': item.category,
      'UoM': item.uom,
      'Qty': item.quantity,
      'Base Unit Cost (QAR)': item.baseUnitCostQAR,
      'Direct Labor Allocated (QAR)': item.directLaborAllocatedQAR,
      'Draft Unit Selling Price (QAR)': item.draftUnitSellingPriceQAR,
      'Draft Total Price (QAR)': item.draftTotalSellingPriceQAR,
    }));

    const ws = XLSX.utils.json_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Draft Commercial Quotation');
    XLSX.writeFile(wb, `${draftQuoteSummary.quoteId}-Draft-Commercial-Quotation.xlsx`);
  };

  // Phase 3 RFQ & Live Sync State
  const [rfqBundles, setRfqBundles] = useState<RFQBundle[]>(initialRFQBundles);
  const [selectedRfqIndex, setSelectedRfqIndex] = useState<number>(0);
  const [isSyncingPrices, setIsSyncingPrices] = useState<boolean>(false);
  const [syncSuccessNotification, setSyncSuccessNotification] = useState<string | null>(null);

  // Flatten winning/selected bids for Engine B
  const allSupplierBids = useMemo<SupplierRFQBid[]>(() => {
    return rfqBundles.flatMap((bundle) => bundle.bids);
  }, [rfqBundles]);

  // Phase 4 Rules Engine B State
  const [rulesBConfig, setRulesBConfig] = useState<RulesEngineBConfig>(defaultRulesEngineBConfig);
  const finalCommercialQuote = useMemo<FinalCommercialQuotation>(() => {
    return RulesEngineService.executeRulesEngineB(
      draftQuoteSummary,
      allSupplierBids,
      masterPriceTable,
      rulesBConfig,
      takeoffSession.clientRef || 'Mwani Qatar / MOI Port Security'
    );
  }, [draftQuoteSummary, allSupplierBids, masterPriceTable, rulesBConfig, takeoffSession.clientRef]);

  // Comparative Audit Analysis
  const comparativeAnalysis = useMemo<QuotationComparativeAnalysis>(() => {
    return RulesEngineService.generateComparativeAnalysis(draftQuoteSummary, finalCommercialQuote);
  }, [draftQuoteSummary, finalCommercialQuote]);

  // --- Handlers ---

  // Calculate route distance in meters based on drawing scale (100% W = 80m, 100% H = 50m)
  const calculateMeasuredLength = (points: { x: number; y: number }[]): number => {
    if (points.length < 2) return 0;
    let totalMeters = 0;
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const dxMeters = ((p2.x - p1.x) / 100) * 80;
      const dyMeters = ((p2.y - p1.y) / 100) * 50;
      totalMeters += Math.sqrt(dxMeters * dxMeters + dyMeters * dyMeters);
    }
    return Math.round(totalMeters * 10) / 10;
  };

  // Canvas Click Handler
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const rawX = ((e.clientX - rect.left) / rect.width) * 100;
    const rawY = ((e.clientY - rect.top) / rect.height) * 100;
    if (isNaN(rawX) || isNaN(rawY)) return;
    const clampedX = Math.max(2, Math.min(98, Math.round(rawX)));
    const clampedY = Math.max(4, Math.min(96, Math.round(rawY)));

    if (selectedOverlayTool === 'camera') {
      setPinModalCoordinates({ x: clampedX, y: clampedY });
      setDeviceToPinNotes(`Grid Coordinate (${clampedX}%, ${clampedY}%) Drop`);
    } else if (selectedOverlayTool === 'cable_tray') {
      setActiveMeasurePoints((prev) => [...prev, { x: clampedX, y: clampedY }]);
    }
  };

  // Confirm and Place New Device Pin
  const handleConfirmPinDevice = () => {
    if (!pinModalCoordinates) return;
    const matchedMaster = masterPriceTable.find((m) => m.itemCode === deviceToPinCode);
    if (!matchedMaster) return;

    const newPin: BlueprintPin = {
      id: `pin-${Date.now()}`,
      x: pinModalCoordinates.x,
      y: pinModalCoordinates.y,
      itemCode: matchedMaster.itemCode,
      label: `${matchedMaster.itemCode.split('-')[1] || 'DEV'} (x${deviceToPinQty})`,
      category: matchedMaster.category,
      quantity: deviceToPinQty,
      locationNotes: deviceToPinNotes,
      iconType: matchedMaster.category.includes('Cameras') ? 'camera' : matchedMaster.category.includes('Access') ? 'access' : matchedMaster.category.includes('Racks') ? 'rack' : 'sensor',
      color: matchedMaster.category.includes('Cameras') ? '#6366f1' : matchedMaster.category.includes('Access') ? '#f59e0b' : '#10b981',
    };

    setBlueprintPins((prev) => [...prev, newPin]);

    // Update Takeoff Session Items
    let updatedTakeoff = [...takeoffSession.takeoffItems];
    const existingIndex = updatedTakeoff.findIndex((t) => t.itemCode === matchedMaster.itemCode);
    if (existingIndex >= 0) {
      const existing = updatedTakeoff[existingIndex];
      updatedTakeoff[existingIndex] = {
        ...existing,
        detectedCountOrLength: existing.detectedCountOrLength + deviceToPinQty,
        calculatedQuantity: existing.calculatedQuantity + deviceToPinQty,
        status: 'Modified',
      };
    } else {
      updatedTakeoff.push({
        id: `to-${Date.now()}`,
        drawingRef: takeoffSession.drawingName,
        itemCode: matchedMaster.itemCode,
        description: matchedMaster.description,
        category: matchedMaster.category,
        uom: matchedMaster.uom,
        detectionMethod: 'Takeoff Overlay Tool',
        detectedCountOrLength: deviceToPinQty,
        siteAnomalyAdjustment: 0,
        calculatedQuantity: deviceToPinQty,
        locationNotes: deviceToPinNotes,
        status: 'Verified',
      });
    }

    setTakeoffSession((prev) => ({ ...prev, takeoffItems: updatedTakeoff }));
    const newBOQ = RulesEngineService.generateStructuredBOQFromTakeoff(updatedTakeoff, masterPriceTable);
    setStructuredBOQ(newBOQ);

    setSyncSuccessNotification(`Pinned ${matchedMaster.description} (Qty: ${deviceToPinQty}) at (${pinModalCoordinates.x}%, ${pinModalCoordinates.y}%) & updated BOQ.`);
    setTimeout(() => setSyncSuccessNotification(null), 4000);
    setPinModalCoordinates(null);
  };

  // Finish and Save Route Measurement
  const handleFinishRouteMeasurement = () => {
    if (activeMeasurePoints.length < 2) return;
    const lengthM = calculateMeasuredLength(activeMeasurePoints);
    const matchedMaster = masterPriceTable.find((m) => m.itemCode === activeMeasureCableType);
    if (!matchedMaster) return;

    const newRoute: BlueprintRoute = {
      id: `route-${Date.now()}`,
      name: `${matchedMaster.description.split(' ')[0]} Route (${lengthM}m)`,
      itemCode: matchedMaster.itemCode,
      type: matchedMaster.category,
      points: activeMeasurePoints,
      lengthMeters: lengthM,
      color: activeMeasureCableType.includes('FIBER') ? '#8b5cf6' : activeMeasureCableType.includes('TRAY') ? '#10b981' : activeMeasureCableType.includes('CONDUIT') ? '#f59e0b' : '#3b82f6',
      anomalyBufferPercent: 10,
    };

    setBlueprintRoutes((prev) => [...prev, newRoute]);

    // Update Takeoff Session Items with Linear Meters (+10% buffer)
    const effectiveMeters = Math.round(lengthM * 1.1);
    let updatedTakeoff = [...takeoffSession.takeoffItems];
    const existingIndex = updatedTakeoff.findIndex((t) => t.itemCode === matchedMaster.itemCode);
    if (existingIndex >= 0) {
      const existing = updatedTakeoff[existingIndex];
      updatedTakeoff[existingIndex] = {
        ...existing,
        detectedCountOrLength: existing.detectedCountOrLength + effectiveMeters,
        calculatedQuantity: existing.calculatedQuantity + effectiveMeters,
        status: 'Modified',
      };
    } else {
      updatedTakeoff.push({
        id: `to-${Date.now()}`,
        drawingRef: takeoffSession.drawingName,
        itemCode: matchedMaster.itemCode,
        description: matchedMaster.description,
        category: matchedMaster.category,
        uom: 'Meter',
        detectionMethod: 'Takeoff Overlay Tool',
        detectedCountOrLength: effectiveMeters,
        siteAnomalyAdjustment: Math.round(lengthM * 0.1),
        calculatedQuantity: effectiveMeters,
        locationNotes: 'Measured Corridor Containment',
        status: 'Verified',
      });
    }

    setTakeoffSession((prev) => ({ ...prev, takeoffItems: updatedTakeoff }));
    const newBOQ = RulesEngineService.generateStructuredBOQFromTakeoff(updatedTakeoff, masterPriceTable);
    setStructuredBOQ(newBOQ);

    setActiveMeasurePoints([]);
    setSyncSuccessNotification(`Measured and saved ${lengthM}m (+10% anomaly = ${effectiveMeters}m) of ${matchedMaster.description} to BOQ!`);
    setTimeout(() => setSyncSuccessNotification(null), 4000);
  };

  // Adjust Pin Quantity from Inspector
  const handleUpdatePinQuantity = (pinId: string, delta: number) => {
    const pin = blueprintPins.find((p) => p.id === pinId);
    if (!pin) return;
    const newQty = Math.max(1, pin.quantity + delta);
    const diff = newQty - pin.quantity;
    if (diff === 0) return;

    setBlueprintPins((prev) =>
      prev.map((p) => (p.id === pinId ? { ...p, quantity: newQty, label: `${p.itemCode.split('-')[1] || 'DEV'} (x${newQty})` } : p))
    );

    if (selectedPinForInspect && selectedPinForInspect.id === pinId) {
      setSelectedPinForInspect({ ...selectedPinForInspect, quantity: newQty });
    }

    // Update Takeoff BOQ
    const updatedTakeoff = takeoffSession.takeoffItems.map((item) => {
      if (item.itemCode === pin.itemCode) {
        const nextQty = Math.max(1, item.calculatedQuantity + diff);
        return { ...item, calculatedQuantity: nextQty, detectedCountOrLength: Math.max(1, item.detectedCountOrLength + diff), status: 'Modified' as const };
      }
      return item;
    });

    setTakeoffSession((prev) => ({ ...prev, takeoffItems: updatedTakeoff }));
    setStructuredBOQ(RulesEngineService.generateStructuredBOQFromTakeoff(updatedTakeoff, masterPriceTable));
  };

  // Delete Pin from Blueprint
  const handleDeletePin = (pinId: string) => {
    const pin = blueprintPins.find((p) => p.id === pinId);
    if (!pin) return;

    setBlueprintPins((prev) => prev.filter((p) => p.id !== pinId));
    setSelectedPinForInspect(null);

    // Decrement from takeoff
    const updatedTakeoff = takeoffSession.takeoffItems.map((item) => {
      if (item.itemCode === pin.itemCode) {
        const nextQty = Math.max(0, item.calculatedQuantity - pin.quantity);
        return { ...item, calculatedQuantity: nextQty, detectedCountOrLength: Math.max(0, item.detectedCountOrLength - pin.quantity), status: 'Modified' as const };
      }
      return item;
    }).filter((item) => item.calculatedQuantity > 0);

    setTakeoffSession((prev) => ({ ...prev, takeoffItems: updatedTakeoff }));
    setStructuredBOQ(RulesEngineService.generateStructuredBOQFromTakeoff(updatedTakeoff, masterPriceTable));
    setSyncSuccessNotification(`Removed pinned device ${pin.itemCode} from blueprint.`);
    setTimeout(() => setSyncSuccessNotification(null), 3000);
  };

  // Delete Route from Blueprint
  const handleDeleteRoute = (routeId: string) => {
    const route = blueprintRoutes.find((r) => r.id === routeId);
    if (!route) return;

    setBlueprintRoutes((prev) => prev.filter((r) => r.id !== routeId));
    setSelectedRouteForInspect(null);

    const lengthToRemove = Math.round(route.lengthMeters * 1.1);
    const updatedTakeoff = takeoffSession.takeoffItems.map((item) => {
      if (item.itemCode === route.itemCode) {
        const nextQty = Math.max(0, item.calculatedQuantity - lengthToRemove);
        return { ...item, calculatedQuantity: nextQty, detectedCountOrLength: Math.max(0, item.detectedCountOrLength - lengthToRemove), status: 'Modified' as const };
      }
      return item;
    }).filter((item) => item.calculatedQuantity > 0);

    setTakeoffSession((prev) => ({ ...prev, takeoffItems: updatedTakeoff }));
    setStructuredBOQ(RulesEngineService.generateStructuredBOQFromTakeoff(updatedTakeoff, masterPriceTable));
    setSyncSuccessNotification(`Removed cable route ${route.name} from blueprint.`);
    setTimeout(() => setSyncSuccessNotification(null), 3000);
  };

  // Reset Blueprint
  const handleResetBlueprintCanvas = () => {
    setBlueprintPins(initialBlueprintPins);
    setBlueprintRoutes(initialBlueprintRoutes);
    setActiveMeasurePoints([]);
    setSelectedPinForInspect(null);
    setSelectedRouteForInspect(null);
    setTakeoffSession(initialTakeoffSession);
    setStructuredBOQ(RulesEngineService.generateStructuredBOQFromTakeoff(initialTakeoffSession.takeoffItems, masterPriceTable));
    setSyncSuccessNotification('Reset blueprint pins and cable routes to baseline drawing takeoff.');
    setTimeout(() => setSyncSuccessNotification(null), 3000);
  };

  // Handle Scan Drawing AI Takeoff
  const handleTriggerAIScan = () => {
    setIsScanningDrawing(true);
    setScanMessage('Analyzing DWG Vector Layers and Device Symbol Legends...');

    setTimeout(() => {
      setScanMessage('Extracting linear cable routes & calculating vertical riser drop drops...');
    }, 900);

    setTimeout(() => {
      setIsScanningDrawing(false);
      setScanMessage('AI Takeoff complete! 78 devices and 4,850m containment detected with +10% site anomaly buffer.');
      setTimeout(() => setScanMessage(''), 4000);
    }, 1800);
  };

  // Update Anomaly adjustment for takeoff item
  const handleTakeoffAnomalyChange = (itemId: string, adjustment: number) => {
    const updatedItems = takeoffSession.takeoffItems.map((item) => {
      if (item.id === itemId) {
        const final = Math.max(1, item.detectedCountOrLength + adjustment);
        return {
          ...item,
          siteAnomalyAdjustment: adjustment,
          calculatedQuantity: final,
          status: 'Modified' as const,
        };
      }
      return item;
    });

    setTakeoffSession((prev) => ({
      ...prev,
      takeoffItems: updatedItems,
    }));

    // Re-generate Structured BOQ
    const updatedBOQ = RulesEngineService.generateStructuredBOQFromTakeoff(updatedItems, masterPriceTable);
    setStructuredBOQ(updatedBOQ);
  };

  // 1-Click Synchronize Supplier Bids to Master Price Table
  const handleSyncSupplierBidsToMaster = () => {
    setIsSyncingPrices(true);
    setTimeout(() => {
      const winningBids = allSupplierBids.filter((b) => b.isWinningBid);
      const updatedMaster = RulesEngineService.syncWinningBidsToMasterPriceTable(masterPriceTable, winningBids);
      setMasterPriceTable(updatedMaster);
      setIsSyncingPrices(false);
      setSyncSuccessNotification(`Successfully synchronized ${winningBids.length} market supplier bids into Master Price Table with automatic price change audit versions!`);
      setTimeout(() => setSyncSuccessNotification(null), 5000);
    }, 800);
  };

  // Add new item to Master Price Table
  const handleSaveNewMasterItem = () => {
    if (!newItemData.itemCode || !newItemData.description) return;

    const oldP = Number(newItemData.standardCostWarehouseQAR) || Number(newItemData.oldPrice) || 100;
    const newP = Number(newItemData.lastSupplierPriceQAR) || Number(newItemData.newPrice) || oldP;
    const diff = newP - oldP;
    const pct = oldP > 0 ? (diff / oldP) * 100 : 0;
    const type: 'Decrease' | 'Increase' | 'Unchanged' = diff < 0 ? 'Decrease' : diff > 0 ? 'Increase' : 'Unchanged';
    const code = newItemData.itemCode || newItemData.productCode || `ITEM-${Date.now()}`;
    const name = newItemData.description || newItemData.productName || '';
    const supp = newItemData.preferredSupplier || newItemData.supplier || 'Authorized Distributor';

    const newItem: PriceHistoryRecord = {
      id: `mpt-${Date.now()}`,
      productCode: code,
      itemCode: code,
      productName: name,
      description: name,
      category: (newItemData.category as any) || 'Cameras & VMS',
      uom: (newItemData.uom as any) || 'Pcs',
      supplier: supp,
      preferredSupplier: supp,
      alternativeSuppliers: [],
      oldPrice: oldP,
      newPrice: newP,
      standardCostWarehouseQAR: oldP,
      lastSupplierPriceQAR: newP,
      priceChange: Number(diff.toFixed(2)),
      percentChange: Number(pct.toFixed(1)),
      changeType: type,
      effectiveDate: new Date().toISOString().split('T')[0],
      leadTime: newItemData.leadTime || 'Ex-Stock (1-2 Days)',
      moiApproved: (newItemData.moiApproved as any) || 'Yes',
      minOrderQty: Number(newItemData.minOrderQty) || 1,
      lastUpdatedDate: new Date().toISOString().split('T')[0],
      reason: 'Initial Catalogue Entry',
      notes: 'Added from SCM Pipeline',
      versionHistory: [
        {
          version: 'v1.0',
          effectiveDate: new Date().toISOString().split('T')[0],
          supplier: supp,
          costQAR: newP,
          reason: 'Initial Catalogue Entry',
        },
      ],
    };

    setMasterPriceTable([newItem, ...masterPriceTable]);
    setIsAddItemModalOpen(false);
    setNewItemData({
      category: 'Cameras & VMS',
      uom: 'Pcs',
      standardCostWarehouseQAR: 100,
      lastSupplierPriceQAR: 90,
      preferredSupplier: '',
      moiApproved: 'Yes',
      leadTime: 'Ex-Stock (1-2 Days)',
      minOrderQty: 1,
    });
  };

  // Export to Excel
  const handleExportToExcel = () => {
    const wsData = finalCommercialQuote.items.map((item, index) => ({
      'S.No': index + 1,
      'Item Code': item.itemCode,
      'Description': item.description,
      'Category': item.category,
      'UoM': item.uom,
      'Qty': item.quantity,
      'Draft Unit Rate (QAR)': item.draftUnitRateQAR,
      'Selected Supplier': item.selectedSupplier,
      'Supplier Market Unit Rate (QAR)': item.supplierUnitPriceQAR,
      'Revised Unit Selling Price (QAR)': item.revisedUnitSellingPriceQAR,
      'Total Selling Price (QAR)': item.revisedTotalSellingPriceQAR,
      'Unit Cost Savings (QAR)': item.costSavingsPerUnitQAR,
    }));

    const ws = XLSX.utils.json_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Final Commercial Quote');
    XLSX.writeFile(wb, `${finalCommercialQuote.finalQuoteId}-Commercial-Quotation.xlsx`);
  };

  // Filtered Master Price Items
  const filteredMasterItems = useMemo(() => {
    return masterPriceTable.filter((item) => {
      const cat = item.category || 'Cameras & VMS';
      if (masterCategoryFilter !== 'All' && cat !== masterCategoryFilter) return false;
      if (masterSearch.trim()) {
        const q = masterSearch.toLowerCase();
        const mCode = (item.itemCode || item.productCode || '').toLowerCase().includes(q);
        const mDesc = (item.description || item.productName || '').toLowerCase().includes(q);
        const mSup = (item.preferredSupplier || item.supplier || '').toLowerCase().includes(q);
        return mCode || mDesc || mSup;
      }
      return true;
    });
  }, [masterPriceTable, masterCategoryFilter, masterSearch]);

  const masterCategories = ['All', 'Cables & Containment', 'Controllers & Access', 'Cameras & VMS', 'Panels & Racks', 'Accessories & Hardware', 'Labor & Engineering'];

  return (
    <div className="space-y-6 pb-12">
      {/* 6-PHASE PIPELINE STEP SELECTOR TABS */}
      <div className="bg-white border border-slate-200 rounded-2xl p-2.5 shadow-xs grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {[
          { id: 'phase1_takeoff', num: 'Phase 1', title: 'Drawing Reading', sub: 'CAD/DWG Takeoff & Pins', icon: Compass },
          { id: 'phase2_boq', num: 'Phase 2', title: 'BOQ', sub: 'Security & Audit Catalogue', icon: Database },
          { id: 'phase3_rules_a', num: 'Phase 3', title: 'Draft Quotation', sub: 'Commercial Quote & Markups', icon: Sliders },
          { id: 'phase4_rfq_sync', num: 'Phase 4', title: 'Supplier RFQ & Bids', sub: 'Market Quotes & SCM Bidding', icon: Send },
          { id: 'phase5_rules_b', num: 'Phase 5', title: 'Rules Engine B', sub: 'Final Client Revision', icon: CheckCircle2 },
          { id: 'audit_comparison', num: 'Phase 6', title: 'Audit & Comparison', sub: 'Draft vs Final & P40 Variance', icon: FileText },
        ].map((step) => {
          const isActive = activeStep === step.id;
          const Icon = step.icon;
          return (
            <button
              key={step.id}
              onClick={() => setActiveStep(step.id as PipelineStep)}
              className={`flex flex-col p-3 rounded-xl text-left transition cursor-pointer border ${
                isActive
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs ring-2 ring-indigo-400/20'
                  : 'bg-slate-50/80 hover:bg-slate-100/90 text-slate-700 border-slate-200/80'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded ${isActive ? 'bg-indigo-700/80 text-white' : 'bg-slate-200 text-slate-600'}`}>
                  {step.num}
                </span>
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              </div>
              <span className="text-xs font-black truncate">{step.title}</span>
              <span className={`text-[10px] truncate ${isActive ? 'text-indigo-100' : 'text-slate-400'}`}>
                {step.sub}
              </span>
            </button>
          );
        })}
      </div>

      {/* SUCCESS BANNER NOTIFICATION */}
      {syncSuccessNotification && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-4 rounded-2xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-950">{syncSuccessNotification}</p>
              <p className="text-[11px] text-emerald-700">Master Price Table has recorded all price adjustments with active timestamps and source RFQ tags.</p>
            </div>
          </div>
          <button
            onClick={() => setSyncSuccessNotification(null)}
            className="text-emerald-700 hover:text-emerald-900 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TOAST NOTIFICATION FOR CATALOG ITEMS ADDED TO BOQ */}
      {catalogAddedToast && (
        <div className="bg-indigo-900 text-white px-5 py-3 rounded-2xl shadow-lg flex items-center justify-between gap-4 animate-bounce">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-indigo-700 flex items-center justify-center">
              <Database className="w-4 h-4 text-emerald-400" />
            </div>
            <span className="text-xs font-bold">{catalogAddedToast}</span>
          </div>
          <button
            onClick={() => setActiveStep('phase2_boq')}
            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-[11px] font-black px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1"
          >
            <span>View in BOQ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 1: DRAWING READING (TAKEOFF & AUTO-DETECTION) */}
      {/* ========================================================================= */}
      {activeStep === 'phase1_takeoff' && (
        <div className="space-y-6">
          {/* Takeoff Visual Workspace Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 1
                  </span>
                  <h3 className="text-lg font-black text-slate-900 tracking-tight">
                    Drawing Reading & Structured Takeoff Engine
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Input: <strong>{takeoffSession.drawingName}</strong> ({takeoffSession.drawingType}) | Project: <strong>{takeoffSession.projectRef}</strong> | Scale: <strong>{takeoffSession.scale}</strong>
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".pdf,.dwg,.dxf,.png,.jpg,.jpeg"
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-slate-900 hover:bg-slate-800 text-slate-100 text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer border border-slate-700"
                >
                  <Upload className="w-4 h-4 text-indigo-400" />
                  <span>Upload Drawing / PDF</span>
                </button>

                <button
                  onClick={handleTriggerAIScan}
                  disabled={isScanningDrawing}
                  className="bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className={`w-4 h-4 ${isScanningDrawing ? 'animate-spin' : ''}`} />
                  <span>{isScanningDrawing ? 'AI Scanning Layers...' : 'Auto-Detect Devices & Measurements'}</span>
                </button>

                <button
                  onClick={() => setActiveStep('phase2_boq')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <span>Compile Takeoff & Open Phase 2 (BOQ)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {scanMessage && (
              <div className="bg-indigo-50 border border-indigo-200 text-indigo-900 px-4 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 animate-pulse">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>{scanMessage}</span>
              </div>
            )}



            {/* Interactive 2D/3D Drawing Map Engine */}
            <DrawingMapEngine
              blueprintPins={blueprintPins}
              setBlueprintPins={setBlueprintPins}
              blueprintRoutes={blueprintRoutes}
              setBlueprintRoutes={setBlueprintRoutes}
              takeoffSession={takeoffSession}
              setTakeoffSession={setTakeoffSession}
              isScanningDrawing={isScanningDrawing}
              scanMessage={scanMessage}
              onFileUpload={handleFileUpload}
              fileInputRef={fileInputRef}
              onTriggerAIScan={handleTriggerAIScan}
            />

            {/* Takeoff Table: Showing ONLY Item Code, Category, and Quantity per user instruction */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-900">
                    Calculated Takeoff Quantities
                  </h4>
                  <p className="text-xs text-slate-500">
                    Quantities extracted from AutoCAD/PDF drawing OCR & map placements.
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 text-[11px] font-black uppercase tracking-wider">
                    <tr>
                      <th className="px-4 py-3">Item Code</th>
                      <th className="px-4 py-3">Category</th>
                      <th className="px-4 py-3 text-right">Quantity</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {takeoffSession.takeoffItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50 transition">
                        <td className="px-4 py-3 font-mono font-bold text-indigo-600 whitespace-nowrap">
                          {item.itemCode}
                        </td>
                        <td className="px-4 py-3">
                          <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2.5 py-1 rounded-md">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-2 justify-end">
                            <div className="inline-flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg p-0.5">
                              <button
                                onClick={() => handleTakeoffAnomalyChange(item.id, item.siteAnomalyAdjustment - (item.uom === 'Meter' ? 50 : 1))}
                                className="w-5 h-5 bg-white hover:bg-slate-200 rounded text-xs font-black text-slate-700 flex items-center justify-center cursor-pointer shadow-2xs"
                                title="Decrease quantity"
                              >
                                -
                              </button>
                              <button
                                onClick={() => handleTakeoffAnomalyChange(item.id, item.siteAnomalyAdjustment + (item.uom === 'Meter' ? 50 : 1))}
                                className="w-5 h-5 bg-white hover:bg-slate-200 rounded text-xs font-black text-slate-700 flex items-center justify-center cursor-pointer shadow-2xs"
                                title="Increase quantity"
                              >
                                +
                              </button>
                            </div>
                            <span className="font-black text-slate-900 font-mono text-xs">
                              {item.calculatedQuantity.toLocaleString()} {item.uom}
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Phase 1 Footer Actions */}
              <div className="flex items-center justify-end pt-3 border-t border-slate-100">
                <button
                  onClick={() => setActiveStep('phase2_boq')}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Phase 2: BOQ</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 2: BOQ (BILL OF QUANTITIES & SECURITY AND AUDIT CATALOGUE) */}
      {/* ========================================================================= */}
      {activeStep === 'phase2_boq' && (
        <div className="space-y-6">
          {/* Top BOQ Controls & Actions */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 2
                  </span>
                  <h3 className="text-lg font-black text-slate-900 tracking-tight">
                    BOQ — Bill of Quantities & Security and Audit Catalogue
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Project: <strong>{takeoffSession.projectRef}</strong> | Active Line Items: <strong>{structuredBOQ.length}</strong> | Master Equipment Database: <strong>{fullSecurityCatalog.length} records</strong>
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <input
                  type="file"
                  ref={boqFileInputRef}
                  onChange={handleBOQFileUpload}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                <button
                  onClick={() => boqFileInputRef.current?.click()}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Import External BOQ (Excel)</span>
                </button>

                <button
                  onClick={handleExportToExcel}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export BOQ (.xlsx)</span>
                </button>
              </div>
            </div>

            {boqUploadMessage && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{boqUploadMessage}</span>
              </div>
            )}

            {/* SECURITY AND AUDIT CATALOGUE (100% SAME AS 3RD OPTION IN MENU) */}
            <div className="space-y-4">
              <ProductCatalogView
                catalog={fullSecurityCatalog}
                onUpdateCatalog={onUpdateSecurityCatalog || (() => {})}
                onOpenQuickAdd={onOpenQuickAdd || (() => {})}
                onAddToBOQ={handleAddCatalogItemToBOQ}
                hideDefaultCartButtons={true}
                onCartCountChange={setPhase2CartCount}
                bindTriggers={(triggers) => { phase2TriggersRef.current = triggers; }}
              />
            </div>
          </div>

          {/* Bottom Phase Navigation Buttons */}
          <div className="flex items-center justify-between bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <button
              onClick={() => setActiveStep('phase1_takeoff')}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>← Back to Phase 1: Drawing Reading</span>
            </button>

            <button
              onClick={() => setActiveStep('phase3_rules_a')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <span>Proceed to Phase 3: Quotation</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODAL: ADD CUSTOM LINE ITEM TO BOQ */}
      {isAddCustomBOQModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-black text-slate-900">Add Custom Line Item to BOQ</h3>
              <button onClick={() => setIsAddCustomBOQModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Item Code / Model</label>
                <input
                  type="text"
                  placeholder="e.g. CAM-CUSTOM-01"
                  value={customBOQItem.itemCode}
                  onChange={(e) => setCustomBOQItem({ ...customBOQItem, itemCode: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Description & Specifications</label>
                <input
                  type="text"
                  placeholder="e.g. 8MP IR Turret Camera with 2.8mm Lens"
                  value={customBOQItem.description}
                  onChange={(e) => setCustomBOQItem({ ...customBOQItem, description: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={customBOQItem.category}
                    onChange={(e) => setCustomBOQItem({ ...customBOQItem, category: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  >
                    {securityCategories.filter(c => c !== 'All').map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">UOM</label>
                  <select
                    value={customBOQItem.uom}
                    onChange={(e) => setCustomBOQItem({ ...customBOQItem, uom: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  >
                    <option value="Pcs">Pcs</option>
                    <option value="Meter">Meter</option>
                    <option value="Set">Set</option>
                    <option value="Lot">Lot</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={customBOQItem.quantity}
                    onChange={(e) => setCustomBOQItem({ ...customBOQItem, quantity: parseInt(e.target.value) || 1 })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Unit Cost Base (QAR)</label>
                  <input
                    type="number"
                    min="0"
                    value={customBOQItem.unitCostBaseQAR}
                    onChange={(e) => setCustomBOQItem({ ...customBOQItem, unitCostBaseQAR: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t">
              <button
                onClick={() => setIsAddCustomBOQModalOpen(false)}
                className="bg-slate-100 text-slate-700 text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomBOQItem}
                className="bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
              >
                Add to BOQ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 3: BOQ ➔ INITIAL QUOTATION (RULES ENGINE ONE) */}
      {/* ========================================================================= */}
      {activeStep === 'phase3_rules_a' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left Column: Rules Form A Configuration Settings */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 lg:col-span-1">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 3
                  </span>
                  <h3 className="text-base font-black text-slate-900">
                    Quotation
                  </h3>
                </div>
              </div>

              {/* Country, City, Project & Quotation Revisions Control Bar */}
              <div className="space-y-4 pt-2 border-t border-slate-100">
                <div>
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase block mb-1">Country</label>
                  <select
                    value={selectedCountry}
                    onChange={(e) => setSelectedCountry(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Qatar">Qatar (Doha)</option>
                    <option value="UAE">UAE (Dubai/Abu Dhabi)</option>
                    <option value="Saudi Arabia">Saudi Arabia (Riyadh/Jeddah)</option>
                    <option value="Oman">Oman (Muscat)</option>
                    <option value="Kuwait">Kuwait (Kuwait City)</option>
                    <option value="Bahrain">Bahrain (Manama)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase block mb-1">City / Region</label>
                  <select
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Doha">Doha</option>
                    <option value="Lusail">Lusail</option>
                    <option value="Al Rayyan">Al Rayyan</option>
                    <option value="Al Wakrah">Al Wakrah</option>
                    <option value="Al Khor">Al Khor</option>
                    <option value="Umm Salal">Umm Salal</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase block mb-1">Quotation Revision</label>
                  <select
                    value={quotationRevision}
                    onChange={(e) => setQuotationRevision(e.target.value)}
                    className="w-full bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-black rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Rev 1">Rev 1 (Draft)</option>
                    <option value="Rev 2">Rev 2 (Value Eng.)</option>
                    <option value="Rev 3">Rev 3 (Final Negotiation)</option>
                    <option value="Rev 4">Rev 4 (Contract Award)</option>
                  </select>
                </div>

                <button
                  onClick={handleUpdateItemPricesWithLatest}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-2 cursor-pointer border border-slate-700 mt-2"
                >
                  <RefreshCw className="w-4 h-4 text-emerald-400" />
                  <span>Update Item Prices with Latest Database ({quotationRevision})</span>
                </button>
              </div>

              {/* Pricing Rules Controls (Left Panel) */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 mt-4 space-y-3">
                <h4 className="text-[11px] font-black text-slate-800 mb-2 uppercase tracking-wider">Pricing Rules Applied</h4>
                <div className="space-y-3">
                  {/* Material Markup */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Material Markup: {rulesAConfig.materialMarkupPercent}%</span>
                    </div>
                    <input type="range" min="0" max="40" step="0.5" value={rulesAConfig.materialMarkupPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, materialMarkupPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-purple-600 cursor-pointer" />
                  </div>
                  {/* Direct Labor */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Direct Labor: {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' ? `${rulesAConfig.directLaborPercent}% of Mat.` : `${rulesAConfig.estimatedLaborHours} hrs at ${rulesAConfig.directLaborHourlyRateQAR} QAR/hr`}</span>
                    </div>
                    {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' && (
                      <input type="range" min="5" max="30" step="0.5" value={rulesAConfig.directLaborPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, directLaborPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-emerald-600 cursor-pointer" />
                    )}
                  </div>
                  {/* Admin & Site Overheads */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Admin & Site Overheads: {rulesAConfig.overheadsPercent}%</span>
                    </div>
                    <input type="range" min="2" max="20" step="0.5" value={rulesAConfig.overheadsPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, overheadsPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-amber-700 cursor-pointer" />
                  </div>
                  {/* Wastage & Scrap */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Wastage & Scrap: {rulesAConfig.wastageScrapPercent}%</span>
                    </div>
                    <input type="range" min="0" max="15" step="0.5" value={rulesAConfig.wastageScrapPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, wastageScrapPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-yellow-400 cursor-pointer" />
                  </div>
                  {/* Transport & Logistics */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Transport & Logistics: {rulesAConfig.logisticsTransportPercent}%</span>
                    </div>
                    <input type="range" min="1" max="12" step="0.5" value={rulesAConfig.logisticsTransportPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, logisticsTransportPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-pink-600 cursor-pointer" />
                  </div>
                  {/* Insurance & Bonds */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Insurance & Bonds: {rulesAConfig.insuranceAndBondsPercent}%</span>
                    </div>
                    <input type="range" min="0" max="10" step="0.5" value={rulesAConfig.insuranceAndBondsPercent} onChange={(e) => setRulesAConfig({ ...rulesAConfig, insuranceAndBondsPercent: parseFloat(e.target.value) })} className="w-full h-1.5 accent-yellow-200 cursor-pointer" />
                  </div>
                  {/* Profit Margin (P1) */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-[10px] font-medium text-slate-600 min-w-[140px]">
                      <span>• Profit Margin (P1): {rulesAConfig.standardProfitMarginP1}%</span>
                    </div>
                    <input type="range" min="5" max="40" step="0.5" value={rulesAConfig.standardProfitMarginP1} onChange={(e) => setRulesAConfig({ ...rulesAConfig, standardProfitMarginP1: parseFloat(e.target.value) })} className="w-full h-1.5 accent-purple-600 cursor-pointer" />
                  </div>
                </div>
              </div>
            </div>
            {/* Right Column: Rules Options & Stats */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 lg:col-span-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-black text-slate-900 tracking-tight">
                    Commercial Quotation Adjustments
                  </h3>
                  <p className="text-xs text-slate-500">
                    Quote Reference: <strong>{draftQuoteSummary.quoteId}</strong> | Calculated Gross Margin: <strong>{draftQuoteSummary.grossMarginPercent}%</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap shrink-0">
                  <button
                    onClick={() => setIsPhase3OfficialQuoteModalOpen(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                  >
                    <FileText className="w-4 h-4 text-indigo-200" />
                    <span>Official Quotation Download</span>
                  </button>
                  <button
                    onClick={handleExportDraftQuoteToExcel}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                    title="Export Draft Commercial Quotation to Excel (.xlsx)"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Excel</span>
                  </button>
                </div>
              </div>

              {/* Rules Sliders Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {/* Slider 1: Material Markup */}
                <div className="space-y-1 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between text-[11px] font-bold text-slate-800">
                    <span>Material Markup</span>
                    <span className="text-indigo-600 font-black">{rulesAConfig.materialMarkupPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="40"
                    step="0.5"
                    value={rulesAConfig.materialMarkupPercent}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, materialMarkupPercent: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>

                {/* Overheads Factor */}
                <div className="space-y-1 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between text-[11px] font-bold text-slate-800">
                    <span>Admin & Site Overheads</span>
                    <span className="text-indigo-600 font-black">{rulesAConfig.overheadsPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="20"
                    step="0.5"
                    value={rulesAConfig.overheadsPercent}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, overheadsPercent: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>

                {/* Wastage / Scrap */}
                <div className="space-y-1 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between text-[11px] font-bold text-slate-800">
                    <span>Wastage & Scrap Factor</span>
                    <span className="text-indigo-600 font-black">{rulesAConfig.wastageScrapPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="15"
                    step="0.5"
                    value={rulesAConfig.wastageScrapPercent}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, wastageScrapPercent: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>

                {/* Transport / Logistics */}
                <div className="space-y-1 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between text-[11px] font-bold text-slate-800">
                    <span>Transport & Logistics</span>
                    <span className="text-indigo-600 font-black">{rulesAConfig.logisticsTransportPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="12"
                    step="0.5"
                    value={rulesAConfig.logisticsTransportPercent}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, logisticsTransportPercent: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>

                {/* Insurance & Performance Bonds */}
                <div className="space-y-1 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between text-[11px] font-bold text-slate-800">
                    <span>Insurance & Bonds</span>
                    <span className="text-indigo-600 font-black">{rulesAConfig.insuranceAndBondsPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="0.5"
                    value={rulesAConfig.insuranceAndBondsPercent}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, insuranceAndBondsPercent: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>

                {/* Standard Profit Margin P1 */}
                <div className="space-y-1 p-2 bg-indigo-50/80 rounded-xl border border-indigo-200">
                  <div className="flex justify-between text-[11px] font-bold text-indigo-950">
                    <span>Standard Profit Margin (P1)</span>
                    <span className="text-indigo-700 font-black">{rulesAConfig.standardProfitMarginP1}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="40"
                    step="0.5"
                    value={rulesAConfig.standardProfitMarginP1}
                    onChange={(e) => setRulesAConfig({ ...rulesAConfig, standardProfitMarginP1: parseFloat(e.target.value) })}
                    className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                  />
                </div>
              </div>

              {/* Custom Rules Section */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 mt-3">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[11px] font-bold text-slate-800">Custom Pricing Rules</h4>
                  {!isAddingRule && (
                    <button onClick={() => setIsAddingRule(true)} className="text-[10px] bg-white border border-slate-200 text-indigo-600 px-2 py-1 rounded-md font-bold hover:bg-slate-50 flex items-center gap-1">
                      <Plus className="w-3 h-3" /> Add Rule
                    </button>
                  )}
                </div>
                
                {isAddingRule && (
                  <div className="bg-white border border-indigo-100 rounded-lg p-2.5 mb-3 flex flex-wrap gap-2 items-end">
                    <div className="flex-1 min-w-[120px]">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Rule Name</label>
                      <input type="text" value={newRule.name} onChange={(e) => setNewRule({...newRule, name: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1" placeholder="e.g. VIP Discount" />
                    </div>
                    <div className="w-20">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Age/Value</label>
                      <input type="text" value={newRule.age} onChange={(e) => setNewRule({...newRule, age: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1" placeholder="e.g. 5" />
                    </div>
                    <div className="w-28">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Scope</label>
                      <select value={newRule.scope} onChange={(e) => setNewRule({...newRule, scope: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1 bg-white">
                        <option value="Overall item">Overall item</option>
                        <option value="Brand-wise">Brand-wise</option>
                        <option value="Date-wise">Date-wise</option>
                      </select>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => {
                        if (newRule.name) {
                          setCustomRules([...customRules, { ...newRule, id: Date.now().toString() }]);
                          setNewRule({ name: '', age: '', scope: 'Overall item' });
                          setIsAddingRule(false);
                        }
                      }} className="bg-indigo-600 text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-indigo-700">Add</button>
                      <button onClick={() => setIsAddingRule(false)} className="bg-slate-100 text-slate-600 text-[10px] font-bold px-3 py-1.5 rounded hover:bg-slate-200">Cancel</button>
                    </div>
                  </div>
                )}

                {customRules.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {customRules.map(rule => (
                      <div key={rule.id} className="bg-white border border-slate-200 rounded-md px-2 py-1 flex items-center gap-2">
                        <div className="text-[10px]">
                          <span className="font-bold text-slate-700">{rule.name}</span>
                          <span className="text-slate-400 mx-1">|</span>
                          <span className="text-indigo-600 font-medium">Age: {rule.age}</span>
                          <span className="text-slate-400 mx-1">|</span>
                          <span className="text-slate-500">{rule.scope}</span>
                        </div>
                        <button onClick={() => setCustomRules(customRules.filter(r => r.id !== rule.id))} className="text-slate-400 hover:text-red-500">
                          &times;
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-400 italic">No custom rules applied.</p>
                )}
              </div>

              {/* Direct Labor Mode */}
              <div className="space-y-1 p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex justify-between text-[11px] font-bold text-slate-800">
                  <span>Direct Labor Rate</span>
                  <span className="text-indigo-600 font-black">
                    {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' ? `${rulesAConfig.directLaborPercent}% of Mat.` : `${rulesAConfig.estimatedLaborHours} hrs @ ${rulesAConfig.directLaborHourlyRateQAR} QAR`}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs items-center pt-0.5">
                  <div className="flex gap-1.5 col-span-1 sm:col-span-2">
                    <button
                      onClick={() => setRulesAConfig({ ...rulesAConfig, directLaborRateMode: 'PercentageOfMaterial' })}
                      className={`flex-1 py-1 px-2 rounded-lg font-bold transition cursor-pointer text-center text-[11px] ${
                        rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      % of Material
                    </button>
                    <button
                      onClick={() => setRulesAConfig({ ...rulesAConfig, directLaborRateMode: 'FixedHourly' })}
                      className={`flex-1 py-1 px-2 rounded-lg font-bold transition cursor-pointer text-center text-[11px] ${
                        rulesAConfig.directLaborRateMode === 'FixedHourly' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      Hourly Rate
                    </button>
                  </div>
                  <div className="col-span-1 sm:col-span-2">
                    {rulesAConfig.directLaborRateMode === 'PercentageOfMaterial' ? (
                      <input
                        type="range"
                        min="5"
                        max="30"
                        step="0.5"
                        value={rulesAConfig.directLaborPercent}
                        onChange={(e) => setRulesAConfig({ ...rulesAConfig, directLaborPercent: parseFloat(e.target.value) })}
                        className="w-full h-1.5 accent-indigo-600 cursor-pointer"
                      />
                    ) : (
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[9px] text-slate-500 font-bold">Hours</label>
                          <input
                            type="number"
                            value={rulesAConfig.estimatedLaborHours}
                            onChange={(e) => setRulesAConfig({ ...rulesAConfig, estimatedLaborHours: parseInt(e.target.value) || 0 })}
                            className="w-full px-2 py-0.5 border rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] text-slate-500 font-bold">QAR / Hour</label>
                          <input
                            type="number"
                            value={rulesAConfig.directLaborHourlyRateQAR}
                            onChange={(e) => setRulesAConfig({ ...rulesAConfig, directLaborHourlyRateQAR: parseFloat(e.target.value) || 0 })}
                            className="w-full px-2 py-0.5 border rounded text-xs"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Key Cost Breakdown Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold uppercase text-slate-500 block leading-tight">Raw Material Base</span>
                  <p className="text-sm font-black text-slate-900 mt-0.5 leading-tight">
                    QAR {draftQuoteSummary.rawMaterialCostQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[9px] text-slate-400 block mt-0.5 leading-tight">+ QAR {draftQuoteSummary.wastageCostQAR.toFixed(0)} Wastage</span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold uppercase text-slate-500 block leading-tight">Direct Labor Cost</span>
                  <p className="text-sm font-black text-indigo-700 mt-0.5 leading-tight">
                    QAR {draftQuoteSummary.directLaborCostQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[9px] text-slate-400 block mt-0.5 leading-tight">Installation & Commissioning</span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold uppercase text-slate-500 block leading-tight">Overheads & Logistics</span>
                  <p className="text-sm font-black text-slate-900 mt-0.5 leading-tight">
                    QAR {(draftQuoteSummary.overheadsCostQAR + draftQuoteSummary.transportLogisticsCostQAR).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[9px] text-slate-400 block mt-0.5 leading-tight">+ Insurance QAR {draftQuoteSummary.insuranceBondsCostQAR.toFixed(0)}</span>
                </div>

                <div className="bg-indigo-900 text-white border border-indigo-700 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold uppercase text-indigo-200 block leading-tight">Total Quotation</span>
                  <p className="text-sm font-black text-white mt-0.5 leading-tight">
                    QAR {draftQuoteSummary.totalDraftQuotationQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[9px] text-emerald-300 font-bold block mt-0.5 leading-tight">Includes P1 Margin: QAR {draftQuoteSummary.standardProfitP1QAR.toFixed(0)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Itemized Draft Quote Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl bg-white shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-100 text-[11px] font-black uppercase">
                <tr>
                  <th className="px-3.5 py-3">S/N</th>
                  <th className="px-3.5 py-3">Item Code</th>
                  <th className="px-3.5 py-3 text-center">Picture</th>
                  <th className="px-3.5 py-3">Name (Model/Brand)</th>
                  <th className="px-3.5 py-3">Description</th>
                  <th className="px-3.5 py-3 text-center">Qty</th>
                  <th className="px-3.5 py-3 text-right">Base Price (QAR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {draftQuoteSummary.items.map((item, index) => {
                  const catItem = fullSecurityCatalog.find(c => c.id === item.itemCode || c.model === item.itemCode || c.brand === item.itemCode);
                  return (
                    <tr key={item.itemCode} className="hover:bg-slate-50">
                      <td className="px-3.5 py-2.5 font-bold text-slate-500">{index + 1}</td>
                      <td className="px-3.5 py-2.5 font-mono font-bold text-indigo-600">{item.itemCode}</td>
                      <td className="px-3.5 py-2.5 text-center">
                        <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center mx-auto text-slate-400">
                          <ImageIcon className="w-3.5 h-3.5" />
                        </div>
                      </td>
                      <td className="px-3.5 py-2.5 font-bold text-slate-800">{catItem ? `${catItem.model} / ${catItem.brand}` : '-'}</td>
                      <td className="px-3.5 py-2.5 text-slate-800 font-medium max-w-xs">{item.description}</td>
                      <td className="px-3.5 py-2.5 text-center font-bold">{item.quantity} {item.uom}</td>
                      <td className="px-3.5 py-2.5 text-right font-medium text-slate-600">QAR {item.baseUnitCostQAR.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Bottom Nav for Rules Engine One */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => setActiveStep('phase2_boq')}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>← Back to Phase 2: BOQ</span>
            </button>

            <button
              onClick={() => setActiveStep('phase4_rfq_sync')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <span>Proceed to Phase 4: Supplier RFQ & Bids</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 4: SUPPLIER RFQ & LATEST PRICE SYNCHRONIZATION */}
      {/* ========================================================================= */}
      {activeStep === 'phase4_rfq_sync' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 4
                  </span>
                  <h3 className="text-lg font-black text-slate-900 tracking-tight">
                    Supplier RFQ & Live Market Quotation Synchronization
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Automated RFQ bundles dispatched to pre-mapped suppliers with live bid comparison and 1-click synchronization to the Master Price Table.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={handleSyncSupplierBidsToMaster}
                  disabled={isSyncingPrices}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncingPrices ? 'animate-spin' : ''}`} />
                  <span>{isSyncingPrices ? 'Syncing with Master Table...' : 'Sync Winning Bids to Master Table'}</span>
                </button>

                <button
                  onClick={() => setActiveStep('phase5_rules_b')}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Phase 5: Rules Engine B</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* RFQ Bundles Tab Selector */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {rfqBundles.map((bundle, idx) => (
                <button
                  key={bundle.rfqId}
                  onClick={() => setSelectedRfqIndex(idx)}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-bold text-left transition cursor-pointer border shrink-0 ${
                    selectedRfqIndex === idx
                      ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                      : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Send className="w-3.5 h-3.5" />
                    <span>{bundle.title}</span>
                  </div>
                  <span className="text-[10px] block opacity-70 mt-0.5">
                    {bundle.rfqNumber} | {bundle.bids.length} Bids Returned
                  </span>
                </button>
              ))}
            </div>

            {/* Active RFQ Details & Supplier Bids Table */}
            {rfqBundles[selectedRfqIndex] && (
              <div className="space-y-4">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col sm:flex-row justify-between gap-3 text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{rfqBundles[selectedRfqIndex].title}</span>
                    <span className="text-slate-500">Dispatched To: {rfqBundles[selectedRfqIndex].targetSuppliers.join(', ')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full text-[10px]">
                      Status: {rfqBundles[selectedRfqIndex].status}
                    </span>
                  </div>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-slate-100 text-[11px] font-black uppercase">
                      <tr>
                        <th className="px-3.5 py-3">Item Code</th>
                        <th className="px-3.5 py-3">Supplier Name</th>
                        <th className="px-3.5 py-3 text-right">Standard Cost (QAR)</th>
                        <th className="px-3.5 py-3 text-right">Quoted Bid (QAR)</th>
                        <th className="px-3.5 py-3 text-center">Variance Alert</th>
                        <th className="px-3.5 py-3">Lead Time & Terms</th>
                        <th className="px-3.5 py-3 text-center">Compliance</th>
                        <th className="px-3.5 py-3 text-center">Selection Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rfqBundles[selectedRfqIndex].bids.map((bid) => {
                        const standardItem = masterPriceTable.find((m) => (m.itemCode === bid.itemCode) || (m.productCode === bid.itemCode));
                        const stdCost = standardItem ? Number(standardItem.standardCostWarehouseQAR ?? standardItem.oldPrice ?? 100) : 100;
                        const isDecrease = bid.varianceVsStandardCostQAR < 0;

                        return (
                          <tr key={bid.bidId} className={`hover:bg-slate-50 ${bid.isWinningBid ? 'bg-emerald-50/30' : ''}`}>
                            <td className="px-3.5 py-3 font-mono font-bold text-indigo-600 whitespace-nowrap">
                              {bid.itemCode}
                            </td>
                            <td className="px-3.5 py-3 font-bold text-slate-800">
                              {bid.supplierName}
                            </td>
                            <td className="px-3.5 py-3 text-right font-medium text-slate-500">
                              QAR {stdCost.toFixed(2)}
                            </td>
                            <td className="px-3.5 py-3 text-right font-black text-slate-900">
                              QAR {bid.quotedUnitPriceQAR.toFixed(2)}
                            </td>
                            <td className="px-3.5 py-3 text-center">
                              <span
                                className={`text-[10px] font-black px-2.5 py-1 rounded-full inline-flex items-center gap-1 ${
                                  isDecrease
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                    : 'bg-rose-100 text-rose-800 border border-rose-300'
                                }`}
                              >
                                {isDecrease ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                                {bid.varianceVsStandardCostPercent.toFixed(1)}% ({bid.varianceVsStandardCostQAR.toFixed(2)} QAR)
                              </span>
                            </td>
                            <td className="px-3.5 py-3 text-slate-600 text-[11px]">
                              <span>{bid.deliveryLeadTime}</span>
                              <span className="block text-[10px] text-slate-400">{bid.paymentTerms} | {bid.warrantyPeriod}</span>
                            </td>
                            <td className="px-3.5 py-3 text-center">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                bid.complianceStatus === 'Fully Compliant' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}>
                                {bid.complianceStatus}
                              </span>
                            </td>
                            <td className="px-3.5 py-3 text-center">
                              {bid.isWinningBid ? (
                                <span className="bg-emerald-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full shadow-2xs inline-flex items-center gap-1">
                                  <Award className="w-3 h-3" />
                                  Lowest / Best Bid
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400 font-medium">Alternative Bid</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Bottom Nav for Supplier RFQ */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <button
                    onClick={() => setActiveStep('phase3_rules_a')}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>← Back to Phase 3: Quotation</span>
                  </button>

                  <button
                    onClick={() => setActiveStep('phase5_rules_b')}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                  >
                    <span>Proceed to Phase 5: Rules Engine B</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 5: QUOTATION ➔ FINAL REVISION (RULES ENGINE B) */}
      {/* ========================================================================= */}
      {activeStep === 'phase5_rules_b' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Rules Form B Configuration */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5 lg:col-span-1">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 5
                  </span>
                  <h3 className="text-base font-black text-slate-900">
                    Rules Engine B (Revision & Optimization)
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Adjust supplier selection logic, volume tiered discounts, competitive deductions, urgency surcharges, and FX buffers.
                </p>
              </div>

              {/* 1. Supplier Selection Logic */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <label className="text-xs font-bold text-slate-800 block">Supplier Selection Logic</label>
                <select
                  value={rulesBConfig.supplierSelectionLogic}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, supplierSelectionLogic: e.target.value as any })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                >
                  <option value="LowestCost">Lowest Cost (Maximum Profit Margin)</option>
                  <option value="MostReliable">Most Reliable (100% MOI & Technical Compliance)</option>
                  <option value="Balanced">Balanced Price & Delivery Lead Time</option>
                  <option value="PreferredSupplier">Strict Preferred Authorized Distributor</option>
                </select>
              </div>

              {/* 2. Competitive Adjustment Slider */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex justify-between text-xs font-bold text-slate-800">
                  <span>Competitive Price Reduction</span>
                  <span className="text-rose-600 font-black">{rulesBConfig.competitiveAdjustmentPercent}%</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="0"
                  step="0.5"
                  value={rulesBConfig.competitiveAdjustmentPercent}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, competitiveAdjustmentPercent: parseFloat(e.target.value) })}
                  className="w-full accent-rose-600 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">Strategic tender discount applied to beat competing market bids</span>
              </div>

              {/* 3. Urgency / Emergency Fast-Track Surcharge */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex justify-between text-xs font-bold text-slate-800">
                  <span>Urgency / Fast-Track Premium</span>
                  <span className="text-amber-600 font-black">+{rulesBConfig.urgencyPremiumPercent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="15"
                  step="0.5"
                  value={rulesBConfig.urgencyPremiumPercent}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, urgencyPremiumPercent: parseFloat(e.target.value) })}
                  className="w-full accent-amber-600 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">Applied if project completion schedule is under 3 weeks</span>
              </div>

              {/* 4. Exchange Rate (FX) Buffer */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex justify-between text-xs font-bold text-slate-800">
                  <span>Exchange Rate (FX) Buffering</span>
                  <span className="text-indigo-600 font-black">+{rulesBConfig.exchangeRateBufferPercent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="5"
                  step="0.5"
                  value={rulesBConfig.exchangeRateBufferPercent}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, exchangeRateBufferPercent: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">Protection against USD / EUR / GBP import currency swings</span>
              </div>

              {/* 5. Payment Terms Modifier */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <label className="text-xs font-bold text-slate-800 block">Client Payment Terms</label>
                <select
                  value={rulesBConfig.paymentTermsMode}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, paymentTermsMode: e.target.value as any })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                >
                  <option value="CashInAdvance">100% Cash / Advance Payment (-2.5% Cash Discount)</option>
                  <option value="Standard30PDC">Standard 30 Days PDC (0.0% Adjustment)</option>
                  <option value="ExtendedCredit60PDC">Extended 60 Days Credit (+2.0% Financing Fee)</option>
                  <option value="LC90Days">Letter of Credit 90 Days (+4.0% Bank / LC Buffer)</option>
                </select>
              </div>

              {/* 6. Final Rounding Rule */}
              <div className="space-y-1.5 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <label className="text-xs font-bold text-slate-800 block">Final Rounding Rule</label>
                <select
                  value={rulesBConfig.finalRoundingRule}
                  onChange={(e) => setRulesBConfig({ ...rulesBConfig, finalRoundingRule: e.target.value as any })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                >
                  <option value="Nearest10">Round to Nearest QAR 10</option>
                  <option value="Nearest50">Round to Nearest QAR 50</option>
                  <option value="Nearest100">Round to Nearest QAR 100</option>
                  <option value="Exact">Exact Mathematical Cents</option>
                </select>
              </div>
            </div>

            {/* Right Column: Final Optimized Commercial Quotation */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-6 lg:col-span-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-black text-slate-900 tracking-tight">
                    Final Commercial Quotation (Rules Engine B Output)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Project: <strong>{finalCommercialQuote.projectName}</strong> | Client: <strong>{finalCommercialQuote.clientName}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handleExportToExcel}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Excel</span>
                  </button>

                  <button
                    onClick={() => setActiveStep('audit_comparison')}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Scale className="w-3.5 h-3.5" />
                    <span>View Full Audit Comparison</span>
                  </button>
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5">
                  <span className="text-[10px] font-bold uppercase text-slate-500">Market-Sourced Base</span>
                  <p className="text-base font-black text-slate-900 mt-1">
                    QAR {finalCommercialQuote.marketSourcedBaseCostQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[10px] text-emerald-600 font-bold">
                    Saved QAR {finalCommercialQuote.supplierNegotiatedSavingsQAR.toFixed(0)} vs Warehouse
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5">
                  <span className="text-[10px] font-bold uppercase text-slate-500">Net Profit Value</span>
                  <p className="text-base font-black text-emerald-600 mt-1">
                    QAR {finalCommercialQuote.netProfitQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[10px] text-slate-400">Net Margin: {finalCommercialQuote.netProfitMarginPercent}%</span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5">
                  <span className="text-[10px] font-bold uppercase text-slate-500">Approval State</span>
                  <p className="text-xs font-black text-slate-900 mt-1.5 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    {finalCommercialQuote.approvalStatus}
                  </p>
                  <span className="text-[10px] text-slate-400">Threshold: QAR 250k</span>
                </div>

                <div className="bg-emerald-600 text-white rounded-2xl p-3.5 shadow-md">
                  <span className="text-[10px] font-bold uppercase text-emerald-100">Final Revised Quotation</span>
                  <p className="text-lg font-black text-white mt-1">
                    QAR {finalCommercialQuote.finalQuotationTotalQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className="text-[10px] text-emerald-200">
                    Draft was: QAR {finalCommercialQuote.draftQuoteTotalQAR.toFixed(0)}
                  </span>
                </div>
              </div>

              {/* Items Breakdown Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-slate-100 text-[11px] font-black uppercase">
                    <tr>
                      <th className="px-3.5 py-3">Item Code</th>
                      <th className="px-3.5 py-3">Selected Supplier</th>
                      <th className="px-3.5 py-3 text-center">Qty</th>
                      <th className="px-3.5 py-3 text-right">Supplier Market Rate</th>
                      <th className="px-3.5 py-3 text-right">Draft Selling</th>
                      <th className="px-3.5 py-3 text-right">Revised Final Rate</th>
                      <th className="px-3.5 py-3 text-right">Total (QAR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {finalCommercialQuote.items.map((item) => (
                      <tr key={item.itemCode} className="hover:bg-slate-50">
                        <td className="px-3.5 py-2.5 font-mono font-bold text-indigo-600">{item.itemCode}</td>
                        <td className="px-3.5 py-2.5 text-slate-800 font-bold">{item.selectedSupplier}</td>
                        <td className="px-3.5 py-2.5 text-center font-bold">{item.quantity} {item.uom}</td>
                        <td className="px-3.5 py-2.5 text-right font-medium text-emerald-600">QAR {item.supplierUnitPriceQAR.toFixed(2)}</td>
                        <td className="px-3.5 py-2.5 text-right text-slate-400 line-through">QAR {item.draftUnitRateQAR.toFixed(2)}</td>
                        <td className="px-3.5 py-2.5 text-right font-black text-indigo-700">QAR {item.revisedUnitSellingPriceQAR.toFixed(2)}</td>
                        <td className="px-3.5 py-2.5 text-right font-black text-slate-900">QAR {item.revisedTotalSellingPriceQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Bottom Nav for Rules Engine B */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <button
                  onClick={() => setActiveStep('phase4_rfq_sync')}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Back to Phase 4: Supplier RFQ & Bids</span>
                </button>

                <button
                  onClick={() => setActiveStep('audit_comparison')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Phase 6: Audit & Comparison</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PHASE 6: AUDIT & COMPARATIVE ANALYSIS (DRAFT VS FINAL COMMERCIAL QUOTE) */}
      {/* ========================================================================= */}
      {activeStep === 'audit_comparison' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded">
                    Phase 6
                  </span>
                  <h3 className="text-lg font-black text-slate-900 tracking-tight">
                    End-to-End Pipeline Audit: Rules Engine One vs Rules Engine B
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Full traceability and cost reduction comparison from Initial Drawing Reading & BOQ to Market-Negotiated Final Commercial Quote.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportToExcel}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Official Proposal (Excel)</span>
                </button>
              </div>
            </div>

            {/* Side-by-Side Comparison KPI Metric Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Phase 3: Rules Engine One Quote</span>
                <p className="text-2xl font-black text-slate-900">
                  QAR {comparativeAnalysis.draftQuote.totalDraftQuotationQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <div className="text-xs text-slate-600 space-y-0.5">
                  <p>Raw Material Cost: QAR {comparativeAnalysis.draftQuote.rawMaterialCostQAR.toLocaleString()}</p>
                  <p>Standard P1 Margin: {rulesAConfig.standardProfitMarginP1}%</p>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 space-y-2">
                <span className="text-xs font-bold text-emerald-800 uppercase">Phase 5: Rules Engine B Final Quote</span>
                <p className="text-2xl font-black text-emerald-700">
                  QAR {comparativeAnalysis.finalQuote.finalQuotationTotalQAR.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <div className="text-xs text-emerald-800 space-y-0.5">
                  <p>Market Cost Basis: QAR {comparativeAnalysis.finalQuote.marketSourcedBaseCostQAR.toLocaleString()}</p>
                  <p>Net Profit Margin: {comparativeAnalysis.finalQuote.netProfitMarginPercent}%</p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl p-5 space-y-2 shadow-sm">
                <span className="text-xs font-bold text-indigo-300 uppercase">Commercial Tender Advantage</span>
                <p className="text-2xl font-black text-white">
                  {comparativeAnalysis.clientPriceAdvantagePercent > 0 ? `-${comparativeAnalysis.clientPriceAdvantagePercent}%` : '+0.0%'}
                </p>
                <div className="text-xs text-indigo-200 space-y-0.5">
                  <p>Client Price Saving: QAR {Math.abs(comparativeAnalysis.totalSellingPriceDifferenceQAR).toLocaleString()}</p>
                  <p className="font-bold text-emerald-400">Rating: {comparativeAnalysis.competitivenessRating}</p>
                </div>
              </div>
            </div>

            {/* Audit Breakdown Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-2xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-100 text-[11px] font-black uppercase">
                  <tr>
                    <th className="px-3.5 py-3">Pipeline Stage</th>
                    <th className="px-3.5 py-3">Processing Engine</th>
                    <th className="px-3.5 py-3">Key Parameters & Factors</th>
                    <th className="px-3.5 py-3 text-right">Material Cost Basis</th>
                    <th className="px-3.5 py-3 text-right">Commercial Quote (QAR)</th>
                    <th className="px-3.5 py-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="px-3.5 py-3 font-bold text-slate-800">1. Drawing Reading</td>
                    <td className="px-3.5 py-3 text-slate-600">CAD / DWG Vector Scanner & AI Take-off</td>
                    <td className="px-3.5 py-3 text-slate-500">78 Devices + 4,850m Traces (+10% Anomaly Buffer)</td>
                    <td className="px-3.5 py-3 text-right font-medium">QAR {comparativeAnalysis.draftQuote.rawMaterialCostQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-right text-slate-400">-</td>
                    <td className="px-3.5 py-3 text-center"><span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Validated</span></td>
                  </tr>
                  <tr>
                    <td className="px-3.5 py-3 font-bold text-slate-800">2. BOQ</td>
                    <td className="px-3.5 py-3 text-slate-600">Bill of Quantities & Security Catalogue</td>
                    <td className="px-3.5 py-3 text-slate-500">Itemized Specifications, UOM, MOI Compliance & Base Unit Rates</td>
                    <td className="px-3.5 py-3 text-right font-medium">QAR {comparativeAnalysis.draftQuote.rawMaterialCostQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-right text-slate-400">-</td>
                    <td className="px-3.5 py-3 text-center"><span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Structured</span></td>
                  </tr>
                  <tr>
                    <td className="px-3.5 py-3 font-bold text-slate-800">3. Rules Engine One</td>
                    <td className="px-3.5 py-3 text-slate-600">Rules Engine One (Draft Estimation)</td>
                    <td className="px-3.5 py-3 text-slate-500">Markup {rulesAConfig.materialMarkupPercent}%, Labor {rulesAConfig.directLaborPercent}%, Overheads {rulesAConfig.overheadsPercent}%, P1 {rulesAConfig.standardProfitMarginP1}%</td>
                    <td className="px-3.5 py-3 text-right font-medium">QAR {comparativeAnalysis.draftQuote.rawMaterialCostQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-right font-black text-slate-900">QAR {comparativeAnalysis.draftQuote.totalDraftQuotationQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-center"><span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Draft Base</span></td>
                  </tr>
                  <tr>
                    <td className="px-3.5 py-3 font-bold text-slate-800">4. Supplier RFQ & Bids</td>
                    <td className="px-3.5 py-3 text-slate-600">Live Bid Sync & Matrix</td>
                    <td className="px-3.5 py-3 text-slate-500">Bids from Mannai, Dahua, Belden, ZKTeco, Cisco/Wipro</td>
                    <td className="px-3.5 py-3 text-right font-black text-emerald-600">QAR {comparativeAnalysis.finalQuote.marketSourcedBaseCostQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-right text-slate-400">-</td>
                    <td className="px-3.5 py-3 text-center"><span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Synced</span></td>
                  </tr>
                  <tr className="bg-emerald-50/40">
                    <td className="px-3.5 py-3 font-black text-emerald-950">5. Rules Engine B</td>
                    <td className="px-3.5 py-3 font-bold text-emerald-900">Rules Engine B (Final Revision)</td>
                    <td className="px-3.5 py-3 text-emerald-800">Lowest Bids, Comp Adj {rulesBConfig.competitiveAdjustmentPercent}%, FX +{rulesBConfig.exchangeRateBufferPercent}%, Rounded</td>
                    <td className="px-3.5 py-3 text-right font-black text-emerald-700">QAR {comparativeAnalysis.finalQuote.marketSourcedBaseCostQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-right font-black text-emerald-800">QAR {comparativeAnalysis.finalQuote.finalQuotationTotalQAR.toLocaleString()}</td>
                    <td className="px-3.5 py-3 text-center"><span className="bg-emerald-600 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full">Approved</span></td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Bottom Nav for Audit */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => setActiveStep('phase5_rules_b')}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>← Back to Phase 5: Rules Engine B</span>
              </button>

              <button
                onClick={() => {
                  setSyncSuccessNotification('Procurement & SCM Pipeline successfully finalized! All phases verified and commercial proposal ready for tender.');
                  setTimeout(() => setSyncSuccessNotification(null), 6000);
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Finalize Proposal & Lock Pipeline</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ITEM PRICE CHANGE VERSION HISTORY */}
      {selectedItemForHistory && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h4 className="font-black text-sm text-slate-900">{selectedItemForHistory.itemCode} Price Version History</h4>
                <p className="text-xs text-slate-500">{selectedItemForHistory.description}</p>
              </div>
              <button
                onClick={() => setSelectedItemForHistory(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto">
              {selectedItemForHistory.versionHistory?.map((ver, idx) => (
                <div key={idx} className="bg-slate-50 p-3 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-black text-indigo-600">{ver.version}</span>
                    <span className="text-slate-500 ml-2">Effective: {ver.effectiveDate}</span>
                    <p className="text-slate-700 mt-1 font-medium">{ver.reason}</p>
                    <span className="text-[10px] text-slate-400">Supplier: {ver.supplier} {ver.sourceRFQ ? `| ${ver.sourceRFQ}` : ''}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-slate-900">QAR {ver.costQAR.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedItemForHistory(null)}
                className="bg-slate-900 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
              >
                Close History
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD CATALOGUE ITEM */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h4 className="font-black text-sm text-slate-900">Add Item to Master Price Repository</h4>
              <button
                onClick={() => setIsAddItemModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Item Code</label>
                <input
                  type="text"
                  placeholder="e.g. CAM-4K-AI-01"
                  value={newItemData.itemCode || ''}
                  onChange={(e) => setNewItemData({ ...newItemData, itemCode: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Description</label>
                <input
                  type="text"
                  placeholder="Detailed equipment description..."
                  value={newItemData.description || ''}
                  onChange={(e) => setNewItemData({ ...newItemData, description: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={newItemData.category}
                    onChange={(e) => setNewItemData({ ...newItemData, category: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-xl"
                  >
                    {masterCategories.filter(c => c !== 'All').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">UoM</label>
                  <select
                    value={newItemData.uom}
                    onChange={(e) => setNewItemData({ ...newItemData, uom: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-xl"
                  >
                    <option value="Pcs">Pcs</option>
                    <option value="Meter">Meter</option>
                    <option value="Set">Set</option>
                    <option value="Lot">Lot</option>
                    <option value="Hour">Hour</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Standard Cost (QAR)</label>
                  <input
                    type="number"
                    value={newItemData.standardCostWarehouseQAR || ''}
                    onChange={(e) => setNewItemData({ ...newItemData, standardCostWarehouseQAR: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Preferred Supplier</label>
                  <input
                    type="text"
                    placeholder="e.g. Mannai Trading"
                    value={newItemData.preferredSupplier || ''}
                    onChange={(e) => setNewItemData({ ...newItemData, preferredSupplier: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t">
              <button
                onClick={() => setIsAddItemModalOpen(false)}
                className="bg-slate-100 text-slate-700 text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNewMasterItem}
                className="bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
              >
                Save Catalogue Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PHASE 3 OFFICIAL COMMERCIAL QUOTATION SHEET MODAL */}
      {isPhase3OfficialQuoteModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 md:p-6 overflow-y-auto">
          <div className="bg-white w-full max-w-7xl rounded-2xl shadow-2xl overflow-hidden my-auto relative max-h-[95vh] flex flex-col">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-sm tracking-wide">
                  Phase 3: Official Commercial Quotation Document (Rules Engine One Result)
                </h3>
              </div>
              <button
                onClick={() => setIsPhase3OfficialQuoteModalOpen(false)}
                className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-2 md:p-4 bg-slate-100">
              <OfficialQuotationView
                onClose={() => setIsPhase3OfficialQuoteModalOpen(false)}
                initialItems={phase3OfficialQuoteItems}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
