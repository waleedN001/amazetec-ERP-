import React, { useState } from 'react';
import {
  Building2,
  ShieldCheck,
  Star,
  Mail,
  Phone,
  Globe,
  Award,
  CheckCircle2,
  Clock,
  Plus,
  Send,
  FileText,
  Sliders,
  X,
  Printer,
  Sparkles,
  Search,
} from 'lucide-react';
import { SupplierRecord, BOQRecord } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';

interface SupplierAVLViewProps {
  suppliers: SupplierRecord[];
  boqs?: BOQRecord[];
  onUpdateSuppliers: (data: SupplierRecord[]) => void;
  onOpenQuickAdd: () => void;
  dropdownOptions?: string[];
}

export const SupplierAVLView: React.FC<SupplierAVLViewProps> = ({
  suppliers,
  boqs = [],
  onUpdateSuppliers,
  onOpenQuickAdd,
  dropdownOptions = [],
}) => {
  const [selectedSupplierForEval, setSelectedSupplierForEval] = useState<SupplierRecord | null>(null);
  const [selectedSupplierForRFQ, setSelectedSupplierForRFQ] = useState<SupplierRecord | null>(null);
  const [notification, setNotification] = useState<string | null>(null);

  // Evaluation Form State
  const [evalMoiScore, setEvalMoiScore] = useState<number>(5);
  const [evalPunctualityScore, setEvalPunctualityScore] = useState<number>(4);
  const [evalCommercialScore, setEvalCommercialScore] = useState<number>(4);
  const [evalTechnicalScore, setEvalTechnicalScore] = useState<number>(5);

  // RFQ Generator State
  const [rfqProjectName, setRfqProjectName] = useState<string>(boqs[0]?.projectName || 'Lusail Tower ELV Upgrade');
  const [rfqDeadline, setRfqDeadline] = useState<string>('2026-08-30');
  const [rfqRemarks, setRfqRemarks] = useState<string>('Please provide your best DDP Doha prices including MOI-SSD datasheets and 2-year warranty.');

  const supplierColumns: ColumnDef[] = [
    { key: 'code', label: 'Code', type: 'readonly' },
    { key: 'name', label: 'Supplier Name', type: 'text' },
    { key: 'country', label: 'Country', type: 'text' },
    { key: 'contactPerson', label: 'Contact', type: 'text' },
    { key: 'phone', label: 'Phone', type: 'text' },
    { key: 'email', label: 'Email', type: 'text' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'select', options: ['Yes', 'No', 'Pending'] },
    { key: 'products', label: 'Products', type: 'text' },
    { key: 'creditTerms', label: 'Credit Terms', type: 'text' },
    { key: 'paymentTerms', label: 'Payment Terms', type: 'select', options: dropdownOptions.length > 0 ? dropdownOptions : ['100% Advance', '30 Days Net', '60 Days PDC', '90 Days PDC', 'LC at Sight'] },
    { key: 'deliveryLeadTime', label: 'Lead Time', type: 'text' },
    { key: 'rating', label: 'Rating (1-5)', type: 'number' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive', 'Onboarding', 'Suspended', 'Pending Approval'] },
  ];

  const handleSaveEvaluation = () => {
    if (!selectedSupplierForEval) return;
    // Calculate weighted score out of 5
    // MOI (30%), Punctuality (25%), Commercial (25%), Technical (20%)
    const weightedScore =
      evalMoiScore * 0.3 +
      evalPunctualityScore * 0.25 +
      evalCommercialScore * 0.25 +
      evalTechnicalScore * 0.2;
    const finalRating = Number(weightedScore.toFixed(1));

    const updated = suppliers.map((s) =>
      s.code === selectedSupplierForEval.code ? { ...s, rating: finalRating } : s
    );
    onUpdateSuppliers(updated);
    setNotification(`Updated performance scorecard for ${selectedSupplierForEval.name} to ${finalRating} / 5.0 ⭐`);
    setSelectedSupplierForEval(null);
    setTimeout(() => setNotification(null), 4000);
  };

  const moiApprovedCount = suppliers.filter((s) => s.moiApproved === 'Yes').length;
  const activeCount = suppliers.filter((s) => s.status === 'Active').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white p-5 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-purple-900/40">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-purple-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-purple-600/30">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base tracking-tight text-white">
                Approved Vendor List (AVL) & Supplier Governance
              </h3>
              <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-2xs px-2 py-0.5 rounded-full font-semibold">
                Tier-1 Authorized Channels
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Vetted security distributors, MOI-SSD compliance audits, supplier credit lines & performance scorecards.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl font-bold">
            {moiApprovedCount} MOI Approved
          </span>
          <span className="px-3 py-1.5 bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl font-bold">
            {activeCount} Active Partners
          </span>
          <button
            onClick={onOpenQuickAdd}
            className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition flex items-center gap-1 shadow-sm cursor-pointer ml-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Supplier</span>
          </button>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex items-center gap-2.5 text-xs text-purple-900 font-semibold animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Supplier Highlight Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {suppliers.slice(0, 3).map((sup) => (
          <div
            key={sup.code}
            className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs hover:shadow-md transition space-y-3 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-extrabold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-lg border border-purple-100">
                  {sup.code}
                </span>
                <div className="flex items-center gap-1 text-amber-500 font-black text-xs">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{sup.rating || 4.5}</span>
                </div>
              </div>

              <h4 className="text-sm font-extrabold text-slate-900 mt-2">{sup.name}</h4>
              <p className="text-2xs text-slate-500 mt-0.5 line-clamp-1">{sup.products}</p>

              <div className="mt-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1 text-2xs text-slate-600">
                <div className="flex justify-between">
                  <span>MOI Status:</span>
                  <strong className={sup.moiApproved === 'Yes' ? 'text-emerald-600' : 'text-slate-700'}>
                    {sup.moiApproved === 'Yes' ? 'Verified Approved' : sup.moiApproved}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span>Payment Terms:</span>
                  <strong className="text-slate-800">{sup.paymentTerms}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Lead Time:</span>
                  <strong className="text-slate-800">{sup.deliveryLeadTime}</strong>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  setSelectedSupplierForEval(sup);
                  setEvalMoiScore(sup.moiApproved === 'Yes' ? 5 : 3);
                }}
                className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-2xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
              >
                <Sliders className="w-3 h-3 text-slate-500" />
                <span>Evaluate</span>
              </button>
              <button
                onClick={() => setSelectedSupplierForRFQ(sup)}
                className="flex-1 py-1.5 px-2 bg-purple-600 hover:bg-purple-500 text-white text-2xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
              >
                <Send className="w-3 h-3" />
                <span>Float RFQ</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Main Editable Table */}
      <EditableTable
        title="Supplier Database (MOI Approved Vendors)"
        subtitle="Active suppliers, MOI compliance status, country of origin, payment terms & ratings"
        columns={supplierColumns}
        data={suppliers}
        onUpdateData={onUpdateSuppliers}
        onAddRow={onOpenQuickAdd}
        badge="Table 3"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />

      {/* ========================================================================= */}
      {/* SUPPLIER SCORECARD & EVALUATION MODAL */}
      {/* ========================================================================= */}
      {selectedSupplierForEval && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-300 space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  Supplier Performance Evaluation — {selectedSupplierForEval.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedSupplierForEval(null)}
                className="text-slate-400 hover:text-slate-700 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>1. MOI-SSD Compliance & Datasheets (30% Weight)</span>
                  <span className="text-purple-700">{evalMoiScore} / 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={evalMoiScore}
                  onChange={(e) => setEvalMoiScore(Number(e.target.value))}
                  className="w-full accent-purple-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>2. Delivery Punctuality & Lead Time (25% Weight)</span>
                  <span className="text-purple-700">{evalPunctualityScore} / 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={evalPunctualityScore}
                  onChange={(e) => setEvalPunctualityScore(Number(e.target.value))}
                  className="w-full accent-purple-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>3. Commercial Pricing & Discounts (25% Weight)</span>
                  <span className="text-purple-700">{evalCommercialScore} / 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={evalCommercialScore}
                  onChange={(e) => setEvalCommercialScore(Number(e.target.value))}
                  className="w-full accent-purple-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>4. Warranty, RMA & Technical Support (20% Weight)</span>
                  <span className="text-purple-700">{evalTechnicalScore} / 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={evalTechnicalScore}
                  onChange={(e) => setEvalTechnicalScore(Number(e.target.value))}
                  className="w-full accent-purple-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-2xl border border-purple-100 flex items-center justify-between">
              <div>
                <span className="text-2xs font-bold uppercase text-purple-600">Calculated Overall Rating</span>
                <div className="text-lg font-black text-purple-900">
                  {(
                    evalMoiScore * 0.3 +
                    evalPunctualityScore * 0.25 +
                    evalCommercialScore * 0.25 +
                    evalTechnicalScore * 0.2
                  ).toFixed(1)}{' '}
                  / 5.0 ⭐
                </div>
              </div>
              <button
                onClick={handleSaveEvaluation}
                className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-xs cursor-pointer"
              >
                Apply Score
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RFQ DISPATCHER MODAL */}
      {/* ========================================================================= */}
      {selectedSupplierForRFQ && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-300 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-purple-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  Float RFQ to {selectedSupplierForRFQ.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedSupplierForRFQ(null)}
                className="text-slate-400 hover:text-slate-700 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-2xs font-bold uppercase text-slate-500">Project Reference</label>
                <input
                  type="text"
                  value={rfqProjectName}
                  onChange={(e) => setRfqProjectName(e.target.value)}
                  className="mt-1 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="text-2xs font-bold uppercase text-slate-500">Target Submission Deadline</label>
                <input
                  type="date"
                  value={rfqDeadline}
                  onChange={(e) => setRfqDeadline(e.target.value)}
                  className="mt-1 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
                />
              </div>

              <div>
                <label className="text-2xs font-bold uppercase text-slate-500">Commercial Notes & Requirements</label>
                <textarea
                  rows={3}
                  value={rfqRemarks}
                  onChange={(e) => setRfqRemarks(e.target.value)}
                  className="mt-1 w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-medium"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                onClick={() => setSelectedSupplierForRFQ(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setNotification(`RFQ successfully drafted and queued for ${selectedSupplierForRFQ.name} (${selectedSupplierForRFQ.email})`);
                  setSelectedSupplierForRFQ(null);
                  setTimeout(() => setNotification(null), 4000);
                }}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send RFQ Notice</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
