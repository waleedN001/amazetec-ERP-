import React, { useState } from 'react';
import { FileSpreadsheet, Download } from 'lucide-react';
import { EditableTable, ColumnDef } from './EditableTable';

interface MasterSpreadsheetViewProps {
  dataState: any;
  onUpdateState: (key: string, data: any[]) => void;
  onExportMasterExcel: () => void;
}

export const MasterSpreadsheetView: React.FC<MasterSpreadsheetViewProps> = ({
  dataState,
  onUpdateState,
  onExportMasterExcel,
}) => {
  const [activeSheet, setActiveSheet] = useState<
    | 'catalog'
    | 'pr'
    | 'submittals'
    | 'boq'
    | 'quote'
    | 'po'
    | 'logistics'
    | 'reconciliation'
    | 'supplier'
    | 'price'
    | 'followup'
    | 'assets'
    | 'employees'
    | 'salary'
    | 'leads'
    | 'projects'
  >('catalog');

  // Security Catalog Columns
  const catalogCols: ColumnDef[] = [
    { key: 'id', label: 'Product ID', type: 'readonly' },
    { key: 'category', label: 'Category', type: 'text' },
    { key: 'productType', label: 'Product Type / Specification', type: 'text' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model No.', type: 'text' },
    { key: 'moiApproved', label: 'MOI SSD Approved', type: 'text' },
    { key: 'moiCertificateNo', label: 'MOI Cert No.', type: 'text' },
    { key: 'unitPriceQAR', label: 'Unit Price (QAR)', type: 'currency' },
    { key: 'cityLocation', label: 'City / Location', type: 'text' },
    { key: 'timeUnitPeriod', label: 'Time Unit / Validity', type: 'text' },
    { key: 'supplyDeliveryTime', label: 'Supply Delivery Time', type: 'text' },
    { key: 'warrantyPeriod', label: 'Warranty Period', type: 'text' },
    { key: 'stockAvailability', label: 'Stock Status', type: 'text' },
  ];

  // Purchase Requisitions
  const prCols: ColumnDef[] = [
    { key: 'prId', label: 'PR Number', type: 'readonly' },
    { key: 'boqId', label: 'BOQ Ref', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'siteLocation', label: 'Site Location', type: 'text' },
    { key: 'requestedBy', label: 'Requested By', type: 'text' },
    { key: 'itemDescription', label: 'Item Description', type: 'text' },
    { key: 'quantity', label: 'Quantity', type: 'number' },
    { key: 'unit', label: 'Unit', type: 'text' },
    { key: 'estimatedBudgetQAR', label: 'Est Budget (QAR)', type: 'currency' },
    { key: 'priority', label: 'Priority', type: 'text' },
    { key: 'technicalVetting', label: 'Technical Vetting', type: 'text' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Material Submittals
  const submittalCols: ColumnDef[] = [
    { key: 'submittalId', label: 'Submittal Ref', type: 'readonly' },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'category', label: 'Category', type: 'text' },
    { key: 'itemDescription', label: 'Equipment', type: 'text' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'consultantName', label: 'Consultant', type: 'text' },
    { key: 'approvalStatus', label: 'Status (Code A/B/C/D)', type: 'text' },
    { key: 'moiCertificateAttached', label: 'MOI Cert', type: 'text' },
  ];

  // Master BOQ List Columns
  const boqCols: ColumnDef[] = [
    { key: 'boqId', label: 'BOQ ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'clientName', label: 'Client', type: 'text' },
    { key: 'category', label: 'Category', type: 'text' },
    { key: 'totalItems', label: 'Items Count', type: 'number' },
    { key: 'materialCost', label: 'Material Cost (QAR)', type: 'currency' },
    { key: 'labourCost', label: 'Labour Cost (QAR)', type: 'currency' },
    { key: 'overheadCost', label: 'Overhead Cost (QAR)', type: 'currency' },
    { key: 'boqValue', label: 'BOQ Total Value (QAR)', type: 'currency' },
    { key: 'marginPercent', label: 'Margin (%)', type: 'percent' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Comparative Quotations
  const quoteCols: ColumnDef[] = [
    { key: 'quoteId', label: 'Quote ID', type: 'readonly' },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'quotedValue', label: 'Quoted Value (QAR)', type: 'currency' },
    { key: 'receivedDate', label: 'Received Date', type: 'date' },
    { key: 'validity', label: 'Validity', type: 'text' },
    { key: 'paymentTerms', label: 'Payment Terms', type: 'text' },
    { key: 'deliveryTime', label: 'Delivery Time', type: 'text' },
    { key: 'status', label: 'Status', type: 'text' },
    { key: 'selected', label: 'Selected (Y/N)', type: 'text' },
  ];

  // Purchase Orders
  const poCols: ColumnDef[] = [
    { key: 'poNumber', label: 'PO Number', type: 'readonly' },
    { key: 'prId', label: 'PR Ref', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'totalAmountQAR', label: 'Total Amount (QAR)', type: 'currency' },
    { key: 'paymentTerms', label: 'Payment Terms', type: 'text' },
    { key: 'issueDate', label: 'Issue Date', type: 'date' },
    { key: 'deliveryDueDate', label: 'Delivery Due', type: 'date' },
    { key: 'turnaroundHours', label: 'Turnaround (h)', type: 'number' },
    { key: 'materialSubmittalApproved', label: 'Submittal OK', type: 'text' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Logistics & Customs
  const logisticsCols: ColumnDef[] = [
    { key: 'shipmentId', label: 'Shipment ID', type: 'readonly' },
    { key: 'poNumber', label: 'PO Ref', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'originCountry', label: 'Origin', type: 'text' },
    { key: 'shippingMode', label: 'Freight Mode', type: 'text' },
    { key: 'carrierForwarder', label: 'Carrier', type: 'text' },
    { key: 'awbOrBolNo', label: 'AWB / BOL #', type: 'text' },
    { key: 'etaPortOrWarehouse', label: 'ETA', type: 'date' },
    { key: 'customsStatus', label: 'Customs Status', type: 'text' },
    { key: 'siteDeliveryStatus', label: 'Delivery Status', type: 'text' },
    { key: 'onTimeStatus', label: 'Schedule SLA', type: 'text' },
    { key: 'qaQcInspectionStatus', label: 'QA/QC Inspection', type: 'text' },
  ];

  // 3-Way Reconciliation
  const reconCols: ColumnDef[] = [
    { key: 'reconciliationId', label: 'Match ID', type: 'readonly' },
    { key: 'invoiceNumber', label: 'Invoice #', type: 'text' },
    { key: 'poNumber', label: 'PO Ref', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'deliveryAdviceNo', label: 'Delivery Note (DA)', type: 'text' },
    { key: 'grnNo', label: 'GRN No.', type: 'text' },
    { key: 'poAmountQAR', label: 'PO Amount', type: 'currency' },
    { key: 'grnReceivedAmountQAR', label: 'GRN Value', type: 'currency' },
    { key: 'invoiceAmountQAR', label: 'Invoice Amount', type: 'currency' },
    { key: 'varianceAmountQAR', label: 'Variance (QAR)', type: 'currency' },
    { key: 'matchStatus', label: 'Match Status', type: 'text' },
    { key: 'financeReleaseStatus', label: 'Finance Release', type: 'text' },
  ];

  // Supplier Database
  const supplierCols: ColumnDef[] = [
    { key: 'code', label: 'Supplier Code', type: 'readonly' },
    { key: 'name', label: 'Supplier Name', type: 'text' },
    { key: 'country', label: 'Country', type: 'text' },
    { key: 'contactPerson', label: 'Contact Person', type: 'text' },
    { key: 'phone', label: 'Phone', type: 'text' },
    { key: 'email', label: 'Email', type: 'text' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'text' },
    { key: 'products', label: 'Products', type: 'text' },
    { key: 'creditTerms', label: 'Credit Terms', type: 'text' },
    { key: 'rating', label: 'Rating (1-5)', type: 'number' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Price History
  const priceCols: ColumnDef[] = [
    { key: 'productCode', label: 'Product Code', type: 'readonly' },
    { key: 'productName', label: 'Product Name', type: 'text' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'oldPrice', label: 'Old Price (QAR)', type: 'currency' },
    { key: 'newPrice', label: 'New Price (QAR)', type: 'currency' },
    { key: 'priceChange', label: 'Price Change', type: 'currency' },
    { key: 'percentChange', label: '% Change', type: 'percent' },
    { key: 'changeType', label: 'Type', type: 'text' },
    { key: 'effectiveDate', label: 'Effective Date', type: 'date' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'text' },
  ];

  // Follow-ups
  const followUpCols: ColumnDef[] = [
    { key: 'id', label: 'Follow-Up ID', type: 'readonly' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'subject', label: 'Subject', type: 'text' },
    { key: 'dateCreated', label: 'Date', type: 'date' },
    { key: 'currentStatus', label: 'Status', type: 'text' },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'priority', label: 'Priority', type: 'text' },
    { key: 'resolution', label: 'Resolution', type: 'text' },
  ];

  // Assets
  const assetCols: ColumnDef[] = [
    { key: 'assetId', label: 'Asset ID', type: 'readonly' },
    { key: 'name', label: 'Asset Name', type: 'text' },
    { key: 'category', label: 'Category', type: 'text' },
    { key: 'location', label: 'Location', type: 'text' },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'purchaseValue', label: 'Purchase Value (QAR)', type: 'currency' },
    { key: 'condition', label: 'Condition', type: 'text' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // HR Staff
  const employeeCols: ColumnDef[] = [
    { key: 'employeeId', label: 'Emp ID', type: 'readonly' },
    { key: 'name', label: 'Employee Name', type: 'text' },
    { key: 'department', label: 'Department', type: 'text' },
    { key: 'designation', label: 'Designation', type: 'text' },
    { key: 'qatarId', label: 'Qatar ID (QID)', type: 'text' },
    { key: 'joiningDate', label: 'Joining Date', type: 'date' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Salary
  const salaryCols: ColumnDef[] = [
    { key: 'bracketId', label: 'Bracket ID', type: 'readonly' },
    { key: 'roleTitle', label: 'Role Title', type: 'text' },
    { key: 'department', label: 'Department', type: 'text' },
    { key: 'basicSalary', label: 'Basic Salary (QAR)', type: 'currency' },
    { key: 'grossMonthly', label: 'Gross Monthly (QAR)', type: 'currency' },
    { key: 'annualPackage', label: 'Annual Package (QAR)', type: 'currency' },
  ];

  // Leads
  const leadCols: ColumnDef[] = [
    { key: 'leadId', label: 'Lead ID', type: 'readonly' },
    { key: 'clientName', label: 'Client Name', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'source', label: 'Lead Source', type: 'text' },
    { key: 'leadValue', label: 'Lead Value (QAR)', type: 'currency' },
    { key: 'probability', label: 'Probability (%)', type: 'percent' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  // Projects
  const projectCols: ColumnDef[] = [
    { key: 'projectId', label: 'Project ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'client', label: 'Client', type: 'text' },
    { key: 'location', label: 'Location', type: 'text' },
    { key: 'contractValue', label: 'Contract Value (QAR)', type: 'currency' },
    { key: 'status', label: 'Status', type: 'text' },
  ];

  return (
    <div className="bg-white border border-slate-300 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[600px]">
      {/* Top Excel Bar */}
      <div className="bg-slate-800 text-white px-4 py-2.5 flex items-center justify-between border-b border-slate-700">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
          <span className="font-bold text-sm tracking-wide">
            Amazetec Enterprise ERP Master Spreadsheet (16 Worksheets)
          </span>
        </div>
        <button
          onClick={onExportMasterExcel}
          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition cursor-pointer shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export All Worksheets (.XLSX)</span>
        </button>
      </div>

      {/* Main Table Content */}
      <div className="p-4 flex-1 overflow-auto bg-slate-50">
        {activeSheet === 'catalog' && (
          <EditableTable
            title="Sheet 1: Security Products Master Catalog"
            subtitle="Master catalog of MOI-SSD approved CCTV, Access Control, VMS, and Fire Safety items"
            columns={catalogCols}
            data={dataState.securityCatalog || []}
            onUpdateData={(newData) => onUpdateState('securityCatalog', newData)}
            badge="Product Catalog"
            badgeColor="bg-indigo-50 text-indigo-800 border-indigo-300"
          />
        )}

        {activeSheet === 'pr' && (
          <EditableTable
            title="Sheet 2: Site Purchase Requisitions (PR)"
            subtitle="Material requisitions submitted by site engineers verified against BOQ line items"
            columns={prCols}
            data={dataState.purchaseRequisitions || []}
            onUpdateData={(newData) => onUpdateState('purchaseRequisitions', newData)}
            badge="PR Requisitions"
            badgeColor="bg-blue-50 text-blue-800 border-blue-300"
          />
        )}

        {activeSheet === 'submittals' && (
          <EditableTable
            title="Sheet 3: Material Approval Submittals (MAS)"
            subtitle="Consultant approvals (Code A/B/C/D) and MOI compliance certificates"
            columns={submittalCols}
            data={dataState.materialSubmittals || []}
            onUpdateData={(newData) => onUpdateState('materialSubmittals', newData)}
            badge="Material Submittals"
            badgeColor="bg-emerald-50 text-emerald-800 border-emerald-300"
          />
        )}

        {activeSheet === 'boq' && (
          <EditableTable
            title="Sheet 4: Master BOQ Cost Breakdowns"
            subtitle="View and live-edit bill of quantities, unit rates, overheads and project totals"
            columns={boqCols}
            data={dataState.boqs || []}
            onUpdateData={(newData) => onUpdateState('boqs', newData)}
            badge="Master BOQs"
            badgeColor="bg-blue-50 text-blue-800 border-blue-300"
          />
        )}

        {activeSheet === 'quote' && (
          <EditableTable
            title="Sheet 5: Commercial Bid Evaluation Matrix (CBE)"
            subtitle="Comparative vendor quotations and supplier selection matrix"
            columns={quoteCols}
            data={dataState.quotations || []}
            onUpdateData={(newData) => onUpdateState('quotations', newData)}
            badge="Comparative Quotes"
            badgeColor="bg-emerald-50 text-emerald-800 border-emerald-300"
          />
        )}

        {activeSheet === 'po' && (
          <EditableTable
            title="Sheet 6: Purchase Orders Registry (PO)"
            subtitle="Commercial purchase orders issued to suppliers with turnaround SLAs"
            columns={poCols}
            data={dataState.purchaseOrders || []}
            onUpdateData={(newData) => onUpdateState('purchaseOrders', newData)}
            badge="Purchase Orders"
            badgeColor="bg-indigo-50 text-indigo-800 border-indigo-300"
          />
        )}

        {activeSheet === 'logistics' && (
          <EditableTable
            title="Sheet 7: Logistics, Customs & QA/QC Receiving"
            subtitle="Tracking AWB/BOL, customs clearance, and storekeeper defect-free inspection"
            columns={logisticsCols}
            data={dataState.shipments || []}
            onUpdateData={(newData) => onUpdateState('shipments', newData)}
            badge="Logistics & Customs"
            badgeColor="bg-teal-50 text-teal-800 border-teal-300"
          />
        )}

        {activeSheet === 'reconciliation' && (
          <EditableTable
            title="Sheet 8: 3-Way Invoice Reconciliation (PO ⟷ DA ⟷ GRN)"
            subtitle="3-way matching validation and finance payment release status"
            columns={reconCols}
            data={dataState.reconciliations || []}
            onUpdateData={(newData) => onUpdateState('reconciliations', newData)}
            badge="3-Way Match"
            badgeColor="bg-purple-50 text-purple-800 border-purple-300"
          />
        )}

        {activeSheet === 'supplier' && (
          <EditableTable
            title="Sheet 9: Approved Vendors Database (AVL)"
            subtitle="Pre-qualified suppliers, MOI compliance, credit terms, and performance ratings"
            columns={supplierCols}
            data={dataState.suppliers || []}
            onUpdateData={(newData) => onUpdateState('suppliers', newData)}
            badge="Approved Suppliers"
            badgeColor="bg-purple-50 text-purple-800 border-purple-300"
          />
        )}

        {activeSheet === 'price' && (
          <EditableTable
            title="Sheet 10: Price History & Variance Logs"
            subtitle="Automated variance calculation: New Price vs Old Price"
            columns={priceCols}
            data={dataState.priceHistory || []}
            onUpdateData={(newData) => onUpdateState('priceHistory', newData)}
            badge="Price History"
            badgeColor="bg-rose-50 text-rose-800 border-rose-300"
          />
        )}

        {activeSheet === 'followup' && (
          <EditableTable
            title="Sheet 11: Procurement Follow-ups (F1...Fn)"
            subtitle="Vendor communication, negotiation, and query resolution tracking"
            columns={followUpCols}
            data={dataState.procurementFollowUps || []}
            onUpdateData={(newData) => onUpdateState('procurementFollowUps', newData)}
            badge="Follow-ups"
            badgeColor="bg-amber-50 text-amber-800 border-amber-300"
          />
        )}

        {activeSheet === 'assets' && (
          <EditableTable
            title="Sheet 12: Admin Asset Register"
            subtitle="Fixed assets, company vehicles, and office equipment"
            columns={assetCols}
            data={dataState.assets || []}
            onUpdateData={(newData) => onUpdateState('assets', newData)}
            badge="Admin Assets"
            badgeColor="bg-slate-50 text-slate-800 border-slate-300"
          />
        )}

        {activeSheet === 'employees' && (
          <EditableTable
            title="Sheet 13: HR Employee Register"
            subtitle="Company staff, Qatar IDs, and departments"
            columns={employeeCols}
            data={dataState.employees || []}
            onUpdateData={(newData) => onUpdateState('employees', newData)}
            badge="Employees"
            badgeColor="bg-amber-50 text-amber-800 border-amber-300"
          />
        )}

        {activeSheet === 'salary' && (
          <EditableTable
            title="Sheet 14: HR Salary Brackets & Payroll"
            subtitle="Basic salary, gross monthly, and annual packages"
            columns={salaryCols}
            data={dataState.salaryBrackets || []}
            onUpdateData={(newData) => onUpdateState('salaryBrackets', newData)}
            badge="Salary Brackets"
            badgeColor="bg-amber-50 text-amber-800 border-amber-300"
          />
        )}

        {activeSheet === 'leads' && (
          <EditableTable
            title="Sheet 15: Business Analyst Leads & Pipeline"
            subtitle="Sales leads, estimated values, and win probabilities"
            columns={leadCols}
            data={dataState.leads || []}
            onUpdateData={(newData) => onUpdateState('leads', newData)}
            badge="BA Leads"
            badgeColor="bg-blue-50 text-blue-800 border-blue-300"
          />
        )}

        {activeSheet === 'projects' && (
          <EditableTable
            title="Sheet 16: PM Projects & Contracts Master"
            subtitle="Active project contracts, values, and managers"
            columns={projectCols}
            data={dataState.projects || []}
            onUpdateData={(newData) => onUpdateState('projects', newData)}
            badge="PM Projects"
            badgeColor="bg-purple-50 text-purple-800 border-purple-300"
          />
        )}
      </div>

      {/* Excel Sheet Tabs Bottom Bar */}
      <div className="p-2 bg-slate-200 border-t border-slate-300 flex items-center gap-1 overflow-x-auto text-xs font-semibold select-none">
        {[
          { id: 'catalog', label: '🛡️ Security Catalog' },
          { id: 'pr', label: '📝 Site PRs' },
          { id: 'submittals', label: '📋 Submittals (MAS)' },
          { id: 'boq', label: '📦 Master BOQs' },
          { id: 'quote', label: '📊 Comparative Quotes' },
          { id: 'po', label: '📄 Purchase Orders (PO)' },
          { id: 'logistics', label: '🚚 Logistics & Customs' },
          { id: 'reconciliation', label: '⚖️ 3-Way Reconciliation' },
          { id: 'supplier', label: '🏭 Suppliers' },
          { id: 'price', label: '📈 Price History' },
          { id: 'followup', label: '📋 Follow-ups' },
          { id: 'assets', label: '🏢 Admin Assets' },
          { id: 'employees', label: '👥 HR Staff' },
          { id: 'salary', label: '💼 HR Payroll' },
          { id: 'leads', label: '🎯 BA Leads' },
          { id: 'projects', label: '🚀 PM Projects' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSheet(tab.id as any)}
            className={`px-3 py-1.5 rounded-t-lg transition border-t border-x cursor-pointer whitespace-nowrap ${
              activeSheet === tab.id
                ? 'bg-white text-indigo-700 font-bold border-slate-300 shadow-2xs'
                : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
};
