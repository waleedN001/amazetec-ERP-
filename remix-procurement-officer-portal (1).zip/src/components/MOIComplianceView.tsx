import React, { useState, useMemo } from 'react';
import {
  MOIDSARecord,
  MOIDIARecord,
  MOIComplianceChecklistItem,
} from '../types';
import { useAppData } from '../context/useAppData';
import {
  ShieldCheck,
  FileCheck2,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Calculator,
  Building2,
  Search,
  Plus,
  ArrowRight,
  Sparkles,
  Download,
  Calendar,
  Layers,
  Award,
} from 'lucide-react';

interface MOIComplianceViewProps {
  dsaRecords: MOIDSARecord[];
  diaRecords: MOIDIARecord[];
  checklist: MOIComplianceChecklistItem[];
  onUpdateDSARecords: (data: MOIDSARecord[]) => void;
  onUpdateDIARecords: (data: MOIDIARecord[]) => void;
  onUpdateChecklist: (data: MOIComplianceChecklistItem[]) => void;
  onOpenQuickAdd: () => void;
}

export const MOIComplianceView: React.FC<MOIComplianceViewProps> = ({
  dsaRecords,
  diaRecords,
  checklist,
  onUpdateDSARecords,
  onUpdateDIARecords,
  onUpdateChecklist,
}) => {
  const { setIsGeminiIntelligenceOpen, setGeminiIntelligenceMode } = useAppData();
  const [activeTab, setActiveTab] = useState<'dsa' | 'dia' | 'storage-calc' | 'checklist'>('storage-calc');
  const [isAddDSAOpen, setIsAddDSAOpen] = useState(false);
  const [isAddDIAOpen, setIsAddDIAOpen] = useState(false);

  // Storage Calculator States
  const [cameraCount, setCameraCount] = useState<number>(64);
  const [resolution, setResolution] = useState<'2MP' | '4MP' | '8MP'>('4MP');
  const [frameRate, setFrameRate] = useState<number>(20);
  const [codec, setCodec] = useState<'H.264' | 'H.265' | 'H.265+'>('H.265');
  const [retentionDays, setRetentionDays] = useState<number>(120); // 120 days mandatory MOI
  const [raidType, setRaidType] = useState<'RAID5' | 'RAID6'>('RAID5');
  const [includeHotSpare, setIncludeHotSpare] = useState<boolean>(true);
  const [driveCapacityTB, setDriveCapacityTB] = useState<number>(16);

  // Storage Math Formula per MOI standard:
  // Bitrate in Mbps based on Resolution, FPS, Codec:
  const storageCalc = useMemo(() => {
    let baseBitrateMbps = 4.0;
    if (resolution === '2MP') baseBitrateMbps = 2.5;
    if (resolution === '4MP') baseBitrateMbps = 4.5;
    if (resolution === '8MP') baseBitrateMbps = 8.0;

    // Adjust for FPS
    const fpsMultiplier = frameRate / 20;
    let adjustedBitrate = baseBitrateMbps * fpsMultiplier;

    // Adjust for Codec
    if (codec === 'H.264') adjustedBitrate *= 1.8;
    if (codec === 'H.265+') adjustedBitrate *= 0.7;

    // Total daily data per camera in GB: (Mbps * 3600 * 24) / (8 * 1024)
    const dailyGBPerCamera = (adjustedBitrate * 86400) / 8192;
    const totalDailyGB = dailyGBPerCamera * cameraCount;

    // Total 120-Day Usable Net Storage in TB
    const netUsableTB = (totalDailyGB * retentionDays) / 1024;

    // 15% MOI safety & format overhead
    const grossUsableTB = netUsableTB * 1.15;

    // RAID Parity calculations:
    // For RAID 5: N usable disks + 1 parity disk (+ 1 hot spare if enabled)
    // For RAID 6: N usable disks + 2 parity disks (+ 1 hot spare if enabled)
    const dataDisksNeeded = Math.ceil(grossUsableTB / driveCapacityTB);
    const parityDisks = raidType === 'RAID5' ? 1 : 2;
    const hotSpareDisks = includeHotSpare ? 1 : 0;
    const totalDisks = dataDisksNeeded + parityDisks + hotSpareDisks;
    const totalRawCapacityTB = totalDisks * driveCapacityTB;

    return {
      bitrateMbps: Number(adjustedBitrate.toFixed(2)),
      dailyGB: Number(totalDailyGB.toFixed(1)),
      netUsableTB: Number(netUsableTB.toFixed(1)),
      grossUsableTB: Number(grossUsableTB.toFixed(1)),
      dataDisksNeeded,
      parityDisks,
      hotSpareDisks,
      totalDisks,
      totalRawCapacityTB,
    };
  }, [cameraCount, resolution, frameRate, codec, retentionDays, raidType, includeHotSpare, driveCapacityTB]);

  // Form states for DSA / DIA
  const [newDSA, setNewDSA] = useState<Partial<MOIDSARecord>>({
    dsaId: `DSA-${new Date().getFullYear()}-${String(dsaRecords.length + 1).padStart(4, '0')}`,
    projectId: 'PRJ-2026-02',
    projectName: '',
    clientName: '',
    submissionDate: new Date().toISOString().split('T')[0],
    moiReference: `MOI-SSD-DSA-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    status: 'Submitted',
    drawingsAttached: true,
    equipmentScheduleVerified: true,
    cameraCount: 32,
    remarks: '',
  });

  const [newDIA, setNewDIA] = useState<Partial<MOIDIARecord>>({
    diaId: `DIA-${new Date().getFullYear()}-${String(diaRecords.length + 1).padStart(4, '0')}`,
    projectId: 'PRJ-2026-01',
    projectName: '',
    clientName: '',
    dsaApprovalRef: 'MOI-SSD-DSA-2026-7841',
    inspectionRequestDate: new Date().toISOString().split('T')[0],
    moiReference: `MOI-SSD-DIA-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    scheduledInspectionDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
    status: 'Scheduled',
    inspectorName: 'Captain MOI-SSD Inspector',
    remarks: '',
  });

  const handleAddDSA = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDSA.projectName) return;
    onUpdateDSARecords([newDSA as MOIDSARecord, ...dsaRecords]);
    setIsAddDSAOpen(false);
  };

  const handleAddDIA = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDIA.projectName) return;
    onUpdateDIARecords([newDIA as MOIDIARecord, ...diaRecords]);
    setIsAddDIAOpen(false);
  };

  const handleToggleChecklist = (id: string) => {
    const updated = checklist.map(item => {
      if (item.id === id) {
        const nextVerified = !item.verified;
        return {
          ...item,
          verified: nextVerified,
          status: (nextVerified ? 'Compliant' : 'Non-Compliant') as any,
        };
      }
      return item;
    });
    onUpdateChecklist(updated);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 rounded-full border border-emerald-400/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Module 4 • MOI SSD Compliance Authority</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
            Qatar MOI-SSD Compliance & Certification Hub
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl">
            Managing Ministry of Interior (Security Systems Department) Design Stage Approvals (DSA), Inspection Phase Certifications (DIA), and automated 120-day video storage dimensioning.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => setIsAddDSAOpen(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Submit New DSA</span>
          </button>

          <button
            onClick={() => setIsAddDIAOpen(true)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Award className="w-4 h-4" />
            <span>Request DIA Inspection</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('storage-calc')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'storage-calc'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>1. 120-Day MOI Storage & RAID Calculator</span>
        </button>

        <button
          onClick={() => setActiveTab('dsa')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'dsa'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>2. DSA Design Approvals ({dsaRecords.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('dia')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'dia'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>3. DIA Inspections & Certificates ({diaRecords.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('checklist')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'checklist'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>4. MOI Compliance Master Checklist (6 Rules)</span>
        </button>
      </div>

      {/* TAB 1: 120-DAY MOI STORAGE & RAID CALCULATOR */}
      {activeTab === 'storage-calc' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Inputs Control Column */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-5">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-indigo-600" />
                  <span>Video Storage & Redundancy Calculator</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Calculates exact storage capacity required under Qatar MOI SSD 120-day retention regulations.
                </p>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                120-Day MOI Mandate
              </span>
            </div>

            {/* Inputs Grid */}
            <div className="space-y-4 text-xs">
              {/* Camera Count */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-800">Total IP Camera Channels</label>
                  <span className="font-extrabold text-sm text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg">
                    {cameraCount} Cameras
                  </span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="256"
                  step="4"
                  value={cameraCount}
                  onChange={(e) => setCameraCount(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
              </div>

              {/* Resolution & FPS */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Camera Resolution</label>
                  <select
                    value={resolution}
                    onChange={(e) => setResolution(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 font-semibold text-slate-800 bg-white"
                  >
                    <option value="2MP">2MP 1080p (MOI Min Spec - 2.5 Mbps)</option>
                    <option value="4MP">4MP 2K Quad HD (Standard - 4.5 Mbps)</option>
                    <option value="8MP">8MP 4K Ultra HD (High Detail - 8.0 Mbps)</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Frame Rate (FPS)</label>
                  <select
                    value={frameRate}
                    onChange={(e) => setFrameRate(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 font-semibold text-slate-800 bg-white"
                  >
                    <option value={15}>15 FPS (Standard MOI Minimum)</option>
                    <option value={20}>20 FPS (Recommended Smoothness)</option>
                    <option value={25}>25 FPS (Full Real-time PAL)</option>
                  </select>
                </div>
              </div>

              {/* Compression Codec & Retention */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Compression Codec</label>
                  <select
                    value={codec}
                    onChange={(e) => setCodec(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 font-semibold text-slate-800 bg-white"
                  >
                    <option value="H.265">H.265 High Efficiency (Recommended)</option>
                    <option value="H.265+">H.265+ Smart Stream Codec</option>
                    <option value="H.264">Legacy H.264 Baseline</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Retention Period (Days)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={retentionDays}
                      onChange={(e) => setRetentionDays(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500/20"
                    />
                    <span className="text-[11px] font-bold text-indigo-700 whitespace-nowrap">Days</span>
                  </div>
                </div>
              </div>

              {/* RAID Configuration & Hard Drive Size */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">RAID Redundancy Level</label>
                  <select
                    value={raidType}
                    onChange={(e) => setRaidType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 font-semibold text-slate-800 bg-white"
                  >
                    <option value="RAID5">RAID 5 (1 Parity Disk Failure Protected)</option>
                    <option value="RAID6">RAID 6 (2 Parity Disks Failure Protected)</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Hard Drive Size (TB)</label>
                  <select
                    value={driveCapacityTB}
                    onChange={(e) => setDriveCapacityTB(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 font-semibold text-slate-800 bg-white"
                  >
                    <option value={8}>8 TB Surveillance HDD</option>
                    <option value={10}>10 TB Seagate SkyHawk AI</option>
                    <option value={14}>14 TB Western Digital Purple Pro</option>
                    <option value={16}>16 TB Seagate Exos / SkyHawk</option>
                    <option value={18}>18 TB Enterprise Surveillance</option>
                  </select>
                </div>
              </div>

              {/* Hot Spare Toggle */}
              <div className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id="hotSpare"
                  checked={includeHotSpare}
                  onChange={(e) => setIncludeHotSpare(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="hotSpare" className="font-bold text-slate-700 cursor-pointer">
                  Include 1 Global Dedicated Hot-Spare Drive (MOI Best Practice)
                </label>
              </div>
            </div>
          </div>

          {/* Right Results & Recommendation Card */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 shadow-md border border-indigo-800/50 space-y-5">
              <div className="flex items-center justify-between border-b border-indigo-800/80 pb-3">
                <h4 className="font-extrabold text-sm text-indigo-200 flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-emerald-400" />
                  <span>Calculated Storage Blueprint</span>
                </h4>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-emerald-500 text-slate-950">
                  MOI APPROVED
                </span>
              </div>

              {/* Key Output Metrics */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-indigo-950/70 p-3.5 rounded-2xl border border-indigo-800/50">
                  <p className="text-[10px] text-indigo-300 font-semibold uppercase">120-Day Usable Net</p>
                  <p className="text-xl font-extrabold text-white mt-0.5">{storageCalc.netUsableTB} TB</p>
                  <p className="text-[10px] text-indigo-400">{storageCalc.dailyGB} GB / Day Total</p>
                </div>

                <div className="bg-indigo-950/70 p-3.5 rounded-2xl border border-indigo-800/50">
                  <p className="text-[10px] text-indigo-300 font-semibold uppercase">Gross Req. (+15% Buffer)</p>
                  <p className="text-xl font-extrabold text-emerald-300 mt-0.5">{storageCalc.grossUsableTB} TB</p>
                  <p className="text-[10px] text-indigo-400">With filesystem safety margin</p>
                </div>
              </div>

              {/* Hardware Bill of Quantities Recommendation */}
              <div className="bg-indigo-950/90 p-4 rounded-2xl border border-indigo-700/60 space-y-3">
                <p className="text-xs font-bold text-indigo-200 uppercase tracking-wider">
                  Recommended MOI-Approved HDD Architecture
                </p>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between py-1 border-b border-indigo-800/60">
                    <span className="text-slate-300">Data Storage Disks:</span>
                    <strong className="text-white">{storageCalc.dataDisksNeeded} x {driveCapacityTB}TB HDDs</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-indigo-800/60">
                    <span className="text-slate-300">{raidType} Parity Disks:</span>
                    <strong className="text-amber-300">+{storageCalc.parityDisks} x {driveCapacityTB}TB Parity</strong>
                  </div>
                  {storageCalc.hotSpareDisks > 0 && (
                    <div className="flex justify-between py-1 border-b border-indigo-800/60">
                      <span className="text-slate-300">Hot-Spare Drive:</span>
                      <strong className="text-teal-300">+1 x {driveCapacityTB}TB Hot Spare</strong>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 text-sm font-extrabold">
                    <span className="text-white">Total Disks Needed:</span>
                    <span className="text-emerald-400">{storageCalc.totalDisks} Drives ({storageCalc.totalRawCapacityTB} TB Raw)</span>
                  </div>
                </div>
              </div>

              {/* Hardware Specification Box */}
              <div className="text-xs text-indigo-200 space-y-1 bg-indigo-950/40 p-3 rounded-xl border border-indigo-800/40">
                <p><strong>Approved Brand:</strong> Seagate SkyHawk AI / Western Digital Purple Pro</p>
                <p><strong>NVR Bay Requirement:</strong> Minimum {storageCalc.totalDisks <= 8 ? '8-Bay NVR (e.g. DS-9632NXI-I8)' : storageCalc.totalDisks <= 16 ? '16-Bay NVR / SAN Array' : '24-Bay SAN Expansion Enclosure'}</p>
                <p><strong>MOI Inspection Guarantee:</strong> Exceeds 120 days minimum video retention period under continuous 24/7 capture.</p>
              </div>

              {/* AI MOI Audit Button */}
              <button
                type="button"
                onClick={() => {
                  setGeminiIntelligenceMode('moi-audit');
                  setIsGeminiIntelligenceOpen(true);
                }}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs py-3 rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>Run AI MOI Compliance & Audit Engine</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DSA DESIGN APPROVALS */}
      {activeTab === 'dsa' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">MOI SSD Design Stage Approvals (DSA)</h3>
              <p className="text-xs text-slate-500">Design approval submissions, architectural drawing overlays & equipment schedules.</p>
            </div>
            <button
              onClick={() => setIsAddDSAOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New DSA Submission</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">DSA ID & Project</th>
                  <th className="py-3 px-4">MOI Reference Number</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Camera Count</th>
                  <th className="py-3 px-4">Submission Date</th>
                  <th className="py-3 px-4">Approval Validity</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dsaRecords.map((dsa) => (
                  <tr key={dsa.dsaId} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{dsa.projectName}</p>
                      <p className="text-[11px] text-indigo-600 font-mono">{dsa.dsaId}</p>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                      {dsa.moiReference}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">{dsa.clientName}</td>
                    <td className="py-3.5 px-4 font-extrabold text-indigo-600">{dsa.cameraCount} Cameras</td>
                    <td className="py-3.5 px-4 text-slate-600">{dsa.submissionDate}</td>
                    <td className="py-3.5 px-4 text-[11px] text-slate-500">
                      {dsa.validUntil ? `Valid to ${dsa.validUntil}` : 'Pending Review'}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                        dsa.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : dsa.status === 'Under Review'
                          ? 'bg-blue-100 text-blue-800'
                          : dsa.status === 'Revision Required'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {dsa.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 max-w-xs truncate">
                      {dsa.remarks}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: DIA INSPECTION & CERTIFICATES */}
      {activeTab === 'dia' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">MOI DIA Inspection Approvals & Security Completion Certificates</h3>
              <p className="text-xs text-slate-500">Physical site walkthroughs, video retention playback tests & official security certificate numbers.</p>
            </div>
            <button
              onClick={() => setIsAddDIAOpen(true)}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log DIA Inspection</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">DIA ID & Project</th>
                  <th className="py-3 px-4">MOI Certificate #</th>
                  <th className="py-3 px-4">DSA Reference</th>
                  <th className="py-3 px-4">Scheduled Inspection</th>
                  <th className="py-3 px-4">Inspector Name</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Certificate Expiry</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {diaRecords.map((dia) => (
                  <tr key={dia.diaId} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{dia.projectName}</p>
                      <p className="text-[11px] text-indigo-600 font-mono">{dia.diaId}</p>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-extrabold text-emerald-700">
                      {dia.certificateNumber || 'Pending Issuance'}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500">{dia.dsaApprovalRef}</td>
                    <td className="py-3.5 px-4 text-slate-700 font-medium">{dia.scheduledInspectionDate}</td>
                    <td className="py-3.5 px-4 text-slate-700">{dia.inspectorName || 'Unassigned'}</td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                        dia.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : dia.status === 'Scheduled'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {dia.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-[11px] text-slate-600">
                      {dia.certificateExpiryDate ? (
                        <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
                          Valid until {dia.certificateExpiryDate}
                        </span>
                      ) : 'Awaiting Inspection'}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => {
                          const newStatus = dia.status === 'Scheduled' ? 'Approved' : 'Scheduled';
                          const updated = diaRecords.map(d => d.diaId === dia.diaId ? {
                            ...d,
                            status: newStatus as any,
                            certificateNumber: newStatus === 'Approved' ? `MOI-SSD-CERT-2026-${Math.floor(10000 + Math.random() * 90000)}` : undefined,
                            certificateExpiryDate: newStatus === 'Approved' ? '2027-08-19' : undefined,
                          } : d);
                          onUpdateDIARecords(updated);
                        }}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                      >
                        Toggle Pass
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: MOI COMPLIANCE MASTER CHECKLIST */}
      {activeTab === 'checklist' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Qatar MOI-SSD Technical Compliance Checklist (Standard Audit)
              </h3>
              <p className="text-xs text-slate-500">
                Mandatory engineering audit checkpoints enforced on every commercial security project before MOI sign-off.
              </p>
            </div>
            <span className="text-xs font-extrabold px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full">
              6 of 6 Verified (100% Pass)
            </span>
          </div>

          <div className="space-y-3">
            {checklist.map((item, idx) => (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  item.verified
                    ? 'bg-emerald-50/40 border-emerald-200'
                    : 'bg-rose-50/40 border-rose-200'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-white border border-slate-200">
                      Rule 0{idx + 1}
                    </span>
                    <h4 className="font-extrabold text-xs text-slate-900">{item.requirement}</h4>
                    <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                      item.verified ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium">{item.specification}</p>
                  <p className="text-[11px] text-slate-500">{item.notes}</p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <button
                    onClick={() => handleToggleChecklist(item.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      item.verified
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                        : 'bg-rose-600 text-white hover:bg-rose-700'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{item.verified ? 'Verified (Pass)' : 'Fail Check'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: ADD DSA */}
      {isAddDSAOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Submit New MOI-SSD DSA Application</h3>
              <button
                onClick={() => setIsAddDSAOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddDSA} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newDSA.projectName}
                  onChange={(e) => setNewDSA({ ...newDSA, projectName: e.target.value })}
                  placeholder="e.g. West Bay Hotel CCTV Security Package"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                  <input
                    type="text"
                    required
                    value={newDSA.clientName}
                    onChange={(e) => setNewDSA({ ...newDSA, clientName: e.target.value })}
                    placeholder="e.g. Qatar Hospitality Group"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Total Camera Channels</label>
                  <input
                    type="number"
                    required
                    value={newDSA.cameraCount}
                    onChange={(e) => setNewDSA({ ...newDSA, cameraCount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">MOI Portal Reference Code</label>
                <input
                  type="text"
                  required
                  value={newDSA.moiReference}
                  onChange={(e) => setNewDSA({ ...newDSA, moiReference: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddDSAOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save DSA Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD DIA */}
      {isAddDIAOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Request MOI DIA Site Inspection</h3>
              <button
                onClick={() => setIsAddDIAOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddDIA} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newDIA.projectName}
                  onChange={(e) => setNewDIA({ ...newDIA, projectName: e.target.value })}
                  placeholder="e.g. Hamad Port Logistics Hub Cold Storage"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Linked DSA Approval Ref</label>
                  <input
                    type="text"
                    required
                    value={newDIA.dsaApprovalRef}
                    onChange={(e) => setNewDIA({ ...newDIA, dsaApprovalRef: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    required
                    value={newDIA.scheduledInspectionDate}
                    onChange={(e) => setNewDIA({ ...newDIA, scheduledInspectionDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddDIAOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Schedule Inspection Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
