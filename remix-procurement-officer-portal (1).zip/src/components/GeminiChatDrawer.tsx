import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  X,
  RotateCcw,
  Copy,
  Check,
  ShieldCheck,
  Scale,
  DollarSign,
  Cpu,
  Maximize2,
  Minimize2,
  ChevronDown,
  Paperclip,
  ArrowRight,
  AlertCircle,
  Lightbulb,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  modelUsed?: string;
}

interface GeminiChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeContext?: any;
  contextTitle?: string;
}

export const GeminiChatDrawer: React.FC<GeminiChatDrawerProps> = ({
  isOpen,
  onClose,
  activeContext,
  contextTitle = 'General Procurement State',
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'model',
      text: `👋 **Marhaba! I am your Gemini ERP & Security Systems AI Assistant.**

I'm grounded in Qatar ELV procurement, **MOI-SSD** standards, Project Management, Sales BPs, and financial reconciliation. 

How can I assist you today?
* 📊 **Analyze vendor quotation variance** & identify target savings
* 📝 **Draft supplier counter-offers** & payment term adjustments
* 🛡️ **Check MOI-SSD CCTV compliance** (storage retention, camera resolutions)
* 💡 **Value-engineer security BOQs** & suggest approved Qatar alternatives
* 🚀 **Draft client sales proposals** & project milestone plans`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: 'gemini-3.7-flash',
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<
    'procurement_officer' | 'moi_compliance' | 'negotiation_strategist' | 'value_engineer' | 'sales_director' | 'project_manager' | 'amc_engineer' | 'financial_controller'
  >('procurement_officer');
  const [selectedModel, setSelectedModel] = useState<'gemini-3.7-flash' | 'gemini-3.1-flash-lite' | 'gemini-flash-latest'>('gemini-3.7-flash');
  const [attachContext, setAttachContext] = useState(true);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputMessage.trim();
    if (!query || isLoading) return;

    const userMsgId = `user-${Date.now()}`;
    const newUserMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedHistory = [...messages, newUserMsg];
    setMessages(updatedHistory);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Prepare message history payload for multi-turn chat
      const historyPayload = updatedHistory
        .filter((m) => m.id !== 'welcome-1') // exclude initial welcome message if preferred or keep
        .map((m) => ({
          role: m.role,
          text: m.text,
        }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historyPayload.slice(0, -1), // previous history
          message: query, // current turn
          model: selectedModel,
          role: selectedRole,
          projectContext: attachContext ? activeContext : undefined,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      const modelMsgId = `model-${Date.now()}`;
      const newModelMsg: ChatMessage = {
        id: modelMsgId,
        role: 'model',
        text: data.reply || 'No response received from Gemini.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.model || selectedModel,
      };

      setMessages((prev) => [...prev, newModelMsg]);
    } catch (err: any) {
      const errorMsgId = `err-${Date.now()}`;
      const errorMsg: ChatMessage = {
        id: errorMsgId,
        role: 'model',
        text: `⚠️ **Error communicating with Gemini AI:**\n\n${err.message || 'Please check that GEMINI_API_KEY is configured in Settings > Secrets and try again.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: selectedModel,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'model',
        text: `🧹 Conversation cleared. Ready for a new query! Select a role or model above if needed.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: selectedModel,
      },
    ]);
  };

  const quickPrompts = [
    { label: '📊 Analyze Quote Disparities', prompt: 'Analyze the current vendor quotation bids. Highlight price variances against target BOQ budgets, fastest delivery times, and evaluate payment term cash flow exposure.' },
    { label: '📝 Draft 10% Counter-Offer', prompt: 'Draft a formal commercial counter-offer letter in QAR requesting a 10% discount from the lowest bidder, plus requesting 45 days credit terms instead of upfront advance payment.' },
    { label: '🛡️ MOI-SSD 120-Day Storage Check', prompt: 'Summarize the Qatar MOI-SSD CCTV video storage retention guidelines. How do we calculate SAN capacity for 120 days at 25fps with H.265 compression for 150 cameras?' },
    { label: '💡 Uniview vs Hikvision Comparison', prompt: 'Compare Hikvision and Uniview (UNV) for Qatar residential compound security projects. Outline MOI approval status, price differences, warranty terms, and local distributor support.' },
  ];

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-y-0 right-0 z-50 flex flex-col bg-white shadow-2xl border-l border-slate-200 transition-all duration-300 ${
        isExpanded ? 'w-full md:w-[760px]' : 'w-full md:w-[480px]'
      }`}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 border-b border-indigo-950/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5 text-emerald-300 animate-pulse" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 border-2 border-slate-900 rounded-full" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm tracking-tight text-white">Gemini Procurement Copilot</h3>
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-400/30">
                AI Powered
              </span>
            </div>
            <p className="text-xs text-slate-300">Qatar BOQ & Vendor Commercial Intelligence</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            title={isExpanded ? 'Minimize width' : 'Expand width'}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={handleClearHistory}
            title="Clear conversation"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            title="Close Assistant"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Control Bar: Persona Role & Model Selection */}
      <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* Role Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-500 font-semibold">Persona:</span>
          <select
            value={selectedRole}
            onChange={(e: any) => setSelectedRole(e.target.value)}
            className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-800 font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer text-xs"
          >
            <option value="procurement_officer">👔 Senior Procurement Officer</option>
            <option value="moi_compliance">🛡️ MOI-SSD Compliance Auditor</option>
            <option value="negotiation_strategist">💼 Negotiation & Terms Strategist</option>
            <option value="value_engineer">💡 Value Engineering Consultant</option>
            <option value="sales_director">📈 Sales & Proposal Strategist</option>
            <option value="project_manager">🏗️ Project Site Operations Director</option>
            <option value="amc_engineer">🔧 AMC Support & SLA Diagnostic</option>
            <option value="financial_controller">💰 Financial Audit & 3-Way Reconciliation</option>
          </select>
        </div>

        {/* Model Switcher */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-500 font-semibold">Model:</span>
          <select
            value={selectedModel}
            onChange={(e: any) => setSelectedModel(e.target.value)}
            className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-800 font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer text-xs"
          >
            <option value="gemini-3.7-flash">Gemini 3.7 Flash (Default)</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Fast)</option>
            <option value="gemini-flash-latest">Gemini Flash Latest</option>
          </select>
        </div>
      </div>

      {/* Active Context Bar */}
      {activeContext && (
        <div className="bg-indigo-50/70 border-b border-indigo-100 px-4 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 overflow-hidden">
            <Paperclip className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span className="text-slate-600 truncate">
              Attached Context: <strong className="text-indigo-900">{contextTitle}</strong>
            </span>
          </div>
          <label className="flex items-center gap-1.5 cursor-pointer shrink-0 font-medium text-slate-700">
            <input
              type="checkbox"
              checked={attachContext}
              onChange={(e) => setAttachContext(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
            />
            <span>Include in prompt</span>
          </label>
        </div>
      )}

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-100/60">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                  isUser
                    ? 'bg-slate-800 text-white'
                    : 'bg-gradient-to-br from-indigo-600 to-indigo-800 text-white'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 shadow-2xs relative group ${
                  isUser
                    ? 'bg-slate-900 text-white rounded-tr-xs'
                    : 'bg-white text-slate-800 border border-slate-200/90 rounded-tl-xs'
                }`}
              >
                {/* Header Info */}
                <div className="flex items-center justify-between gap-4 mb-1.5 text-[11px] opacity-70">
                  <span className="font-bold">
                    {isUser ? 'You' : 'Gemini AI Assistant'}
                  </span>
                  <div className="flex items-center gap-2">
                    {msg.modelUsed && !isUser && (
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">
                        {msg.modelUsed}
                      </span>
                    )}
                    <span>{msg.timestamp}</span>
                  </div>
                </div>

                {/* Body Content */}
                <div
                  className={`text-xs leading-relaxed space-y-2 prose-xs ${
                    isUser
                      ? 'text-slate-100'
                      : 'text-slate-800 [&_ul]:list-disc [&_ul]:pl-4 [&_ol]:list-decimal [&_ol]:pl-4 [&_strong]:text-slate-950 [&_table]:w-full [&_table]:border [&_table]:border-slate-200 [&_th]:bg-slate-100 [&_th]:p-1.5 [&_td]:p-1.5 [&_td]:border-t [&_td]:border-slate-200'
                  }`}
                >
                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                </div>

                {/* Copy Button on Hover */}
                {!isUser && (
                  <button
                    onClick={() => handleCopyText(msg.id, msg.text)}
                    className="absolute bottom-2 right-2 p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                    title="Copy to clipboard"
                  >
                    {copiedMessageId === msg.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs p-3.5 shadow-2xs flex items-center gap-2 text-xs text-slate-500">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" />
              </div>
              <span className="font-medium">Gemini is reasoning over procurement data...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="bg-white border-t border-slate-200 px-4 py-2 overflow-x-auto flex items-center gap-2 no-scrollbar">
        <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500 shrink-0">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
          <span>Quick:</span>
        </div>
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(qp.prompt)}
            disabled={isLoading}
            className="text-[11px] font-semibold bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 transition shrink-0 cursor-pointer disabled:opacity-50"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <div className="p-4 bg-white border-t border-slate-200">
        <div className="relative rounded-2xl border border-slate-300 focus-within:border-indigo-600 focus-within:ring-2 focus-within:ring-indigo-100 bg-slate-50 transition">
          <textarea
            ref={inputRef}
            rows={2}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Ask Gemini about BOQs, quotes, MOI-SSD specs, or negotiations... (Enter to send)`}
            disabled={isLoading}
            className="w-full bg-transparent px-3.5 pt-3 pb-10 text-xs text-slate-900 focus:outline-none resize-none placeholder:text-slate-400"
          />

          <div className="absolute bottom-2.5 left-3.5 right-3 flex items-center justify-between">
            <span className="text-[10px] text-slate-400">
              Shift + Enter for new line • Grounded in Qatar Procurement
            </span>

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputMessage.trim() || isLoading}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white p-2 rounded-xl transition cursor-pointer disabled:cursor-not-allowed shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
