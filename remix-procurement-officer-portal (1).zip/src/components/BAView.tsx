import React from 'react';
import { EditableTable, ColumnDef } from './EditableTable';
import { LeadRecord, LeadConversionRate, VisitScheduling, BOQRecord, ProcurementAssignment, DropdownMaster } from '../types';
import { TrendingUp, Target, Calendar, FileSpreadsheet, CheckSquare } from 'lucide-react';

interface BAViewProps {
  leads: LeadRecord[];
  conversions: LeadConversionRate[];
  visits: VisitScheduling[];
  boqs: BOQRecord[];
  procurementAssignments: ProcurementAssignment[];
  dropdowns: DropdownMaster[];
  onUpdateLeads: (data: LeadRecord[]) => void;
  onUpdateConversions: (data: LeadConversionRate[]) => void;
  onUpdateVisits: (data: VisitScheduling[]) => void;
  onUpdateBOQs: (data: BOQRecord[]) => void;
  onUpdateProcurementAssignments: (data: ProcurementAssignment[]) => void;
  onOpenQuickAdd: () => void;
}

export const BAView: React.FC<BAViewProps> = ({
  leads,
  conversions,
  visits,
  boqs,
  procurementAssignments,
  dropdowns,
  onUpdateLeads,
  onUpdateConversions,
  onUpdateVisits,
  onUpdateBOQs,
  onUpdateProcurementAssignments,
  onOpenQuickAdd,
}) => {
  const getDropdownOptions = (catName: string) => {
    const found = dropdowns.find((d) => d.categoryName.toLowerCase().includes(catName.toLowerCase()));
    return found ? found.options : [];
  };

  // Lead Columns
  const leadCols: ColumnDef[] = [
    { key: 'id', label: 'Lead ID', type: 'readonly' },
    { key: 'companyName', label: 'Company / Project', type: 'text' },
    { key: 'sourceType', label: 'Source', type: 'select', options: getDropdownOptions('Source Type') },
    { key: 'industry', label: 'Industry', type: 'text' },
    { key: 'sector', label: 'Sector', type: 'select', options: getDropdownOptions('Sectors') },
    { key: 'contactPerson', label: 'Contact', type: 'text' },
    { key: 'leadValue', label: 'Lead Value', type: 'currency' },
    { key: 'qualified', label: 'Qualified', type: 'select', options: ['Yes', 'No'] },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['New', 'In Progress', 'Under Preparation', 'Proposal Submitted', 'Negotiation', 'Won', 'Lost', 'On Hold'] },
    { key: 'stage', label: 'Stage', type: 'select', options: ['Lead Generation', 'Qualification', 'Assessment', 'Proposal', 'Negotiation', 'Closing', 'Won', 'Lost'] },
    { key: 'probability', label: 'Prob (%)', type: 'percent' },
    { key: 'expectedCloseDate', label: 'Close Date', type: 'date' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Conversion Rates Columns
  const conversionCols: ColumnDef[] = [
    { key: 'month', label: 'Month', type: 'text' },
    { key: 'totalLeads', label: 'Total Leads', type: 'number' },
    { key: 'qualifiedLeads', label: 'Qualified', type: 'number' },
    { key: 'proposalsSent', label: 'Proposals Sent', type: 'number' },
    { key: 'proposalsWon', label: 'Won', type: 'number' },
    { key: 'proposalsLost', label: 'Lost', type: 'number' },
    { key: 'conversionRate', label: 'Conversion %', type: 'percent', isFormula: true, formulaLabel: '=Won / TotalLeads' },
    { key: 'revenueGenerated', label: 'Revenue Generated', type: 'currency' },
    { key: 'targetConversionRate', label: 'Target %', type: 'percent' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Visit Scheduling Columns
  const visitCols: ColumnDef[] = [
    { key: 'visitId', label: 'Visit ID', type: 'readonly' },
    { key: 'projectLeadName', label: 'Project / Lead', type: 'text' },
    { key: 'visitType', label: 'Visit Type', type: 'select', options: getDropdownOptions('Visit Type') },
    { key: 'location', label: 'Location', type: 'text' },
    { key: 'visitDate', label: 'Visit Date', type: 'date' },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Pending', 'Completed', 'Rescheduled', 'Cancelled', 'In Progress'] },
    { key: 'siteSurveyComplete', label: 'Survey Complete', type: 'select', options: ['Yes', 'No'] },
    { key: 'dsaApprovalDate', label: 'DSA Approval', type: 'date' },
    { key: 'diaApprovalDate', label: 'DIA Approval', type: 'date' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // BOQ Columns
  const boqCols: ColumnDef[] = [
    { key: 'boqId', label: 'BOQ ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'clientName', label: 'Client', type: 'text' },
    { key: 'category', label: 'Category', type: 'select', options: getDropdownOptions('Categories') },
    { key: 'sector', label: 'Sector', type: 'select', options: getDropdownOptions('Sectors') },
    { key: 'boqValue', label: 'BOQ Value', type: 'currency' },
    { key: 'preparedBy', label: 'Prepared By', type: 'text' },
    { key: 'approvedBy', label: 'Approved By', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Draft', 'In Progress', 'Under Review', 'Approved', 'Rejected', 'On Hold'] },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Procurement Assignment Columns
  const procAssignCols: ColumnDef[] = [
    { key: 'id', label: 'Assign ID', type: 'readonly' },
    { key: 'boqId', label: 'BOQ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'assignedTo', label: 'Assigned Officer', type: 'text' },
    { key: 'dateAssigned', label: 'Date Assigned', type: 'date' },
    { key: 'quoteDueDate', label: 'Due Date', type: 'date' },
    { key: 'quoteValue', label: 'Quote Value', type: 'currency' },
    { key: 'status', label: 'Status', type: 'select', options: ['Pending', 'In Progress', 'Completed', 'On Hold', 'Cancelled'] },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  const totalPipelineVal = leads.reduce((sum, l) => sum + (Number(l.leadValue) || 0), 0);
  const qualifiedLeads = leads.filter((l) => l.qualified === 'Yes').length;

  return (
    <div className="space-y-6 pb-8">
      {/* Small Dashboard Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-5 h-5 text-indigo-600" />
          <h2 className="font-bold text-slate-900 text-lg tracking-tight">Business Analyst Master Sheet</h2>
          <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
            Leads, Conversion Rates, Visits, BOQs & Procurement Assignments
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Leads Captured</p>
            <p className="text-xl font-black text-slate-900">{leads.length} Leads</p>
            <p className="text-[10px] text-slate-500 mt-0.5">{qualifiedLeads} Qualified Opportunities</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Pipeline Value</p>
            <p className="text-xl font-black font-mono text-indigo-600">QAR {totalPipelineVal.toLocaleString()}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Ezdan, KPOI & Argentine</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Site Visits & ELV Surveys</p>
            <p className="text-xl font-black text-slate-900">{visits.length} Scheduled Visits</p>
            <p className="text-[10px] text-emerald-600 font-semibold mt-0.5">DSA & DIA Checks Included</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">BOQs Generated</p>
            <p className="text-xl font-black text-slate-900">{boqs.length} BOQ Specs</p>
            <p className="text-[10px] text-slate-500 mt-0.5">{procurementAssignments.length} Assigned to Procurement</p>
          </div>
        </div>
      </div>

      {/* Table 1: Leads Sources */}
      <EditableTable
        title="Leads Sources & Pipeline Tracking"
        subtitle="Track incoming leads, industry sectors, probability %, stage & expected close dates"
        columns={leadCols}
        data={leads}
        onUpdateData={onUpdateLeads}
        onAddRow={onOpenQuickAdd}
        badge="Table 1"
      />

      {/* Table 2: Monthly Lead Conversion Rates */}
      <EditableTable
        title="Monthly Lead Conversion & Revenue Tracking"
        subtitle="Track total vs qualified leads, sent proposals, won/lost metrics and target benchmarks"
        columns={conversionCols}
        data={conversions}
        onUpdateData={onUpdateConversions}
        badge="Table 2"
        badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
      />

      {/* Table 3: Visit Scheduling (ELV / DIA / DSA) */}
      <EditableTable
        title="Visit Scheduling & Site Audits (ELV, DIA & DSA)"
        subtitle="Schedule site surveys, DSA approvals and MOI DIA inspections with site engineers"
        columns={visitCols}
        data={visits}
        onUpdateData={onUpdateVisits}
        badge="Table 3"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />

      {/* Table 4: BOQ Management */}
      <EditableTable
        title="BOQ Management Table"
        subtitle="Master BOQ estimates, categories, preparation dates and CEO approval status"
        columns={boqCols}
        data={boqs}
        onUpdateData={onUpdateBOQs}
        badge="Table 4"
        badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
      />

      {/* Table 5: Procurement Assignments */}
      <EditableTable
        title="Procurement Team Quotation Assignments"
        subtitle="Assign BOQs to procurement officers (Syed Khaleel, Ahtasham Ali) for supplier quotes"
        columns={procAssignCols}
        data={procurementAssignments}
        onUpdateData={onUpdateProcurementAssignments}
        badge="Table 5"
        badgeColor="bg-amber-50 text-amber-700 border-amber-200"
      />
    </div>
  );
};
