import React from 'react';
import { EditableTable, ColumnDef } from './EditableTable';
import { EmployeeRecord, SalaryBracket, EmployeeBenefit, EmployeeContract, DropdownMaster } from '../types';
import { Users, DollarSign, FileText, HeartHandshake } from 'lucide-react';

interface HRViewProps {
  employees: EmployeeRecord[];
  salaryBrackets: SalaryBracket[];
  benefits: EmployeeBenefit[];
  contracts: EmployeeContract[];
  dropdowns: DropdownMaster[];
  onUpdateEmployees: (data: EmployeeRecord[]) => void;
  onUpdateSalaryBrackets: (data: SalaryBracket[]) => void;
  onUpdateBenefits: (data: EmployeeBenefit[]) => void;
  onUpdateContracts: (data: EmployeeContract[]) => void;
  onOpenQuickAdd: () => void;
}

export const HRView: React.FC<HRViewProps> = ({
  employees,
  salaryBrackets,
  benefits,
  contracts,
  dropdowns,
  onUpdateEmployees,
  onUpdateSalaryBrackets,
  onUpdateBenefits,
  onUpdateContracts,
  onOpenQuickAdd,
}) => {
  const getDropdownOptions = (catName: string) => {
    const found = dropdowns.find((d) => d.categoryName.toLowerCase().includes(catName.toLowerCase()));
    return found ? found.options : [];
  };

  // Employee Record Columns
  const employeeCols: ColumnDef[] = [
    { key: 'id', label: 'Emp ID', type: 'readonly' },
    { key: 'name', label: 'Employee Name', type: 'text' },
    { key: 'designation', label: 'Designation', type: 'text' },
    { key: 'department', label: 'Department', type: 'select', options: getDropdownOptions('Departments') },
    { key: 'dateOfJoining', label: 'Date of Joining', type: 'date' },
    { key: 'employmentType', label: 'Type', type: 'select', options: getDropdownOptions('Employment Type') },
    { key: 'nationality', label: 'Nationality', type: 'select', options: getDropdownOptions('Nationality') },
    { key: 'contactNumber', label: 'Phone', type: 'text' },
    { key: 'email', label: 'Email', type: 'text' },
    { key: 'passportNo', label: 'Passport No.', type: 'text' },
    { key: 'qidNo', label: 'QID No.', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive', 'On Leave', 'Terminated', 'Resigned'] },
  ];

  // Salary Brackets Columns with Formula recalculations
  const salaryCols: ColumnDef[] = [
    { key: 'employeeId', label: 'Emp ID', type: 'readonly' },
    { key: 'employeeName', label: 'Employee Name', type: 'text' },
    { key: 'designation', label: 'Designation', type: 'text' },
    { key: 'basicSalary', label: 'Basic Salary', type: 'currency' },
    { key: 'housingAllowance', label: 'Housing Allw.', type: 'currency' },
    { key: 'transportAllowance', label: 'Transport Allw.', type: 'currency' },
    { key: 'totalAllowances', label: 'Total Allowances', type: 'currency', isFormula: true, formulaLabel: '=Housing+Transport+Other' },
    { key: 'grossSalary', label: 'Gross Salary', type: 'currency', isFormula: true, formulaLabel: '=Basic+TotalAllowances' },
    { key: 'socialSecurity', label: 'Social Sec.', type: 'currency' },
    { key: 'healthInsurance', label: 'Health Ins.', type: 'currency' },
    { key: 'totalBenefits', label: 'Total Benefits', type: 'currency', isFormula: true, formulaLabel: '=SocSec+Health+Life' },
    { key: 'netSalary', label: 'Net Salary', type: 'currency', isFormula: true, formulaLabel: '=Gross - Benefits' },
    { key: 'annualPackage', label: 'Annual Package', type: 'currency', isFormula: true, formulaLabel: '=Net * 12' },
    { key: 'nextReviewDate', label: 'Next Review', type: 'date' },
  ];

  // Benefits Columns
  const benefitCols: ColumnDef[] = [
    { key: 'id', label: 'Benefit ID', type: 'readonly' },
    { key: 'benefitName', label: 'Benefit Name', type: 'text' },
    { key: 'description', label: 'Description', type: 'text' },
    { key: 'applicableTo', label: 'Applicable To', type: 'text' },
    { key: 'coverageAmount', label: 'Coverage Amount', type: 'currency' },
    { key: 'monthlyCost', label: 'Monthly Cost', type: 'currency' },
    { key: 'annualCost', label: 'Annual Cost', type: 'currency', isFormula: true, formulaLabel: '=Monthly * 12' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive'] },
  ];

  // Contract Columns
  const contractCols: ColumnDef[] = [
    { key: 'contractId', label: 'Contract ID', type: 'readonly' },
    { key: 'employeeId', label: 'Emp ID', type: 'text' },
    { key: 'employeeName', label: 'Employee Name', type: 'text' },
    { key: 'contractType', label: 'Contract Type', type: 'select', options: getDropdownOptions('Employment Type') },
    { key: 'startDate', label: 'Start Date', type: 'date' },
    { key: 'endDate', label: 'End Date', type: 'date' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Expired', 'Terminated', 'Under Review', 'Pending Renewal'] },
    { key: 'probationPeriod', label: 'Probation', type: 'text' },
    { key: 'revisionNo', label: 'Revision #', type: 'text' },
    { key: 'approvedBy', label: 'Approved By', type: 'text' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Auto-recalculate Salary Brackets on edit
  const handleSalaryUpdate = (updatedSalaryData: SalaryBracket[]) => {
    const recalculated = updatedSalaryData.map((row) => {
      const basic = Number(row.basicSalary) || 0;
      const housing = Number(row.housingAllowance) || 0;
      const transport = Number(row.transportAllowance) || 0;
      const other = Number(row.otherAllowances) || 0;
      const totalAllw = housing + transport + other;
      const gross = basic + totalAllw;

      const soc = Number(row.socialSecurity) || 0;
      const health = Number(row.healthInsurance) || 0;
      const life = Number(row.lifeInsurance) || 0;
      const totBen = soc + health + life;

      const net = gross - totBen;
      const annual = net * 12;

      return {
        ...row,
        totalAllowances: totalAllw,
        grossSalary: gross,
        totalBenefits: totBen,
        netSalary: net,
        annualPackage: annual,
      };
    });

    onUpdateSalaryBrackets(recalculated);
  };

  const totalMonthlyPayroll = salaryBrackets.reduce((sum, s) => sum + (s.grossSalary || 0), 0);
  const activeContracts = contracts.filter((c) => c.status === 'Active').length;

  return (
    <div className="space-y-6 pb-8">
      {/* Small Dashboard Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-3">
          <Users className="w-5 h-5 text-indigo-600" />
          <h2 className="font-bold text-slate-900 text-lg tracking-tight">Human Resources Master Sheet</h2>
          <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
            Recruitment, Salary Brackets, Benefits & Contracts
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Employees</p>
            <p className="text-xl font-black text-slate-900">{employees.length} Staff Members</p>
            <p className="text-[10px] text-slate-500 mt-0.5">8 Departments Active</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Monthly Gross Payroll</p>
            <p className="text-xl font-black font-mono text-indigo-600">QAR {totalMonthlyPayroll.toLocaleString()}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Calculated from Salary Brackets</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Active Contracts</p>
            <p className="text-xl font-black text-emerald-600">{activeContracts} / {contracts.length} Active</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Permanent & Fixed Term</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Employee Benefits</p>
            <p className="text-xl font-black text-slate-900">{benefits.length} Benefits Active</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Health, Life & Air Ticket</p>
          </div>
        </div>
      </div>

      {/* Table 1: Employee Records */}
      <EditableTable
        title="Employee Records Master List"
        subtitle="Full employee roster, contact info, QID, passport, and employment classification"
        columns={employeeCols}
        data={employees}
        onUpdateData={onUpdateEmployees}
        onAddRow={onOpenQuickAdd}
        badge="Table 1"
      />

      {/* Table 2: Salary Brackets Calculation Sheet */}
      <EditableTable
        title="Salary Brackets & Payroll Calculation Sheet"
        subtitle="Automated calculations: Allowances = Housing+Transport, Gross = Basic+Allowances, Net = Gross - Benefits"
        columns={salaryCols}
        data={salaryBrackets}
        onUpdateData={handleSalaryUpdate}
        badge="Table 2"
        badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
      />

      {/* Table 3: Employee Benefits */}
      <EditableTable
        title="Employee Benefits Master List"
        subtitle="Comprehensive medical, life insurance and travel allowance coverage caps"
        columns={benefitCols}
        data={benefits}
        onUpdateData={onUpdateBenefits}
        badge="Table 3"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />

      {/* Table 4: Contracts & Revisions */}
      <EditableTable
        title="Employee Contracts & Revision History"
        subtitle="Employment terms, probation periods, salary revision logs (R1...Rn) and board approvals"
        columns={contractCols}
        data={contracts}
        onUpdateData={onUpdateContracts}
        badge="Table 4"
        badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
      />
    </div>
  );
};
