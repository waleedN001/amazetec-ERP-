import React, { useState, useMemo } from 'react';
import {
  FileText,
  Download,
  Printer,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Camera,
  Server,
  Cpu,
  HardDrive,
  Monitor,
  Wifi,
  Wrench,
  BatteryCharging,
  Layers,
  ChevronDown,
  ChevronUp,
  X,
  Sparkles,
  Save,
  Search,
  RefreshCw,
  Info,
  Check
} from 'lucide-react';
import * as XLSX from 'xlsx';

export interface QuotationLineItem {
  id: string;
  sNo: number;
  section: string;
  modelBrand: string;
  imageUrl?: string;
  itemType?: 'camera' | 'ptz' | 'storage' | 'server' | 'monitor' | 'anpr' | 'switch' | 'passive' | 'ups' | 'access' | 'services' | 'general';
  description: string;
  unit: string;
  qty: number;
  unitPriceQAR: number;
}

// Pre-populated initial quotation data extracted directly from the official Qatar sample document
export const sampleOfficialQuotationData: QuotationLineItem[] = [
  // DOME AND BULLET CAMERAS - AUTO-IRIS
  {
    id: 'q-1',
    sNo: 1,
    section: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
    modelBrand: 'DS-2CD3743G2-IZSK(2.7-13.5mm)',
    itemType: 'camera',
    description: '4 MP Varifocal Dome Network Camera,2.7 to 13.5 mm motorized varifocal lens,Up to 40 m IR,IP120 db IP67,IK10,Auto-iris (Junction box is not included)(MOI-SSD Approved,3 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 320,
    unitPriceQAR: 406.00,
  },
  {
    id: 'q-2',
    sNo: 2,
    section: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
    modelBrand: 'Hikvision',
    itemType: 'general',
    description: 'Dome Camera Bracket',
    unit: 'Nos.',
    qty: 320,
    unitPriceQAR: 45.00,
  },
  {
    id: 'q-3',
    sNo: 3,
    section: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
    modelBrand: 'DS-2CD3643G2-IZSK(2.7-13.5mm)',
    itemType: 'camera',
    description: '4 MP Bullet Camera,2.7 to 13.5 mm motorized varifocal lens,up to 60m IR,IP67,IK10,120dB WDR,Auto-iris (Junction box is not included)(MOI-SSD Approved,3 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 50,
    unitPriceQAR: 406.00,
  },
  {
    id: 'q-4',
    sNo: 4,
    section: 'DOME AND BULLET CAMERAS - AUTO-IRIS',
    modelBrand: 'Hikvision',
    itemType: 'general',
    description: 'Junction Box Bullet Camera',
    unit: 'Nos.',
    qty: 50,
    unitPriceQAR: 36.00,
  },

  // PTZ CAMERAS
  {
    id: 'q-5',
    sNo: 5,
    section: 'PTZ CAMERAS',
    modelBrand: 'DS-2DE5425W-AE',
    itemType: 'ptz',
    description: '4MP PTZ Camera, 25x optical zoom, 16x digital zoom, 120dB WDR, IP66, IK10 (MOI-SSD Approved, 2 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 4,
    unitPriceQAR: 1441.00,
  },
  {
    id: 'q-6',
    sNo: 6,
    section: 'PTZ CAMERAS',
    modelBrand: '-',
    itemType: 'general',
    description: 'Bracket for PTZ Camera',
    unit: 'Included',
    qty: 4,
    unitPriceQAR: 0.00,
  },
  {
    id: 'q-7',
    sNo: 7,
    section: 'PTZ CAMERAS',
    modelBrand: 'DS-1005KI',
    itemType: 'ptz',
    description: 'USB Joystick Keyboard, USB port, used to control DVR, NVR and software, 3-axis joystick.',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 733.00,
  },

  // STORAGE
  {
    id: 'q-8',
    sNo: 8,
    section: 'STORAGE',
    modelBrand: 'DS-A80248SI',
    itemType: 'storage',
    description: 'HIKVISION 48-slot Single Controller Storage(MOI-SSD Approved, 3 Years Standard Warranty)(Use only HIKVISION recommended HDDs)',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 28105.00,
  },
  {
    id: 'q-9',
    sNo: 9,
    section: 'STORAGE',
    modelBrand: 'Seagate/ Equal',
    itemType: 'storage',
    description: '16TB HDD for NVR, Enterprise level (2-Years Standard Warranty - MOI Approved)',
    unit: 'Nos.',
    qty: 111,
    unitPriceQAR: 2805.00,
  },

  // FAILOVER STORAGE
  {
    id: 'q-10',
    sNo: 10,
    section: 'FAILOVER STORAGE',
    modelBrand: 'DS-A80248SI',
    itemType: 'storage',
    description: 'HIKVISION 48-slot Single Controller Storage(MOI-SSD Approved, 3 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 28105.00,
  },
  {
    id: 'q-11',
    sNo: 11,
    section: 'FAILOVER STORAGE',
    modelBrand: 'Seagate/ Equal',
    itemType: 'storage',
    description: '16TB HDD for NVR, Enterprise level (2-Years Standard Warranty - MOI Approved)',
    unit: 'Nos.',
    qty: 13,
    unitPriceQAR: 2805.00,
  },

  // VMS AND SERVER
  {
    id: 'q-12',
    sNo: 12,
    section: 'VMS AND SERVER',
    modelBrand: 'HikCentral-P-VSS-Base/300Ch',
    itemType: 'server',
    description: 'HikCentral video surveillance base package for 300 cameras management, 3 years free Software Upgrade Period (Sold by key)',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 23710.00,
  },
  {
    id: 'q-13',
    sNo: 13,
    section: 'VMS AND SERVER',
    modelBrand: 'HikCentral-P-VSS-1Ch',
    itemType: 'server',
    description: 'Extra 1 Camera License, 1 camera connection license in HikCentral Professional software.',
    unit: 'Nos.',
    qty: 102,
    unitPriceQAR: 116.00,
  },
  {
    id: 'q-14',
    sNo: 14,
    section: 'VMS AND SERVER',
    modelBrand: 'DS-VE11-R/HW1D',
    itemType: 'server',
    description: 'VMS Server-less than 800Ch, E-2434/1x16GB DDR5/1*1.27 2K SATAx2(RAID_1)/1GbEx2/600W(Dual power)/R360/1U/No win/win server 2019/3 years global platform service',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 24035.00,
  },
  {
    id: 'q-15',
    sNo: 15,
    section: 'VMS AND SERVER',
    modelBrand: 'DS-VE11-R/HW1D',
    itemType: 'server',
    description: 'VMS Server-less than 800Ch, E-2434/1x16GB DDR5/1*1.27 2K SATAx2(RAID_1)/1GbEx2/600W(Dual power)/R360/1U/No win/win server 2019/3 years global platform service',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 24035.00,
  },
  {
    id: 'q-16',
    sNo: 16,
    section: 'VMS AND SERVER',
    modelBrand: 'Rose Replicator Plus 3 years',
    itemType: 'server',
    description: 'ROSE REPLICATOR',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 12820.00,
  },

  // WORKSTATION AND MONITORS
  {
    id: 'q-17',
    sNo: 17,
    section: 'WORKSTATION AND MONITORS',
    modelBrand: 'DS-D5043FL',
    itemType: 'monitor',
    description: '43" LED Monitor, 1080P, HDMI/VGA/DVI/BNC input, build-in speaker, view angle:178°/178°, plastic casing(1 Year Standard Warranty)(MOI-SSD Approved, 1 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 6,
    unitPriceQAR: 1119.00,
  },
  {
    id: 'q-18',
    sNo: 18,
    section: 'WORKSTATION AND MONITORS',
    modelBrand: 'DP-DS01940',
    itemType: 'general',
    description: 'Monitor Brackets > 40-inch, Wall-mounted bracket, Dimension 450 mm x 420 mm x 25mm, VESA 400 (H) mm x 400 (V) mm, recommended for larger size monitor (> 40-inch)',
    unit: 'Nos.',
    qty: 6,
    unitPriceQAR: 40.00,
  },
  {
    id: 'q-19',
    sNo: 19,
    section: 'WORKSTATION AND MONITORS',
    modelBrand: 'DS-D5024F2-1P2',
    itemType: 'monitor',
    description: '23.8" 1080P, HDMI/VGA input, view angle:178°/178°, plastic casing, VESA, base bracket included, 7*24h (MOI-SSD Approved, 1-Years Standard Warranty).',
    unit: 'Nos.',
    qty: 4,
    unitPriceQAR: 372.00,
  },
  {
    id: 'q-20',
    sNo: 20,
    section: 'WORKSTATION AND MONITORS',
    modelBrand: 'DELL OPTIPLEX TOWER 7010(32 GB RAM)',
    itemType: 'server',
    description: 'Dell Pro Tower QCT1250 Intel Core i7-14700 (20 cores, up to 5.4GHz) 16GB, DDR5, up to 5600 MT/s, non-ECC 512GB SSD 2280 M.2, 8 gb graphics card Intel(R) Wi-Fi 6E AX211, 2x2, 802.11ax, Bluetooth(R) wireless card Dell Wired Keyboard - KB216 - Arabic (QWERTY) - Black, Dell Wired Mouse - MS116 - Black Internal speaker, 8x DVD+/-RW/RAM 9.5mm Slimline Optical Disk Drive, 360W Platinum PSU Dos, 1 Year Warranty',
    unit: 'Nos.',
    qty: 5,
    unitPriceQAR: 5445.00,
  },
  {
    id: 'q-21',
    sNo: 21,
    section: 'WORKSTATION AND MONITORS',
    modelBrand: '-',
    itemType: 'general',
    description: 'DP to HDMI Cable',
    unit: 'Nos.',
    qty: 5,
    unitPriceQAR: 66.00,
  },

  // ANPR SYSTEM
  {
    id: 'q-22',
    sNo: 22,
    section: 'ANPR SYSTEM',
    modelBrand: 'iDS-2CD7A46G0/P-IZHS(2.8-12mm)',
    itemType: 'anpr',
    description: '4MP ANPR Camera- IR Light Darkfighter Ultra-low light technology, 1/1.8" Progressive Scan CMOS, ICR, Color: 0.0005 Lux/F1.2 B/W: 0.0003 Lux/F1.2 4MP 25fps/30fps H.265+/H.265/H.264+/H.264, 140dB WDR 1*AudioOut,1*AudioIn-y (Support 1*Wiegand-(Y Support) 2*AlarmIn, 2*AlarmOut 5streams+5custom streams IP67 IK10 ANPR base in deeplearning technology. (MOI-SSD Approved,2 Years Standard Warranty).',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 2079.00,
  },
  {
    id: 'q-24',
    sNo: 24,
    section: 'ANPR SYSTEM',
    modelBrand: 'DS-1475ZJ-SUS',
    itemType: 'general',
    description: 'Vertical Pole Mounted Bracket',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 88.00,
  },
  {
    id: 'q-25',
    sNo: 25,
    section: 'ANPR SYSTEM',
    modelBrand: 'HikCentral-P-VSS/Base',
    itemType: 'server',
    description: 'Hikvision ANPR VMS - HikCentral Base License',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 165.00,
  },
  {
    id: 'q-26',
    sNo: 26,
    section: 'ANPR SYSTEM',
    modelBrand: 'HikCentral-P-VSS-1Ch/ANPR',
    itemType: 'server',
    description: 'ANPR License',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 451.00,
  },
  {
    id: 'q-27',
    sNo: 27,
    section: 'ANPR SYSTEM',
    modelBrand: 'DS-D5024F2-1P2(British Standard)',
    itemType: 'monitor',
    description: '24" Monitor - HIKVISION',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 372.00,
  },
  {
    id: 'q-28',
    sNo: 28,
    section: 'ANPR SYSTEM',
    modelBrand: 'DELL OPTIPLEX TOWER 7020(32 GB RAM)',
    itemType: 'server',
    description: 'Dell Pro Tower QCT1250 Intel Core i7-14700, 16GB, DDR5, 512GB SSD, 8GB GPU, Windows 11 Pro',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 5445.00,
  },
  {
    id: 'q-29',
    sNo: 29,
    section: 'ANPR SYSTEM',
    modelBrand: 'DS-9616NI-M8',
    itemType: 'storage',
    description: '16 CH NVR 256Mbps Bit Rate Input Max (up to 16-ch IP video), 16x4MP decoding capability, 8 SATA Interfaces, 2 HDMI outputs(up to 8K), 1 eSATA, 1 CVBS, alarm I/O: 16/9, 2U case,19" (MOI-SSD Approved, 1 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 2970.00,
  },
  {
    id: 'q-30',
    sNo: 30,
    section: 'ANPR SYSTEM',
    modelBrand: 'Seagate/ Equal',
    itemType: 'storage',
    description: '4 TB Enterprise HDD (MOI-SSD Approved, 1 Years Standard Warranty)',
    unit: 'Nos.',
    qty: 4,
    unitPriceQAR: 880.00,
  },

  // NETWORKSWITCHES
  {
    id: 'q-31',
    sNo: 31,
    section: 'NETWORKSWITCHES',
    modelBrand: 'DS-3E3728F-H',
    itemType: 'switch',
    description: 'HIKVISION 24 Port Fiber Core Switch, 24xSFP ports (including 8xcombo interfaces), 4x10G/1G Base-X SFP+ ports (MOI-SSD Approved Standard Warranty)',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 6160.00,
  },
  {
    id: 'q-32',
    sNo: 32,
    section: 'NETWORKSWITCHES',
    modelBrand: 'DS-3E0326P-E',
    itemType: 'switch',
    description: '24-ports 100Mbps PoE Switch, 2 gigabit combos Uplink Port, 370 W PoE power budget (MOI-SSD Approved, 1 Year Standard Warranty)',
    unit: 'Nos.',
    qty: 6,
    unitPriceQAR: 579.00,
  },
  {
    id: 'q-33',
    sNo: 33,
    section: 'NETWORKSWITCHES',
    modelBrand: 'DS-3T0510HP/No Power Unit',
    itemType: 'switch',
    description: 'L2, Unmanaged, 8 Gigabit PoE ports, 2 Gigabit SFP Uplink, 802.3af/at/bt, port 1-2 support Hi-PoE 60W, power budget 110W (based on power supply, power supply unit not included), ports 7-8 support up to 300meter, 6KV surge protection, supports PoE watchdog, port isolation, -40~75°C, DIN rail',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 275.00,
  },
  {
    id: 'q-34',
    sNo: 34,
    section: 'NETWORKSWITCHES',
    modelBrand: 'NDR-240-48',
    itemType: 'switch',
    description: 'AC/DC Power Supply, Output 48V-55V, 0-5A, 240watts, Input 90-264VAC, 127-370VDC, DIN rail, -20~70°C',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 225.00,
  },
  {
    id: 'q-35',
    sNo: 35,
    section: 'NETWORKSWITCHES',
    modelBrand: 'DS-3E1552P-SI',
    itemType: 'switch',
    description: '48 Port Gigabit Smart PoE Switch, 48 x Gigabit PoE Ports, 2 x gigabit RJ45, 2 x fiber optical ports, Total PoE Power Budget 470W (MOI-SSD Approved, 1 Year Standard Warranty)',
    unit: 'Nos.',
    qty: 9,
    unitPriceQAR: 1650.00,
  },

  // PASSIVE COMPONENTS
  {
    id: 'q-36',
    sNo: 36,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: '15U Cabinet Rack (MOI - Approved)',
    unit: 'Nos.',
    qty: 12,
    unitPriceQAR: 1155.00,
  },
  {
    id: 'q-37',
    sNo: 37,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: '42U Cabinet Rack (MOI - Approved)',
    unit: 'Nos.',
    qty: 1,
    unitPriceQAR: 2585.00,
  },
  {
    id: 'q-38',
    sNo: 38,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'ENCLOSURE 400x400x200',
    unit: 'Nos.',
    qty: 2,
    unitPriceQAR: 550.00,
  },
  {
    id: 'q-39',
    sNo: 39,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'POWER DISTRIBUTION UNIT (PDU) 6way UK',
    unit: 'Nos.',
    qty: 14,
    unitPriceQAR: 95.00,
  },
  {
    id: 'q-40',
    sNo: 40,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'Keystone Jack Cat6A',
    unit: 'Nos.',
    qty: 405,
    unitPriceQAR: 7.00,
  },
  {
    id: 'q-41',
    sNo: 41,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'RJ45 Connectors',
    unit: 'Nos.',
    qty: 405,
    unitPriceQAR: 0.60,
  },
  {
    id: 'q-42',
    sNo: 42,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'Cat6E cable should be HDPE LSZH Low Smoke Zero Halogen, Qatar Civil Defence Approved',
    unit: 'Roll',
    qty: 90,
    unitPriceQAR: 660.00,
  },
  {
    id: 'q-43',
    sNo: 43,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: 'PVC/GI Conduits & Accessories Containment System',
    unit: 'Lot',
    qty: 1,
    unitPriceQAR: 115000.00,
  },
  {
    id: 'q-44',
    sNo: 44,
    section: 'PASSIVE COMPONENTS',
    modelBrand: 'Netcon/ Equal',
    itemType: 'passive',
    description: '1U Cable Management Tray',
    unit: 'Nos.',
    qty: 16,
    unitPriceQAR: 39.00,
  },

  // UPS AND BATTERY
  {
    id: 'q-68',
    sNo: 68,
    section: 'UPS AND BATTERY',
    modelBrand: 'EVADA/ EQUAL',
    itemType: 'ups',
    description: '1KVA UPS with 6 in-Built Batteries & External 36V Rack Tower Battery Pack for 1000W - 60 Minutes Backup',
    unit: 'Set.',
    qty: 2,
    unitPriceQAR: 3520.00,
  },
  {
    id: 'q-69',
    sNo: 69,
    section: 'UPS AND BATTERY',
    modelBrand: 'EVADA/ EQUAL',
    itemType: 'ups',
    description: '1KVA UPS with 6 in-Built Batteries & External 36V Rack Tower Battery Pack for 500W - 60 Minutes Backup',
    unit: 'Set.',
    qty: 9,
    unitPriceQAR: 2200.00,
  },
  {
    id: 'q-70',
    sNo: 70,
    section: 'UPS AND BATTERY',
    modelBrand: 'EVADA/ EQUAL',
    itemType: 'ups',
    description: '10kva online single phase rm series ups with six external battery bank ASRM6K which can support one hour backup with 6000W load',
    unit: 'Set.',
    qty: 1,
    unitPriceQAR: 18700.00,
  },

  // ACCESS CONTROL SYSTEM
  {
    id: 'q-71',
    sNo: 71,
    section: 'ACCESS CONTROL SYSTEM',
    modelBrand: 'Hikvision/ Equal',
    itemType: 'access',
    description: 'Access Control Controller & Reader Kit with Magnetic Lock',
    unit: 'Set',
    qty: 12,
    unitPriceQAR: 352.00,
  },
];

interface OfficialQuotationViewProps {
  onClose?: () => void;
  initialItems?: QuotationLineItem[];
}

export const OfficialQuotationView: React.FC<OfficialQuotationViewProps> = ({
  onClose,
  initialItems,
}) => {
  const [items, setItems] = useState<QuotationLineItem[]>(initialItems && initialItems.length > 0 ? initialItems : sampleOfficialQuotationData);
  const [filterSection, setFilterSection] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Editable headers info
  const [quotationMeta, setQuotationMeta] = useState({
    projectName: 'QATAR COMMERCIAL CENTER ELV & SECURITY SYSTEM',
    clientName: 'AL AHMAD CONTRACTING & REAL ESTATE W.L.L',
    refNo: 'AMAZETEC/QT/2026/0812-MOI',
    date: '12-AUG-2026',
    preparedBy: 'ENG. WALEED AL-QATARI (PROCUREMENT DEPT)',
    moiStatus: 'MOI SSD Approved Project Specification',
  });

  // Calculate distinct sections
  const sections = useMemo(() => {
    const list = Array.from(new Set(items.map((i) => i.section)));
    return ['All', ...list];
  }, [items]);

  // Filtered Items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (filterSection !== 'All' && item.section !== filterSection) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const mBrand = item.modelBrand.toLowerCase().includes(q);
        const mDesc = item.description.toLowerCase().includes(q);
        const mSec = item.section.toLowerCase().includes(q);
        return mBrand || mDesc || mSec;
      }
      return true;
    });
  }, [items, filterSection, searchQuery]);

  // Group items by section
  const groupedSections = useMemo(() => {
    const map: Record<string, QuotationLineItem[]> = {};
    filteredItems.forEach((item) => {
      if (!map[item.section]) map[item.section] = [];
      map[item.section].push(item);
    });
    return map;
  }, [filteredItems]);

  // Totals calculation
  const grandTotalQAR = useMemo(() => {
    return items.reduce((sum, item) => sum + item.qty * item.unitPriceQAR, 0);
  }, [items]);

  const totalQtyCount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.qty, 0);
  }, [items]);

  // Handle cell edit
  const handleItemChange = (id: string, field: keyof QuotationLineItem, value: any) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }
        return item;
      })
    );
  };

  // Delete line item
  const handleDeleteItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Add new item
  const handleAddNewRow = (sectionName: string) => {
    const newId = `q-new-${Date.now()}`;
    const newItem: QuotationLineItem = {
      id: newId,
      sNo: items.length + 1,
      section: sectionName || 'GENERAL EQUIPMENT',
      modelBrand: 'Hikvision / Equal',
      description: 'New Qatar SSD Security Item Specification Description...',
      unit: 'Nos.',
      qty: 1,
      unitPriceQAR: 100.00,
    };
    setItems((prev) => [...prev, newItem]);
    setEditingId(newId);
  };

  // Export to official Excel spreadsheet matching Qatar BOQ format
  const handleExportExcel = () => {
    const exportRows: any[] = [];

    // Header info
    exportRows.push(['AMAZETEC MASTER ERP PORTAL - OFFICIAL BOQ QUOTATION (QATAR)']);
    exportRows.push([`PROJECT: ${quotationMeta.projectName}`]);
    exportRows.push([`CLIENT: ${quotationMeta.clientName}`, `REF: ${quotationMeta.refNo}`, `DATE: ${quotationMeta.date}`]);
    exportRows.push([]); // Empty row

    // Table Header
    exportRows.push(['S.No', 'Model / Part No', 'Description / Technical Specifications', 'Unit', 'Qty', 'Unit Price (QAR)', 'Total Amount (QAR)']);

    let currentSec = '';
    items.forEach((item) => {
      if (item.section !== currentSec) {
        currentSec = item.section;
        exportRows.push([`=== ${currentSec} ===`]);
      }
      exportRows.push([
        item.sNo,
        item.modelBrand,
        item.description,
        item.unit,
        item.qty,
        item.unitPriceQAR,
        item.qty * item.unitPriceQAR,
      ]);
    });

    exportRows.push([]);
    exportRows.push(['GRAND TOTAL (QAR)', '', '', '', totalQtyCount, '', grandTotalQAR]);

    const worksheet = XLSX.utils.aoa_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Official BOQ Quotation');

    XLSX.writeFile(workbook, `Amazetec_Official_Quotation_${quotationMeta.refNo.replace(/\//g, '_')}.xlsx`);
  };

  // Helper renderer for SVG product thumbnail icons matching screenshot aesthetics
  const renderProductThumbnail = (item: QuotationLineItem) => {
    const type = item.itemType || 'general';
    const desc = item.description.toLowerCase();

    if (type === 'camera' || desc.includes('dome') || desc.includes('bullet')) {
      return (
        <div className="w-12 h-10 bg-slate-100 rounded border border-slate-300 flex items-center justify-center shrink-0">
          <Camera className="w-6 h-6 text-slate-700" />
        </div>
      );
    }
    if (type === 'ptz' || desc.includes('ptz')) {
      return (
        <div className="w-12 h-10 bg-sky-50 rounded border border-sky-300 flex items-center justify-center shrink-0">
          <Camera className="w-6 h-6 text-sky-700" />
        </div>
      );
    }
    if (type === 'storage' || desc.includes('hdd') || desc.includes('nvr') || desc.includes('storage')) {
      return (
        <div className="w-12 h-10 bg-indigo-50 rounded border border-indigo-300 flex items-center justify-center shrink-0">
          <HardDrive className="w-6 h-6 text-indigo-700" />
        </div>
      );
    }
    if (type === 'server' || desc.includes('vms') || desc.includes('hikcentral') || desc.includes('dell')) {
      return (
        <div className="w-12 h-10 bg-amber-50 rounded border border-amber-300 flex items-center justify-center shrink-0">
          <Server className="w-6 h-6 text-amber-700" />
        </div>
      );
    }
    if (type === 'monitor' || desc.includes('monitor') || desc.includes('led')) {
      return (
        <div className="w-12 h-10 bg-blue-50 rounded border border-blue-300 flex items-center justify-center shrink-0">
          <Monitor className="w-6 h-6 text-blue-700" />
        </div>
      );
    }
    if (type === 'anpr' || desc.includes('anpr') || desc.includes('license')) {
      return (
        <div className="w-12 h-10 bg-purple-50 rounded border border-purple-300 flex items-center justify-center shrink-0">
          <Cpu className="w-6 h-6 text-purple-700" />
        </div>
      );
    }
    if (type === 'switch' || desc.includes('switch') || desc.includes('poe')) {
      return (
        <div className="w-12 h-10 bg-cyan-50 rounded border border-cyan-300 flex items-center justify-center shrink-0">
          <Layers className="w-6 h-6 text-cyan-700" />
        </div>
      );
    }
    if (type === 'ups' || desc.includes('ups') || desc.includes('battery')) {
      return (
        <div className="w-12 h-10 bg-yellow-50 rounded border border-yellow-300 flex items-center justify-center shrink-0">
          <BatteryCharging className="w-6 h-6 text-yellow-700" />
        </div>
      );
    }
    if (type === 'passive' || desc.includes('rack') || desc.includes('cabinet') || desc.includes('cable')) {
      return (
        <div className="w-12 h-10 bg-slate-100 rounded border border-slate-300 flex items-center justify-center shrink-0">
          <Wrench className="w-5 h-5 text-slate-600" />
        </div>
      );
    }

    return (
      <div className="w-12 h-10 bg-slate-50 rounded border border-slate-200 flex items-center justify-center shrink-0">
        <Building2 className="w-5 h-5 text-slate-400" />
      </div>
    );
  };

  return (
    <div className="bg-slate-100 min-h-screen p-3 md:p-6 text-slate-800 font-sans space-y-4">
      {/* TOP CONTROL BAR (Screen Only) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-xs">
            A
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base text-slate-900 tracking-tight">
                Official Qatar BOQ Quotation Document
              </h1>
              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[11px] px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> MOI-SSD Qatar Specification
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Interactive official sample quotation sheet with section headers, product thumbnails & live QAR total calculations.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => window.print()}
            className="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Print / PDF</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Export Master Excel (.xlsx)</span>
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs px-3 py-2 rounded-xl transition cursor-pointer"
            >
              Close
            </button>
          )}
        </div>
      </div>

      {/* FILTER & METADATA EDITOR BAR (Screen Only) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3 print:hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Project Name</label>
            <input
              type="text"
              value={quotationMeta.projectName}
              onChange={(e) => setQuotationMeta({ ...quotationMeta, projectName: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Client Name</label>
            <input
              type="text"
              value={quotationMeta.clientName}
              onChange={(e) => setQuotationMeta({ ...quotationMeta, clientName: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Quotation Ref No.</label>
            <input
              type="text"
              value={quotationMeta.refNo}
              onChange={(e) => setQuotationMeta({ ...quotationMeta, refNo: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-mono font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Date</label>
            <input
              type="text"
              value={quotationMeta.date}
              onChange={(e) => setQuotationMeta({ ...quotationMeta, date: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search model number, brand, or specification..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 w-full sm:w-72 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1">
            <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap">Filter Section:</span>
            <select
              value={filterSection}
              onChange={(e) => setFilterSection(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-700 focus:outline-none cursor-pointer"
            >
              {sections.map((sec) => (
                <option key={sec} value={sec}>
                  {sec}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* PRINTABLE OFFICIAL SHEET CONTAINER */}
      <div className="bg-white rounded-xl border border-slate-300 shadow-md p-4 md:p-8 space-y-6 max-w-7xl mx-auto print:shadow-none print:border-none print:p-0 print:max-w-none">
        {/* DOCUMENT FORMAL HEADER (QATAR OFFICIAL STYLE) */}
        <div className="border-b-2 border-slate-900 pb-4 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight uppercase">
                AMAZETEC MASTER ERP PORTAL
              </h2>
              <p className="text-xs font-bold text-indigo-700 tracking-wider uppercase">
                QATAR SECURITY SYSTEMS & ELV CONTRACTING DIVISION
              </p>
              <p className="text-[11px] text-slate-500">
                Doha, State of Qatar | Tel: +974 4400 0000 | Email: sales@amazetec.qa
              </p>
            </div>

            <div className="text-right">
              <span className="bg-sky-100 text-sky-950 border border-sky-300 font-mono font-black text-xs px-3 py-1 rounded">
                BILL OF QUANTITIES (BOQ) QUOTATION
              </span>
              <p className="text-xs font-mono font-extrabold text-slate-900 mt-2">
                REF: {quotationMeta.refNo}
              </p>
              <p className="text-xs text-slate-600 font-bold">DATE: {quotationMeta.date}</p>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
              <span className="text-slate-400 font-bold uppercase text-[10px] block">Project Title:</span>
              <span className="font-extrabold text-slate-900">{quotationMeta.projectName}</span>
            </div>
            <div>
              <span className="text-slate-400 font-bold uppercase text-[10px] block">Client / Main Contractor:</span>
              <span className="font-extrabold text-slate-900">{quotationMeta.clientName}</span>
            </div>
          </div>
        </div>

        {/* SECTIONAL BOQ TABLE (EXACT MATCH TO SAMPLE USER IMAGE) */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-slate-400 text-xs text-left">
            {/* Table Column Definitions */}
            <thead>
              <tr className="bg-slate-200 text-slate-900 font-black uppercase text-[11px] border-b-2 border-slate-400">
                <th className="border border-slate-400 p-2 text-center w-12">S.No</th>
                <th className="border border-slate-400 p-2 w-48">Model / Part No</th>
                <th className="border border-slate-400 p-2 text-center w-20">Image</th>
                <th className="border border-slate-400 p-2">Detailed Specification / Description</th>
                <th className="border border-slate-400 p-2 text-center w-16">Unit</th>
                <th className="border border-slate-400 p-2 text-center w-16">Qty</th>
                <th className="border border-slate-400 p-2 text-right w-28">Unit Price (QAR)</th>
                <th className="border border-slate-400 p-2 text-right w-32">Total Amount (QAR)</th>
                <th className="border border-slate-400 p-1 text-center w-10 print:hidden"></th>
              </tr>
            </thead>

            <tbody>
              {Object.keys(groupedSections).length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-slate-500 font-bold">
                    No quotation items found matching search query or filter.
                  </td>
                </tr>
              ) : (
                (Object.entries(groupedSections) as [string, QuotationLineItem[]][]).map(([secTitle, secItems]) => {
                  const sectionSubtotal = secItems.reduce((sum, row) => sum + row.qty * row.unitPriceQAR, 0);

                  return (
                    <React.Fragment key={secTitle}>
                      {/* LIGHT-BLUE SECTION HEADER BANNER (EXACT MATCH TO SAMPLE) */}
                      <tr className="bg-[#dce6f1] text-slate-900 font-black tracking-wide border border-slate-400">
                        <td colSpan={8} className="p-2.5 text-center uppercase text-xs font-black tracking-wider bg-[#dce6f1]">
                          {secTitle}
                        </td>
                        <td className="p-1 text-center print:hidden bg-[#dce6f1]">
                          <button
                            onClick={() => handleAddNewRow(secTitle)}
                            title="Add item to this section"
                            className="p-1 rounded bg-white hover:bg-slate-100 text-slate-700 text-[10px] font-bold cursor-pointer"
                          >
                            + Add
                          </button>
                        </td>
                      </tr>

                      {/* SECTION LINE ITEMS */}
                      {secItems.map((item) => {
                        const totalRowAmt = item.qty * item.unitPriceQAR;
                        const isEditing = editingId === item.id;

                        return (
                          <tr
                            key={item.id}
                            className="hover:bg-amber-50/40 transition border-b border-slate-300 group"
                          >
                            {/* S.No */}
                            <td className="border border-slate-300 p-2 text-center font-mono font-bold text-slate-700">
                              {item.sNo}
                            </td>

                            {/* Model / Part No */}
                            <td className="border border-slate-300 p-2 font-bold text-slate-900 align-top">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={item.modelBrand}
                                  onChange={(e) => handleItemChange(item.id, 'modelBrand', e.target.value)}
                                  className="w-full bg-amber-50 border border-amber-300 rounded px-1.5 py-1 text-xs font-bold"
                                />
                              ) : (
                                <span>{item.modelBrand}</span>
                              )}
                            </td>

                            {/* Product Image Thumbnail */}
                            <td className="border border-slate-300 p-1.5 text-center align-top">
                              <div className="flex justify-center">{renderProductThumbnail(item)}</div>
                            </td>

                            {/* Detailed Description */}
                            <td className="border border-slate-300 p-2 text-slate-800 leading-snug align-top">
                              {isEditing ? (
                                <textarea
                                  value={item.description}
                                  onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                                  rows={3}
                                  className="w-full bg-amber-50 border border-amber-300 rounded p-1 text-xs"
                                />
                              ) : (
                                <p className="whitespace-pre-line text-[11px] leading-relaxed">
                                  {item.description}
                                </p>
                              )}
                            </td>

                            {/* Unit */}
                            <td className="border border-slate-300 p-2 text-center font-semibold text-slate-700 align-top">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={item.unit}
                                  onChange={(e) => handleItemChange(item.id, 'unit', e.target.value)}
                                  className="w-12 bg-amber-50 border border-amber-300 rounded text-center text-xs"
                                />
                              ) : (
                                item.unit
                              )}
                            </td>

                            {/* Qty */}
                            <td className="border border-slate-300 p-2 text-center font-mono font-bold text-slate-900 align-top">
                              <input
                                type="number"
                                min="0"
                                value={item.qty}
                                onChange={(e) => handleItemChange(item.id, 'qty', Number(e.target.value) || 0)}
                                className="w-16 bg-slate-50 hover:bg-amber-50 focus:bg-white border border-slate-300 focus:border-amber-500 rounded px-1 py-1 text-center font-mono font-bold text-xs"
                              />
                            </td>

                            {/* Unit Price (QAR) */}
                            <td className="border border-slate-300 p-2 text-right font-mono font-bold text-slate-900 align-top">
                              <div className="flex items-center justify-end gap-1">
                                <span className="text-[10px] text-slate-400">QAR</span>
                                <input
                                  type="number"
                                  step="0.01"
                                  value={item.unitPriceQAR}
                                  onChange={(e) => handleItemChange(item.id, 'unitPriceQAR', Number(e.target.value) || 0)}
                                  className="w-20 bg-slate-50 hover:bg-amber-50 focus:bg-white border border-slate-300 focus:border-amber-500 rounded px-1 py-1 text-right font-mono font-bold text-xs"
                                />
                              </div>
                            </td>

                            {/* Total Amount (QAR) */}
                            <td className="border border-slate-300 p-2 text-right font-mono font-black text-slate-950 bg-slate-50/50 align-top">
                              QAR {totalRowAmt.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>

                            {/* Actions (Screen Only) */}
                            <td className="border border-slate-300 p-1 text-center align-top print:hidden">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  onClick={() => setEditingId(isEditing ? null : item.id)}
                                  className={`p-1 rounded cursor-pointer ${isEditing ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:text-slate-700'}`}
                                  title={isEditing ? 'Save Changes' : 'Edit Row'}
                                >
                                  {isEditing ? <Check className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
                                </button>
                                <button
                                  onClick={() => handleDeleteItem(item.id)}
                                  className="p-1 rounded text-slate-300 hover:text-rose-600 cursor-pointer"
                                  title="Delete Item"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}

                      {/* SECTION SUBTOTAL ROW */}
                      <tr className="bg-slate-100 font-bold text-slate-800 text-xs border-b-2 border-slate-400">
                        <td colSpan={7} className="border border-slate-300 p-2 text-right uppercase text-[11px] font-black">
                          Subtotal ({secTitle}):
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono font-black text-slate-900 bg-slate-200/60">
                          QAR {sectionSubtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>
                        <td className="print:hidden border border-slate-300"></td>
                      </tr>
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* SUMMARY & GRAND TOTAL FOOTER (EXACT MATCH TO QATAR QUOTATIONS) */}
        <div className="pt-4 border-t-2 border-slate-900 flex flex-col md:flex-row items-start justify-between gap-6">
          <div className="space-y-2 text-xs text-slate-600 max-w-lg">
            <h4 className="font-extrabold text-slate-900 uppercase tracking-tight">Terms & Conditions (State of Qatar):</h4>
            <ul className="list-disc list-inside space-y-1 text-[11px] leading-relaxed">
              <li>Prices quoted in Qatari Riyals (QAR) inclusive of supply, delivery, and installation.</li>
              <li>MOI-SSD Inspection and approval Certificate support included.</li>
              <li>Warranty: As specified per item (1 to 3 Years Standard Manufacturer Warranty).</li>
              <li>Payment Terms: 30% Advance, 60% On Delivery of Material, 10% On Handover/Testing.</li>
            </ul>
          </div>

          <div className="w-full md:w-80 bg-slate-900 text-white p-5 rounded-2xl space-y-3 shadow-lg">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Total Unique Items:</span>
              <span className="font-mono font-bold text-white">{items.length} Lines</span>
            </div>

            <div className="flex justify-between text-xs text-slate-300">
              <span>Total Unit Quantity:</span>
              <span className="font-mono font-bold text-amber-400">{totalQtyCount.toLocaleString()} Units</span>
            </div>

            <div className="pt-3 border-t border-slate-700 flex justify-between items-center">
              <span className="font-black text-sm uppercase text-slate-200">Grand Total (QAR):</span>
              <span className="font-mono font-black text-xl text-emerald-400">
                QAR {grandTotalQAR.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <p className="text-[10px] text-slate-400 text-center font-mono pt-1">
              *** OFFICIAL AMAZETEC ERP MASTER QUOTATION ***
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
