import React from 'react';
import { EditableTable, ColumnDef } from './EditableTable';
import { AssetRecord, EquipmentMasterItem, EquipmentIssuance, AttendanceRecord, KYCQuery, DropdownMaster } from '../types';
import { ShieldCheck, Calendar } from 'lucide-react';

interface AdministratorViewProps {
  assets: AssetRecord[];
  equipmentMaster: EquipmentMasterItem[];
  equipmentIssuance: EquipmentIssuance[];
  attendance: AttendanceRecord[];
  kycQueries: KYCQuery[];
  dropdowns: DropdownMaster[];
  onUpdateAssets: (data: AssetRecord[]) => void;
  onUpdateEquipmentMaster: (data: EquipmentMasterItem[]) => void;
  onUpdateEquipmentIssuance: (data: EquipmentIssuance[]) => void;
  onUpdateAttendance: (data: AttendanceRecord[]) => void;
  onUpdateKYCQueries: (data: KYCQuery[]) => void;
  onOpenQuickAdd: () => void;
}

export const AdministratorView: React.FC<AdministratorViewProps> = ({
  assets,
  equipmentMaster,
  equipmentIssuance,
  attendance,
  kycQueries,
  dropdowns,
  onUpdateAssets,
  onUpdateEquipmentMaster,
  onUpdateEquipmentIssuance,
  onUpdateAttendance,
  onUpdateKYCQueries,
  onOpenQuickAdd,
}) => {
  const getDropdownOptions = (catName: string) => {
    const found = dropdowns.find((d) => d.categoryName.toLowerCase().includes(catName.toLowerCase()));
    return found ? found.options : [];
  };

  // Asset Columns
  const assetCols: ColumnDef[] = [
    { key: 'id', label: 'Asset ID', type: 'readonly' },
    { key: 'assetName', label: 'Asset Name', type: 'text' },
    { key: 'category', label: 'Category', type: 'select', options: getDropdownOptions('Categories') },
    { key: 'modelSerial', label: 'Model / Serial No.', type: 'text' },
    { key: 'location', label: 'Location', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Issued', 'Under Maintenance', 'Retired', 'In Stock'] },
    { key: 'purchasePrice', label: 'Purchase Price', type: 'currency' },
    { key: 'currentValue', label: 'Current Value', type: 'currency' },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'warrantyExpiry', label: 'Warranty Expiry', type: 'date' },
    { key: 'supplier', label: 'Supplier', type: 'text' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Equipment Master Columns
  const equipmentMasterCols: ColumnDef[] = [
    { key: 'code', label: 'Code', type: 'readonly' },
    { key: 'name', label: 'Equipment Name', type: 'text' },
    { key: 'category', label: 'Category', type: 'select', options: getDropdownOptions('Categories') },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model', type: 'text' },
    { key: 'totalQuantity', label: 'Total Qty', type: 'number' },
    { key: 'unitPrice', label: 'Unit Price', type: 'currency' },
    { key: 'totalValue', label: 'Total Value', type: 'currency', isFormula: true, formulaLabel: '=Qty * UnitPrice' },
    { key: 'moiApproved', label: 'MOI Approved', type: 'select', options: ['Yes', 'No'] },
    { key: 'currentStock', label: 'Current Stock', type: 'number' },
    { key: 'reorderStatus', label: 'Status', type: 'text' },
  ];

  // Equipment Issuance Columns
  const issuanceCols: ColumnDef[] = [
    { key: 'issueId', label: 'Issue ID', type: 'readonly' },
    { key: 'equipmentCode', label: 'Equipment Code', type: 'text' },
    { key: 'equipmentName', label: 'Equipment Name', type: 'text' },
    { key: 'quantityIssued', label: 'Qty Issued', type: 'number' },
    { key: 'issueDate', label: 'Issue Date', type: 'date' },
    { key: 'issuedTo', label: 'Issued To (Team/Project)', type: 'text' },
    { key: 'issuedBy', label: 'Issued By', type: 'text' },
    { key: 'expectedReturnDate', label: 'Expected Return', type: 'date' },
    { key: 'status', label: 'Status', type: 'select', options: ['Issued', 'Returned', 'Partially Returned', 'Lost', 'Damaged'] },
    { key: 'conditionOnIssue', label: 'Condition', type: 'text' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Attendance Columns
  const attendanceCols: ColumnDef[] = [
    { key: 'employeeId', label: 'Emp ID', type: 'readonly' },
    { key: 'employeeName', label: 'Employee Name', type: 'text' },
    { key: 'designation', label: 'Designation', type: 'text' },
    { key: 'department', label: 'Department', type: 'select', options: getDropdownOptions('Departments') },
    { key: 'date', label: 'Date', type: 'date' },
    { key: 'checkIn', label: 'Check-In', type: 'text' },
    { key: 'checkOut', label: 'Check-Out', type: 'text' },
    { key: 'totalHours', label: 'Hours', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Present', 'Absent', 'Leave', 'Half Day', 'Holiday', 'Sick Leave', 'Work From Home'] },
    { key: 'isLate', label: 'Late (Y/N)', type: 'select', options: ['Yes', 'No'] },
    { key: 'lateMinutes', label: 'Late Min', type: 'number' },
    { key: 'overtimeHours', label: 'Overtime Hrs', type: 'number' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // KYC Columns
  const kycCols: ColumnDef[] = [
    { key: 'id', label: 'Query ID', type: 'readonly' },
    { key: 'employeeId', label: 'Emp ID', type: 'text' },
    { key: 'employeeName', label: 'Employee Name', type: 'text' },
    { key: 'nationality', label: 'Nationality', type: 'select', options: getDropdownOptions('Nationality') },
    { key: 'queryType', label: 'Query Type', type: 'select', options: getDropdownOptions('Query Type') },
    { key: 'dateRaised', label: 'Date Raised', type: 'date' },
    { key: 'priority', label: 'Priority', type: 'select', options: ['High', 'Medium', 'Low'] },
    { key: 'status', label: 'Status', type: 'select', options: ['Pending', 'In Progress', 'Resolved', 'Rejected', 'On Hold'] },
    { key: 'assignedTo', label: 'Assigned To', type: 'text' },
    { key: 'actionTaken', label: 'Action Taken', type: 'text' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // Calculate Small Dashboard metrics
  const activeAssetsCount = assets.filter((a) => a.status === 'Active').length;
  const totalStockVal = equipmentMaster.reduce((sum, e) => sum + (e.totalValue || 0), 0);
  const openKYC = kycQueries.filter((q) => q.status !== 'Resolved').length;

  return (
    <div className="space-y-6 pb-8">
      {/* Small Dashboard Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck className="w-5 h-5 text-indigo-600" />
          <h2 className="font-bold text-slate-900 text-lg tracking-tight">Administrator Master Sheet</h2>
          <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
            Asset, Equipment, Attendance & KYC
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Active Assets</p>
            <p className="text-xl font-black text-slate-900">{activeAssetsCount} / {assets.length} Active</p>
            <p className="text-[10px] text-slate-500 mt-0.5">NVRs, Cameras & Vehicles</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Equipment Store Value</p>
            <p className="text-xl font-black font-mono text-indigo-600">QAR {totalStockVal.toLocaleString()}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">5 Categories Registered</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Equipment Issuance</p>
            <p className="text-xl font-black text-slate-900">{equipmentIssuance.length} Issued Records</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Projects & Site Engineers</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">KYC Government Queries</p>
            <p className="text-xl font-black text-amber-600">{openKYC} Open Queries</p>
            <p className="text-[10px] text-slate-500 mt-0.5">QID Renewal & Work Permits</p>
          </div>
        </div>
      </div>

      {/* Table 1: Asset Management */}
      <EditableTable
        title="Asset Management Table"
        subtitle="Track company assets, location, assigned engineers, purchase value & maintenance schedules"
        columns={assetCols}
        data={assets}
        onUpdateData={onUpdateAssets}
        onAddRow={onOpenQuickAdd}
        badge="Table 1"
      />

      {/* Table 2: Equipment Management */}
      <div className="space-y-6">
        <EditableTable
          title="Equipment Store Master List"
          subtitle="Master inventory of cameras, HDDs, switches, brackets and MOI approval status"
          columns={equipmentMasterCols}
          data={equipmentMaster}
          onUpdateData={onUpdateEquipmentMaster}
          onAddRow={onOpenQuickAdd}
          badge="Table 2A"
          badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
        />

        <EditableTable
          title="Equipment Issuance & Site Tracking"
          subtitle="Track store items issued to project sites, teams, return dates and conditions"
          columns={issuanceCols}
          data={equipmentIssuance}
          onUpdateData={onUpdateEquipmentIssuance}
          badge="Table 2B"
          badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
        />
      </div>

      {/* Table 3: Attendance Record */}
      <EditableTable
        title="Daily Attendance Record"
        subtitle="Daily staff check-in/out, total hours, overtime tracking and leave logs"
        columns={attendanceCols}
        data={attendance}
        onUpdateData={onUpdateAttendance}
        badge="Table 3"
        badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
      />

      {/* Table 4: KYC & Support Queries */}
      <EditableTable
        title="KYC & Employee Government Queries"
        subtitle="QID renewals, MOI work permits, visa transfers and medical insurance requests"
        columns={kycCols}
        data={kycQueries}
        onUpdateData={onUpdateKYCQueries}
        badge="Table 4"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />
    </div>
  );
};
