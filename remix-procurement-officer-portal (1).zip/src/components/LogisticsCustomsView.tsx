import React, { useState } from 'react';
import {
  Truck,
  Plane,
  Ship,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileCheck,
  ShieldCheck,
  MapPin,
  Calendar,
  DollarSign,
  Printer,
  X,
  Plus,
  ArrowRight,
  Eye,
  BadgeCheck,
  Scale,
  Building2,
  Package,
  Layers,
  Sparkles,
  QrCode,
  FileText,
  Anchor,
  Compass,
} from 'lucide-react';
import { LogisticsShipment } from '../types';
import { EditableTable, ColumnDef } from './EditableTable';
import { useAppData } from '../context/useAppData';

interface LogisticsCustomsViewProps {
  shipments: LogisticsShipment[];
  onUpdateShipments: (data: LogisticsShipment[]) => void;
  onOpenQuickAdd: () => void;
}

export const LogisticsCustomsView: React.FC<LogisticsCustomsViewProps> = ({
  shipments,
  onUpdateShipments,
  onOpenQuickAdd,
}) => {
  const { createReconciliationForPO, setActiveTab, setProcurementSubModule } = useAppData();
  const [selectedShipment, setSelectedShipment] = useState<LogisticsShipment | null>(shipments[0] || null);
  const [isDeliveryDocOpen, setIsDeliveryDocOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'table' | 'demurrage'>('pipeline');

  // Demurrage Calculator State
  const [portArrivalDate, setPortArrivalDate] = useState<string>('2026-08-15');
  const [customsClearanceDate, setCustomsClearanceDate] = useState<string>('2026-08-22');
  const [containersCount, setContainersCount] = useState<number>(2);
  const [freeDaysAllowed, setFreeDaysAllowed] = useState<number>(5); // Standard Hamad Port Free Time
  const [demurrageDailyRateQAR, setDemurrageDailyRateQAR] = useState<number>(350); // QAR/day/container

  const logisticsColumns: ColumnDef[] = [
    { key: 'shipmentId', label: 'Shipment ID', type: 'readonly' },
    { key: 'poNumber', label: 'PO Ref', type: 'text' },
    { key: 'supplier', label: 'Supplier / Vendor', type: 'text' },
    { key: 'originCountry', label: 'Origin', type: 'text' },
    {
      key: 'shippingMode',
      label: 'Freight Mode',
      type: 'select',
      options: ['Ex-Stock Doha', 'Air Freight', 'Sea Cargo', 'Road Transport'],
    },
    { key: 'carrierForwarder', label: 'Carrier / Forwarder', type: 'text' },
    { key: 'awbOrBolNo', label: 'AWB / BOL #', type: 'text' },
    { key: 'dispatchDate', label: 'Dispatch Date', type: 'date' },
    { key: 'etaPortOrWarehouse', label: 'ETA', type: 'date' },
    {
      key: 'customsStatus',
      label: 'Customs Status',
      type: 'select',
      options: [
        'Customs Cleared',
        'Port Clearance in Progress',
        'Inspection Scheduled',
        'Pending Duty Payment',
        'Direct Delivery (Local)',
      ],
    },
    {
      key: 'siteDeliveryStatus',
      label: 'Delivery Status',
      type: 'select',
      options: ['Delivered to Site', 'Delivered to Central Warehouse', 'In Transit', 'Delayed'],
    },
    {
      key: 'onTimeStatus',
      label: 'Schedule SLA',
      type: 'select',
      options: ['On-Time (Schedule Met)', 'Delayed', 'Ahead of Schedule'],
    },
    {
      key: 'qaQcInspectionStatus',
      label: 'QA/QC Inspection',
      type: 'select',
      options: [
        'Passed 100% (Defect Free)',
        'Minor Defects (Rectified)',
        'Rejected / Return',
        'Pending Inspection',
      ],
    },
  ];

  const handleUpdateStatus = (shipmentId: string, updates: Partial<LogisticsShipment>) => {
    const updated = shipments.map((s) => (s.shipmentId === shipmentId ? { ...s, ...updates } : s));
    onUpdateShipments(updated);
    setNotification(`Updated shipment ${shipmentId}`);
    setTimeout(() => setNotification(null), 3500);
  };

  const handleGenerateSiteGRN = (shipment: LogisticsShipment) => {
    const recon = createReconciliationForPO(shipment.poNumber);
    if (recon) {
      setNotification(`Generated Site GRN and linked into 3-Way Reconciliation ${recon.reconciliationId}`);
      setTimeout(() => setNotification(null), 5000);
    }
  };

  // Demurrage calculation
  const daysAtPort = Math.max(
    0,
    Math.round(
      (new Date(customsClearanceDate).getTime() - new Date(portArrivalDate).getTime()) / (1000 * 3600 * 24)
    )
  );
  const excessDays = Math.max(0, daysAtPort - freeDaysAllowed);
  const estimatedDemurrageQAR = excessDays * containersCount * demurrageDailyRateQAR;

  const inTransitCount = shipments.filter((s) => s.siteDeliveryStatus === 'In Transit').length;
  const deliveredCount = shipments.filter(
    (s) => s.siteDeliveryStatus === 'Delivered to Site' || s.siteDeliveryStatus === 'Delivered to Central Warehouse'
  ).length;
  const customsClearedCount = shipments.filter((s) => s.customsStatus === 'Customs Cleared' || s.customsStatus === 'Direct Delivery (Local)').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white p-5 rounded-3xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-teal-900/40">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-teal-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-teal-600/30">
            <Truck className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base tracking-tight text-white">
                Logistics, Freight Expediting & Qatar Customs Tracker
              </h3>
              <span className="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-2xs px-2 py-0.5 rounded-full font-semibold">
                Al-Nadeeb / Bayan Integrated
              </span>
            </div>
            <p className="text-xs text-slate-300">
              End-to-end international freight expediting, Hamad Port / Airport customs clearance, and site QA/QC handover.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-white/10 p-1 rounded-xl border border-white/15">
            <button
              onClick={() => setActiveSubTab('pipeline')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                activeSubTab === 'pipeline' ? 'bg-teal-500 text-slate-900 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              Live Pipeline
            </button>
            <button
              onClick={() => setActiveSubTab('table')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                activeSubTab === 'table' ? 'bg-teal-500 text-slate-900 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              Shipments Table
            </button>
            <button
              onClick={() => setActiveSubTab('demurrage')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                activeSubTab === 'demurrage' ? 'bg-teal-500 text-slate-900 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              Port SLA & Demurrage
            </button>
          </div>
          <button
            onClick={onOpenQuickAdd}
            className="bg-teal-500 hover:bg-teal-400 text-slate-900 text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Shipment</span>
          </button>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 flex items-center justify-between text-xs text-teal-900 font-semibold animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
            <span>{notification}</span>
          </div>
          <button
            onClick={() => {
              setActiveTab('procurement');
              setProcurementSubModule('po_logistics');
            }}
            className="text-xs font-bold text-teal-700 hover:underline flex items-center gap-1"
          >
            <span>View Reconciliations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Key Metric Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-2xs font-bold uppercase tracking-wider">
            <span>In-Transit Cargo</span>
            <Plane className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-black text-slate-900">{inTransitCount}</div>
          <p className="text-2xs text-indigo-600 font-medium">Air & Sea Shipments en route</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-2xs font-bold uppercase tracking-wider">
            <span>Customs Cleared</span>
            <ShieldCheck className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-teal-700">{customsClearedCount}</div>
          <p className="text-2xs text-teal-600 font-medium">Hamad Port & Airport Cleared</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-2xs font-bold uppercase tracking-wider">
            <span>Site Delivered</span>
            <BadgeCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700">{deliveredCount}</div>
          <p className="text-2xs text-emerald-600 font-medium">Accepted by Site Engineer</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-2xs font-bold uppercase tracking-wider">
            <span>QA/QC Inspected</span>
            <FileCheck className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-purple-700">100%</div>
          <p className="text-2xs text-purple-600 font-medium">MOI Serial Match Verified</p>
        </div>
      </div>

      {/* Main View Switcher */}
      {activeSubTab === 'pipeline' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-extrabold text-sm text-slate-900">
              Live Active Freight Pipelines & Clearance Tracking
            </h4>
            <span className="text-2xs text-slate-500">Showing {shipments.length} tracked commercial consignments</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {shipments.map((shipment) => {
              const isSea = shipment.shippingMode === 'Sea Cargo';
              const isAir = shipment.shippingMode === 'Air Freight';
              const isLocal = shipment.shippingMode === 'Ex-Stock Doha';

              return (
                <div
                  key={shipment.shipmentId}
                  className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs hover:shadow-md transition space-y-4 flex flex-col justify-between"
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-extrabold text-teal-800 bg-teal-50 px-2.5 py-1 rounded-xl border border-teal-200">
                          {shipment.shipmentId}
                        </span>
                        <span className="flex items-center gap-1 text-2xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg">
                          {isSea ? <Ship className="w-3 h-3 text-blue-600" /> : isAir ? <Plane className="w-3 h-3 text-indigo-600" /> : <Truck className="w-3 h-3 text-emerald-600" />}
                          {shipment.shippingMode}
                        </span>
                      </div>
                      <span
                        className={`text-2xs font-bold px-2.5 py-0.5 rounded-full ${
                          shipment.siteDeliveryStatus === 'Delivered to Site'
                            ? 'bg-emerald-100 text-emerald-800'
                            : shipment.siteDeliveryStatus === 'In Transit'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {shipment.siteDeliveryStatus}
                      </span>
                    </div>

                    {/* Content Details */}
                    <div className="mt-3 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 text-2xs">Vendor / Forwarder:</span>
                        <span className="font-bold text-slate-900">{shipment.supplier} ({shipment.carrierForwarder})</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 text-2xs">Origin / AWB-BOL:</span>
                        <span className="font-mono text-slate-700">{shipment.originCountry} · {shipment.awbOrBolNo}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 text-2xs">PO Commitment Ref:</span>
                        <span className="font-mono font-bold text-indigo-600">{shipment.poNumber}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                        <span className="text-slate-500 text-2xs">ETA Port / Warehouse:</span>
                        <span className="font-semibold text-teal-800">{shipment.etaPortOrWarehouse}</span>
                      </div>
                    </div>

                    {/* Progress Stepper */}
                    <div className="mt-4 bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-2">
                      <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                        Milestone Status
                      </div>
                      <div className="grid grid-cols-3 gap-1 text-center text-[11px] font-bold">
                        <div className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg">
                          1. Dispatched
                        </div>
                        <div
                          className={`p-1.5 rounded-lg ${
                            shipment.customsStatus === 'Customs Cleared' || shipment.customsStatus === 'Direct Delivery (Local)'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          2. {shipment.customsStatus.includes('Cleared') ? 'Customs OK' : 'Customs In-Proc'}
                        </div>
                        <div
                          className={`p-1.5 rounded-lg ${
                            shipment.siteDeliveryStatus.includes('Delivered')
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          3. Site QA/QC
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        setSelectedShipment(shipment);
                        setIsDeliveryDocOpen(true);
                      }}
                      className="flex-1 py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-2xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5 text-slate-500" />
                      <span>Delivery Advice (DA)</span>
                    </button>
                    <button
                      onClick={() => handleGenerateSiteGRN(shipment)}
                      title="1-Click: Issue Goods Receipt Note (GRN) for Site Delivery"
                      className="flex-1 py-1.5 px-2.5 bg-teal-600 hover:bg-teal-500 text-white text-2xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                    >
                      <Scale className="w-3.5 h-3.5" />
                      <span>Issue Site GRN</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Shipments Table */}
      {activeSubTab === 'table' && (
        <EditableTable
          title="Freight Expediting & Customs Registry"
          subtitle="Real-time freight manifests, bill of lading tracking, and Qatar customs single-window status"
          columns={logisticsColumns}
          data={shipments}
          onUpdateData={onUpdateShipments}
          onAddRow={onOpenQuickAdd}
          badge="Table 2E"
          badgeColor="bg-teal-50 text-teal-700 border-teal-200"
        />
      )}

      {/* Port SLA & Demurrage Risk Calculator */}
      {activeSubTab === 'demurrage' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center">
              <Anchor className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-base text-slate-900">
                Hamad Port & Air Cargo Free-Time & Demurrage Risk Calculator
              </h4>
              <p className="text-xs text-slate-500">
                Monitor port storage dwell times to avoid costly container detention fees and customs inspection penalties.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div>
              <label className="text-2xs font-bold text-slate-500 uppercase">Port Inward Date</label>
              <input
                type="date"
                value={portArrivalDate}
                onChange={(e) => setPortArrivalDate(e.target.value)}
                className="mt-1 w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
              />
            </div>
            <div>
              <label className="text-2xs font-bold text-slate-500 uppercase">Target Clearance Date</label>
              <input
                type="date"
                value={customsClearanceDate}
                onChange={(e) => setCustomsClearanceDate(e.target.value)}
                className="mt-1 w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
              />
            </div>
            <div>
              <label className="text-2xs font-bold text-slate-500 uppercase">Containers / Consignments</label>
              <input
                type="number"
                value={containersCount}
                onChange={(e) => setContainersCount(Number(e.target.value) || 1)}
                className="mt-1 w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
              />
            </div>
            <div>
              <label className="text-2xs font-bold text-slate-500 uppercase">Port Free Days Allowed</label>
              <input
                type="number"
                value={freeDaysAllowed}
                onChange={(e) => setFreeDaysAllowed(Number(e.target.value) || 5)}
                className="mt-1 w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-2xs font-bold uppercase text-slate-400">Total Dwell Time</span>
              <div className="text-xl font-mono font-black text-slate-900">{daysAtPort} Days</div>
              <p className="text-2xs text-slate-500">Days cargo sits in port terminal</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-2xs font-bold uppercase text-slate-400">Excess Dwell Days</span>
              <div className={`text-xl font-mono font-black ${excessDays > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {excessDays} Days
              </div>
              <p className="text-2xs text-slate-500">{excessDays === 0 ? 'Within free time window' : 'Overdue port stay'}</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-2xs font-bold uppercase text-slate-400">Estimated Demurrage Liability</span>
              <div className={`text-xl font-mono font-black ${estimatedDemurrageQAR > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                QAR {estimatedDemurrageQAR.toLocaleString()}
              </div>
              <p className="text-2xs text-slate-500">Potential financial penalty</p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DELIVERY ADVICE (DA) & SITE HANDOVER CERTIFICATE MODAL */}
      {/* ========================================================================= */}
      {isDeliveryDocOpen && selectedShipment && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-300 my-auto flex flex-col">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl shrink-0">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-teal-400" />
                <span className="font-bold text-sm">
                  Official Delivery Advice (DA) & Site Handover Note — {selectedShipment.shipmentId}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Note</span>
                </button>
                <button
                  onClick={() => setIsDeliveryDocOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-8 space-y-6 text-xs text-slate-800 font-sans">
              <div className="border-b border-slate-200 pb-4 flex justify-between items-start">
                <div>
                  <h2 className="text-base font-black text-slate-900">
                    DELIVERY ADVICE & SITE RECEIVING DOCKET
                  </h2>
                  <p className="text-2xs text-slate-500 uppercase tracking-wider">
                    Amazetec Security & ELV Systems W.L.L. - Logistics Division
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-teal-800 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200">
                    DA-{selectedShipment.shipmentId}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Carrier / Forwarder</span>
                  <p className="font-bold text-slate-900 mt-0.5">{selectedShipment.carrierForwarder}</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Associated PO Ref</span>
                  <p className="font-bold text-indigo-700 font-mono mt-0.5">{selectedShipment.poNumber}</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">Freight Mode</span>
                  <p className="font-semibold text-slate-800 mt-0.5">{selectedShipment.shippingMode}</p>
                </div>
                <div>
                  <span className="text-2xs font-extrabold uppercase text-slate-400">AWB / BOL No.</span>
                  <p className="font-mono text-slate-800 mt-0.5">{selectedShipment.awbOrBolNo}</p>
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl p-4 space-y-2">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-2xs">
                  On-Site Inspection & QA/QC Confirmation
                </h4>
                <div className="grid grid-cols-2 gap-2 text-2xs text-slate-600">
                  <div>Inspection Result: <strong className="text-emerald-700">{selectedShipment.qaQcInspectionStatus}</strong></div>
                  <div>Customs Clearance: <strong className="text-slate-800">{selectedShipment.customsStatus}</strong></div>
                  <div>Delivery Status: <strong className="text-slate-800">{selectedShipment.siteDeliveryStatus}</strong></div>
                  <div>SLA Adherence: <strong className="text-slate-800">{selectedShipment.onTimeStatus}</strong></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-8 border-t border-slate-200 pt-6">
                <div className="space-y-4">
                  <div className="text-2xs font-extrabold uppercase text-slate-400">Delivered By (Driver / Freight Agent)</div>
                  <div className="h-8 border-b border-slate-300"></div>
                  <div className="text-2xs text-slate-500">Sign & Stamp</div>
                </div>
                <div className="space-y-4">
                  <div className="text-2xs font-extrabold uppercase text-slate-400">Received By (Site Engineer / Storekeeper)</div>
                  <div className="h-8 border-b border-slate-300"></div>
                  <div className="text-2xs text-slate-500">Sign & Amazetec Stamp</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
