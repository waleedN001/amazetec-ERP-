import React from 'react';
import { DataGrid, DataGridColumn, DataGridProps } from './DataGrid';

export type ColumnDef = {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'currency' | 'percent' | 'select' | 'date' | 'readonly';
  options?: string[];
  isFormula?: boolean;
  formulaLabel?: string;
  width?: string;
};

interface EditableTableProps {
  title: string;
  subtitle?: string;
  columns: ColumnDef[];
  data: any[];
  onUpdateData: (newData: any[]) => void;
  onAddRow?: () => void;
  badge?: string;
  badgeColor?: string;
  enableSelection?: boolean;
}

/**
 * EditableTable
 * Standard table adapter wrapping the unified DataGrid component with sorting,
 * filtering, pagination, and in-place editing.
 */
export const EditableTable: React.FC<EditableTableProps> = ({
  title,
  subtitle,
  columns,
  data,
  onUpdateData,
  onAddRow,
  badge,
  badgeColor = 'bg-indigo-50 text-indigo-700 border-indigo-200',
  enableSelection = true,
}) => {
  const gridColumns: DataGridColumn[] = columns.map((col) => ({
    key: col.key,
    header: col.label,
    type: col.type || 'text',
    options: col.options,
    isFormula: col.isFormula,
    formulaLabel: col.formulaLabel,
    width: col.width,
    sortable: true,
    filterable: true,
  }));

  return (
    <DataGrid
      title={title}
      subtitle={subtitle}
      badge={badge}
      badgeColor={badgeColor}
      columns={gridColumns}
      data={data}
      onUpdateData={onUpdateData}
      onAddRow={onAddRow}
      enableSelection={enableSelection}
      enablePagination={true}
      defaultPageSize={10}
      enableExport={true}
    />
  );
};
