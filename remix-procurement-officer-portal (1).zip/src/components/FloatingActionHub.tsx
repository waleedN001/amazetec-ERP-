import React, { useState } from 'react';
import { Sparkles, Bot, Plus, Rss, FileDown, LayoutGrid, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FloatingActionHubProps {
  onOpenGeminiChat: () => void;
  onOpenGeminiIntelligence: () => void;
  onOpenQuickAdd: () => void;
  onOpenFeed: () => void;
  onExportMasterExcel: () => void;
}

export const FloatingActionHub: React.FC<FloatingActionHubProps> = ({
  onOpenGeminiChat,
  onOpenGeminiIntelligence,
  onOpenQuickAdd,
  onOpenFeed,
  onExportMasterExcel,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 flex items-center gap-3 z-50">
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="flex flex-col gap-2 bg-white p-2 rounded-2xl shadow-xl border border-slate-200 mb-16 mr-2"
          >
            <button onClick={onOpenGeminiIntelligence} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 whitespace-nowrap transition-all">
              <Sparkles className="w-4 h-4 text-violet-600" /> CAD Take-Off
            </button>
            <button onClick={onOpenGeminiChat} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 whitespace-nowrap transition-all">
              <Bot className="w-4 h-4 text-emerald-600" /> AI Copilot
            </button>
            <button onClick={onOpenQuickAdd} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 whitespace-nowrap transition-all">
              <Plus className="w-4 h-4 text-indigo-600" /> Quick Add
            </button>
            <button onClick={onOpenFeed} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 whitespace-nowrap transition-all">
              <Rss className="w-4 h-4 text-amber-500" /> Feed
            </button>
            <button onClick={onExportMasterExcel} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 whitespace-nowrap transition-all">
              <FileDown className="w-4 h-4 text-emerald-600" /> Export Excel
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className="flex items-center justify-center w-12 h-12 bg-white hover:bg-slate-50 text-indigo-700 rounded-full shadow-lg border border-slate-200 transition-all"
        title="Quick Menu"
      >
        {isMenuOpen ? <X className="w-6 h-6" /> : <LayoutGrid className="w-6 h-6" />}
      </button>

      <button
        onClick={onOpenGeminiChat}
        className="flex items-center justify-center w-12 h-12 bg-indigo-700 hover:bg-indigo-800 text-white rounded-full shadow-lg transition-all"
        title="Open AI Copilot"
      >
        <Bot className="w-6 h-6" />
      </button>
    </div>
  );
};
