import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Trash2,
  Download,
  Edit2,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Layers,
  Copy,
  FileSpreadsheet,
  Eye,
  EyeOff,
} from 'lucide-react';
import { exportSingleTableToCSV } from '../utils/excelExport';

export type DataGridColumnType =
  | 'text'
  | 'number'
  | 'currency'
  | 'percent'
  | 'badge'
  | 'date'
  | 'select'
  | 'readonly'
  | 'custom';

export interface DataGridColumn<T = any> {
  key: string;
  header: string;
  type?: DataGridColumnType;
  options?: string[];
  sortable?: boolean;
  filterable?: boolean;
  isFormula?: boolean;
  formulaLabel?: string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  renderCell?: (value: any, row: T, isEditing: boolean) => React.ReactNode;
}

export interface DataGridRowAction<T = any> {
  label: string;
  icon?: React.ReactNode;
  variant?: 'default' | 'primary' | 'danger' | 'success';
  onClick: (row: T, index: number) => void;
  showIf?: (row: T) => boolean;
}

export interface DataGridProps<T = any> {
  id?: string;
  title?: string;
  subtitle?: string;
  badge?: string;
  badgeColor?: string;
  columns: DataGridColumn<T>[];
  data: T[];
  onUpdateData?: (newData: T[]) => void;
  onAddRow?: () => void;
  onDeleteRow?: (row: T, index: number) => void;
  rowActions?: DataGridRowAction<T>[];
  enableSelection?: boolean;
  enablePagination?: boolean;
  defaultPageSize?: number;
  enableExport?: boolean;
  enableDensityToggle?: boolean;
  primaryKey?: string;
  emptyStateMessage?: string;
  customHeaderActions?: React.ReactNode;
}

export function DataGrid<T extends Record<string, any>>({
  id = 'unified-data-grid',
  title,
  subtitle,
  badge,
  badgeColor = 'bg-indigo-50 text-indigo-700 border-indigo-200',
  columns,
  data,
  onUpdateData,
  onAddRow,
  onDeleteRow,
  rowActions,
  enableSelection = true,
  enablePagination = true,
  defaultPageSize = 10,
  enableExport = true,
  enableDensityToggle = true,
  primaryKey = 'id',
  emptyStateMessage = 'No records found. Click "Add Record" to insert a new entry.',
  customHeaderActions,
}: DataGridProps<T>) {
  // 1. Search and Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [showFilterBar, setShowFilterBar] = useState(false);

  // 2. Sorting States
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // 3. Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(defaultPageSize);

  // 4. Selection & Density States
  const [selectedRowKeys, setSelectedRowKeys] = useState<Set<string>>(new Set());
  const [density, setDensity] = useState<'compact' | 'standard' | 'relaxed'>('standard');
  const [hiddenColumns, setHiddenColumns] = useState<Set<string>>(new Set());

  // 5. In-place Edit States
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [editingRowData, setEditingRowData] = useState<T | null>(null);

  // Get primary row identifier
  const getRowId = (row: T, idx: number): string => {
    return (
      row[primaryKey] ||
      row.prId ||
      row.submittalId ||
      row.poNumber ||
      row.shipmentId ||
      row.reconciliationId ||
      row.quoteId ||
      row.boqId ||
      row.leadId ||
      row.projectId ||
      row.itemCode ||
      row.assetTag ||
      row.equipmentId ||
      `row-${idx}`
    );
  };

  // Filter & Search Logic
  const filteredData = useMemo(() => {
    return data.filter((row) => {
      // Global Search
      if (searchTerm) {
        const matchesGlobal = Object.values(row).some((val) =>
          String(val ?? '').toLowerCase().includes(searchTerm.toLowerCase())
        );
        if (!matchesGlobal) return false;
      }

      // Column Filters
      for (const [colKey, filterVal] of Object.entries(columnFilters)) {
        if (filterVal) {
          const rowVal = String(row[colKey] ?? '').toLowerCase();
          if (!rowVal.includes(filterVal.toLowerCase())) {
            return false;
          }
        }
      }

      return true;
    });
  }, [data, searchTerm, columnFilters]);

  // Sort Logic
  const sortedData = useMemo(() => {
    if (!sortKey) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];

      if (valA === valB) return 0;
      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;

      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortOrder === 'asc' ? valA - valB : valB - valA;
      }

      const strA = String(valA).toLowerCase();
      const strB = String(valB).toLowerCase();
      return sortOrder === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
    });
  }, [filteredData, sortKey, sortOrder]);

  // Paginated Data
  const paginatedData = useMemo(() => {
    if (!enablePagination || pageSize === -1) return sortedData;
    const startIndex = (currentPage - 1) * pageSize;
    return sortedData.slice(startIndex, startIndex + pageSize);
  }, [sortedData, enablePagination, currentPage, pageSize]);

  const totalPages = pageSize === -1 ? 1 : Math.ceil(sortedData.length / pageSize) || 1;

  // Sorting Handler
  const handleSort = (key: string) => {
    if (sortKey === key) {
      if (sortOrder === 'asc') {
        setSortOrder('desc');
      } else {
        setSortKey(null);
        setSortOrder('asc');
      }
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };

  // Selection Handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedData.map((row, idx) => getRowId(row, idx)));
      setSelectedRowKeys(allIds);
    } else {
      setSelectedRowKeys(new Set());
    }
  };

  const handleSelectRow = (rowId: string) => {
    const next = new Set(selectedRowKeys);
    if (next.has(rowId)) {
      next.delete(rowId);
    } else {
      next.add(rowId);
    }
    setSelectedRowKeys(next);
  };

  // In-place Editing Handlers
  const handleStartEdit = (idx: number, row: T) => {
    setEditingRowIndex(idx);
    setEditingRowData({ ...row });
  };

  const handleSaveEdit = (originalIdx: number) => {
    if (editingRowData && onUpdateData) {
      const updated = [...data];
      updated[originalIdx] = editingRowData;
      onUpdateData(updated);
      setEditingRowIndex(null);
      setEditingRowData(null);
    }
  };

  const handleCancelEdit = () => {
    setEditingRowIndex(null);
    setEditingRowData(null);
  };

  const handleCellChange = (key: string, value: any) => {
    setEditingRowData((prev) => (prev ? { ...prev, [key]: value } : prev));
  };

  const handleDelete = (row: T, originalIdx: number) => {
    if (onDeleteRow) {
      onDeleteRow(row, originalIdx);
    } else if (onUpdateData) {
      const updated = data.filter((_, idx) => idx !== originalIdx);
      onUpdateData(updated);
    }
  };

  const handleBulkDelete = () => {
    if (selectedRowKeys.size === 0) return;
    if (window.confirm(`Delete ${selectedRowKeys.size} selected records?`)) {
      if (onUpdateData) {
        const remaining = data.filter((row, idx) => !selectedRowKeys.has(getRowId(row, idx)));
        onUpdateData(remaining);
        setSelectedRowKeys(new Set());
      }
    }
  };

  // Density padding helper
  const densityPadding = {
    compact: 'py-1.5 px-2.5 text-xs',
    standard: 'py-2.5 px-3 text-xs',
    relaxed: 'py-3.5 px-4 text-sm',
  }[density];

  // Render Cell content
  const renderCellContent = (col: DataGridColumn<T>, row: T, isEditing: boolean) => {
    if (col.renderCell) {
      return col.renderCell(row[col.key], row, isEditing);
    }

    const value = isEditing && editingRowData ? editingRowData[col.key] : row[col.key];

    if (isEditing && col.type !== 'readonly' && !col.isFormula) {
      if (col.type === 'select' && col.options) {
        return (
          <select
            value={value ?? ''}
            onChange={(e) => handleCellChange(col.key, e.target.value)}
            className="w-full bg-white border border-indigo-300 rounded px-2 py-1 text-xs focus:ring-2 focus:ring-indigo-500 font-medium text-slate-800"
          >
            <option value="">-- Select --</option>
            {col.options.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        );
      }

      if (col.type === 'number' || col.type === 'currency' || col.type === 'percent') {
        return (
          <input
            type="number"
            value={value ?? 0}
            onChange={(e) => handleCellChange(col.key, parseFloat(e.target.value) || 0)}
            className="w-full bg-white border border-indigo-300 rounded px-2 py-1 text-xs focus:ring-2 focus:ring-indigo-500 font-mono text-slate-800"
          />
        );
      }

      if (col.type === 'date') {
        return (
          <input
            type="date"
            value={value ?? ''}
            onChange={(e) => handleCellChange(col.key, e.target.value)}
            className="w-full bg-white border border-indigo-300 rounded px-2 py-1 text-xs focus:ring-2 focus:ring-indigo-500 text-slate-800"
          />
        );
      }

      return (
        <input
          type="text"
          value={value ?? ''}
          onChange={(e) => handleCellChange(col.key, e.target.value)}
          className="w-full bg-white border border-indigo-300 rounded px-2 py-1 text-xs focus:ring-2 focus:ring-indigo-500 text-slate-800"
        />
      );
    }

    // Formatted display values
    if (col.type === 'currency' || (typeof value === 'number' && col.key.toLowerCase().includes('qar'))) {
      const numVal = Number(value) || 0;
      
      let textColor = 'text-slate-900';
      if (col.key === 'priceChange') {
        if (numVal < 0) textColor = 'text-emerald-600';
        else if (numVal > 0) textColor = 'text-rose-600';
      }
      
      return <span className={`font-mono font-semibold ${textColor}`}>QAR {numVal.toLocaleString('en-US')}</span>;
    }

    if (col.type === 'percent' || col.key.toLowerCase().includes('percent') || col.key.toLowerCase().includes('rate')) {
      const numVal = Number(value) || 0;
      
      let textColor = 'text-indigo-600';
      if (col.key === 'percentChange') {
        if (numVal < 0) textColor = 'text-emerald-600';
        else if (numVal > 0) textColor = 'text-rose-600';
      }
      
      return <span className={`font-mono font-bold ${textColor}`}>{numVal}%</span>;
    }

    // Status Badge Render
    const strVal = String(value ?? '');
    if (['Active', 'Approved', 'Cleared', 'Completed', 'Yes', 'Passed', 'Issued', 'Won', 'Healthy', 'Delivered to Site', 'In Stock', '3-Way Match Passed'].includes(strVal)) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
          {strVal}
        </span>
      );
    }
    if (['In Progress', 'Under Review', 'Pending', 'Issued to Vendor', 'Ongoing', 'Warning', 'Critical', 'In Transit', 'Planning Phase'].includes(strVal)) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
          {strVal}
        </span>
      );
    }
    if (['High', 'Lost', 'Rejected', 'Failed', 'Exceeded', 'Out of Stock', 'Mismatch'].includes(strVal)) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
          {strVal}
        </span>
      );
    }

    return <span className="text-slate-700 font-medium">{strVal}</span>;
  };

  const isAllSelected = paginatedData.length > 0 && paginatedData.every((row, idx) => selectedRowKeys.has(getRowId(row, idx)));

  return (
    <div id={id} className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col mb-6">
      {/* Header Toolbar */}
      {(title || subtitle || onAddRow || enableExport || customHeaderActions) && (
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              {title && <h3 className="font-bold text-slate-900 text-sm tracking-tight">{title}</h3>}
              {badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase border ${badgeColor}`}>
                  {badge}
                </span>
              )}
            </div>
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs w-36 sm:w-48 focus:w-60 transition-all focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-800"
              />
            </div>

              {/* Column Filter Toggle */}
              <div className="flex items-center bg-white border border-slate-200 rounded-lg">
                <button
                  onClick={() => setShowFilterBar(!showFilterBar)}
                  className={`p-1.5 text-xs font-semibold transition cursor-pointer ${
                    showFilterBar || Object.values(columnFilters).some(Boolean)
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                  title="Toggle Column Filters"
                >
                  <Filter className="w-3.5 h-3.5" />
                </button>
                
                {hiddenColumns.size > 0 && (
                  <div className="flex items-center">
                    <div className="w-[1px] h-4 bg-slate-200 mx-1"></div>
                    <button
                      onClick={() => setHiddenColumns(new Set())}
                      className="p-1.5 text-indigo-600 hover:bg-indigo-50 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                      title="Show Hidden Columns"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span className="text-[10px] pr-1">{hiddenColumns.size} Hidden</span>
                    </button>
                  </div>
                )}
              </div>

            {/* Bulk Selection Actions */}
            {selectedRowKeys.size > 0 && (
              <div className="flex items-center gap-1 bg-indigo-50 border border-indigo-200 rounded-lg px-2 py-1 text-xs">
                <span className="font-bold text-indigo-700">{selectedRowKeys.size} selected</span>
                <button
                  onClick={handleBulkDelete}
                  className="p-1 text-rose-600 hover:bg-rose-100 rounded cursor-pointer transition"
                  title="Bulk Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Custom Header Actions */}
            {customHeaderActions}

            {/* Add Record */}
            {onAddRow && (
              <button
                onClick={onAddRow}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Record
              </button>
            )}

            {/* Export CSV / Excel */}
            {enableExport && (
              <button
                onClick={() => exportSingleTableToCSV(sortedData, (title || 'Export').replace(/[^a-zA-Z0-9]/g, '_'))}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition-all cursor-pointer shadow-2xs"
                title="Export to CSV"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">Export</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Column Filter Sub-bar */}
      {showFilterBar && (
        <div className="p-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 items-center text-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Filters:</span>
          {columns
            .filter((c) => c.filterable !== false)
            .map((col) => (
              <input
                key={col.key}
                type="text"
                placeholder={`Filter ${col.header}...`}
                value={columnFilters[col.key] || ''}
                onChange={(e) =>
                  setColumnFilters((prev) => ({
                    ...prev,
                    [col.key]: e.target.value,
                  }))
                }
                className="px-2 py-1 bg-white border border-slate-200 rounded text-xs w-28 focus:w-36 transition-all focus:ring-1 focus:ring-indigo-500"
              />
            ))}
          {Object.values(columnFilters).some(Boolean) && (
            <button
              onClick={() => setColumnFilters({})}
              className="text-xs text-rose-600 font-bold hover:underline ml-auto cursor-pointer"
            >
              Clear Filters
            </button>
          )}
        </div>
      )}

      {/* Spreadsheet Grid Table */}
      <div className="overflow-x-auto max-h-[520px]">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100/90 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 sticky top-0 z-10">
              {enableSelection && (
                <th className="py-2.5 px-3 w-10 text-center border-r border-slate-200/60">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </th>
              )}
              <th className="py-2.5 px-3 w-10 text-center font-mono text-[10px] border-r border-slate-200/60">#</th>

              {columns.filter(col => !hiddenColumns.has(col.key)).map((col) => {
                const isSorted = sortKey === col.key;
                return (
                  <th
                    key={col.key}
                    className={`py-2.5 px-3 whitespace-nowrap font-semibold border-r border-slate-200/50 select-none group ${
                      col.sortable !== false ? 'hover:bg-slate-200/70 transition' : ''
                    } ${col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'}`}
                    style={{ width: col.width }}
                  >
                    <div className={`flex items-center justify-between gap-2`}>
                      <div 
                        className={`flex items-center gap-1.5 ${col.sortable !== false ? 'cursor-pointer' : ''} ${col.align === 'right' ? 'justify-end' : col.align === 'center' ? 'justify-center' : 'justify-start'}`}
                        onClick={() => col.sortable !== false && handleSort(col.key)}
                      >
                        <span>{col.header}</span>
                        {col.isFormula && (
                          <span className="text-[9px] font-mono text-indigo-500 bg-indigo-50 px-1 rounded font-normal lowercase" title={col.formulaLabel}>
                            fx
                          </span>
                        )}
                        {col.sortable !== false && (
                          <span className="text-slate-400">
                            {isSorted ? (
                              sortOrder === 'asc' ? (
                                <ArrowUp className="w-3 h-3 text-indigo-600 font-bold" />
                              ) : (
                                <ArrowDown className="w-3 h-3 text-indigo-600 font-bold" />
                              )
                            ) : (
                              <ArrowUpDown className="w-3 h-3 opacity-40 hover:opacity-100" />
                            )}
                          </span>
                        )}
                      </div>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          const nextHidden = new Set(hiddenColumns);
                          nextHidden.add(col.key);
                          setHiddenColumns(nextHidden);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-indigo-600 transition cursor-pointer"
                        title="Hide Column"
                      >
                        <EyeOff className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </th>
                );
              })}

              <th className="py-2.5 px-3 text-right w-24">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {paginatedData.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (enableSelection ? 2 : 1) + 1}
                  className="py-10 text-center text-slate-400 italic font-medium"
                >
                  {emptyStateMessage}
                </td>
              </tr>
            ) : (
              paginatedData.map((row, index) => {
                const originalIndex = data.findIndex((d) => d === row);
                const isEditing = editingRowIndex === originalIndex;
                const rowId = getRowId(row, originalIndex);
                const isSelected = selectedRowKeys.has(rowId);

                return (
                  <tr
                    key={rowId}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      isSelected ? 'bg-indigo-50/60' : isEditing ? 'bg-indigo-50/40' : index % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'
                    }`}
                  >
                    {/* Row Checkbox */}
                    {enableSelection && (
                      <td className={`${densityPadding} text-center border-r border-slate-100`}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleSelectRow(rowId)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>
                    )}

                    {/* Row Index */}
                    <td className={`${densityPadding} text-center font-mono text-[10px] text-slate-400 font-semibold border-r border-slate-100`}>
                      {(currentPage - 1) * pageSize + index + 1}
                    </td>

                    {/* Cell Data */}
                    {columns.filter(col => !hiddenColumns.has(col.key)).map((col) => (
                      <td
                        key={col.key}
                        className={`${densityPadding} whitespace-nowrap border-r border-slate-100/60 max-w-xs truncate ${
                          col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                        }`}
                      >
                        {renderCellContent(col, row, isEditing)}
                      </td>
                    ))}

                    {/* Action Column */}
                    <td className={`${densityPadding} text-right whitespace-nowrap`}>
                      {isEditing ? (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleSaveEdit(originalIndex)}
                            className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700 transition cursor-pointer"
                            title="Save Changes"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={handleCancelEdit}
                            className="p-1 bg-slate-200 text-slate-600 rounded hover:bg-slate-300 transition cursor-pointer"
                            title="Cancel Edit"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-1">
                          {rowActions &&
                            rowActions.map((action, aIdx) => {
                              if (action.showIf && !action.showIf(row)) return null;
                              return (
                                <button
                                  key={aIdx}
                                  onClick={() => action.onClick(row, originalIndex)}
                                  className="p-1 text-slate-500 hover:text-indigo-600 rounded hover:bg-slate-100 transition cursor-pointer"
                                  title={action.label}
                                >
                                  {action.icon || action.label}
                                </button>
                              );
                            })}

                          {onUpdateData && (
                            <button
                              onClick={() => handleStartEdit(originalIndex, row)}
                              className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-slate-100 transition cursor-pointer"
                              title="Edit Record"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {(onDeleteRow || onUpdateData) && (
                            <button
                              onClick={() => handleDelete(row, originalIndex)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition cursor-pointer"
                              title="Delete Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 bg-slate-50 border-t border-slate-100 text-xs font-semibold text-slate-600 flex flex-wrap justify-between items-center px-4 gap-3">
        <div className="flex items-center gap-2">
          <span>
            Showing <span className="font-bold text-slate-900">{filteredData.length > 0 ? (currentPage - 1) * pageSize + 1 : 0}</span> to{' '}
            <span className="font-bold text-slate-900">
              {pageSize === -1 ? filteredData.length : Math.min(currentPage * pageSize, filteredData.length)}
            </span>{' '}
            of <span className="font-bold text-slate-900">{filteredData.length}</span> records
          </span>
          {data.length !== filteredData.length && (
            <span className="text-slate-400 text-[11px]">(filtered from {data.length} total)</span>
          )}
        </div>

        {/* Page Controls */}
        {enablePagination && totalPages > 1 && (
          <div className="flex items-center gap-2">
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 rounded px-2 py-1 text-xs text-slate-700"
            >
              <option value={10}>10 / page</option>
              <option value={25}>25 / page</option>
              <option value={50}>50 / page</option>
              <option value={100}>100 / page</option>
              <option value={-1}>All</option>
            </select>

            <div className="flex items-center gap-1">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded bg-white border border-slate-200 disabled:opacity-40 hover:bg-slate-100 transition cursor-pointer"
                title="Previous Page"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono text-[11px]">
                {currentPage} / {totalPages}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="p-1 rounded bg-white border border-slate-200 disabled:opacity-40 hover:bg-slate-100 transition cursor-pointer"
                title="Next Page"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
