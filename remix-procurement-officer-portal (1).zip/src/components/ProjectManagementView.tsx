import React, { useState, useMemo } from 'react';
import {
  ProjectOverview,
  PhasedProjectTask,
  TeamSelection,
  ExecutionPhase,
  WeeklyExecutionReport,
  DropdownMaster,
  ProjectInstallationPhase,
} from '../types';
import { useAppData } from '../context/useAppData';
import {
  Briefcase,
  Layers,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Plus,
  Search,
  Filter,
  Users,
  ChevronRight,
  ArrowRight,
  ShieldCheck,
  Building2,
  FileCheck2,
  UserCheck,
  TrendingUp,
  Sparkles,
} from 'lucide-react';

interface ProjectManagementViewProps {
  projects: ProjectOverview[];
  tasks: PhasedProjectTask[];
  teams: TeamSelection[];
  executionPhases: ExecutionPhase[];
  weeklyReports: WeeklyExecutionReport[];
  dropdowns: DropdownMaster[];
  onUpdateProjects: (data: ProjectOverview[]) => void;
  onUpdateTasks: (data: PhasedProjectTask[]) => void;
  onUpdateTeams: (data: TeamSelection[]) => void;
  onOpenQuickAdd: () => void;
}

export const ProjectManagementView: React.FC<ProjectManagementViewProps> = ({
  projects,
  tasks,
  teams,
  executionPhases,
  weeklyReports,
  onUpdateProjects,
  onUpdateTasks,
  onUpdateTeams,
  onOpenQuickAdd,
}) => {
  const { setIsGeminiIntelligenceOpen, setGeminiIntelligenceMode } = useAppData();
  const [activeTab, setActiveTab] = useState<'master' | 'phased-tracker' | 'gantt' | 'tasks' | 'teams'>('phased-tracker');
  const [selectedProjectId, setSelectedProjectId] = useState<string>(projects[0]?.id || 'PRJ-2026-01');
  const [filterPhase, setFilterPhase] = useState<string>('All');
  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);

  // New task form state
  const [newTask, setNewTask] = useState<Partial<PhasedProjectTask>>({
    taskId: `TSK-${Date.now().toString().slice(-4)}`,
    projectId: selectedProjectId,
    projectName: projects.find(p => p.id === selectedProjectId)?.projectName || 'Project Site',
    taskName: '',
    phase: '1st Fix (Conduits, PVC/GI & Backboxes)',
    assignedTo: 'Technician Team A',
    startDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
    status: 'In Progress',
    priority: 'High',
    progressPercent: 0,
    notes: '',
  });

  const selectedProject = projects.find(p => p.id === selectedProjectId) || projects[0];

  const projectTasks = tasks.filter(t => t.projectId === selectedProjectId);

  const phaseProgress = useMemo(() => {
    const phases: { phase: ProjectInstallationPhase; name: string; tasksCount: number; avgProgress: number }[] = [
      {
        phase: '1st Fix (Conduits, PVC/GI & Backboxes)',
        name: '1. 1st Fix (Containment & Piping)',
        tasksCount: 0,
        avgProgress: 0,
      },
      {
        phase: '2nd Fix (Cable Pulling & Fluke Test)',
        name: '2. 2nd Fix (Cabling & Fluke Testing)',
        tasksCount: 0,
        avgProgress: 0,
      },
      {
        phase: 'Equipment Installation (Cameras, NVR, Server)',
        name: '3. Equipment Mounting (Cameras & Racks)',
        tasksCount: 0,
        avgProgress: 0,
      },
      {
        phase: 'System Integration & VMS Config',
        name: '4. VMS & RAID 5/6 Configuration',
        tasksCount: 0,
        avgProgress: 0,
      },
      {
        phase: 'Commissioning & Handover',
        name: '5. Testing, MOI DIA & Handover',
        tasksCount: 0,
        avgProgress: 0,
      },
    ];

    return phases.map(p => {
      const matched = projectTasks.filter(t => t.phase === p.phase);
      const totalProg = matched.reduce((sum, t) => sum + (t.progressPercent || 0), 0);
      const avg = matched.length > 0 ? Math.round(totalProg / matched.length) : (p.phase === '1st Fix (Conduits, PVC/GI & Backboxes)' ? 85 : p.phase === '2nd Fix (Cable Pulling & Fluke Test)' ? 40 : 0);
      return {
        ...p,
        tasksCount: matched.length,
        avgProgress: avg,
      };
    });
  }, [projectTasks]);

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.taskName) return;
    const taskToAdd: PhasedProjectTask = {
      ...(newTask as PhasedProjectTask),
      projectId: selectedProjectId,
      projectName: selectedProject.projectName,
    };
    onUpdateTasks([taskToAdd, ...tasks]);
    setIsAddTaskOpen(false);
    setNewTask({
      taskId: `TSK-${Date.now().toString().slice(-4)}`,
      projectId: selectedProjectId,
      projectName: selectedProject.projectName,
      taskName: '',
      phase: '1st Fix (Conduits, PVC/GI & Backboxes)',
      assignedTo: 'Technician Team A',
      startDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
      status: 'In Progress',
      priority: 'High',
      progressPercent: 0,
      notes: '',
    });
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: PhasedProjectTask['status'], progress: number) => {
    const updated = tasks.map(t => {
      if (t.taskId === taskId) {
        return {
          ...t,
          status: newStatus,
          progressPercent: progress,
        };
      }
      return t;
    });
    onUpdateTasks(updated);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 rounded-full border border-purple-400/30 text-purple-300 text-xs font-bold uppercase tracking-wider">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Module 3 • Project Management & Engineering</span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-white">
            ELV & Security Phased Execution Engine
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl">
            Track site milestones across 1st Fix, 2nd Fix, Equipment Installation, VMS Configuration, and MOI SSD Inspection Handover with interactive Gantt schedules.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            className="bg-slate-800 text-white border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500/40 cursor-pointer"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>
                {p.id}: {p.projectName.slice(0, 32)}...
              </option>
            ))}
          </select>

          <button
            onClick={() => {
              setGeminiIntelligenceMode('pm-risk');
              setIsGeminiIntelligenceOpen(true);
            }}
            className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-purple-200" />
            <span>Audit Schedule Risks (AI)</span>
          </button>

          <button
            onClick={() => setIsAddTaskOpen(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Site Task</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="bg-white border border-slate-200 rounded-2xl p-1.5 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('phased-tracker')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'phased-tracker'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>1. Phased Installation Tracker (1st/2nd Fix)</span>
        </button>

        <button
          onClick={() => setActiveTab('gantt')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'gantt'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>2. Interactive Gantt Timeline</span>
        </button>

        <button
          onClick={() => setActiveTab('tasks')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'tasks'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>3. Task & Dependency Board ({projectTasks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('master')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'master'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>4. All Projects Portfolio ({projects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('teams')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'teams'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>5. Engineering & Site Teams ({teams.length})</span>
        </button>
      </div>

      {/* TAB 1: PHASED INSTALLATION TRACKER */}
      {activeTab === 'phased-tracker' && (
        <div className="space-y-6">
          {/* Active Project Highlight Banner */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md">
                  {selectedProject.id}
                </span>
                <h3 className="text-lg font-extrabold text-slate-900 mt-1">
                  {selectedProject.projectName}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Client: <strong className="text-slate-700">{selectedProject.clientName}</strong> • Sector: {selectedProject.sector} • PM: {selectedProject.projectManager}
                </p>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div>
                  <p className="text-[11px] text-slate-400 font-semibold uppercase">Contract Value</p>
                  <p className="text-base font-extrabold text-slate-900">
                    QAR {selectedProject.contractValue?.toLocaleString() || '3,200,000'}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-slate-400 font-semibold uppercase">Target Handover</p>
                  <p className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg">
                    {selectedProject.plannedEndDate}
                  </p>
                </div>
              </div>
            </div>

            {/* 5-Phase Horizontal Milestone Flow */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-2">
              {phaseProgress.map((phase, idx) => {
                const isComplete = phase.avgProgress === 100;
                const isInProg = phase.avgProgress > 0 && phase.avgProgress < 100;

                return (
                  <div
                    key={phase.phase}
                    className={`p-4 rounded-2xl border transition relative space-y-2 ${
                      isComplete
                        ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
                        : isInProg
                        ? 'bg-indigo-50/60 border-indigo-200 text-indigo-950 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-white border border-slate-200">
                        Phase 0{idx + 1}
                      </span>
                      <span className="text-xs font-extrabold">
                        {phase.avgProgress}%
                      </span>
                    </div>

                    <h5 className="font-extrabold text-xs leading-snug">
                      {phase.name}
                    </h5>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isComplete ? 'bg-emerald-500' : 'bg-indigo-600'
                        }`}
                        style={{ width: `${phase.avgProgress}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                      <span>{phase.tasksCount} Tasks</span>
                      <span className="font-semibold">
                        {isComplete ? 'Completed' : isInProg ? 'In Progress' : 'Pending'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Phase-by-Phase Task Breakdown */}
          <div className="space-y-4">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Detailed Installation Activities & Site Reports</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {projectTasks.map((task) => (
                <div
                  key={task.taskId}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs hover:shadow-xs transition space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      {task.phase}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      task.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : task.status === 'In Progress'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {task.status} ({task.progressPercent}%)
                    </span>
                  </div>

                  <h5 className="font-extrabold text-xs text-slate-900">{task.taskName}</h5>
                  <p className="text-xs text-slate-600">{task.notes}</p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                    <span>Assigned: <strong className="text-slate-700">{task.assignedTo}</strong></span>
                    <span>Due: <strong>{task.dueDate}</strong></span>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleUpdateTaskStatus(task.taskId, 'In Progress', 50)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      50% In Prog
                    </button>
                    <button
                      onClick={() => handleUpdateTaskStatus(task.taskId, 'Completed', 100)}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      ✓ Mark 100% Done
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INTERACTIVE GANTT TIMELINE */}
      {activeTab === 'gantt' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">Project Gantt Schedule & Milestone Dependencies</h3>
              <p className="text-xs text-slate-500">Visual timeline mapped across project weeks and MOI submission gates.</p>
            </div>
            <span className="text-xs font-bold px-3 py-1 bg-indigo-50 text-indigo-700 rounded-xl">
              August – November 2026
            </span>
          </div>

          <div className="space-y-4 pt-2">
            {[
              { label: '1. Site Mobilization & Containment (1st Fix)', startPct: 0, widthPct: 30, color: 'bg-blue-600', status: '85% Complete' },
              { label: '2. Structured Cabling & Fluke Certification (2nd Fix)', startPct: 20, widthPct: 35, color: 'bg-indigo-600', status: '40% In Progress' },
              { label: '3. CCTV & NVR Equipment Mounting', startPct: 45, widthPct: 30, color: 'bg-purple-600', status: 'Planned' },
              { label: '4. 120-Day RAID 6 Storage & VMS Integration', startPct: 65, widthPct: 25, color: 'bg-teal-600', status: 'Planned' },
              { label: '5. MOI-SSD DIA Final Inspection & Certification', startPct: 80, widthPct: 20, color: 'bg-emerald-600', status: 'Target Gate' },
            ].map((milestone, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span>{milestone.label}</span>
                  <span className="text-slate-500 font-medium">{milestone.status}</span>
                </div>
                <div className="w-full bg-slate-100 h-6 rounded-xl overflow-hidden relative border border-slate-200">
                  <div
                    className={`h-full rounded-lg ${milestone.color} text-white text-[10px] font-bold flex items-center px-3 absolute transition-all duration-500 shadow-xs`}
                    style={{ left: `${milestone.startPct}%`, width: `${milestone.widthPct}%` }}
                  >
                    Phase {idx + 1}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: TASK BOARD */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">Task Board for {selectedProject.projectName}</h3>
            <button
              onClick={() => setIsAddTaskOpen(true)}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Task</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {['Not Started', 'In Progress', 'Completed'].map((columnStatus) => {
              const columnTasks = projectTasks.filter(t => t.status === columnStatus);
              return (
                <div key={columnStatus} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 min-h-[350px]">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <h5 className="font-extrabold text-xs uppercase tracking-wider text-slate-700">{columnStatus}</h5>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-700">
                      {columnTasks.length}
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {columnTasks.map((t) => (
                      <div key={t.taskId} className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700">
                          {t.phase}
                        </span>
                        <h6 className="font-bold text-xs text-slate-900">{t.taskName}</h6>
                        <p className="text-[11px] text-slate-500">{t.notes}</p>
                        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-100">
                          <span>{t.assignedTo}</span>
                          <span>Due: {t.dueDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: ALL PROJECTS PORTFOLIO */}
      {activeTab === 'master' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">Portfolio of Active Security & ELV Contracts</h3>
            <span className="text-xs text-slate-500 font-medium">{projects.length} Total Projects</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Project ID & Name</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Sector & Type</th>
                  <th className="py-3 px-4">Contract Value (QAR)</th>
                  <th className="py-3 px-4">Assigned PM</th>
                  <th className="py-3 px-4">Timeline</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {projects.map((proj) => (
                  <tr key={proj.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{proj.projectName}</p>
                      <p className="text-[11px] text-indigo-600 font-mono">{proj.id}</p>
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">{proj.clientName}</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold">
                        {proj.sector}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-extrabold text-slate-900">
                      QAR {proj.contractValue?.toLocaleString() || '3,200,000'}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">{proj.projectManager}</td>
                    <td className="py-3.5 px-4 text-[11px] text-slate-500">
                      {proj.startDate} → {proj.plannedEndDate}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800">
                        {proj.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => {
                          setSelectedProjectId(proj.id);
                          setActiveTab('phased-tracker');
                        }}
                        className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition cursor-pointer"
                      >
                        View Phases
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: ENGINEERING & TEAMS */}
      {activeTab === 'teams' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {teams.map((team) => (
            <div key={team.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h4 className="font-extrabold text-sm text-slate-900">{team.projectName}</h4>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {team.status}
                </span>
              </div>
              <div className="space-y-1.5 text-xs text-slate-600">
                <p><strong className="text-slate-800">Lead PM:</strong> {team.pm}</p>
                <p><strong className="text-slate-800">Site Engineer:</strong> {team.siteEngineer}</p>
                <p><strong className="text-slate-800">ELV Supervisor:</strong> {team.elvSupervisor}</p>
                <p><strong className="text-slate-800">Certified Technicians:</strong> {team.elvTechniciansCount} Techs</p>
                <p><strong className="text-slate-800">Helpers:</strong> {team.helpersCount} Staff</p>
              </div>
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400">Total Deployment:</span>
                <span className="font-extrabold text-indigo-600">{team.totalTeam} Personnel</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL: ADD TASK */}
      {isAddTaskOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-base text-slate-900">Add Phased Project Task</h3>
              <button
                onClick={() => setIsAddTaskOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddTask} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Task Description</label>
                <input
                  type="text"
                  required
                  value={newTask.taskName}
                  onChange={(e) => setNewTask({ ...newTask, taskName: e.target.value })}
                  placeholder="e.g. Pulling Cat6A LSZH Cable for 32 Dome Cameras"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Project Phase</label>
                <select
                  value={newTask.phase}
                  onChange={(e) => setNewTask({ ...newTask, phase: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden bg-white"
                >
                  <option value="1st Fix (Conduits, PVC/GI & Backboxes)">1st Fix (Conduits, PVC/GI & Backboxes)</option>
                  <option value="2nd Fix (Cable Pulling & Fluke Test)">2nd Fix (Cable Pulling & Fluke Test)</option>
                  <option value="Equipment Installation (Cameras, NVR, Server)">Equipment Installation (Cameras, NVR, Server)</option>
                  <option value="System Integration & VMS Config">System Integration & VMS Config</option>
                  <option value="Commissioning & Handover">Commissioning & Handover</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Assigned Team / Lead</label>
                  <input
                    type="text"
                    required
                    value={newTask.assignedTo}
                    onChange={(e) => setNewTask({ ...newTask, assignedTo: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Due Date</label>
                  <input
                    type="date"
                    required
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Technical Notes</label>
                <textarea
                  rows={2}
                  value={newTask.notes}
                  onChange={(e) => setNewTask({ ...newTask, notes: e.target.value })}
                  placeholder="Scaffolding requirements, Fluke test calibration..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddTaskOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
