import React, { useState, useMemo } from 'react';
import { ProjectAssetAssignment, InventoryItemRecord } from '../types';
import {
  Barcode,
  Building2,
  Search,
  Plus,
  QrCode,
  MapPin,
  Calendar,
  ShieldCheck,
  Tag,
  Filter,
  CheckCircle2,
  AlertTriangle,
  LayoutGrid,
  List,
  Layers,
  Sparkles,
} from 'lucide-react';
import { EditableTable, ColumnDef } from './EditableTable';

interface SerializedDeploymentsViewProps {
  projectAssets: ProjectAssetAssignment[];
  inventoryItems?: InventoryItemRecord[];
  onUpdateProjectAssets: (data: ProjectAssetAssignment[]) => void;
  onOpenQuickAdd?: () => void;
}

export const SerializedDeploymentsView: React.FC<SerializedDeploymentsViewProps> = ({
  projectAssets,
  inventoryItems = [],
  onUpdateProjectAssets,
  onOpenQuickAdd,
}) => {
  const [search, setSearch] = useState('');
  const [projectFilter, setProjectFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const [newAsset, setNewAsset] = useState<Partial<ProjectAssetAssignment>>({
    serialNumber: `SN-HIK-${Date.now().toString().slice(-6)}`,
    productName: '8MP Panoramic ColorVu Turret Camera',
    brand: 'Hikvision',
    model: 'DS-2CD2387G2P-LSU/SL',
    assignedProjectId: 'PRJ-2026-001',
    projectName: 'Ezdan Real Estate Phase 2 Upgrade',
    clientName: 'Ezdan Holding Group',
    installedLocation: 'Building B - Main Entrance Lobby (Ceiling Mount)',
    installationDate: new Date().toISOString().split('T')[0],
    warrantyExpiryDate: '2028-08-30',
    status: 'Installed Active',
    notes: 'MOI SSD approved camera connected to NVR-01 Port 4',
  });

  // Projects list
  const projectList = useMemo(() => {
    const list = new Set<string>();
    projectAssets.forEach((a) => {
      if (a.projectName) list.add(a.projectName);
    });
    return Array.from(list);
  }, [projectAssets]);

  // Filtered Assets
  const filteredAssets = useMemo(() => {
    return projectAssets.filter((asset) => {
      if (projectFilter !== 'All' && asset.projectName !== projectFilter) return false;
      if (statusFilter !== 'All' && asset.status !== statusFilter) return false;

      if (search.trim()) {
        const q = search.toLowerCase();
        const matchSerial = asset.serialNumber?.toLowerCase().includes(q);
        const matchProduct = asset.productName?.toLowerCase().includes(q);
        const matchBrand = asset.brand?.toLowerCase().includes(q);
        const matchModel = asset.model?.toLowerCase().includes(q);
        const matchProject = asset.projectName?.toLowerCase().includes(q);
        const matchLocation = asset.installedLocation?.toLowerCase().includes(q);
        const matchClient = asset.clientName?.toLowerCase().includes(q);
        if (!matchSerial && !matchProduct && !matchBrand && !matchModel && !matchProject && !matchLocation && !matchClient) {
          return false;
        }
      }
      return true;
    });
  }, [projectAssets, projectFilter, statusFilter, search]);

  const totalUnits = projectAssets.length;
  const activeInstalled = projectAssets.filter((a) => a.status === 'Installed Active').length;
  const needsAttention = projectAssets.filter((a) => a.status === 'Needs Replacement' || a.status === 'Decommissioned').length;

  const handleSaveNewAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAsset.serialNumber || !newAsset.productName) return;

    const record: ProjectAssetAssignment = {
      assetId: `ASSET-${Date.now().toString().slice(-5)}`,
      itemId: newAsset.itemId || `SKU-${Date.now().toString().slice(-4)}`,
      productName: newAsset.productName || 'Security Hardware Unit',
      brand: newAsset.brand || 'Generic',
      model: newAsset.model || '',
      serialNumber: newAsset.serialNumber || '',
      assignedProjectId: newAsset.assignedProjectId || 'PRJ-GEN',
      projectName: newAsset.projectName || 'General Deployment',
      clientName: newAsset.clientName || 'General Client',
      installedLocation: newAsset.installedLocation || 'On-Site Location',
      installationDate: newAsset.installationDate || new Date().toISOString().split('T')[0],
      warrantyExpiryDate: newAsset.warrantyExpiryDate || '2028-12-31',
      status: (newAsset.status as any) || 'Installed Active',
      notes: newAsset.notes || 'Registered in Unified Serial Barcode & Site Mapping Registry',
    };

    onUpdateProjectAssets([record, ...projectAssets]);
    setIsAddModalOpen(false);
  };

  const assetColumns: ColumnDef[] = [
    { key: 'serialNumber', label: 'Serial No / Barcode', type: 'text' },
    { key: 'productName', label: 'Hardware Description', type: 'text' },
    { key: 'brand', label: 'Brand', type: 'text' },
    { key: 'model', label: 'Model Code', type: 'text' },
    { key: 'projectName', label: 'Assigned Project', type: 'text' },
    { key: 'clientName', label: 'Client', type: 'text' },
    { key: 'installedLocation', label: 'Site Location / Zone', type: 'text' },
    { key: 'installationDate', label: 'Install Date', type: 'date' },
    { key: 'warrantyExpiryDate', label: 'Warranty Expiry', type: 'date' },
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: ['Installed Active', 'Needs Replacement', 'Decommissioned'],
    },
    { key: 'notes', label: 'Remarks / Zone Notes', type: 'text' },
  ];

  return (
    <div className="space-y-5">
      {/* Control Bar: Filters, Register Button & View Switcher */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-wrap flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search serial #, model, site, project..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-2xs font-bold text-slate-400 uppercase">Project:</span>
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden"
            >
              <option value="All">All Projects ({projectAssets.length})</option>
              {projectList.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span className="text-2xs font-bold text-slate-400 uppercase">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="Installed Active">Installed Active ({activeInstalled})</option>
              <option value="Needs Replacement">Needs Replacement</option>
              <option value="Decommissioned">Decommissioned</option>
            </select>
          </div>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Register Serialized Unit</span>
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shrink-0 self-end md:self-auto">
          <button
            onClick={() => setViewMode('cards')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              viewMode === 'cards' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Combined Cards</span>
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span>Master Spreadsheet</span>
          </button>
        </div>
      </div>

      {/* VIEW MODE 1: COMBINED CARDS (BARCODES + DEPLOYMENT MAPPING) */}
      {viewMode === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAssets.length === 0 ? (
            <div className="col-span-full py-12 text-center bg-white border border-slate-200 rounded-3xl p-8">
              <Barcode className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <h3 className="font-bold text-slate-700 text-sm">No Serialized Deployments Found</h3>
              <p className="text-xs text-slate-500 mt-1">Try adjusting your search or project filters.</p>
            </div>
          ) : (
            filteredAssets.map((asset) => {
              const isWarrantyExpired = new Date(asset.warrantyExpiryDate) < new Date();
              return (
                <div
                  key={asset.assetId}
                  className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs hover:shadow-md transition space-y-4 relative flex flex-col justify-between"
                >
                  <div className="space-y-3.5">
                    {/* Top Barcode Header */}
                    <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-teal-50 text-teal-700 rounded-lg flex items-center justify-center border border-teal-200">
                          <Barcode className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="font-mono text-xs font-black text-slate-900 tracking-tight block">
                            {asset.serialNumber}
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold uppercase">Barcode UID</span>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                          asset.status === 'Installed Active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : asset.status === 'Needs Replacement'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {asset.status}
                      </span>
                    </div>

                    {/* Hardware Info */}
                    <div>
                      <h4 className="font-extrabold text-xs text-slate-900 leading-snug">{asset.productName}</h4>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {asset.brand} • {asset.model}
                      </p>
                    </div>

                    {/* Site Deployment Location Mapping Box */}
                    <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 space-y-2 text-xs">
                      <div className="flex items-start gap-2">
                        <Building2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-extrabold text-slate-900 text-[11px]">{asset.projectName}</p>
                          <p className="text-[10px] text-slate-500">Client: {asset.clientName}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 pt-1 border-t border-slate-200/60">
                        <MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-[10px] font-bold text-slate-500 uppercase">Exact Site Location</p>
                          <p className="text-[11px] font-medium text-slate-800">{asset.installedLocation}</p>
                        </div>
                      </div>
                    </div>

                    {/* Lifecycle & Warranty Dates */}
                    <div className="grid grid-cols-2 gap-2 text-2xs bg-slate-50/50 p-2.5 rounded-xl border border-slate-100">
                      <div>
                        <span className="text-slate-400 block font-semibold">Installed Date:</span>
                        <span className="font-bold text-slate-700">{asset.installationDate}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block font-semibold">Warranty Expiry:</span>
                        <span className={`font-bold ${isWarrantyExpired ? 'text-rose-600' : 'text-emerald-700'}`}>
                          {asset.warrantyExpiryDate} {isWarrantyExpired ? '(Expired)' : '(Valid)'}
                        </span>
                      </div>
                    </div>

                    {asset.notes && (
                      <p className="text-[11px] text-slate-500 bg-white p-2 rounded-xl border border-slate-100 italic">
                        "{asset.notes}"
                      </p>
                    )}
                  </div>

                  {/* Footer Simulated QR & ID */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-400">
                    <span className="font-mono">{asset.assetId}</span>
                    <span className="inline-flex items-center gap-1 text-teal-600 font-bold">
                      <QrCode className="w-3 h-3" /> Scannable QR Ready
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* VIEW MODE 2: MASTER SPREADSHEET TABLE */}
      {viewMode === 'table' && (
        <EditableTable
          title="Serialized Assets & Project Site Deployment Master Table"
          subtitle="Direct live editing for hardware serial identifiers, barcodes, client project mappings, and warranty lifecycles"
          columns={assetColumns}
          data={filteredAssets}
          onUpdateData={onUpdateProjectAssets}
          onAddRow={() => setIsAddModalOpen(true)}
          badge="Table 5"
          badgeColor="bg-teal-50 text-teal-700 border-teal-200"
          enableSelection={false}
        />
      )}

      {/* MODAL: REGISTER NEW SERIALIZED ASSET & SITE MAPPING */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-xl shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  Register Serialized Asset & Site Deployment Mapping
                </h3>
                <p className="text-2xs text-slate-500">
                  Create a unified barcode/serial registry record and map it directly to a project site location.
                </p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNewAsset} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Serial Number / Barcode</label>
                  <input
                    type="text"
                    required
                    value={newAsset.serialNumber}
                    onChange={(e) => setNewAsset({ ...newAsset, serialNumber: e.target.value })}
                    placeholder="e.g. SN-HIK-882910"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Select Hardware SKU</label>
                  <select
                    onChange={(e) => {
                      const selectedItem = inventoryItems.find((i) => i.itemId === e.target.value);
                      if (selectedItem) {
                        setNewAsset({
                          ...newAsset,
                          itemId: selectedItem.itemId,
                          productName: `${selectedItem.brand} ${selectedItem.model}`,
                          brand: selectedItem.brand,
                          model: selectedItem.model,
                        });
                      }
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  >
                    <option value="">-- Choose from Warehouse SKU --</option>
                    {inventoryItems.map((item) => (
                      <option key={item.itemId} value={item.itemId}>
                        {item.brand} {item.model} ({item.itemId})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Hardware Product Name</label>
                <input
                  type="text"
                  required
                  value={newAsset.productName}
                  onChange={(e) => setNewAsset({ ...newAsset, productName: e.target.value })}
                  placeholder="e.g. 8MP Panoramic ColorVu Turret Camera"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Brand</label>
                  <input
                    type="text"
                    value={newAsset.brand}
                    onChange={(e) => setNewAsset({ ...newAsset, brand: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Model Code</label>
                  <input
                    type="text"
                    value={newAsset.model}
                    onChange={(e) => setNewAsset({ ...newAsset, model: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Site Deployment Info */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-teal-600" />
                  <span>Project Site Deployment Mapping</span>
                </h4>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Assigned Project Name</label>
                    <input
                      type="text"
                      required
                      value={newAsset.projectName}
                      onChange={(e) => setNewAsset({ ...newAsset, projectName: e.target.value })}
                      placeholder="e.g. Ezdan Real Estate Phase 2 Upgrade"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Client Name</label>
                    <input
                      type="text"
                      value={newAsset.clientName}
                      onChange={(e) => setNewAsset({ ...newAsset, clientName: e.target.value })}
                      placeholder="e.g. Ezdan Holding Group"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Exact Installed Location on Site</label>
                  <input
                    type="text"
                    required
                    value={newAsset.installedLocation}
                    onChange={(e) => setNewAsset({ ...newAsset, installedLocation: e.target.value })}
                    placeholder="e.g. Building B - Level 2 Server Room / Rack 04"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Install Date</label>
                  <input
                    type="date"
                    value={newAsset.installationDate}
                    onChange={(e) => setNewAsset({ ...newAsset, installationDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Warranty Expiry</label>
                  <input
                    type="date"
                    value={newAsset.warrantyExpiryDate}
                    onChange={(e) => setNewAsset({ ...newAsset, warrantyExpiryDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Deployment Status</label>
                  <select
                    value={newAsset.status}
                    onChange={(e) => setNewAsset({ ...newAsset, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  >
                    <option value="Installed Active">Installed Active</option>
                    <option value="Needs Replacement">Needs Replacement</option>
                    <option value="Decommissioned">Decommissioned</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Technician / Zone Remarks</label>
                <input
                  type="text"
                  value={newAsset.notes}
                  onChange={(e) => setNewAsset({ ...newAsset, notes: e.target.value })}
                  placeholder="e.g. Tested with DIA Inspector, port configured on PoE Switch 01"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  <span>Register & Save Deployment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
