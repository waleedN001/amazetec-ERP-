import React from 'react';
import { EditableTable, ColumnDef } from './EditableTable';
import {
  ProjectOverview,
  ProjectPaymentMilestone,
  AdvanceCheck,
  TeamSelection,
  ExecutionPhase,
  WeeklyExecutionReport,
  QualityCheckInspection,
  ClientCommunication,
  ProjectCompletionApproval,
  DropdownMaster,
} from '../types';
import { Briefcase, CheckCircle2, Clock, Users, Shield, MessageSquare } from 'lucide-react';

interface PMViewProps {
  projects: ProjectOverview[];
  paymentMilestones: ProjectPaymentMilestone[];
  advanceChecks: AdvanceCheck[];
  teamSelections: TeamSelection[];
  executionPhases: ExecutionPhase[];
  weeklyReports: WeeklyExecutionReport[];
  qualityChecks: QualityCheckInspection[];
  clientCommunications: ClientCommunication[];
  projectCompletions: ProjectCompletionApproval[];
  dropdowns: DropdownMaster[];
  onUpdateProjects: (data: ProjectOverview[]) => void;
  onUpdateMilestones: (data: ProjectPaymentMilestone[]) => void;
  onUpdateAdvanceChecks: (data: AdvanceCheck[]) => void;
  onUpdateTeamSelections: (data: TeamSelection[]) => void;
  onUpdateExecutionPhases: (data: ExecutionPhase[]) => void;
  onUpdateWeeklyReports: (data: WeeklyExecutionReport[]) => void;
  onUpdateQualityChecks: (data: QualityCheckInspection[]) => void;
  onUpdateClientCommunications: (data: ClientCommunication[]) => void;
  onUpdateProjectCompletions: (data: ProjectCompletionApproval[]) => void;
  onOpenQuickAdd: () => void;
}

export const PMView: React.FC<PMViewProps> = ({
  projects,
  paymentMilestones,
  advanceChecks,
  teamSelections,
  executionPhases,
  weeklyReports,
  qualityChecks,
  clientCommunications,
  projectCompletions,
  dropdowns,
  onUpdateProjects,
  onUpdateMilestones,
  onUpdateAdvanceChecks,
  onUpdateTeamSelections,
  onUpdateExecutionPhases,
  onUpdateWeeklyReports,
  onUpdateQualityChecks,
  onUpdateClientCommunications,
  onUpdateProjectCompletions,
  onOpenQuickAdd,
}) => {
  const getDropdownOptions = (catName: string) => {
    const found = dropdowns.find((d) => d.categoryName.toLowerCase().includes(catName.toLowerCase()));
    return found ? found.options : [];
  };

  // 1. Project Overview Columns
  const projectCols: ColumnDef[] = [
    { key: 'id', label: 'PRJ ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'clientName', label: 'Client', type: 'text' },
    { key: 'sector', label: 'Sector', type: 'select', options: getDropdownOptions('Sectors') },
    { key: 'category', label: 'Category', type: 'select', options: getDropdownOptions('Categories') },
    { key: 'boqValue', label: 'BOQ Value', type: 'currency' },
    { key: 'contractValue', label: 'Contract Value', type: 'currency' },
    { key: 'startDate', label: 'Start Date', type: 'date' },
    { key: 'plannedEndDate', label: 'Planned End', type: 'date' },
    { key: 'status', label: 'Status', type: 'select', options: ['Planned', 'Ongoing', 'Completed', 'On Hold', 'Cancelled', 'Tender', 'Under Review'] },
    { key: 'projectManager', label: 'PM', type: 'text' },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // 2. Payment Milestones Columns
  const milestoneCols: ColumnDef[] = [
    { key: 'id', label: 'ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'mobilization', label: 'Mobilization (10%)', type: 'currency' },
    { key: 'materialSupply', label: 'Material (50%)', type: 'currency' },
    { key: 'installation', label: 'Installation (25%)', type: 'currency' },
    { key: 'commissioning', label: 'Commissioning (10%)', type: 'currency' },
    { key: 'retention', label: 'Retention (5%)', type: 'currency' },
    { key: 'total', label: 'Total Value', type: 'currency', isFormula: true, formulaLabel: '=SUM(Milestones)' },
  ];

  // 3. Advance Checks Columns
  const advanceCheckCols: ColumnDef[] = [
    { key: 'id', label: 'AC ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'advanceAmount', label: 'Advance QAR', type: 'currency' },
    { key: 'receivedDate', label: 'Received Date', type: 'date' },
    { key: 'chequeNumber', label: 'Cheque #', type: 'text' },
    { key: 'bank', label: 'Bank', type: 'text' },
    { key: 'clearanceStatus', label: 'Clearance Status', type: 'select', options: ['Cleared', 'Pending', 'Bounced', 'On Hold', 'Under Verification'] },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // 4. Team Selection Columns
  const teamCols: ColumnDef[] = [
    { key: 'id', label: 'TS ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'pm', label: 'Lead PM', type: 'text' },
    { key: 'siteEngineer', label: 'Site Engineer', type: 'text' },
    { key: 'elvSupervisor', label: 'ELV Supervisor', type: 'text' },
    { key: 'elvTechniciansCount', label: 'Technicians Count', type: 'number' },
    { key: 'helpersCount', label: 'Helpers Count', type: 'number' },
    { key: 'totalTeam', label: 'Total Team Size', type: 'number', isFormula: true, formulaLabel: '=Techs + Helpers + Eng' },
    { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Planned', 'Completed'] },
  ];

  // 5. Execution Phases Columns
  const phaseCols: ColumnDef[] = [
    { key: 'id', label: 'EP ID', type: 'readonly' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'phase1', label: 'Phase 1 (1st Fix)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'phase2', label: 'Phase 2 (2nd Fix)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'phase3', label: 'Phase 3 (Equipment)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'phase4', label: 'Phase 4 (Testing)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'phase5', label: 'Phase 5 (DIA)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'phase6', label: 'Phase 6 (Handover)', type: 'select', options: getDropdownOptions('Phase Status') },
    { key: 'overallProgress', label: 'Overall Progress', type: 'percent' },
  ];

  // 6. Weekly Execution Reports Columns
  const reportCols: ColumnDef[] = [
    { key: 'reportId', label: 'Report ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'weekEnding', label: 'Week Ending', type: 'date' },
    { key: 'progressPercent', label: 'Progress (%)', type: 'percent' },
    { key: 'keyAchievements', label: 'Key Achievements', type: 'text' },
    { key: 'issuesChallenges', label: 'Issues / Challenges', type: 'text' },
    { key: 'mitigation', label: 'Mitigation', type: 'text' },
    { key: 'nextWeekPlan', label: 'Next Week Plan', type: 'text' },
    { key: 'preparedBy', label: 'Prepared By', type: 'text' },
  ];

  // 7. Quality Check Columns
  const qcCols: ColumnDef[] = [
    { key: 'id', label: 'QC ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'qcCheckDate', label: 'QC Date', type: 'text' },
    { key: 'cameraResolution', label: 'Resolution', type: 'text' },
    { key: 'storageRetention', label: 'Storage Days', type: 'text' },
    { key: 'raidConfig', label: 'RAID', type: 'text' },
    { key: 'moiCompliance', label: 'MOI Status', type: 'text' },
    { key: 'overallRatingPercent', label: 'Rating (%)', type: 'percent' },
    { key: 'findings', label: 'Findings', type: 'text' },
    { key: 'status', label: 'Status', type: 'select', options: ['Pending', 'In Progress', 'Passed', 'Failed', 'On Hold'] },
  ];

  // 8. Client Communications Columns
  const clientCommCols: ColumnDef[] = [
    { key: 'id', label: 'CC ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'clientName', label: 'Client Name', type: 'text' },
    { key: 'dateSent', label: 'Date Sent', type: 'date' },
    { key: 'updateType', label: 'Update Type', type: 'select', options: getDropdownOptions('Update Type') },
    { key: 'status', label: 'Status', type: 'select', options: ['Sent', 'Pending', 'Acknowledged'] },
    { key: 'attachments', label: 'Attachments', type: 'text' },
    { key: 'responseReceived', label: 'Response (Y/N)', type: 'select', options: ['Yes', 'No'] },
    { key: 'remarks', label: 'Remarks', type: 'text' },
  ];

  // 9. Completion & Approval Status Columns
  const completionCols: ColumnDef[] = [
    { key: 'id', label: 'PCA ID', type: 'readonly' },
    { key: 'projectId', label: 'PRJ ID', type: 'text' },
    { key: 'projectName', label: 'Project Name', type: 'text' },
    { key: 'completionDate', label: 'Completion Date', type: 'text' },
    { key: 'diaSubmissionDate', label: 'DIA Submission', type: 'text' },
    { key: 'inspectionDate', label: 'Inspection Date', type: 'text' },
    { key: 'inspectionStatus', label: 'Inspection', type: 'select', options: ['Passed', 'Failed', 'Pending'] },
    { key: 'moiCertificateStatus', label: 'MOI Certificate', type: 'select', options: ['Issued', 'Pending', 'In Progress'] },
    { key: 'dsaApprovalStatus', label: 'DSA Approval', type: 'select', options: ['Approved', 'Pending', 'In Progress'] },
    { key: 'diaApprovalStatus', label: 'DIA Approval', type: 'select', options: ['Approved', 'Pending', 'In Progress'] },
    { key: 'overallStatus', label: 'Overall Status', type: 'select', options: ['Completed', 'Ongoing', 'Planned'] },
  ];

  const completedCount = projects.filter((p) => p.status === 'Completed').length;
  const totalContractValue = projects.reduce((sum, p) => sum + (Number(p.contractValue) || 0), 0);

  return (
    <div className="space-y-6 pb-8">
      {/* Small Dashboard Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-3">
          <Briefcase className="w-5 h-5 text-indigo-600" />
          <h2 className="font-bold text-slate-900 text-lg tracking-tight">Project Manager Master Sheet</h2>
          <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
            Project Overview, Payment Milestones, Team Resources, Execution Phases, Weekly Reports, Quality & DIA/MOI Approvals
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Projects Managed</p>
            <p className="text-xl font-black text-slate-900">{projects.length} Projects</p>
            <p className="text-[10px] text-emerald-600 font-semibold mt-0.5">{completedCount} Projects Completed</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Contract Value</p>
            <p className="text-xl font-black font-mono text-indigo-600">QAR {totalContractValue.toLocaleString()}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Healthcare, Schools, Ezdan</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">Site Execution Teams</p>
            <p className="text-xl font-black text-slate-900">{teamSelections.length} Deployed Teams</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Engineers & ELV Technicians</p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
            <p className="text-[10px] font-bold uppercase text-slate-400">MOI Certificates Issued</p>
            <p className="text-xl font-black text-emerald-600">
              {projectCompletions.filter((c) => c.moiCertificateStatus === 'Issued').length} Certificates
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">100% MOI Inspection Pass Rate</p>
          </div>
        </div>
      </div>

      {/* Table 1: Project Overview */}
      <EditableTable
        title="Project Overview Master Table"
        subtitle="All projects, clients, sectors, contract values, PM leads and planned start/end timelines"
        columns={projectCols}
        data={projects}
        onUpdateData={onUpdateProjects}
        onAddRow={onOpenQuickAdd}
        badge="Table 1"
      />

      {/* Table 2: Payment Milestones & Advance Checks */}
      <div className="space-y-6">
        <EditableTable
          title="Payment Milestones Breakdown"
          subtitle="Contract terms: Mobilization (10%), Material Supply (50%), Installation (25%), Commissioning (10%), Retention (5%)"
          columns={milestoneCols}
          data={paymentMilestones}
          onUpdateData={onUpdateMilestones}
          badge="Table 2A"
          badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
        />

        <EditableTable
          title="Advance Payment Cheques Log"
          subtitle="Track mobilization advance cheques, banks (QNB), clearance dates and status"
          columns={advanceCheckCols}
          data={advanceChecks}
          onUpdateData={onUpdateAdvanceChecks}
          badge="Table 2B"
          badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
        />
      </div>

      {/* Table 3: Team Selection & Resource Planning */}
      <EditableTable
        title="Team Selection & Site Resource Planning"
        subtitle="Assign Lead PM (Syed Amer), Site Engineers (Zain Tariq, Syed Salman), Supervisors & Technicians"
        columns={teamCols}
        data={teamSelections}
        onUpdateData={onUpdateTeamSelections}
        badge="Table 3"
        badgeColor="bg-purple-50 text-purple-700 border-purple-200"
      />

      {/* Table 4: Execution Phases */}
      <EditableTable
        title="Execution Phases & Milestones Tracker"
        subtitle="Track Phase 1 (1st Fix), Phase 2 (2nd Fix), Phase 3 (Equipment), Phase 4 (Testing), Phase 5 (DIA), Phase 6 (Handover)"
        columns={phaseCols}
        data={executionPhases}
        onUpdateData={onUpdateExecutionPhases}
        badge="Table 4"
        badgeColor="bg-indigo-50 text-indigo-700 border-indigo-200"
      />

      {/* Table 5: Weekly Execution Reports */}
      <EditableTable
        title="Weekly Site Execution Reports"
        subtitle="Progress percentages, achievements, site challenges, mitigations and next week's operational plan"
        columns={reportCols}
        data={weeklyReports}
        onUpdateData={onUpdateWeeklyReports}
        badge="Table 5"
        badgeColor="bg-amber-50 text-amber-700 border-amber-200"
      />

      {/* Table 6: Quality Checks & Inspections */}
      <EditableTable
        title="Quality Checks & Technical Inspections"
        subtitle="Camera resolutions, HDD storage retention days (120 days), RAID 5 configuration & MOI compliance"
        columns={qcCols}
        data={qualityChecks}
        onUpdateData={onUpdateQualityChecks}
        badge="Table 6"
        badgeColor="bg-rose-50 text-rose-700 border-rose-200"
      />

      {/* Table 7: Client Communication & Updates */}
      <EditableTable
        title="Client Communication & Progress Updates"
        subtitle="Weekly PDF updates sent to clients (Ezdan, Al Jazeera) and acknowledgement records"
        columns={clientCommCols}
        data={clientCommunications}
        onUpdateData={onUpdateClientCommunications}
        badge="Table 7"
        badgeColor="bg-sky-50 text-sky-700 border-sky-200"
      />

      {/* Table 8: Completion & MOI / DIA Approvals */}
      <EditableTable
        title="Project Completion, DIA & MOI Certificate Approvals"
        subtitle="Track DIA inspection dates, DSA approvals, MOI certificate issuance and final client handover"
        columns={completionCols}
        data={projectCompletions}
        onUpdateData={onUpdateProjectCompletions}
        badge="Table 8"
        badgeColor="bg-emerald-50 text-emerald-700 border-emerald-200"
      />
    </div>
  );
};
