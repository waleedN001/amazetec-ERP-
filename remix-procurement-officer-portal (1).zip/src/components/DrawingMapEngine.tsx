import React, { useState, useRef, useMemo } from 'react';
import {
  Camera,
  Network,
  Server,
  Route,
  ShieldCheck,
  Box,
  Eye,
  Cpu,
  Radio,
  MapPin,
  MousePointer,
  Layers,
  FileCode2,
  ZoomIn,
  PenTool,
  Highlighter,
  Eraser,
  ZoomOut,
  RotateCcw,
  Upload,
  Sparkles,
  Check,
  Trash2,
  X,
  Plus,
  ArrowRight,
  Info,
  Maximize2,
  SlidersHorizontal,
  ChevronDown,
  Activity,
  Zap,
  Cable,
  Building,
  CheckCircle2,
  Workflow
} from 'lucide-react';
import { BlueprintPin, BlueprintRoute } from './SCMPipelineView';
import { DrawingTakeoffSession } from '../types';

export interface DrawingMapEngineProps {
  blueprintPins: BlueprintPin[];
  setBlueprintPins: React.Dispatch<React.SetStateAction<BlueprintPin[]>>;
  blueprintRoutes: BlueprintRoute[];
  setBlueprintRoutes: React.Dispatch<React.SetStateAction<BlueprintRoute[]>>;
  takeoffSession: DrawingTakeoffSession;
  setTakeoffSession: React.Dispatch<React.SetStateAction<DrawingTakeoffSession>>;
  isScanningDrawing: boolean;
  scanMessage: string;
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  fileInputRef: React.RefObject<HTMLInputElement>;
  onTriggerAIScan: () => void;
}

export type MapViewMode = '2d_blueprint' | '3d_isometric' | 'topology';

// Pre-defined Sample Drawings for instant OCR demonstration
export const SAMPLE_CAD_PLANS = [
  {
    name: 'Hamad_Port_Security_Gate_Perimeter.dwg',
    type: 'DWG' as const,
    scale: '1:100',
    project: 'Hamad Port Terminal 2 Upgrade',
    devices: 28,
    cablesMeters: 2450,
  },
  {
    name: 'Doha_West_Bay_Tower_ELV_FloorPlan.pdf',
    type: 'PDF' as const,
    scale: '1:50',
    project: 'West Bay Commercial Tower',
    devices: 46,
    cablesMeters: 4120,
  },
  {
    name: 'Lusail_Marina_Hotel_CCTV_Containment.dwg',
    type: 'DWG' as const,
    scale: '1:100',
    project: 'Lusail Marina Luxury Hotel',
    devices: 34,
    cablesMeters: 3100,
  },
];

export type DrawingPath = {
  id: string;
  type: 'draw' | 'highlight';
  points: { x: number; y: number }[];
};

export const DrawingMapEngine: React.FC<DrawingMapEngineProps> = ({
  blueprintPins,
  setBlueprintPins,
  blueprintRoutes,
  setBlueprintRoutes,
  takeoffSession,
  setTakeoffSession,
  isScanningDrawing,
  scanMessage,
  onFileUpload,
  fileInputRef,
  onTriggerAIScan,
}) => {
  // Map View Mode State
  const [mapViewMode, setMapViewMode] = useState<MapViewMode>('2d_blueprint');
  const [selectedOverlayTool, setSelectedOverlayTool] = useState<'camera' | 'switch' | 'cable_tray' | 'select' | 'draw' | 'highlight' | 'eraser'>('select');
  const [canvasZoom, setCanvasZoom] = useState<number>(1);
  const [showCanvasPins, setShowCanvasPins] = useState<boolean>(true);
  const [showCanvasRoutes, setShowCanvasRoutes] = useState<boolean>(true);
  
  // Annotation States
  const [drawingPaths, setDrawingPaths] = useState<DrawingPath[]>([]);
  const [currentDrawingPath, setCurrentDrawingPath] = useState<DrawingPath | null>(null);
  const [isDrawingOverlay, setIsDrawingOverlay] = useState(false);
  const [showCanvasGrid, setShowCanvasGrid] = useState<boolean>(true);
  const [showFovCones, setShowFovCones] = useState<boolean>(true);
  const [showSwitchesOnly, setShowSwitchesOnly] = useState<boolean>(false);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');
  const [hoveredEntityId, setHoveredEntityId] = useState<string | null>(null);

  // Active Selected Element for Detailed Inspector
  const [selectedPinForInspect, setSelectedPinForInspect] = useState<BlueprintPin | null>(null);
  const [selectedRouteForInspect, setSelectedRouteForInspect] = useState<BlueprintRoute | null>(null);

  // Measurement State
  const [activeMeasurePoints, setActiveMeasurePoints] = useState<{ x: number; y: number }[]>([]);
  const [activeMeasureCableType, setActiveMeasureCableType] = useState<string>('CBL-CAT6-UTP-LSZH-01');

  // Modal Pinning State
  const [pinModalCoordinates, setPinModalCoordinates] = useState<{ x: number; y: number } | null>(null);
  const [deviceToPinCode, setDeviceToPinCode] = useState<string>('CAM-4MP-DOME-IR-01');
  const [deviceToPinCategory, setDeviceToPinCategory] = useState<string>('Cameras & VMS');
  const [deviceToPinQty, setDeviceToPinQty] = useState<number>(1);
  const [deviceToPinNotes, setDeviceToPinNotes] = useState<string>('East Corridor Ceiling Mount');
  const [deviceConnectedSwitch, setDeviceConnectedSwitch] = useState<string>('SW-POE-24P-MDF (Port 05)');
  const [deviceConnectedWire, setDeviceConnectedWire] = useState<string>('Cat6 UTP LSZH Cable');

  const canvasRef = useRef<HTMLDivElement>(null);

  // Network Switch Definitions mapped on the Map
  const networkSwitches = useMemo(() => [
    {
      id: 'sw-1',
      tag: 'SW-POE-24P-MDF',
      name: 'MDF Core 24-Port PoE+ Gigabit Switch',
      model: 'Cisco Catalyst C9200L-24P-4G',
      location: 'MDF Server Room GF',
      x: 16,
      y: 44,
      portsTotal: 24,
      portsUsed: 18,
      poeBudget: '370W (Used: 210W)',
      uplink: '10G SM Fiber to Core Server NVR',
      color: '#8b5cf6',
      connectedCameras: ['CAM-01 Dome', 'CAM-02 Bullet', 'ACS-4Door Panel', 'Face Recognition Terminals']
    },
    {
      id: 'sw-2',
      tag: 'SW-IDF-01-GATE',
      name: 'IDF Gate 1-4 Sub-Distribution Switch',
      model: 'Cisco Catalyst C9200L-8P-2G',
      location: 'Gate 1-4 Guard Cabin IDF',
      x: 78,
      y: 72,
      portsTotal: 8,
      portsUsed: 6,
      poeBudget: '124W (Used: 68W)',
      uplink: '12-Core SM Fiber to MDF Server Room',
      color: '#10b981',
      connectedCameras: ['ANPR-4K Gate 1', 'ANPR-4K Gate 2', 'ANPR-4K Gate 3', 'ANPR-4K Gate 4']
    }
  ], []);

  // Available Devices to Pin
  const availableDevicesToPin = [
    { code: 'CAM-4MP-DOME-IR-01', label: '4MP IR Dome Camera (Indoor Corridor)', category: 'Cameras & VMS', iconType: 'camera' as const, color: '#3b82f6', defaultWire: 'Cat6 UTP LSZH Cable' },
    { code: 'CAM-4MP-BULLET-WDR-02', label: '4MP WDR Bullet Camera (Perimeter Fence)', category: 'Cameras & VMS', iconType: 'camera' as const, color: '#0ea5e9', defaultWire: 'Cat6 UTP LSZH Cable' },
    { code: 'CAM-32X-PTZ-03', label: '32x Speed Dome PTZ Camera (Yard / 360°)', category: 'Cameras & VMS', iconType: 'camera' as const, color: '#a855f7', defaultWire: 'Cat6 UTP High-PoE Cable' },
    { code: 'CAM-4K-ANPR-04', label: '4K ANPR Number Plate Camera (Gate Vehicle Lanes)', category: 'Cameras & VMS', iconType: 'anpr' as const, color: '#10b981', defaultWire: 'Cat6 UTP LSZH Cable' },
    { code: 'SW-POE-24PORT-L2-02', label: '24-Port PoE+ L2 Gigabit Switch (Rack Mount)', category: 'Active Switches', iconType: 'rack' as const, color: '#8b5cf6', defaultWire: '12-Core SM Fiber Backbone' },
    { code: 'RACK-42U-SRV-01', label: '42U Server Rack Enclosure (Server Room)', category: 'Racks & Power', iconType: 'rack' as const, color: '#6366f1', defaultWire: 'GI Cable Tray Main Spine' },
    { code: 'ACS-FACE-TERM-02', label: 'AI Face Recognition & Biometric Terminal', category: 'Access Control', iconType: 'sensor' as const, color: '#06b6d4', defaultWire: 'Cat6 UTP LSZH Cable' },
    { code: 'ACS-4DOOR-NET-01', label: '4-Door TCP/IP Access Control Panel', category: 'Access Control', iconType: 'access' as const, color: '#f59e0b', defaultWire: 'Cat6 UTP + 1.5mm Fire Wire' },
  ];

  // Canvas Click Handler for Pinning or Route Measuring
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (selectedOverlayTool !== 'draw' && selectedOverlayTool !== 'highlight' && selectedOverlayTool !== 'eraser') return;
    
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;
    
    const xPercent = (clickX / rect.width) * 100;
    const yPercent = (clickY / rect.height) * 100;

    if (selectedOverlayTool === 'eraser') {
      setDrawingPaths(prev => prev.filter(path => {
        return !path.points.some(p => Math.abs(p.x - xPercent) < 2 && Math.abs(p.y - yPercent) < 2);
      }));
      setIsDrawingOverlay(true);
    } else {
      setIsDrawingOverlay(true);
      setCurrentDrawingPath({
        id: crypto.randomUUID(),
        type: selectedOverlayTool,
        points: [{ x: xPercent, y: yPercent }]
      });
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDrawingOverlay || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;
    
    const xPercent = (clickX / rect.width) * 100;
    const yPercent = (clickY / rect.height) * 100;

    if (selectedOverlayTool === 'eraser') {
      setDrawingPaths(prev => prev.filter(path => {
        return !path.points.some(p => Math.abs(p.x - xPercent) < 2 && Math.abs(p.y - yPercent) < 2);
      }));
    } else if (currentDrawingPath) {
      setCurrentDrawingPath(prev => {
        if (!prev) return null;
        return {
          ...prev,
          points: [...prev.points, { x: xPercent, y: yPercent }]
        };
      });
    }
  };

  const handleCanvasMouseUp = () => {
    if (isDrawingOverlay) {
      if (currentDrawingPath && currentDrawingPath.points.length > 1) {
        setDrawingPaths(prev => [...prev, currentDrawingPath]);
      }
      setCurrentDrawingPath(null);
      setIsDrawingOverlay(false);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (selectedOverlayTool === 'draw' || selectedOverlayTool === 'highlight' || selectedOverlayTool === 'eraser') return;

    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const xPercent = Math.round((clickX / rect.width) * 100);
    const yPercent = Math.round((clickY / rect.height) * 100);

    if (selectedOverlayTool === 'camera' || selectedOverlayTool === 'switch') {
      setPinModalCoordinates({ x: xPercent, y: yPercent });
    } else if (selectedOverlayTool === 'cable_tray') {
      setActiveMeasurePoints((prev) => [...prev, { x: xPercent, y: yPercent }]);
    }
  };

  const handleSavePin = () => {
    if (!pinModalCoordinates) return;
    const selectedDev = availableDevicesToPin.find((d) => d.code === deviceToPinCode) || availableDevicesToPin[0];

    const newPin: BlueprintPin = {
      id: `pin-${Date.now()}`,
      x: pinModalCoordinates.x,
      y: pinModalCoordinates.y,
      itemCode: selectedDev.code,
      label: selectedDev.label.split('(')[0].trim(),
      category: selectedDev.category,
      quantity: deviceToPinQty,
      locationNotes: `${deviceToPinNotes} | Connected via ${deviceConnectedWire} to ${deviceConnectedSwitch}`,
      iconType: selectedDev.iconType,
      color: selectedDev.color,
    };

    setBlueprintPins((prev) => [...prev, newPin]);
    setPinModalCoordinates(null);
    setDeviceToPinNotes('Zone Corridor Mount');
  };

  const calculateMeasuredLength = (points: { x: number; y: number }[]) => {
    if (points.length < 2) return 0;
    let totalPixelDist = 0;
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const dist = Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
      totalPixelDist += dist;
    }
    // Scale factor: 1% width approx 0.8 meters
    return Math.round(totalPixelDist * 0.8 * 10);
  };

  const handleFinishRouteMeasurement = () => {
    if (activeMeasurePoints.length < 2) return;
    const measuredMeters = calculateMeasuredLength(activeMeasurePoints);
    const cableLookup: { [code: string]: { name: string; type: string; color: string } } = {
      'CBL-CAT6-UTP-LSZH-01': { name: 'Cat6 UTP LSZH Drop Cable Run', type: 'Cat6 Cable', color: '#3b82f6' },
      'CBL-FIBER-12C-SM-02': { name: '12-Core SM Fiber Optic Backbone', type: 'Fiber Optic', color: '#8b5cf6' },
      'TRAY-GI-PERF-150MM-03': { name: '150mm GI Overhead Cable Tray', type: 'Cable Tray', color: '#10b981' },
      'CONDUIT-EMT-25MM-04': { name: '25mm EMT Galvanized Wall Conduit', type: 'EMT Conduit', color: '#f59e0b' },
    };

    const cableMeta = cableLookup[activeMeasureCableType] || {
      name: 'Cat6 UTP Cable Run',
      type: 'Cat6 Cable',
      color: '#3b82f6',
    };

    const newRoute: BlueprintRoute = {
      id: `route-${Date.now()}`,
      name: `${cableMeta.name} (${activeMeasurePoints.length} Waypoints)`,
      itemCode: activeMeasureCableType,
      type: cableMeta.type,
      points: activeMeasurePoints,
      lengthMeters: measuredMeters,
      color: cableMeta.color,
      anomalyBufferPercent: 10,
    };

    setBlueprintRoutes((prev) => [...prev, newRoute]);
    setActiveMeasurePoints([]);
  };

  const handleDeletePin = (id: string) => {
    setBlueprintPins((prev) => prev.filter((p) => p.id !== id));
    setSelectedPinForInspect(null);
  };

  const handleDeleteRoute = (id: string) => {
    setBlueprintRoutes((prev) => prev.filter((r) => r.id !== id));
    setSelectedRouteForInspect(null);
  };

  const handleLoadSampleDrawing = (sample: typeof SAMPLE_CAD_PLANS[0]) => {
    setTakeoffSession((prev) => ({
      ...prev,
      drawingName: sample.name,
      drawingType: sample.type,
      projectRef: sample.project,
      scale: sample.scale,
      status: 'Takeoff Complete',
    }));
  };

  return (
    <div className="space-y-4">
      {/* Map & Viewport Header Controls */}
      <div className="bg-slate-950 rounded-3xl p-5 border border-slate-800 text-white relative shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <FileCode2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-black text-slate-100 tracking-tight">
                  AutoCAD / PDF Security Takeoff & Device Placement Map
                </h4>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-800 font-mono font-bold">
                  OCR Engine: Active
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Loaded: <strong className="text-slate-200">{takeoffSession.drawingName}</strong> ({takeoffSession.drawingType}) | Scale: <span className="text-indigo-300 font-mono font-bold">{takeoffSession.scale}</span> | Map Mode: <span className="text-emerald-300 uppercase font-bold">{mapViewMode.replace('_', ' ')}</span>
              </p>
            </div>
          </div>

          {/* Mode Switcher Buttons: 2D Blueprint, 3D Isometric, Topology */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800 flex-wrap">
            <button
              onClick={() => setMapViewMode('2d_blueprint')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                mapViewMode === '2d_blueprint'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>2D CAD Blueprint</span>
            </button>

            <button
              onClick={() => setMapViewMode('3d_isometric')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                mapViewMode === '3d_isometric'
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              <span>3D Isometric Map</span>
            </button>

            <button
              onClick={() => setMapViewMode('topology')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                mapViewMode === 'topology'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Workflow className="w-3.5 h-3.5" />
              <span>System Topology</span>
            </button>
          </div>
        </div>

        {/* Action & Tools Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs bg-slate-900/70 p-3 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => {
                setSelectedOverlayTool('select');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'select'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <MousePointer className="w-3.5 h-3.5" />
              <span>Select & Inspect</span>
            </button>

            <button
              onClick={() => {
                setSelectedOverlayTool('camera');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'camera'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>+ Pin Camera</span>
            </button>

            <button
              onClick={() => {
                setSelectedOverlayTool('switch');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'switch'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>+ Pin Switch / Rack</span>
            </button>

            <button
              onClick={() => setSelectedOverlayTool('cable_tray')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'cable_tray'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Route className="w-3.5 h-3.5" />
              <span>Measure Wire Route</span>
            </button>

            <span className="text-slate-700">|</span>

            <button
              onClick={() => {
                setSelectedOverlayTool('draw');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'draw'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title="Draw / Mark"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>Draw</span>
            </button>

            <button
              onClick={() => {
                setSelectedOverlayTool('highlight');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'highlight'
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title="Highlight Area"
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span>Highlight</span>
            </button>

            <button
              onClick={() => {
                setSelectedOverlayTool('eraser');
                setActiveMeasurePoints([]);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                selectedOverlayTool === 'eraser'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title="Erase Drawing"
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Erase</span>
            </button>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer hover:text-white">
              <input
                type="checkbox"
                checked={showFovCones}
                onChange={(e) => setShowFovCones(e.target.checked)}
                className="accent-indigo-600 rounded cursor-pointer"
              />
              <span>Camera FOV Cones</span>
            </label>

            <span className="text-slate-700">|</span>

            <button
              onClick={() => setCanvasZoom((prev) => Math.max(1, prev - 0.25))}
              className="p-1 hover:bg-slate-800 rounded text-slate-300 cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-slate-300 font-bold">{Math.round(canvasZoom * 100)}%</span>
            <button
              onClick={() => setCanvasZoom((prev) => Math.min(1.75, prev + 0.25))}
              className="p-1 hover:bg-slate-800 rounded text-slate-300 cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Contextual Sub-bar for Measuring Route */}
        {selectedOverlayTool === 'cable_tray' && (
          <div className="bg-slate-900 border border-indigo-500/50 rounded-2xl p-3.5 text-xs space-y-3 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Route className="w-4 h-4 text-indigo-400 shrink-0" />
                <span className="font-bold text-white">Wiring Route Measurement Mode:</span>
                <span className="text-slate-400 text-[11px]">(Click points on the floorplan to link cameras to switches)</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveMeasurePoints((prev) => prev.slice(0, -1))}
                  disabled={activeMeasurePoints.length === 0}
                  className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                >
                  <span>Undo Point</span>
                </button>
                <button
                  onClick={() => setActiveMeasurePoints([])}
                  disabled={activeMeasurePoints.length === 0}
                  className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer"
                >
                  Clear
                </button>
                <button
                  onClick={handleFinishRouteMeasurement}
                  disabled={activeMeasurePoints.length < 2}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white px-3 py-1 rounded-lg text-xs font-black transition flex items-center gap-1 cursor-pointer shadow-md"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Wire Route</span>
                </button>
              </div>
            </div>

            {/* Cable Types */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-slate-400 text-[11px] font-bold">Select Wire / Conduit Type:</span>
                {[
                  { code: 'CBL-CAT6-UTP-LSZH-01', label: '🔵 Cat6 UTP Cable (Camera ➔ Switch)', color: 'border-blue-500 bg-blue-950/40 text-blue-300' },
                  { code: 'CBL-FIBER-12C-SM-02', label: '🟣 12-Core SM Fiber (MDF ➔ IDF)', color: 'border-purple-500 bg-purple-950/40 text-purple-300' },
                  { code: 'TRAY-GI-PERF-150MM-03', label: '🟢 GI Cable Tray 150mm (Main Corridor)', color: 'border-emerald-500 bg-emerald-950/40 text-emerald-300' },
                  { code: 'CONDUIT-EMT-25MM-04', label: '🟡 EMT Conduit 25mm (Wall Drops)', color: 'border-amber-500 bg-amber-950/40 text-amber-300' },
                ].map((item) => (
                  <button
                    key={item.code}
                    onClick={() => setActiveMeasureCableType(item.code)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition cursor-pointer ${
                      activeMeasureCableType === item.code ? `${item.color} ring-1 ring-white/30` : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="bg-slate-950 px-3 py-1 rounded-xl border border-slate-800 font-mono text-[11px]">
                <span className="text-slate-400">Waypoints: </span>
                <span className="text-white font-bold">{activeMeasurePoints.length}</span>
                <span className="text-slate-600 mx-1.5">|</span>
                <span className="text-slate-400">Length: </span>
                <span className="text-indigo-400 font-bold">{calculateMeasuredLength(activeMeasurePoints)}m</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW MODE 1: 2D CAD BLUEPRINT FLOORPLAN MAP */}
        {/* ========================================================================= */}
        {mapViewMode === '2d_blueprint' && (
          <div
            ref={canvasRef}
            onClick={handleCanvasClick}
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            onMouseLeave={handleCanvasMouseUp}
            style={{ transform: `scale(${canvasZoom})`, transformOrigin: 'top left' }}
            className={`w-full h-96 bg-slate-900/95 rounded-2xl relative border border-slate-800/80 overflow-hidden select-none transition-transform duration-150 ${
              selectedOverlayTool === 'camera' || selectedOverlayTool === 'switch' || selectedOverlayTool === 'cable_tray' || selectedOverlayTool === 'draw' || selectedOverlayTool === 'highlight'
                ? 'cursor-crosshair'
                : selectedOverlayTool === 'eraser'
                ? 'cursor-pointer'
                : 'cursor-default'
            }`}
          >
            {/* Grid Pattern */}
            {showCanvasGrid && (
              <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#80808018_1px,transparent_1px),linear-gradient(to_bottom,#80808018_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
            )}

            {/* Architectural Layout: Zone Boundaries & Rooms */}
            <div className="absolute inset-4 sm:inset-6 border-2 border-slate-700/60 rounded-xl flex flex-col justify-between p-3.5 pointer-events-none">
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span className="bg-slate-950/90 px-2.5 py-0.5 rounded border border-slate-800 text-indigo-300 font-bold">
                  ZONE A1-D8: GF SECURITY CONTROL ROOM, MDF & CONCOURSE CORRIDORS
                </span>
                <span className="bg-slate-950/90 px-2.5 py-0.5 rounded border border-slate-800 text-amber-400 font-bold">
                  NORTH ↑
                </span>
              </div>

              {/* Room Quadrants */}
              <div className="grid grid-cols-3 gap-3 h-48 border border-slate-800/50 p-2 rounded-lg bg-slate-950/40">
                {/* MDF Server Room */}
                <div className="border border-indigo-500/40 rounded-xl bg-indigo-950/30 p-2.5 text-[9px] text-indigo-300 font-mono flex flex-col justify-between pointer-events-auto hover:bg-indigo-950/50 transition">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-indigo-200 text-[10px]">MDF Server Room</span>
                    <Server className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <div className="space-y-1 text-[8px] text-slate-300">
                    <span className="text-emerald-400 font-bold block">• 2x 42U Server Racks</span>
                    <span className="text-purple-300 font-bold block">• Cisco 24-Port PoE+ Core Switch</span>
                    <span className="text-slate-400 block">• 120-Day MOI Storage NVR</span>
                  </div>
                  <span className="text-[8px] text-indigo-400 font-mono">Zone A1-Riser (Secure)</span>
                </div>

                {/* Main Passenger Concourse */}
                <div className="border border-slate-700/50 rounded-xl bg-slate-800/30 p-2.5 text-[9px] text-slate-300 font-mono flex flex-col justify-between pointer-events-auto hover:bg-slate-800/40 transition">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-200 text-[10px]">Main Passenger Concourse</span>
                    <Radio className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                  <div className="space-y-0.5 text-[8px] text-slate-400">
                    <span>• 150mm GI Overhead Cable Tray Spine</span>
                    <span>• 4MP IR Dome Cameras with 90° FOV</span>
                    <span className="text-cyan-300 block">• Ceiling Height: 4.8m (+1.2m drop buffer)</span>
                  </div>
                  <span className="text-[8px] text-slate-500">Zone B2 Corridor</span>
                </div>

                {/* Gate 1-4 Vehicle Access Lanes */}
                <div className="border border-emerald-500/40 rounded-xl bg-emerald-950/30 p-2.5 text-[9px] text-emerald-300 font-mono flex flex-col justify-between pointer-events-auto hover:bg-emerald-950/50 transition">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-emerald-200 text-[10px]">Gate 1-4 ANPR Lanes</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="space-y-0.5 text-[8px] text-slate-300">
                    <span className="text-emerald-400 font-bold block">• 4x 4K ANPR Vehicle Cameras</span>
                    <span className="text-purple-300 font-bold block">• IDF Gate 8-Port Switch</span>
                    <span className="text-slate-400 block">• 12-Core Fiber Link to MDF</span>
                  </div>
                  <span className="text-[8px] text-emerald-400 font-mono font-bold">Zone C4 Perimeter Gate</span>
                </div>
              </div>

              <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                <span className="bg-slate-950/90 px-2 py-0.5 rounded border border-slate-800">
                  GI Cable Tray Spine: Main Corridor (300m Active)
                </span>
                <span className="bg-slate-950/90 px-2 py-0.5 rounded border border-slate-800 text-indigo-300">
                  {blueprintPins.reduce((s, p) => s + p.quantity, 0)} Total Devices Pinned | {networkSwitches.length} Switches
                </span>
              </div>
            </div>

            {/* SVG Layer for Drawing Cable Routes & Wiring Connections & Freehand Drawings */}
            {showCanvasRoutes && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                
                {/* Annotations / Highlights */}
                {[...drawingPaths, currentDrawingPath].filter(Boolean).map((path, idx) => {
                  if (!path || path.points.length < 2) return null;
                  
                  const pathData = path.points.reduce((acc, p, pIdx) => {
                    const px = Number(p.x) || 0;
                    const py = Number(p.y) || 0;
                    return pIdx === 0 ? `M ${px}% ${py}%` : `${acc} L ${px}% ${py}%`;
                  }, '');

                  return (
                    <path
                      key={path.id || idx}
                      d={pathData}
                      fill="none"
                      stroke={path.type === 'highlight' ? '#fbbf24' : '#ef4444'} // Amber for highlight, Red for draw
                      strokeWidth={path.type === 'highlight' ? '24' : '3'}
                      strokeOpacity={path.type === 'highlight' ? '0.4' : '0.8'}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="pointer-events-none"
                    />
                  );
                })}

                {/* Saved Blueprint Routes */}
                {blueprintRoutes.map((route) => {
                  if (route.points.length < 2) return null;
                  const pathData = route.points.reduce((acc, p, idx) => {
                    const px = Number(p.x) || 0;
                    const py = Number(p.y) || 0;
                    return idx === 0 ? `M ${px}% ${py}%` : `${acc} L ${px}% ${py}%`;
                  }, '');

                  return (
                    <g key={route.id} className="pointer-events-auto cursor-pointer">
                      {/* Route Thick Glow */}
                      <path
                        d={pathData}
                        fill="none"
                        stroke={route.color}
                        strokeWidth="7"
                        strokeOpacity="0.3"
                        className="hover:stroke-opacity-70 transition"
                      />
                      {/* Route Main Line */}
                      <path
                        d={pathData}
                        fill="none"
                        stroke={route.color}
                        strokeWidth="3"
                        strokeDasharray={route.type.includes('Fiber') ? '5 4' : undefined}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedRouteForInspect(route);
                        }}
                      />
                      {/* Route Waypoint Dots */}
                      {route.points.map((pt, pIdx) => (
                        <circle
                          key={pIdx}
                          cx={`${Number(pt.x) || 0}%`}
                          cy={`${Number(pt.y) || 0}%`}
                          r="3.5"
                          fill={route.color}
                          stroke="#020617"
                          strokeWidth="2"
                        />
                      ))}
                    </g>
                  );
                })}

                {/* Direct Wire Connections from Cameras to Switches (Cyan / Blue Links) */}
                {showCanvasPins &&
                  blueprintPins.map((pin) => {
                    // Connect pin to nearest switch or MDF switch
                    const targetSwitch = pin.label.includes('ANPR') ? networkSwitches[1] : networkSwitches[0];
                    const pinX = Number(pin.x) || 0;
                    const pinY = Number(pin.y) || 0;
                    const swX = targetSwitch.x;
                    const swY = targetSwitch.y;

                    return (
                      <g key={`wire-link-${pin.id}`} className="opacity-40 hover:opacity-100 transition">
                        <line
                          x1={`${swX}%`}
                          y1={`${swY}%`}
                          x2={`${pinX}%`}
                          y2={`${pinY}%`}
                          stroke={pin.iconType === 'anpr' ? '#10b981' : '#38bdf8'}
                          strokeWidth="1.5"
                          strokeDasharray="3 3"
                        />
                      </g>
                    );
                  })}

                {/* Active Measuring Polyline */}
                {activeMeasurePoints.length > 0 && (
                  <g>
                    {activeMeasurePoints.length > 1 && (
                      <path
                        d={activeMeasurePoints.reduce((acc, p, idx) => {
                          const px = Number(p.x) || 0;
                          const py = Number(p.y) || 0;
                          return idx === 0 ? `M ${px}% ${py}%` : `${acc} L ${px}% ${py}%`;
                        }, '')}
                        fill="none"
                        stroke="#818cf8"
                        strokeWidth="3"
                        strokeDasharray="6 4"
                        className="animate-pulse"
                      />
                    )}
                    {activeMeasurePoints.map((pt, idx) => {
                      const px = Number(pt.x) || 0;
                      const py = Number(pt.y) || 0;
                      return (
                        <g key={idx}>
                          <circle
                            cx={`${px}%`}
                            cy={`${py}%`}
                            r="5"
                            fill="#6366f1"
                            stroke="#ffffff"
                            strokeWidth="2"
                          />
                          <text
                            x={`${px}%`}
                            y={`${py - 2}%`}
                            fill="#ffffff"
                            fontSize="9"
                            fontWeight="bold"
                            textAnchor="middle"
                          >
                            {idx + 1}
                          </text>
                        </g>
                      );
                    })}
                  </g>
                )}
              </svg>
            )}

            {/* Network Switch Map Markers */}
            {networkSwitches.map((sw) => (
              <div
                key={sw.id}
                style={{
                  left: `${sw.x}%`,
                  top: `${sw.y}%`,
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedPinForInspect({
                    id: sw.id,
                    x: sw.x,
                    y: sw.y,
                    itemCode: sw.model,
                    label: sw.tag,
                    category: 'Active Switches',
                    quantity: 1,
                    locationNotes: `${sw.location} | Ports: ${sw.portsUsed}/${sw.portsTotal} Used | Uplink: ${sw.uplink}`,
                    iconType: 'rack',
                    color: sw.color,
                  });
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 bg-purple-900/90 border-2 border-purple-400 text-white text-[10px] font-black px-2.5 py-1 rounded-xl shadow-2xl flex items-center gap-1.5 cursor-pointer z-30 hover:scale-110 transition group"
              >
                <Server className="w-3.5 h-3.5 text-purple-300" />
                <span>{sw.tag}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping ml-1" />
              </div>
            ))}

            {/* Render Interactive Blueprint Device Pins with FOV Cones */}
            {showCanvasPins &&
              blueprintPins.map((pin) => {
                const isSelected = selectedPinForInspect?.id === pin.id;
                const pinX = Number(pin.x) || 0;
                const pinY = Number(pin.y) || 0;
                const IconComponent =
                  pin.iconType === 'camera'
                    ? Camera
                    : pin.iconType === 'anpr'
                    ? ShieldCheck
                    : pin.iconType === 'rack'
                    ? Server
                    : pin.iconType === 'sensor'
                    ? Eye
                    : Cpu;

                return (
                  <div key={pin.id}>
                    {/* Camera Field of View (FOV) Visual Cone */}
                    {showFovCones && pin.iconType === 'camera' && (
                      <div
                        style={{
                          left: `${pinX}%`,
                          top: `${pinY}%`,
                        }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10"
                      >
                        <svg className="w-24 h-24 -ml-12 -mt-12 overflow-visible opacity-30 hover:opacity-60 transition">
                          <polygon
                            points="48,48 10,8 86,8"
                            fill={pin.color}
                          />
                        </svg>
                      </div>
                    )}

                    {/* Camera Device Pin Badge */}
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedPinForInspect(pin);
                      }}
                      style={{
                        left: `${pinX}%`,
                        top: `${pinY}%`,
                        backgroundColor: pin.color,
                      }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-lg flex items-center gap-1.5 cursor-pointer transition-all duration-150 z-20 ${
                        isSelected
                          ? 'ring-4 ring-white scale-110 shadow-2xl z-30'
                          : 'hover:scale-105 hover:ring-2 hover:ring-white/80'
                      }`}
                    >
                      <IconComponent className="w-3 h-3 shrink-0" />
                      <span className="whitespace-nowrap font-mono">{pin.label}</span>
                    </div>
                  </div>
                );
              })}

            {/* Map Legend Overlay in Bottom Left */}
            <div className="absolute bottom-2 left-3 text-[10px] bg-slate-950/95 text-slate-300 border border-slate-800 p-2 rounded-xl backdrop-blur-xs font-mono pointer-events-auto flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                <span>Dome / Bullet Cam</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span>4K ANPR Gate Cam</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                <span>PoE Switch / Racks</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-cyan-400 rounded-full" />
                <span>Cat6 Cable Wire</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-purple-400 rounded-full border-dashed" />
                <span>SM Fiber Backbone</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW MODE 2: 3D ISOMETRIC SPATIAL SECURITY MAP */}
        {/* ========================================================================= */}
        {mapViewMode === '3d_isometric' && (
          <div className="w-full h-96 bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950/40 rounded-2xl relative border border-slate-800 overflow-hidden select-none p-4 flex flex-col justify-between shadow-2xl">
            {/* Top 3D Camera Controls */}
            <div className="flex items-center justify-between z-20">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-mono font-bold text-slate-200">3D Isometric Facility Security Model (Elevation +4.5m)</span>
              </div>
              <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950/70 border border-indigo-800/60 px-2.5 py-1 rounded-lg">
                3D SIGHTLINES & FOV PROJECTIONS ACTIVE
              </span>
            </div>

            {/* Isometric 3D Canvas Projection */}
            <div className="relative w-full h-64 flex items-center justify-center">
              {/* Isometric 3D Floor Base Grid */}
              <div
                style={{
                  transform: 'rotateX(58deg) rotateZ(-38deg) scale(0.95)',
                  transformStyle: 'preserve-3d',
                }}
                className="w-96 h-96 border-2 border-indigo-500/40 bg-slate-950/80 rounded-2xl relative shadow-2xl shadow-indigo-950/50"
              >
                {/* 3D Grid Lines */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#6366f120_1px,transparent_1px),linear-gradient(to_bottom,#6366f120_1px,transparent_1px)] bg-[size:32px_32px]" />

                {/* 3D Extruded Room 1: MDF Server Room */}
                <div
                  style={{
                    transform: 'translateZ(24px)',
                  }}
                  className="absolute top-6 left-6 w-32 h-28 bg-indigo-900/60 border-2 border-indigo-400/80 rounded-xl p-2 text-white shadow-2xl"
                >
                  <div className="flex items-center gap-1 text-[9px] font-bold text-indigo-200">
                    <Server className="w-3 h-3 text-indigo-300" />
                    <span>MDF Room</span>
                  </div>
                  {/* 3D Server Rack Model */}
                  <div className="w-12 h-14 bg-slate-950 border border-purple-400 rounded-lg mt-1 p-1 text-[7px] text-purple-300 font-mono">
                    <span>42U RACK</span>
                    <div className="w-full h-1 bg-emerald-400 mt-1 animate-pulse" />
                    <div className="w-full h-1 bg-indigo-400 mt-1" />
                  </div>
                </div>

                {/* 3D Extruded Room 2: Main Corridor & Passenger Concourse */}
                <div
                  style={{
                    transform: 'translateZ(18px)',
                  }}
                  className="absolute top-6 right-6 w-48 h-56 bg-slate-800/50 border-2 border-slate-600/70 rounded-xl p-2.5 text-white"
                >
                  <div className="flex items-center justify-between text-[9px] font-bold text-slate-300">
                    <span>Passenger Concourse</span>
                    <Radio className="w-3 h-3 text-slate-400" />
                  </div>

                  {/* 3D Suspended GI Cable Tray */}
                  <div className="w-full h-2 bg-emerald-500/80 rounded-full mt-4 shadow-lg shadow-emerald-500/30 flex items-center justify-around">
                    <span className="w-1 h-1 bg-white rounded-full" />
                    <span className="w-1 h-1 bg-white rounded-full" />
                    <span className="w-1 h-1 bg-white rounded-full" />
                  </div>
                  <span className="text-[7px] text-emerald-400 font-mono block mt-1">150mm GI Tray Spine</span>

                  {/* 3D Wall Mounted Cameras with Light Rays */}
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex flex-col items-center">
                      <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[8px] font-bold shadow-lg">
                        <Camera className="w-2.5 h-2.5" />
                      </div>
                      <div className="w-10 h-8 border-l border-r border-blue-400/40 bg-blue-500/10 mt-1 clip-triangle" />
                      <span className="text-[7px] text-blue-300 font-mono">CAM-01 Dome</span>
                    </div>

                    <div className="flex flex-col items-center">
                      <div className="w-5 h-5 rounded-full bg-sky-500 text-white flex items-center justify-center text-[8px] font-bold shadow-lg">
                        <Camera className="w-2.5 h-2.5" />
                      </div>
                      <div className="w-10 h-8 border-l border-r border-sky-400/40 bg-sky-500/10 mt-1" />
                      <span className="text-[7px] text-sky-300 font-mono">CAM-02 Bullet</span>
                    </div>
                  </div>
                </div>

                {/* 3D Extruded Room 3: Gate 1-4 ANPR Lanes */}
                <div
                  style={{
                    transform: 'translateZ(12px)',
                  }}
                  className="absolute bottom-6 left-6 w-36 h-28 bg-emerald-950/60 border-2 border-emerald-500/80 rounded-xl p-2 text-white"
                >
                  <div className="flex items-center gap-1 text-[9px] font-bold text-emerald-300">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Gate 1-4 ANPR</span>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-emerald-600 flex items-center justify-center text-[7px]">
                      📹
                    </div>
                    <span className="text-[7px] text-emerald-200 font-mono">4K License Plate Cam</span>
                  </div>
                </div>

                {/* 3D Fiber & Cat6 Wire Links */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  <line x1="80" y1="80" x2="260" y2="80" stroke="#a855f7" strokeWidth="2.5" strokeDasharray="4 2" />
                  <line x1="80" y1="80" x2="90" y2="280" stroke="#3b82f6" strokeWidth="2" />
                </svg>
              </div>
            </div>

            {/* Bottom 3D Stats */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-[11px] text-slate-300 font-mono z-20">
              <div className="flex items-center gap-2">
                <span className="text-indigo-400 font-bold">3D Perspective Render:</span>
                <span>Isometric Camera Elevation: 4.8m AGL | Tray Clearances: 3.6m</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">FOV Coverage: 100% Perimeter & Gates</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW MODE 3: SYSTEM TOPOLOGY FLOW & PORT MAPPING */}
        {/* ========================================================================= */}
        {mapViewMode === 'topology' && (
          <div className="w-full bg-slate-900/90 rounded-2xl border border-slate-800 p-4 text-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Workflow className="w-4 h-4 text-indigo-400" />
                <span className="font-black text-slate-200">Security Network Topology: Camera ➔ Wire ➔ Switch ➔ NVR Server</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                100% Port Integrity Verified
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              {/* Column 1: Field Devices (Cameras & Sensors) */}
              <div className="bg-slate-950/80 border border-blue-500/40 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-blue-400 text-[11px]">1. Field Cameras & Devices</span>
                  <Camera className="w-3.5 h-3.5 text-blue-400" />
                </div>
                {blueprintPins.map((pin) => (
                  <div key={pin.id} className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                    <div className="flex justify-between font-bold text-slate-200">
                      <span>{pin.label}</span>
                      <span className="text-indigo-400">{pin.quantity}x</span>
                    </div>
                    <span className="text-slate-400 block font-mono text-[9px]">{pin.itemCode}</span>
                  </div>
                ))}
              </div>

              {/* Column 2: Structured Cabling & Containment */}
              <div className="bg-slate-950/80 border border-cyan-500/40 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-cyan-400 text-[11px]">2. Wires & Containment</span>
                  <Cable className="w-3.5 h-3.5 text-cyan-400" />
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                  <span className="font-bold text-blue-300 block">Cat6 UTP LSZH Cable</span>
                  <span className="text-slate-400 text-[9px]">4,620m Linear Run (Drops to Cameras)</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                  <span className="font-bold text-purple-300 block">12-Core SM Fiber Backbone</span>
                  <span className="text-slate-400 text-[9px]">715m (MDF Server to Gate IDF)</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                  <span className="font-bold text-emerald-300 block">150mm GI Cable Tray</span>
                  <span className="text-slate-400 text-[9px]">300m Overhead Main Corridor</span>
                </div>
              </div>

              {/* Column 3: Network Switches */}
              <div className="bg-slate-950/80 border border-purple-500/40 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-purple-400 text-[11px]">3. Network PoE Switches</span>
                  <Server className="w-3.5 h-3.5 text-purple-400" />
                </div>
                {networkSwitches.map((sw) => (
                  <div key={sw.id} className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1.5">
                    <div className="flex justify-between font-bold text-slate-200">
                      <span>{sw.tag}</span>
                      <span className="text-emerald-400">{sw.portsUsed}/{sw.portsTotal} Ports</span>
                    </div>
                    <span className="text-slate-400 block text-[9px]">{sw.model}</span>
                    <span className="text-purple-300 font-mono text-[9px] block">PoE: {sw.poeBudget}</span>
                  </div>
                ))}
              </div>

              {/* Column 4: Storage NVR & Core Server */}
              <div className="bg-slate-950/80 border border-emerald-500/40 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-emerald-400 text-[11px]">4. Storage NVR & VMS</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                  <span className="font-bold text-emerald-300 block">120-Day MOI Retention SAN</span>
                  <span className="text-slate-400 text-[9px]">RAID 6 Storage Array (128TB Raw)</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px] space-y-1">
                  <span className="font-bold text-slate-200 block">Dual 42U Server Cabinets</span>
                  <span className="text-slate-400 text-[9px]">MDF Server Room GF with UPS Backup</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Sample Drawings Bar for Instant Testing */}
        <div className="flex items-center justify-between text-xs bg-slate-900/50 p-2.5 rounded-xl border border-slate-800/80">
          <span className="text-slate-400 font-mono text-[11px]">Sample CAD Drawings to Test OCR:</span>
          <div className="flex items-center gap-2">
            {SAMPLE_CAD_PLANS.map((sample) => (
              <button
                key={sample.name}
                onClick={() => handleLoadSampleDrawing(sample)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition cursor-pointer ${
                  takeoffSession.drawingName === sample.name
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {sample.name.split('.')[0].replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: PIN DEVICE MODAL (when clicked on canvas) */}
      {/* ========================================================================= */}
      {pinModalCoordinates && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Pin New Device to Floorplan</h4>
                  <p className="text-[11px] text-slate-500">
                    Floorplan Coordinates: X: {pinModalCoordinates.x}%, Y: {pinModalCoordinates.y}%
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPinModalCoordinates(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Select Equipment / Device Model:</label>
                <select
                  value={deviceToPinCode}
                  onChange={(e) => setDeviceToPinCode(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden"
                >
                  {availableDevicesToPin.map((item) => (
                    <option key={item.code} value={item.code}>
                      [{item.code}] - {item.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Connected Network Switch:</label>
                  <select
                    value={deviceConnectedSwitch}
                    onChange={(e) => setDeviceConnectedSwitch(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="SW-POE-24P-MDF (Port 05)">SW-POE-24P-MDF (Port 05)</option>
                    <option value="SW-IDF-01-GATE (Port 02)">SW-IDF-01-GATE (Port 02)</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Connected Cable / Wire:</label>
                  <select
                    value={deviceConnectedWire}
                    onChange={(e) => setDeviceConnectedWire(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="Cat6 UTP LSZH Cable">Cat6 UTP LSZH Cable</option>
                    <option value="12-Core SM Fiber Backbone">12-Core SM Fiber Backbone</option>
                    <option value="GI Cable Tray Main Spine">GI Cable Tray Main Spine</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Quantity to Place at this Position:</label>
                <input
                  type="number"
                  min="1"
                  value={deviceToPinQty}
                  onChange={(e) => setDeviceToPinQty(Number(e.target.value) || 1)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Location / Zone Notes:</label>
                <input
                  type="text"
                  value={deviceToPinNotes}
                  onChange={(e) => setDeviceToPinNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setPinModalCoordinates(null)}
                className="text-slate-600 hover:bg-slate-100 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePin}
                className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-xs cursor-pointer"
              >
                Place Pin on Map
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: INSPECT DEVICE PIN */}
      {/* ========================================================================= */}
      {selectedPinForInspect && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div
                  style={{ backgroundColor: selectedPinForInspect.color }}
                  className="w-8 h-8 rounded-xl text-white flex items-center justify-center shadow-xs"
                >
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">{selectedPinForInspect.label}</h4>
                  <p className="text-[11px] font-mono text-indigo-600 font-bold">{selectedPinForInspect.itemCode}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPinForInspect(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Equipment Category:</span>
                <span className="font-bold text-slate-800">{selectedPinForInspect.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pinned Quantity:</span>
                <span className="font-black text-indigo-700">{selectedPinForInspect.quantity} Units</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Location / Zone:</span>
                <span className="font-medium text-slate-700 text-right">{selectedPinForInspect.locationNotes}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Map Coordinates:</span>
                <span className="font-mono text-slate-700 font-bold">X: {selectedPinForInspect.x}%, Y: {selectedPinForInspect.y}%</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => handleDeletePin(selectedPinForInspect.id)}
                className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Pin</span>
              </button>

              <button
                onClick={() => setSelectedPinForInspect(null)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: INSPECT ROUTE */}
      {/* ========================================================================= */}
      {selectedRouteForInspect && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div
                  style={{ backgroundColor: selectedRouteForInspect.color }}
                  className="w-8 h-8 rounded-xl text-white flex items-center justify-center shadow-xs"
                >
                  <Route className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">{selectedRouteForInspect.name}</h4>
                  <p className="text-[11px] font-mono text-indigo-600 font-bold">{selectedRouteForInspect.itemCode}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedRouteForInspect(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Route Type:</span>
                <span className="font-bold text-slate-800">{selectedRouteForInspect.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Waypoints:</span>
                <span className="font-mono font-bold text-slate-800">{selectedRouteForInspect.points.length} Coordinates</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Linear Measured Length:</span>
                <span className="font-bold text-indigo-700">{selectedRouteForInspect.lengthMeters} Meters</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => handleDeleteRoute(selectedRouteForInspect.id)}
                className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Route</span>
              </button>

              <button
                onClick={() => setSelectedRouteForInspect(null)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
