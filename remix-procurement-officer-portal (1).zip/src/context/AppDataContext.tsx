import React, { createContext, useContext, useState, useMemo, ReactNode } from 'react';
import {
  RoleTab,
  ViewMode,
  ProcurementSubModule,
  AssetRecord,
  EquipmentMasterItem,
  EquipmentIssuance,
  AttendanceRecord,
  KYCQuery,
  EmployeeRecord,
  SalaryBracket,
  EmployeeBenefit,
  EmployeeContract,
  LeadRecord,
  LeadConversionRate,
  VisitScheduling,
  BOQRecord,
  ProcurementAssignment,
  QuotationResult,
  SupplierRecord,
  PriceHistoryRecord,
  ProcurementFollowUp,
  ProcurementRevision,
  ProjectOverview,
  ProjectPaymentMilestone,
  AdvanceCheck,
  TeamSelection,
  ExecutionPhase,
  WeeklyExecutionReport,
  QualityCheckInspection,
  ClientCommunication,
  ProjectCompletionApproval,
  DropdownMaster,
  PurchaseRequisition,
  MaterialSubmittal,
  PurchaseOrder,
  LogisticsShipment,
  InvoiceReconciliationRecord,
  TenderRecord,
  ProposalRecord,
  ActivityLog,
  PhasedTask,
  MOIDSARecord,
  MOIDIARecord,
  MOIChecklistItem,
  AMCContract,
  ServiceTicket,
  TechnicianSchedule,
  InventoryItem,
  ProjectAsset,
  ProjectBudget,
  ClientInvoice,
  ProjectExpense,
  ClientPortalAccount,
  AutomatedReport,
  SecurityProductCatalogItem,
} from '../types';

import {
  initialAssets,
  initialEquipmentMaster,
  initialEquipmentIssuance,
  initialAttendance,
  initialKYCQueries,
  initialEmployees,
  initialSalaryBrackets,
  initialEmployeeBenefits,
  initialEmployeeContracts,
  initialLeads,
  initialLeadConversionRates,
  initialVisitScheduling,
  initialBOQs,
  initialProcurementAssignments,
  initialPurchaseRequisitions,
  initialMaterialSubmittals,
  initialQuotations,
  initialPurchaseOrders,
  initialLogisticsShipments,
  initialInvoiceReconciliations,
  initialSuppliers,
  initialPriceHistory,
  initialProcurementFollowUps,
  initialProcurementRevisions,
  initialSecurityProductCatalog,
  initialProjects,
  initialProjectPaymentMilestones,
  initialAdvanceChecks,
  initialTeamSelection,
  initialExecutionPhases,
  initialWeeklyReports,
  initialQualityChecks,
  initialClientCommunications,
  initialProjectCompletions,
  initialDropdownMaster,
} from '../initialData';

import {
  initialTenders,
  initialProposals,
  initialActivityLogs,
  initialPhasedTasks,
  initialMOIDSA,
  initialMOIDIA,
  initialMOIChecklist,
  initialAMCs,
  initialServiceTickets,
  initialTechnicianSchedules,
  initialInventory,
  initialProjectAssets,
  initialProjectBudgets,
  initialClientInvoices,
  initialProjectExpenses,
  initialClientPortalAccounts,
  initialAutomatedReports,
} from '../data/crmSeedData';

import {
  generatePOFromPR,
  generatePOFromQuotation,
  generateReconciliationFromPO,
  generateSubmittalFromCatalog,
} from '../services/relationalEngine';

import {
  calculateExecutiveKPIs,
  calculateProjectFinancials,
  calculateProcurementSavings,
  ExecutiveKPIs,
  ProjectFinancialSummary,
} from '../services/calculationEngine';

import { exportMasterWorkbookToExcel } from '../utils/excelExport';

export interface AppDataContextType {
  // Navigation & Shell State
  activeTab: RoleTab;
  setActiveTab: (tab: RoleTab) => void;
  procurementSubModule: ProcurementSubModule;
  setProcurementSubModule: (sub: ProcurementSubModule) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  globalSearch: string;
  setGlobalSearch: (term: string) => void;

  // Global Modals & AI State
  isQuickAddOpen: boolean;
  setIsQuickAddOpen: (open: boolean) => void;
  isFeedOpen: boolean;
  setIsFeedOpen: (open: boolean) => void;
  isGeminiChatOpen: boolean;
  setIsGeminiChatOpen: (open: boolean) => void;
  isGeminiIntelligenceOpen: boolean;
  setIsGeminiIntelligenceOpen: (open: boolean) => void;
  geminiIntelligenceMode:
    | 'dwg-extractor'
    | 'quote-analysis'
    | 'counter-offer'
    | 'boq-generator'
    | 'value-engineering'
    | 'sales-proposal'
    | 'moi-audit'
    | 'pm-risk'
    | 'amc-diagnostic'
    | 'finance-audit';
  setGeminiIntelligenceMode: (
    mode:
      | 'dwg-extractor'
      | 'quote-analysis'
      | 'counter-offer'
      | 'boq-generator'
      | 'value-engineering'
      | 'sales-proposal'
      | 'moi-audit'
      | 'pm-risk'
      | 'amc-diagnostic'
      | 'finance-audit'
  ) => void;
  geminiSelectedBoqId: string;
  setGeminiSelectedBoqId: (boqId: string) => void;

  // Core Datasets
  assets: AssetRecord[];
  equipmentMaster: EquipmentMasterItem[];
  equipmentIssuance: EquipmentIssuance[];
  attendance: AttendanceRecord[];
  kycQueries: KYCQuery[];
  employees: EmployeeRecord[];
  salaryBrackets: SalaryBracket[];
  benefits: EmployeeBenefit[];
  contracts: EmployeeContract[];
  leads: LeadRecord[];
  conversions: LeadConversionRate[];
  visits: VisitScheduling[];
  boqs: BOQRecord[];
  procurementAssignments: ProcurementAssignment[];
  purchaseRequisitions: PurchaseRequisition[];
  materialSubmittals: MaterialSubmittal[];
  quotations: QuotationResult[];
  purchaseOrders: PurchaseOrder[];
  logisticsShipments: LogisticsShipment[];
  invoiceReconciliations: InvoiceReconciliationRecord[];
  suppliers: SupplierRecord[];
  priceHistory: PriceHistoryRecord[];
  procurementFollowUps: ProcurementFollowUp[];
  procurementRevisions: ProcurementRevision[];
  securityProductCatalog: SecurityProductCatalogItem[];
  projects: ProjectOverview[];
  projectPaymentMilestones: ProjectPaymentMilestone[];
  advanceChecks: AdvanceCheck[];
  teamSelection: TeamSelection[];
  executionPhases: ExecutionPhase[];
  weeklyReports: WeeklyExecutionReport[];
  qualityChecks: QualityCheckInspection[];
  clientCommunications: ClientCommunication[];
  projectCompletions: ProjectCompletionApproval[];
  dropdownMaster: DropdownMaster[];

  // Extended CRM / ERP Datasets
  tenders: TenderRecord[];
  proposals: ProposalRecord[];
  activities: ActivityLog[];
  phasedTasks: PhasedTask[];
  dsaRecords: MOIDSARecord[];
  diaRecords: MOIDIARecord[];
  complianceChecklist: MOIChecklistItem[];
  amcContracts: AMCContract[];
  serviceTickets: ServiceTicket[];
  schedules: TechnicianSchedule[];
  inventoryItems: InventoryItem[];
  projectAssets: ProjectAsset[];
  projectBudgets: ProjectBudget[];
  clientInvoices: ClientInvoice[];
  projectExpenses: ProjectExpense[];
  clientPortalAccounts: ClientPortalAccount[];
  automatedReports: AutomatedReport[];

  // State Mutation Handlers
  handleUpdateState: (stateKey: string, newData: any[]) => void;
  handleAddRecord: (type: string, record: any) => void;
  handleExportAll: () => void;

  // 1-Click Operations
  convertPRToPO: (prId: string) => PurchaseOrder | null;
  convertQuoteToPO: (quoteId: string) => PurchaseOrder | null;
  createReconciliationForPO: (poId: string) => InvoiceReconciliationRecord | null;
  createSubmittalFromProduct: (itemCode: string, projectName: string) => MaterialSubmittal | null;

  // Computed Unified KPIs & Metrics
  executiveKPIs: ExecutiveKPIs;
  financialSummary: ProjectFinancialSummary;
  procurementSavings: { totalSavings: number; avgSavingsPercent: number; negotiatedItemCount: number };
}

const AppDataContext = createContext<AppDataContextType | undefined>(undefined);

export const AppDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Navigation & Shell
  const [activeTab, setActiveTab] = useState<RoleTab>('dashboard');
  const [procurementSubModule, setProcurementSubModule] = useState<ProcurementSubModule>('scm_pipeline');
  const [viewMode, setViewMode] = useState<ViewMode>('bento');
  const [globalSearch, setGlobalSearch] = useState('');

  // Global Modals & AI
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isFeedOpen, setIsFeedOpen] = useState(false);
  const [isGeminiChatOpen, setIsGeminiChatOpen] = useState(false);
  const [isGeminiIntelligenceOpen, setIsGeminiIntelligenceOpen] = useState(false);
  const [geminiIntelligenceMode, setGeminiIntelligenceMode] = useState<
    | 'dwg-extractor'
    | 'quote-analysis'
    | 'counter-offer'
    | 'boq-generator'
    | 'value-engineering'
    | 'sales-proposal'
    | 'moi-audit'
    | 'pm-risk'
    | 'amc-diagnostic'
    | 'finance-audit'
  >('dwg-extractor');
  const [geminiSelectedBoqId, setGeminiSelectedBoqId] = useState<string>('BOQ-003');

  // Datasets State
  const [assets, setAssets] = useState<AssetRecord[]>(initialAssets);
  const [equipmentMaster, setEquipmentMaster] = useState<EquipmentMasterItem[]>(initialEquipmentMaster);
  const [equipmentIssuance, setEquipmentIssuance] = useState<EquipmentIssuance[]>(initialEquipmentIssuance);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(initialAttendance);
  const [kycQueries, setKYCQueries] = useState<KYCQuery[]>(initialKYCQueries);
  const [employees, setEmployees] = useState<EmployeeRecord[]>(initialEmployees);
  const [salaryBrackets, setSalaryBrackets] = useState<SalaryBracket[]>(initialSalaryBrackets);
  const [benefits, setBenefits] = useState<EmployeeBenefit[]>(initialEmployeeBenefits);
  const [contracts, setContracts] = useState<EmployeeContract[]>(initialEmployeeContracts);
  const [leads, setLeads] = useState<LeadRecord[]>(initialLeads);
  const [conversions, setConversions] = useState<LeadConversionRate[]>(initialLeadConversionRates);
  const [visits, setVisits] = useState<VisitScheduling[]>(initialVisitScheduling);
  const [boqs, setBOQs] = useState<BOQRecord[]>(initialBOQs);
  const [procurementAssignments, setProcurementAssignments] = useState<ProcurementAssignment[]>(initialProcurementAssignments);
  const [purchaseRequisitions, setPurchaseRequisitions] = useState<PurchaseRequisition[]>(initialPurchaseRequisitions);
  const [materialSubmittals, setMaterialSubmittals] = useState<MaterialSubmittal[]>(initialMaterialSubmittals);
  const [quotations, setQuotations] = useState<QuotationResult[]>(initialQuotations);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(initialPurchaseOrders);
  const [logisticsShipments, setLogisticsShipments] = useState<LogisticsShipment[]>(initialLogisticsShipments);
  const [invoiceReconciliations, setInvoiceReconciliations] = useState<InvoiceReconciliationRecord[]>(initialInvoiceReconciliations);
  const [suppliers, setSuppliers] = useState<SupplierRecord[]>(initialSuppliers);
  const [priceHistory, setPriceHistory] = useState<PriceHistoryRecord[]>(initialPriceHistory);
  const [procurementFollowUps, setProcurementFollowUps] = useState<ProcurementFollowUp[]>(initialProcurementFollowUps);
  const [procurementRevisions, setProcurementRevisions] = useState<ProcurementRevision[]>(initialProcurementRevisions);
  const [securityProductCatalog, setSecurityProductCatalog] = useState<SecurityProductCatalogItem[]>(initialSecurityProductCatalog as any);
  const [projects, setProjects] = useState<ProjectOverview[]>(initialProjects);
  const [projectPaymentMilestones, setProjectPaymentMilestones] = useState<ProjectPaymentMilestone[]>(initialProjectPaymentMilestones);
  const [advanceChecks, setAdvanceChecks] = useState<AdvanceCheck[]>(initialAdvanceChecks);
  const [teamSelection, setTeamSelection] = useState<TeamSelection[]>(initialTeamSelection);
  const [executionPhases, setExecutionPhases] = useState<ExecutionPhase[]>(initialExecutionPhases);
  const [weeklyReports, setWeeklyReports] = useState<WeeklyExecutionReport[]>(initialWeeklyReports);
  const [qualityChecks, setQualityChecks] = useState<QualityCheckInspection[]>(initialQualityChecks);
  const [clientCommunications, setClientCommunications] = useState<ClientCommunication[]>(initialClientCommunications);
  const [projectCompletions, setProjectCompletions] = useState<ProjectCompletionApproval[]>(initialProjectCompletions);
  const [dropdownMaster] = useState<DropdownMaster[]>(initialDropdownMaster as any);

  // Extended CRM / ERP States
  const [tenders, setTenders] = useState<TenderRecord[]>(initialTenders);
  const [proposals, setProposals] = useState<ProposalRecord[]>(initialProposals);
  const [activities, setActivities] = useState<ActivityLog[]>(initialActivityLogs);
  const [phasedTasks, setPhasedTasks] = useState<PhasedTask[]>(initialPhasedTasks);
  const [dsaRecords, setDsaRecords] = useState<MOIDSARecord[]>(initialMOIDSA);
  const [diaRecords, setDiaRecords] = useState<MOIDIARecord[]>(initialMOIDIA);
  const [complianceChecklist, setComplianceChecklist] = useState<MOIChecklistItem[]>(initialMOIChecklist);
  const [amcContracts, setAmcContracts] = useState<AMCContract[]>(initialAMCs);
  const [serviceTickets, setServiceTickets] = useState<ServiceTicket[]>(initialServiceTickets);
  const [schedules, setSchedules] = useState<TechnicianSchedule[]>(initialTechnicianSchedules);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(initialInventory);
  const [projectAssets, setProjectAssets] = useState<ProjectAsset[]>(initialProjectAssets);
  const [projectBudgets, setProjectBudgets] = useState<ProjectBudget[]>(initialProjectBudgets);
  const [clientInvoices, setClientInvoices] = useState<ClientInvoice[]>(initialClientInvoices);
  const [projectExpenses, setProjectExpenses] = useState<ProjectExpense[]>(initialProjectExpenses);
  const [clientPortalAccounts] = useState<ClientPortalAccount[]>(initialClientPortalAccounts);
  const [automatedReports] = useState<AutomatedReport[]>(initialAutomatedReports);

  // Computed Metrics from Single Source of Truth
  const executiveKPIs = useMemo(
    () =>
      calculateExecutiveKPIs({
        projects,
        purchaseOrders,
        purchaseRequisitions,
        reconciliations: invoiceReconciliations,
        priceHistory,
        amcs: amcContracts,
        tickets: serviceTickets,
      }),
    [projects, purchaseOrders, purchaseRequisitions, invoiceReconciliations, priceHistory, amcContracts, serviceTickets]
  );

  const financialSummary = useMemo(
    () => calculateProjectFinancials(projects, purchaseOrders, invoiceReconciliations),
    [projects, purchaseOrders, invoiceReconciliations]
  );

  const procurementSavings = useMemo(
    () => calculateProcurementSavings(priceHistory, purchaseOrders),
    [priceHistory, purchaseOrders]
  );

  // Central State Dispatcher
  const handleUpdateState = (stateKey: string, newData: any[]) => {
    switch (stateKey) {
      case 'assets': setAssets(newData); break;
      case 'equipmentMaster': setEquipmentMaster(newData); break;
      case 'equipmentIssuance': setEquipmentIssuance(newData); break;
      case 'attendance': setAttendance(newData); break;
      case 'kycQueries': setKYCQueries(newData); break;
      case 'employees': setEmployees(newData); break;
      case 'salaryBrackets': setSalaryBrackets(newData); break;
      case 'benefits': setBenefits(newData); break;
      case 'contracts': setContracts(newData); break;
      case 'leads': setLeads(newData); break;
      case 'conversions': setConversions(newData); break;
      case 'visits': setVisits(newData); break;
      case 'boqs': setBOQs(newData); break;
      case 'procurementAssignments': setProcurementAssignments(newData); break;
      case 'purchaseRequisitions': setPurchaseRequisitions(newData); break;
      case 'materialSubmittals': setMaterialSubmittals(newData); break;
      case 'quotations': setQuotations(newData); break;
      case 'purchaseOrders': setPurchaseOrders(newData); break;
      case 'logisticsShipments':
      case 'shipments': setLogisticsShipments(newData); break;
      case 'invoiceReconciliations':
      case 'reconciliations': setInvoiceReconciliations(newData); break;
      case 'suppliers': setSuppliers(newData); break;
      case 'priceHistory': setPriceHistory(newData); break;
      case 'procurementFollowUps':
      case 'followUps': setProcurementFollowUps(newData); break;
      case 'procurementRevisions':
      case 'revisions': setProcurementRevisions(newData); break;
      case 'securityProductCatalog':
      case 'securityCatalog': setSecurityProductCatalog(newData); break;
      case 'projects': setProjects(newData); break;
      case 'projectPaymentMilestones': setProjectPaymentMilestones(newData); break;
      case 'advanceChecks': setAdvanceChecks(newData); break;
      case 'teamSelection':
      case 'teamSelections': setTeamSelection(newData); break;
      case 'executionPhases': setExecutionPhases(newData); break;
      case 'weeklyReports': setWeeklyReports(newData); break;
      case 'qualityChecks': setQualityChecks(newData); break;
      case 'clientCommunications': setClientCommunications(newData); break;
      case 'projectCompletions': setProjectCompletions(newData); break;
      case 'tenders': setTenders(newData); break;
      case 'proposals': setProposals(newData); break;
      case 'activities': setActivities(newData); break;
      case 'phasedTasks': setPhasedTasks(newData); break;
      case 'dsaRecords': setDsaRecords(newData); break;
      case 'diaRecords': setDiaRecords(newData); break;
      case 'complianceChecklist': setComplianceChecklist(newData); break;
      case 'amcContracts': setAmcContracts(newData); break;
      case 'serviceTickets': setServiceTickets(newData); break;
      case 'schedules': setSchedules(newData); break;
      case 'inventoryItems': setInventoryItems(newData); break;
      case 'projectAssets': setProjectAssets(newData); break;
      case 'projectBudgets': setProjectBudgets(newData); break;
      case 'clientInvoices': setClientInvoices(newData); break;
      case 'projectExpenses': setProjectExpenses(newData); break;
      default: console.warn(`Unhandled state update key: ${stateKey}`);
    }
  };

  const handleAddRecord = (type: string, record: any) => {
    switch (type) {
      case 'asset':
      case 'assets': setAssets((prev) => [record, ...prev]); break;
      case 'equipment':
      case 'equipmentMaster': setEquipmentMaster((prev) => [record, ...prev]); break;
      case 'employee':
      case 'employees': setEmployees((prev) => [record, ...prev]); break;
      case 'lead':
      case 'leads': setLeads((prev) => [record, ...prev]); break;
      case 'boq':
      case 'boqs': setBOQs((prev) => [record, ...prev]); break;
      case 'requisition':
      case 'purchaseRequisitions': setPurchaseRequisitions((prev) => [record, ...prev]); break;
      case 'submittal':
      case 'materialSubmittals': setMaterialSubmittals((prev) => [record, ...prev]); break;
      case 'quotation':
      case 'quotations': setQuotations((prev) => [record, ...prev]); break;
      case 'po':
      case 'purchaseOrders': setPurchaseOrders((prev) => [record, ...prev]); break;
      case 'shipment':
      case 'shipments':
      case 'logisticsShipments': setLogisticsShipments((prev) => [record, ...prev]); break;
      case 'reconciliation':
      case 'reconciliations':
      case 'invoiceReconciliations': setInvoiceReconciliations((prev) => [record, ...prev]); break;
      case 'supplier':
      case 'suppliers': setSuppliers((prev) => [record, ...prev]); break;
      case 'price':
      case 'priceHistory': setPriceHistory((prev) => [record, ...prev]); break;
      case 'project':
      case 'projects': setProjects((prev) => [record, ...prev]); break;
      case 'tender':
      case 'tenders': setTenders((prev) => [record, ...prev]); break;
      case 'proposal':
      case 'proposals': setProposals((prev) => [record, ...prev]); break;
      case 'activity':
      case 'activities': setActivities((prev) => [record, ...prev]); break;
      case 'amc':
      case 'amcContracts': setAmcContracts((prev) => [record, ...prev]); break;
      case 'serviceTicket':
      case 'serviceTickets': setServiceTickets((prev) => [record, ...prev]); break;
      case 'inventory':
      case 'inventoryItems': setInventoryItems((prev) => [record, ...prev]); break;
      case 'securityCatalog': setSecurityProductCatalog((prev) => [record, ...prev]); break;
      default: console.warn(`Unhandled add record type: ${type}`);
    }
  };

  // 1-Click Operations
  const convertPRToPO = (prId: string): PurchaseOrder | null => {
    const pr = purchaseRequisitions.find((p) => p.prId === prId);
    if (!pr) return null;
    const newPO = generatePOFromPR(pr, suppliers, purchaseOrders.length);
    setPurchaseOrders((prev) => [newPO, ...prev]);
    setPurchaseRequisitions((prev) =>
      prev.map((item) => (item.prId === prId ? { ...item, status: 'PO Issued' } : item))
    );
    return newPO;
  };

  const convertQuoteToPO = (quoteId: string): PurchaseOrder | null => {
    const quote = quotations.find((q) => q.quoteId === quoteId);
    if (!quote) return null;
    const newPO = generatePOFromQuotation(quote, purchaseOrders.length);
    setPurchaseOrders((prev) => [newPO, ...prev]);
    setQuotations((prev) =>
      prev.map((item) => (item.quoteId === quoteId ? { ...item, status: 'Accepted', selected: 'Yes' } : item))
    );
    return newPO;
  };

  const createReconciliationForPO = (poId: string): InvoiceReconciliationRecord | null => {
    const po = purchaseOrders.find((p) => p.poNumber === poId);
    if (!po) return null;
    const newRecon = generateReconciliationFromPO(po, invoiceReconciliations.length);
    setInvoiceReconciliations((prev) => [newRecon, ...prev]);
    return newRecon;
  };

  const createSubmittalFromProduct = (itemCode: string, projectName: string): MaterialSubmittal | null => {
    const product = equipmentMaster.find((item) => item.code === itemCode);
    if (!product) return null;
    const newSubmittal = generateSubmittalFromCatalog(product, projectName, materialSubmittals.length);
    setMaterialSubmittals((prev) => [newSubmittal, ...prev]);
    return newSubmittal;
  };

  const handleExportAll = () => {
    exportMasterWorkbookToExcel({
      assets,
      equipmentMaster,
      equipmentIssuance,
      attendance,
      kycQueries,
      employees,
      salaryBrackets,
      benefits,
      contracts,
      leads,
      conversions,
      visits,
      boqs,
      procurementAssignments,
      purchaseRequisitions,
      materialSubmittals,
      quotations,
      purchaseOrders,
      shipments: logisticsShipments,
      reconciliations: invoiceReconciliations,
      suppliers,
      priceHistory,
      procurementFollowUps,
      procurementRevisions,
      securityCatalog: securityProductCatalog,
      projects,
      paymentMilestones: projectPaymentMilestones,
      advanceChecks,
      teamSelections: teamSelection,
      executionPhases,
      weeklyReports,
      qualityChecks,
      clientCommunications,
      projectCompletions,
      dropdowns: dropdownMaster as any,
    });
  };

  const value: AppDataContextType = {
    activeTab,
    setActiveTab,
    procurementSubModule,
    setProcurementSubModule,
    viewMode,
    setViewMode,
    globalSearch,
    setGlobalSearch,

    isQuickAddOpen,
    setIsQuickAddOpen,
    isFeedOpen,
    setIsFeedOpen,
    isGeminiChatOpen,
    setIsGeminiChatOpen,
    isGeminiIntelligenceOpen,
    setIsGeminiIntelligenceOpen,
    geminiIntelligenceMode,
    setGeminiIntelligenceMode,
    geminiSelectedBoqId,
    setGeminiSelectedBoqId,

    assets,
    equipmentMaster,
    equipmentIssuance,
    attendance,
    kycQueries,
    employees,
    salaryBrackets,
    benefits,
    contracts,
    leads,
    conversions,
    visits,
    boqs,
    procurementAssignments,
    purchaseRequisitions,
    materialSubmittals,
    quotations,
    purchaseOrders,
    logisticsShipments,
    invoiceReconciliations,
    suppliers,
    priceHistory,
    procurementFollowUps,
    procurementRevisions,
    securityProductCatalog,
    projects,
    projectPaymentMilestones,
    advanceChecks,
    teamSelection,
    executionPhases,
    weeklyReports,
    qualityChecks,
    clientCommunications,
    projectCompletions,
    dropdownMaster,

    tenders,
    proposals,
    activities,
    phasedTasks,
    dsaRecords,
    diaRecords,
    complianceChecklist,
    amcContracts,
    serviceTickets,
    schedules,
    inventoryItems,
    projectAssets,
    projectBudgets,
    clientInvoices,
    projectExpenses,
    clientPortalAccounts,
    automatedReports,

    handleUpdateState,
    handleAddRecord,
    handleExportAll,

    convertPRToPO,
    convertQuoteToPO,
    createReconciliationForPO,
    createSubmittalFromProduct,

    executiveKPIs,
    financialSummary,
    procurementSavings,
  };

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
};

export const useAppData = (): AppDataContextType => {
  const context = useContext(AppDataContext);
  if (!context) {
    throw new Error('useAppData must be used within an AppDataProvider');
  }
  return context;
};
