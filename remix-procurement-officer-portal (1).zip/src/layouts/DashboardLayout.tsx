import React, { ReactNode, useState } from 'react';
import { PanelLeft } from 'lucide-react';
import { Sidebar } from '../components/Sidebar';
import { FloatingActionHub } from '../components/FloatingActionHub';
import { QuickAddModal } from '../components/QuickAddModal';
import { FeedModal } from '../components/FeedModal';
import { GeminiChatDrawer } from '../components/GeminiChatDrawer';
import { GeminiIntelligenceModal } from '../components/GeminiIntelligenceModal';
import { useAppData } from '../context/useAppData';

interface DashboardLayoutProps {
  children: ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const {
    activeTab,
    setActiveTab,
    procurementSubModule,
    setProcurementSubModule,
    isQuickAddOpen,
    setIsQuickAddOpen,
    isFeedOpen,
    setIsFeedOpen,
    isGeminiChatOpen,
    setIsGeminiChatOpen,
    isGeminiIntelligenceOpen,
    setIsGeminiIntelligenceOpen,
    geminiIntelligenceMode,
    setGeminiIntelligenceMode,
    geminiSelectedBoqId,
    boqs,
    quotations,
    suppliers,
    projects,
    employees,
    handleAddRecord,
    handleExportAll,
  } = useAppData();

  return (
    <div id="dashboard-layout-root" className="flex h-screen bg-[#F8FAFC] text-slate-800 overflow-hidden font-sans antialiased relative">
      {/* Collapsed Edge Trigger */}
      {!isSidebarOpen && (
        <button
          id="edge-sidebar-open-btn"
          onClick={() => setIsSidebarOpen(true)}
          className="fixed left-0 top-20 z-40 bg-indigo-600 hover:bg-indigo-700 text-white px-1.5 py-3 rounded-r-xl shadow-md transition-all cursor-pointer flex items-center justify-center group"
          title="Show Navigation Sidebar"
        >
          <PanelLeft className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>
      )}

      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        activeSubModule={procurementSubModule}
        onSubModuleChange={setProcurementSubModule}
        totalProjects={projects.length}
        activeEmployees={employees.length}
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Workspace Area */}
      <div id="main-content-wrapper" className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Dynamic Screen View Content */}
        <main id="active-screen-container" className="flex-1 overflow-y-auto p-4 md:p-6 bg-slate-100/70">
          <div className="max-w-7xl mx-auto space-y-6">
            {children}
          </div>
        </main>
      </div>

      {/* Floating Action Hub */}
      <FloatingActionHub
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        onOpenFeed={() => setIsFeedOpen(true)}
        onOpenGeminiChat={() => setIsGeminiChatOpen(true)}
        onOpenGeminiIntelligence={() => {
          setGeminiIntelligenceMode('quote-analysis');
          setIsGeminiIntelligenceOpen(true);
        }}
        onExportMasterExcel={handleExportAll}
      />

      {/* Global Quick Add Modal with Relational Auto-Fill */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAddRecord={handleAddRecord}
      />

      {/* Activity Feed Modal */}
      <FeedModal
        isOpen={isFeedOpen}
        onClose={() => setIsFeedOpen(false)}
      />

      {/* Gemini AI Contextual Chat Drawer */}
      <GeminiChatDrawer
        isOpen={isGeminiChatOpen}
        onClose={() => setIsGeminiChatOpen(false)}
        contextTitle={activeTab.toUpperCase()}
      />

      {/* Gemini Strategic Intelligence Hub */}
      {isGeminiIntelligenceOpen && (
        <GeminiIntelligenceModal
          isOpen={isGeminiIntelligenceOpen}
          onClose={() => setIsGeminiIntelligenceOpen(false)}
          initialMode={geminiIntelligenceMode}
          selectedBoqId={geminiSelectedBoqId}
          boqs={boqs}
          quotations={quotations}
          suppliers={suppliers}
          onAddBOQRecord={(boq) => handleAddRecord('boqs', boq)}
          onNavigateTab={(tab, sub) => {
            setActiveTab(tab as any);
            if (sub) setProcurementSubModule(sub as any);
          }}
        />
      )}
    </div>
  );
};


