import React, { ReactNode } from 'react';
import { useAppData } from '../context/useAppData';
import { ArrowLeft, Sparkles, Plus, Download, Filter } from 'lucide-react';

export interface MainContentLayoutProps {
  id?: string;
  title: string;
  subtitle?: string;
  badge?: string;
  badgeColor?: string;
  breadcrumbs?: { label: string; onClick?: () => void }[];
  actions?: ReactNode;
  onQuickAdd?: () => void;
  onOpenAIInsight?: () => void;
  children: ReactNode;
  className?: string;
}

/**
 * MainContentLayout
 * Standard business screen wrapper that abstracts away global framing,
 * provides contextual breadcrumbs, status tags, domain-specific actions,
 * and AI Intelligence shortcuts.
 */
export const MainContentLayout: React.FC<MainContentLayoutProps> = ({
  id,
  title,
  subtitle,
  badge,
  badgeColor = 'bg-indigo-50 text-indigo-700 border-indigo-200',
  breadcrumbs,
  actions,
  onQuickAdd,
  onOpenAIInsight,
  children,
  className = '',
}) => {
  const {
    setIsQuickAddOpen,
    setIsGeminiIntelligenceOpen,
    setGeminiIntelligenceMode,
    handleExportAll,
  } = useAppData();

  const handleTriggerQuickAdd = () => {
    if (onQuickAdd) {
      onQuickAdd();
    } else {
      setIsQuickAddOpen(true);
    }
  };

  const handleTriggerAI = () => {
    if (onOpenAIInsight) {
      onOpenAIInsight();
    } else {
      setGeminiIntelligenceMode('quote-analysis');
      setIsGeminiIntelligenceOpen(true);
    }
  };

  return (
    <div id={id} className={`space-y-6 ${className}`}>
      {/* Screen Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          {/* Breadcrumbs */}
          {breadcrumbs && breadcrumbs.length > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5 font-medium">
              {breadcrumbs.map((crumb, idx) => (
                <React.Fragment key={idx}>
                  {idx > 0 && <span>/</span>}
                  {crumb.onClick ? (
                    <button
                      onClick={crumb.onClick}
                      className="hover:text-indigo-600 hover:underline transition cursor-pointer"
                    >
                      {crumb.label}
                    </button>
                  ) : (
                    <span className="text-slate-800 font-semibold">{crumb.label}</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight font-serif">
              {title}
            </h1>
            {badge && (
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase border ${badgeColor}`}>
                {badge}
              </span>
            )}
          </div>

          {subtitle && <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl">{subtitle}</p>}
        </div>

        {/* Action Header Slot */}
        <div className="flex items-center gap-2 flex-wrap sm:self-start">
          {actions}

          <button
            onClick={handleTriggerAI}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
            title="Open Gemini Strategic Intelligence"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>AI Insight</span>
          </button>

          <button
            onClick={handleTriggerQuickAdd}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Quick Entry</span>
          </button>
        </div>
      </div>

      {/* Screen Domain Body */}
      <div className="space-y-6">
        {children}
      </div>
    </div>
  );
};
