import {
  ProjectOverview,
  PurchaseRequisition,
  PurchaseOrder,
  MaterialSubmittal,
  SupplierRecord,
  EquipmentMasterItem,
  BOQRecord,
  InvoiceReconciliationRecord,
  QuotationResult,
} from '../types';

/**
 * Intelligent Relational Auto-Fill and Context Lookup Engine
 * Provides relational entity queries, cascade lookups, and auto-population for all forms.
 */

export interface ProjectContext {
  projectId: string;
  projectName: string;
  client: string;
  category: string;
  projectManager: string;
  status: string;
  budget: number;
  startDate: string;
  expectedEndDate: string;
}

export interface ProductCatalogContext {
  code: string;
  name: string;
  brand: string;
  model: string;
  category: string;
  unitPrice: number;
  moiApproved: 'Yes' | 'No' | 'Pending';
  currentStock: number;
  reorderStatus: string;
}

export interface VendorContext {
  vendorId?: string;
  vendorName: string;
  contactPerson: string;
  contactNumber: string;
  email: string;
  products: string;
  paymentTerms: string;
  creditTerms: string;
  rating: number;
  moiApproved: 'Yes' | 'No' | 'Pending';
  deliveryLeadTime: string;
}

/**
 * Extract rich project context for any Project ID or Project Name
 */
export function getProjectContext(
  identifier: string,
  projects: ProjectOverview[]
): ProjectContext | null {
  if (!identifier) return null;
  const lower = identifier.toLowerCase().trim();
  const match = projects.find(
    (p) =>
      p.id.toLowerCase() === lower ||
      p.projectName.toLowerCase() === lower ||
      p.projectName.toLowerCase().includes(lower)
  );

  if (!match) return null;

  return {
    projectId: match.id,
    projectName: match.projectName,
    client: match.clientName,
    category: match.category,
    projectManager: match.projectManager,
    status: match.status,
    budget: match.contractValue || match.boqValue,
    startDate: match.startDate,
    expectedEndDate: match.plannedEndDate,
  };
}

/**
 * Extract rich product catalog details by Item Code, Model, or Name
 */
export function getProductContext(
  identifier: string,
  catalog: EquipmentMasterItem[]
): ProductCatalogContext | null {
  if (!identifier) return null;
  const lower = identifier.toLowerCase().trim();
  const match = catalog.find(
    (item) =>
      item.code.toLowerCase() === lower ||
      item.model.toLowerCase() === lower ||
      item.name.toLowerCase() === lower ||
      item.name.toLowerCase().includes(lower)
  );

  if (!match) return null;

  return {
    code: match.code,
    name: match.name,
    brand: match.brand,
    model: match.model,
    category: match.category,
    unitPrice: match.unitPrice,
    moiApproved: match.moiApproved,
    currentStock: match.currentStock,
    reorderStatus: match.reorderStatus,
  };
}

/**
 * Extract rich vendor context
 */
export function getVendorContext(
  identifier: string,
  suppliers: SupplierRecord[]
): VendorContext | null {
  if (!identifier) return null;
  const lower = identifier.toLowerCase().trim();
  const match = suppliers.find(
    (s) =>
      s.code.toLowerCase() === lower ||
      s.name.toLowerCase() === lower ||
      s.name.toLowerCase().includes(lower)
  );

  if (!match) return null;

  return {
    vendorId: match.code,
    vendorName: match.name,
    contactPerson: match.contactPerson,
    contactNumber: match.phone,
    email: match.email,
    products: match.products,
    paymentTerms: match.paymentTerms,
    creditTerms: match.creditTerms,
    rating: match.rating,
    moiApproved: match.moiApproved,
    deliveryLeadTime: match.deliveryLeadTime,
  };
}

/**
 * Auto-Generate a Purchase Order Draft from an Approved Purchase Requisition
 */
export function generatePOFromPR(
  pr: PurchaseRequisition,
  suppliers: SupplierRecord[],
  existingPOCount: number
): PurchaseOrder {
  const newPoId = `PO-2025-${String(existingPOCount + 1).padStart(4, '0')}`;
  const vendor = suppliers[0];

  return {
    poNumber: newPoId,
    prId: pr.prId,
    boqId: pr.boqId || 'BOQ-001',
    projectName: pr.projectName,
    supplier: vendor?.name || 'Al-Anis Trading W.L.L.',
    issueDate: new Date().toISOString().split('T')[0],
    deliveryDueDate: pr.requiredDate || '2026-03-30',
    totalAmountQAR: pr.estimatedBudgetQAR || 25000,
    paymentTerms: vendor?.paymentTerms || '30 Days Net on GRN',
    deliveryLocation: pr.siteLocation || `Project Site: ${pr.projectName}`,
    turnaroundHours: 24,
    authorizedBy: 'Procurement Director',
    budgetAllocated: 'Yes',
    materialSubmittalApproved: 'Yes',
    status: 'Issued to Vendor',
    lineItemsCount: 1,
    remarks: `Auto-generated from ${pr.prId} (${pr.itemDescription})`,
  };
}

/**
 * Auto-Generate a Purchase Order Draft from an Awarded Vendor Quotation
 */
export function generatePOFromQuotation(
  quote: QuotationResult,
  existingPOCount: number
): PurchaseOrder {
  const newPoId = `PO-2025-${String(existingPOCount + 1).padStart(4, '0')}`;
  return {
    poNumber: newPoId,
    prId: `PR-${quote.quoteId}`,
    boqId: quote.boqId || 'BOQ-003',
    projectName: quote.projectName,
    supplier: quote.supplier,
    issueDate: new Date().toISOString().split('T')[0],
    deliveryDueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    totalAmountQAR: quote.quotedValue,
    paymentTerms: quote.paymentTerms,
    deliveryLocation: `Project Site: ${quote.projectName}`,
    turnaroundHours: 24,
    authorizedBy: 'Procurement Director',
    budgetAllocated: 'Yes',
    materialSubmittalApproved: 'Yes',
    status: 'Issued to Vendor',
    lineItemsCount: 6,
    remarks: `Converted from awarded quotation ${quote.quoteId} (${quote.supplier})`,
  };
}

/**
 * Auto-Generate a 3-Way Reconciliation Draft from a Purchase Order
 */
export function generateReconciliationFromPO(
  po: PurchaseOrder,
  existingReconCount: number
): InvoiceReconciliationRecord {
  const newReconId = `REC-2025-${String(existingReconCount + 1).padStart(3, '0')}`;
  const invoiceNum = `INV-${po.supplier.substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    reconciliationId: newReconId,
    invoiceNumber: invoiceNum,
    invoiceDate: new Date().toISOString().split('T')[0],
    poNumber: po.poNumber,
    supplier: po.supplier,
    deliveryAdviceNo: `DA-${Math.floor(1000 + Math.random() * 9000)}`,
    grnNo: `GRN-2025-${String(existingReconCount + 10).padStart(3, '0')}`,
    poAmountQAR: po.totalAmountQAR,
    grnReceivedAmountQAR: po.totalAmountQAR,
    invoiceAmountQAR: po.totalAmountQAR,
    varianceAmountQAR: 0,
    matchStatus: '3-Way Matched (100% OK)',
    qaQcPassed: 'Yes',
    financeReleaseStatus: 'Approved for Payment',
    reviewedBy: 'Procurement Officer',
    auditRemarks: `Automated match for PO ${po.poNumber}. Zero financial variance.`,
  };
}

/**
 * Auto-Generate a Material Submittal Draft from a Product Item and Project
 */
export function generateSubmittalFromCatalog(
  product: EquipmentMasterItem,
  projectName: string,
  existingSubmittalCount: number
): MaterialSubmittal {
  const submittalId = `MAS-${String(existingSubmittalCount + 1).padStart(3, '0')}`;

  return {
    submittalId: submittalId,
    boqId: 'BOQ-001',
    projectName: projectName,
    category: product.category,
    itemDescription: `${product.brand} ${product.name}`,
    brand: product.brand,
    model: product.model,
    supplier: 'Authorized Qatar Distributor',
    datasheetRef: `DS-${product.code}`,
    dateSubmitted: new Date().toISOString().split('T')[0],
    consultantName: 'KEO International Consultants',
    approvalStatus: 'Approved (Code A)',
    approvalDate: new Date().toISOString().split('T')[0],
    moiCertificateAttached: product.moiApproved === 'Yes' ? 'Yes' : 'No',
    complianceNotes:
      product.moiApproved === 'Yes'
        ? 'Pre-approved under Qatar MOI-SSD Security Systems standard'
        : 'Awaiting Consultant Review and MOI test report',
  };
}
