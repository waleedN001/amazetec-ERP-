import {
  PriceHistoryRecord,
  DrawingTakeoffItem,
  DrawingTakeoffSession,
  StructuredBOQItem,
  RulesEngineAConfig,
  DraftQuotationSummary,
  DraftQuotationItem,
  RFQBundle,
  SupplierRFQBid,
  RulesEngineBConfig,
  FinalCommercialQuotation,
  FinalQuotationItem,
  QuotationComparativeAnalysis,
  PriceHistoryVersion,
} from '../types';

/**
 * Default Rules Engine A Configuration (BOQ -> Initial Quote)
 */
export const defaultRulesEngineAConfig: RulesEngineAConfig = {
  materialMarkupPercent: 15,
  directLaborRateMode: 'PercentageOfMaterial',
  directLaborPercent: 12,
  directLaborHourlyRateQAR: 45,
  estimatedLaborHours: 120,
  overheadsPercent: 8,
  wastageScrapPercent: 5,
  logisticsTransportMode: 'Percentage',
  logisticsTransportPercent: 4,
  logisticsFixedFeeQAR: 2500,
  insuranceAndBondsPercent: 2,
  standardProfitMarginP1: 18,
};

/**
 * Default Rules Engine B Configuration (Supplier Update -> Revised Final Quote)
 */
export const defaultRulesEngineBConfig: RulesEngineBConfig = {
  supplierSelectionLogic: 'LowestCost',
  bulkDiscountsEnabled: true,
  bulkDiscountTiers: [
    { minVolumeQAR: 25000, discountPercent: 3 },
    { minVolumeQAR: 75000, discountPercent: 6 },
    { minVolumeQAR: 150000, discountPercent: 10 },
  ],
  competitiveAdjustmentPercent: -3.5, // 3.5% strategic discount to win tender
  urgencyPremiumPercent: 0,
  exchangeRateBufferPercent: 1.5,
  paymentTermsMode: 'Standard30PDC',
  paymentTermModifierPercent: 0,
  finalRoundingRule: 'Nearest10',
  approvalThresholdLimitQAR: 250000,
};

/**
 * Rules Engine Service
 * Implements the automated calculation pipeline from Engineering Drawings to Final Commercial Quotation
 * powered by Price History Logs as the single source of truth.
 */
export class RulesEngineService {
  /**
   * Phase 1: Aggregate Drawing Takeoff items into a Structured BOQ using Price History Logs
   */
  public static generateStructuredBOQFromTakeoff(
    takeoffItems: DrawingTakeoffItem[],
    priceHistory: PriceHistoryRecord[]
  ): StructuredBOQItem[] {
    const priceMap = new Map<string, PriceHistoryRecord>();
    priceHistory.forEach((item) => {
      const code = item.productCode || (item as any).itemCode;
      if (code) priceMap.set(code, item);
    });

    return takeoffItems.map((item) => {
      const priceItem = priceMap.get(item.itemCode);
      const unitCost = priceItem ? (Number(priceItem.newPrice) || Number((priceItem as any).standardCostWarehouseQAR) || Number(priceItem.oldPrice) || 100) : 100;
      const detected = Number(item.detectedCountOrLength ?? (item as any).qtyCounted ?? 1);
      const anomaly = Number(item.siteAnomalyAdjustment ?? 0);
      const finalQty = Math.max(1, detected + anomaly);
      const totalCost = finalQty * unitCost;

      return {
        id: `sboq-${item.id}`,
        itemCode: item.itemCode,
        description: item.description,
        category: item.category,
        uom: item.uom,
        takeoffQuantity: detected,
        manualAdjustment: anomaly,
        finalQuantity: finalQty,
        unitCostBaseQAR: unitCost,
        totalCostBaseQAR: totalCost,
      };
    });
  }

  /**
   * Phase 2: Rules Engine A (BOQ -> Initial Draft Quotation)
   */
  public static executeRulesEngineA(
    boqItems: StructuredBOQItem[],
    config: RulesEngineAConfig,
    projectName: string = 'Commercial ELV Installation',
    quoteId: string = 'DRAFT-Q-001'
  ): DraftQuotationSummary {
    const rawMaterialCostQAR = boqItems.reduce(
      (sum, item) => sum + item.finalQuantity * item.unitCostBaseQAR,
      0
    );

    // 1. Wastage / Scrap Factor
    const wastageCostQAR = (rawMaterialCostQAR * config.wastageScrapPercent) / 100;
    const effectiveMaterialCostQAR = rawMaterialCostQAR + wastageCostQAR;

    // 2. Material Markup
    const materialMarkupValueQAR = (effectiveMaterialCostQAR * config.materialMarkupPercent) / 100;

    // 3. Direct Labor Rate
    let directLaborCostQAR = 0;
    if (config.directLaborRateMode === 'PercentageOfMaterial') {
      directLaborCostQAR = (effectiveMaterialCostQAR * config.directLaborPercent) / 100;
    } else {
      directLaborCostQAR = config.estimatedLaborHours * config.directLaborHourlyRateQAR;
    }

    // 4. Overheads (Administrative, PM, Site Office)
    const overheadsCostQAR = (effectiveMaterialCostQAR * config.overheadsPercent) / 100;

    // 5. Transport / Logistics
    let transportLogisticsCostQAR = 0;
    if (config.logisticsTransportMode === 'Percentage') {
      transportLogisticsCostQAR = (effectiveMaterialCostQAR * config.logisticsTransportPercent) / 100;
    } else {
      transportLogisticsCostQAR = config.logisticsFixedFeeQAR;
    }

    // Subtotal before insurance and profit
    const primeCostQAR =
      effectiveMaterialCostQAR +
      materialMarkupValueQAR +
      directLaborCostQAR +
      overheadsCostQAR +
      transportLogisticsCostQAR;

    // 6. Insurance & Performance Bonds
    const insuranceBondsCostQAR = (primeCostQAR * config.insuranceAndBondsPercent) / 100;

    // Cost basis before target profit margin
    const subtotalWithInsuranceQAR = primeCostQAR + insuranceBondsCostQAR;

    // 7. Standard Profit Margin (P1)
    const standardProfitP1QAR = (subtotalWithInsuranceQAR * config.standardProfitMarginP1) / 100;
    const totalDraftQuotationQAR = subtotalWithInsuranceQAR + standardProfitP1QAR;

    const grossMarginPercent =
      totalDraftQuotationQAR > 0
        ? ((totalDraftQuotationQAR - rawMaterialCostQAR) / totalDraftQuotationQAR) * 100
        : 0;

    // Itemized distribution
    const items: DraftQuotationItem[] = boqItems.map((boq) => {
      const itemBase = boq.finalQuantity * boq.unitCostBaseQAR;
      const proportion = rawMaterialCostQAR > 0 ? itemBase / rawMaterialCostQAR : 0;

      const itemWastage = wastageCostQAR * proportion;
      const itemMarkup = materialMarkupValueQAR * proportion;
      const itemLabor = directLaborCostQAR * proportion;
      const itemOverhead = overheadsCostQAR * proportion;
      const itemLogistics = transportLogisticsCostQAR * proportion;
      const itemInsurance = insuranceBondsCostQAR * proportion;
      const itemProfit = standardProfitP1QAR * proportion;

      const itemTotalSelling =
        itemBase +
        itemWastage +
        itemMarkup +
        itemLabor +
        itemOverhead +
        itemLogistics +
        itemInsurance +
        itemProfit;

      const itemUnitSelling = boq.finalQuantity > 0 ? itemTotalSelling / boq.finalQuantity : 0;

      return {
        itemCode: boq.itemCode,
        description: boq.description,
        category: boq.category,
        uom: boq.uom,
        quantity: boq.finalQuantity,
        baseUnitCostQAR: boq.unitCostBaseQAR,
        baseMaterialTotalQAR: itemBase,
        materialWithWastageQAR: itemBase + itemWastage,
        materialWithMarkupQAR: itemBase + itemWastage + itemMarkup,
        directLaborAllocatedQAR: itemLabor,
        overheadsAllocatedQAR: itemOverhead,
        logisticsAllocatedQAR: itemLogistics,
        insuranceAllocatedQAR: itemInsurance,
        profitMarginP1AllocatedQAR: itemProfit,
        draftUnitSellingPriceQAR: Number(itemUnitSelling.toFixed(2)),
        draftTotalSellingPriceQAR: Number(itemTotalSelling.toFixed(2)),
      };
    });

    return {
      quoteId,
      boqId: 'BOQ-AUTO-01',
      projectName,
      generatedDate: new Date().toISOString().split('T')[0],
      rawMaterialCostQAR: Number(rawMaterialCostQAR.toFixed(2)),
      wastageCostQAR: Number(wastageCostQAR.toFixed(2)),
      effectiveMaterialCostQAR: Number(effectiveMaterialCostQAR.toFixed(2)),
      materialMarkupValueQAR: Number(materialMarkupValueQAR.toFixed(2)),
      directLaborCostQAR: Number(directLaborCostQAR.toFixed(2)),
      overheadsCostQAR: Number(overheadsCostQAR.toFixed(2)),
      transportLogisticsCostQAR: Number(transportLogisticsCostQAR.toFixed(2)),
      insuranceBondsCostQAR: Number(insuranceBondsCostQAR.toFixed(2)),
      standardProfitP1QAR: Number(standardProfitP1QAR.toFixed(2)),
      totalDraftQuotationQAR: Number(totalDraftQuotationQAR.toFixed(2)),
      grossMarginPercent: Number(grossMarginPercent.toFixed(1)),
      items,
    };
  }

  /**
   * Phase 3: Synchronize Supplier Bids with Price History Logs (Single Source of Truth)
   * Updates price history records with latest newPrice, priceChange, changeType, effectiveDate, and logs versionHistory.
   */
  public static syncWinningBidsToPriceHistory(
    priceHistory: PriceHistoryRecord[],
    winningBids: SupplierRFQBid[]
  ): PriceHistoryRecord[] {
    const winningMap = new Map<string, SupplierRFQBid>();
    winningBids.forEach((bid) => winningMap.set(bid.itemCode, bid));

    return priceHistory.map((item) => {
      const code = item.productCode || (item as any).itemCode;
      const bid = code ? winningMap.get(code) : undefined;
      if (!bid) return item;

      const previousPrice = Number(item.newPrice) || Number(item.oldPrice) || 0;
      const newCost = Number(bid.quotedUnitPriceQAR) || 0;
      const diff = newCost - previousPrice;
      const pct = previousPrice > 0 ? (diff / previousPrice) * 100 : 0;
      let type: 'Decrease' | 'Increase' | 'Unchanged' = 'Unchanged';
      if (diff < 0) type = 'Decrease';
      if (diff > 0) type = 'Increase';

      const newVersion: PriceHistoryVersion = {
        version: `v${(item.versionHistory?.length || 0) + 1}.0`,
        effectiveDate: new Date().toISOString().split('T')[0],
        supplier: bid.supplierName,
        costQAR: newCost,
        reason: `Automated RFQ Sync: ${bid.complianceStatus}`,
        sourceRFQ: bid.rfqId,
      };

      return {
        ...item,
        oldPrice: previousPrice > 0 ? previousPrice : newCost,
        newPrice: newCost,
        priceChange: Number(diff.toFixed(2)),
        percentChange: Number(pct.toFixed(1)),
        changeType: type,
        supplier: bid.supplierName,
        leadTime: bid.deliveryLeadTime || item.leadTime,
        effectiveDate: new Date().toISOString().split('T')[0],
        reason: `RFQ Sync: ${bid.complianceStatus}`,
        versionHistory: [newVersion, ...(item.versionHistory || [])],
      };
    });
  }

  // Backward compatibility alias
  public static syncWinningBidsToMasterPriceTable = RulesEngineService.syncWinningBidsToPriceHistory;

  /**
   * Phase 4: Rules Engine B (Quotation -> Final Revision with Supplier Market Bids)
   */
  public static executeRulesEngineB(
    draftQuote: DraftQuotationSummary,
    supplierBids: SupplierRFQBid[],
    priceHistory: PriceHistoryRecord[],
    config: RulesEngineBConfig,
    clientName: string = 'Hamad Medical Corporation / MOI SSD'
  ): FinalCommercialQuotation {
    // 1. Supplier Selection Logic per Item
    const selectedBidsByItem = new Map<string, SupplierRFQBid>();

    draftQuote.items.forEach((item) => {
      const itemBids = supplierBids.filter((b) => b.itemCode === item.itemCode);
      if (itemBids.length === 0) {
        // Fallback to price history logs
        const priceItem = priceHistory.find((m) => (m.productCode === item.itemCode) || ((m as any).itemCode === item.itemCode));
        const fallbackCost = priceItem ? (priceItem.newPrice || priceItem.oldPrice || (priceItem as any).standardCostWarehouseQAR) : item.baseUnitCostQAR;
        selectedBidsByItem.set(item.itemCode, {
          bidId: `auto-fallback-${item.itemCode}`,
          rfqId: 'RFQ-FALLBACK',
          itemCode: item.itemCode,
          supplierName: priceItem?.supplier || 'Authorized Distributor',
          quotedUnitPriceQAR: fallbackCost,
          deliveryLeadTime: priceItem?.leadTime || 'Ex-Stock (1-2 Days)',
          paymentTerms: '30 Days PDC',
          validityDays: 30,
          warrantyPeriod: '3 Years MOI',
          complianceStatus: 'Fully Compliant',
          varianceVsStandardCostQAR: fallbackCost - item.baseUnitCostQAR,
          varianceVsStandardCostPercent: item.baseUnitCostQAR > 0 ? ((fallbackCost - item.baseUnitCostQAR) / item.baseUnitCostQAR) * 100 : 0,
        });
        return;
      }

      if (config.supplierSelectionLogic === 'LowestCost') {
        const sorted = [...itemBids].sort((a, b) => a.quotedUnitPriceQAR - b.quotedUnitPriceQAR);
        selectedBidsByItem.set(item.itemCode, sorted[0]);
      } else if (config.supplierSelectionLogic === 'MostReliable') {
        const compliant = itemBids.filter((b) => b.complianceStatus === 'Fully Compliant');
        const sorted = compliant.length > 0 ? compliant : itemBids;
        selectedBidsByItem.set(item.itemCode, sorted[0]);
      } else {
        // Balanced
        selectedBidsByItem.set(item.itemCode, itemBids[0]);
      }
    });

    // Calculate Market-Sourced Base Cost
    let marketSourcedBaseCostQAR = 0;
    let baselineWarehouseCostQAR = 0;

    draftQuote.items.forEach((item) => {
      const selBid = selectedBidsByItem.get(item.itemCode);
      const unitRate = selBid ? selBid.quotedUnitPriceQAR : item.baseUnitCostQAR;
      marketSourcedBaseCostQAR += item.quantity * unitRate;
      baselineWarehouseCostQAR += item.quantity * item.baseUnitCostQAR;
    });

    const supplierNegotiatedSavingsQAR = Math.max(0, baselineWarehouseCostQAR - marketSourcedBaseCostQAR);

    // 2. Bulk & Tiered Volume Discounts
    let bulkDiscountPercent = 0;
    if (config.bulkDiscountsEnabled && config.bulkDiscountTiers?.length > 0) {
      const matchedTier = [...config.bulkDiscountTiers]
        .sort((a, b) => b.minVolumeQAR - a.minVolumeQAR)
        .find((tier) => marketSourcedBaseCostQAR >= tier.minVolumeQAR);
      if (matchedTier) {
        bulkDiscountPercent = matchedTier.discountPercent;
      }
    }
    const bulkDiscountSavingsQAR = (marketSourcedBaseCostQAR * bulkDiscountPercent) / 100;
    const discountedMarketCostQAR = marketSourcedBaseCostQAR - bulkDiscountSavingsQAR;

    // Maintain draft quotation markup structure scaled to revised market costs
    const scaleRatio = baselineWarehouseCostQAR > 0 ? discountedMarketCostQAR / baselineWarehouseCostQAR : 1;
    const scaledDraftSubtotal = draftQuote.totalDraftQuotationQAR * scaleRatio;

    // 3. Competitive Adjustment
    const competitiveDiscountQAR = (scaledDraftSubtotal * Math.abs(config.competitiveAdjustmentPercent)) / 100;

    // 4. Urgency / Emergency Premium
    const urgencySurchargeQAR = (scaledDraftSubtotal * config.urgencyPremiumPercent) / 100;

    // 5. Exchange Rate Buffering
    const fxBufferAmountQAR = (discountedMarketCostQAR * config.exchangeRateBufferPercent) / 100;

    // 6. Payment Term Modifier
    let paymentTermAdjustmentQAR = 0;
    if (config.paymentTermsMode === 'CashInAdvance') {
      paymentTermAdjustmentQAR = -(scaledDraftSubtotal * 2.5) / 100;
    } else if (config.paymentTermsMode === 'ExtendedCredit60PDC') {
      paymentTermAdjustmentQAR = +(scaledDraftSubtotal * 2.0) / 100;
    } else if (config.paymentTermsMode === 'LC90Days') {
      paymentTermAdjustmentQAR = +(scaledDraftSubtotal * 4.0) / 100;
    }

    const preRoundedTotalQAR =
      scaledDraftSubtotal -
      competitiveDiscountQAR +
      urgencySurchargeQAR +
      fxBufferAmountQAR +
      paymentTermAdjustmentQAR;

    // 7. Final Rounding
    let finalQuotationTotalQAR = preRoundedTotalQAR;
    if (config.finalRoundingRule === 'Nearest5') {
      finalQuotationTotalQAR = Math.round(preRoundedTotalQAR / 5) * 5;
    } else if (config.finalRoundingRule === 'Nearest10') {
      finalQuotationTotalQAR = Math.round(preRoundedTotalQAR / 10) * 10;
    } else if (config.finalRoundingRule === 'Nearest50') {
      finalQuotationTotalQAR = Math.round(preRoundedTotalQAR / 50) * 50;
    } else if (config.finalRoundingRule === 'Nearest100') {
      finalQuotationTotalQAR = Math.round(preRoundedTotalQAR / 100) * 100;
    }

    const netProfitQAR = finalQuotationTotalQAR - discountedMarketCostQAR;
    const netProfitMarginPercent =
      finalQuotationTotalQAR > 0 ? Number(((netProfitQAR / finalQuotationTotalQAR) * 100).toFixed(1)) : 0;

    // 8. Management Approval Threshold
    const requiresExecutiveApproval = finalQuotationTotalQAR > config.approvalThresholdLimitQAR;
    const approvalStatus = requiresExecutiveApproval ? 'Requires Director Signoff' : 'Auto-Approved';

    // Detailed item breakdown
    const items: FinalQuotationItem[] = draftQuote.items.map((draftItem) => {
      const bid = selectedBidsByItem.get(draftItem.itemCode);
      const supplierPrice = bid ? bid.quotedUnitPriceQAR : draftItem.baseUnitCostQAR;
      const supplierDiscountedPrice = supplierPrice * (1 - bulkDiscountPercent / 100);
      const costSavingsPerUnit = Math.max(0, draftItem.baseUnitCostQAR - supplierDiscountedPrice);

      const itemTotalProportion =
        draftQuote.totalDraftQuotationQAR > 0
          ? draftItem.draftTotalSellingPriceQAR / draftQuote.totalDraftQuotationQAR
          : 0;

      const revisedTotalSelling = finalQuotationTotalQAR * itemTotalProportion;
      const revisedUnitSelling = draftItem.quantity > 0 ? revisedTotalSelling / draftItem.quantity : 0;

      return {
        itemCode: draftItem.itemCode,
        description: draftItem.description,
        category: draftItem.category,
        uom: draftItem.uom,
        quantity: draftItem.quantity,
        draftUnitRateQAR: draftItem.draftUnitSellingPriceQAR,
        selectedSupplier: bid?.supplierName || 'Primary Supplier',
        supplierUnitPriceQAR: supplierPrice,
        supplierDiscountedUnitRateQAR: Number(supplierDiscountedPrice.toFixed(2)),
        revisedUnitSellingPriceQAR: Number(revisedUnitSelling.toFixed(2)),
        revisedTotalSellingPriceQAR: Number(revisedTotalSelling.toFixed(2)),
        costSavingsPerUnitQAR: Number(costSavingsPerUnit.toFixed(2)),
      };
    });

    const now = new Date();
    const validUntilDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    return {
      finalQuoteId: `REV-FINAL-${draftQuote.quoteId}`,
      boqId: draftQuote.boqId,
      projectName: draftQuote.projectName,
      clientName,
      creationDate: now.toISOString().split('T')[0],
      validUntil: validUntilDate.toISOString().split('T')[0],
      draftQuoteTotalQAR: draftQuote.totalDraftQuotationQAR,
      marketSourcedBaseCostQAR: Number(marketSourcedBaseCostQAR.toFixed(2)),
      supplierNegotiatedSavingsQAR: Number(supplierNegotiatedSavingsQAR.toFixed(2)),
      bulkDiscountSavingsQAR: Number(bulkDiscountSavingsQAR.toFixed(2)),
      competitiveDiscountQAR: Number(competitiveDiscountQAR.toFixed(2)),
      urgencySurchargeQAR: Number(urgencySurchargeQAR.toFixed(2)),
      fxBufferAmountQAR: Number(fxBufferAmountQAR.toFixed(2)),
      paymentTermAdjustmentQAR: Number(paymentTermAdjustmentQAR.toFixed(2)),
      preRoundedTotalQAR: Number(preRoundedTotalQAR.toFixed(2)),
      finalQuotationTotalQAR: Number(finalQuotationTotalQAR.toFixed(2)),
      netProfitQAR: Number(netProfitQAR.toFixed(2)),
      netProfitMarginPercent,
      requiresExecutiveApproval,
      approvalStatus,
      items,
    };
  }

  /**
   * Comparative Analysis: Initial Draft (Rules A) vs Revised Final Quote (Rules B)
   */
  public static generateComparativeAnalysis(
    draftQuote: DraftQuotationSummary,
    finalQuote: FinalCommercialQuotation
  ): QuotationComparativeAnalysis {
    const totalCostDifferenceQAR = draftQuote.rawMaterialCostQAR - finalQuote.marketSourcedBaseCostQAR;
    const totalSellingPriceDifferenceQAR = draftQuote.totalDraftQuotationQAR - finalQuote.finalQuotationTotalQAR;

    const costReductionPercent =
      draftQuote.rawMaterialCostQAR > 0
        ? Number(((totalCostDifferenceQAR / draftQuote.rawMaterialCostQAR) * 100).toFixed(1))
        : 0;

    const clientPriceAdvantagePercent =
      draftQuote.totalDraftQuotationQAR > 0
        ? Number(((totalSellingPriceDifferenceQAR / draftQuote.totalDraftQuotationQAR) * 100).toFixed(1))
        : 0;

    const draftProfit = draftQuote.totalDraftQuotationQAR - draftQuote.rawMaterialCostQAR;
    const finalProfit = finalQuote.finalQuotationTotalQAR - finalQuote.marketSourcedBaseCostQAR;
    const profitDifferenceQAR = finalProfit - draftProfit;

    let competitivenessRating: 'Aggressive / Highly Competitive' | 'Optimal Market Price' | 'Premium / Low Risk' = 'Optimal Market Price';
    if (clientPriceAdvantagePercent > 5 && finalQuote.netProfitMarginPercent >= 15) {
      competitivenessRating = 'Aggressive / Highly Competitive';
    } else if (finalQuote.netProfitMarginPercent >= 22) {
      competitivenessRating = 'Premium / Low Risk';
    }

    return {
      draftQuote,
      finalQuote,
      totalCostDifferenceQAR: Number(totalCostDifferenceQAR.toFixed(2)),
      totalSellingPriceDifferenceQAR: Number(totalSellingPriceDifferenceQAR.toFixed(2)),
      costReductionPercent,
      clientPriceAdvantagePercent,
      profitDifferenceQAR: Number(profitDifferenceQAR.toFixed(2)),
      competitivenessRating,
    };
  }
}
