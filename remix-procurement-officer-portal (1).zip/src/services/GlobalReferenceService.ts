import {
  PurchaseOrder,
  InventoryItemRecord,
  ProjectBudgetRecord,
  QuotationResult,
  LogisticsShipment,
  InvoiceReconciliationRecord,
  BOQRecord,
  EquipmentMasterItem,
  EquipmentIssuance,
  ProjectAssetAssignment,
  LeadRecord,
  ProjectOverview,
} from '../types';

/**
 * Global Reference Service
 * Resolves cross-module entity relationships and propagates cascading state updates
 * so that an update in one domain (e.g. issuing a PO) automatically syncs related
 * entities (e.g. inventory stock, project budget commitment, 3-way reconciliation, submittals).
 */
export class GlobalReferenceService {
  /**
   * Resolve Inventory Items from a Purchase Order
   * When a PO is created or updated, synchronize the Inventory Catalog records.
   */
  static resolveInventoryFromPO(
    po: PurchaseOrder,
    existingInventory: InventoryItemRecord[]
  ): InventoryItemRecord[] {
    const itemId = `INV-${po.poNumber.replace(/[^a-zA-Z0-9]/g, '')}`;
    const existingIndex = existingInventory.findIndex(
      (item) => item.itemId === itemId || item.description.includes(po.poNumber)
    );

    const isDelivered = po.status === 'Delivered';

    const resolvedItem: InventoryItemRecord = {
      itemId,
      brand: po.supplier.includes('Hikvision')
        ? 'Hikvision'
        : po.supplier.includes('Dahua')
        ? 'Dahua'
        : po.supplier.includes('Honeywell')
        ? 'Honeywell'
        : 'Enterprise Security',
      model: `MOD-${po.poNumber.slice(-4)}`,
      category: 'CCTV & Security Hardware',
      description: `${po.projectName} Security Package (${po.supplier}) [Ref: ${po.poNumber}]`,
      warehouseLocation: po.deliveryLocation || `Doha Central Warehouse / ${po.projectName}`,
      quantityOnHand: isDelivered ? po.lineItemsCount * 5 : 0,
      minimumStockLevel: 5,
      reorderQuantity: 10,
      reorderStatus: isDelivered ? 'Sufficient' : 'Low Stock',
      status: isDelivered ? 'In Stock' : 'Reserved for Project',
      unitCostQAR: Math.round(po.totalAmountQAR / (po.lineItemsCount || 1)),
      totalValueQAR: po.totalAmountQAR,
      preferredSupplier: po.supplier,
      moiApproved: po.materialSubmittalApproved === 'Yes' ? 'Yes' : 'No',
    };

    if (existingIndex >= 0) {
      const updated = [...existingInventory];
      updated[existingIndex] = {
        ...updated[existingIndex],
        ...resolvedItem,
        quantityOnHand: isDelivered
          ? Math.max(updated[existingIndex].quantityOnHand, resolvedItem.quantityOnHand)
          : updated[existingIndex].quantityOnHand,
      };
      return updated;
    } else {
      return [resolvedItem, ...existingInventory];
    }
  }

  /**
   * Resolve Project Budget Committed & Spent Spend from Purchase Orders & Invoices
   */
  static resolveProjectBudget(
    projectName: string,
    budgets: ProjectBudgetRecord[],
    purchaseOrders: PurchaseOrder[],
    invoices: InvoiceReconciliationRecord[]
  ): ProjectBudgetRecord[] {
    const projectPOs = purchaseOrders.filter(
      (po) => po.projectName.toLowerCase() === projectName.toLowerCase()
    );
    const totalCommittedPO = projectPOs.reduce((acc, po) => acc + (po.totalAmountQAR || 0), 0);

    const projectInvoices = invoices.filter(
      (inv) => inv.poNumber && projectPOs.some((p) => p.poNumber === inv.poNumber) && inv.matchStatus === '3-Way Matched (100% OK)'
    );
    const totalActualSpend = projectInvoices.reduce((acc, inv) => acc + (inv.invoiceAmountQAR || 0), 0);

    const existingBudgetIndex = budgets.findIndex(
      (b) => b.projectName.toLowerCase() === projectName.toLowerCase()
    );

    if (existingBudgetIndex >= 0) {
      const current = budgets[existingBudgetIndex];
      const revisedHardwareActual = totalActualSpend || current.hardwareActualQAR;
      const totalActual = revisedHardwareActual + current.labourActualQAR + current.logisticsActualQAR + current.overheadActualQAR;
      const variance = totalActual - current.totalBudgetQAR;

      const updatedBudget: ProjectBudgetRecord = {
        ...current,
        hardwareActualQAR: revisedHardwareActual,
        totalActualQAR: totalActual,
        varianceQAR: variance,
        profitMarginPercent: current.totalBudgetQAR > 0
          ? Math.round(((current.totalBudgetQAR - totalActual) / current.totalBudgetQAR) * 100)
          : current.profitMarginPercent,
      };

      const updatedList = [...budgets];
      updatedList[existingBudgetIndex] = updatedBudget;
      return updatedList;
    }

    return budgets;
  }

  /**
   * Resolve Shipment Delivery Cascade
   * When a shipment clears customs and is delivered to site:
   * 1. Updates PO status to 'Delivered'
   * 2. Auto-generates or verifies 3-Way Reconciliation record
   * 3. Updates Inventory available stock
   */
  static resolveShipmentDelivery(
    shipment: LogisticsShipment,
    purchaseOrders: PurchaseOrder[],
    reconciliations: InvoiceReconciliationRecord[],
    inventory: InventoryItemRecord[]
  ): {
    updatedPOs: PurchaseOrder[];
    updatedReconciliations: InvoiceReconciliationRecord[];
    updatedInventory: InventoryItemRecord[];
  } {
    const isDelivered = shipment.siteDeliveryStatus === 'Delivered to Site';

    // 1. Update matching PO
    const updatedPOs = purchaseOrders.map((po) => {
      if (po.poNumber === shipment.poNumber) {
        return {
          ...po,
          status: (isDelivered ? 'Delivered' : po.status) as any,
          remarks: `${po.remarks || ''} [Shipment ${shipment.shipmentId}: ${shipment.siteDeliveryStatus}]`.trim(),
        };
      }
      return po;
    });

    // 2. Resolve matching 3-Way Reconciliation
    let updatedReconciliations = [...reconciliations];
    const matchingReconIndex = updatedReconciliations.findIndex(
      (r) => r.poNumber === shipment.poNumber
    );

    if (matchingReconIndex >= 0) {
      updatedReconciliations[matchingReconIndex] = {
        ...updatedReconciliations[matchingReconIndex],
        deliveryAdviceNo: `DA-${shipment.shipmentId}`,
        grnNo: `GRN-${shipment.shipmentId}`,
        matchStatus: isDelivered ? '3-Way Matched (100% OK)' : 'Pending GRN',
        financeReleaseStatus: isDelivered ? 'Approved for Payment' : 'Payment On Hold',
        auditRemarks: `Auto-verified against AWB/BOL: ${shipment.awbOrBolNo}`,
      };
    } else {
      const targetPO = purchaseOrders.find((p) => p.poNumber === shipment.poNumber);
      if (targetPO) {
        const newRecon: InvoiceReconciliationRecord = {
          reconciliationId: `REC-${Date.now().toString().slice(-4)}`,
          invoiceNumber: `INV-VEND-${shipment.supplier.slice(0, 3).toUpperCase()}-2025`,
          invoiceDate: new Date().toISOString().split('T')[0],
          poNumber: targetPO.poNumber,
          supplier: targetPO.supplier,
          deliveryAdviceNo: `DA-${shipment.shipmentId}`,
          grnNo: `GRN-${shipment.shipmentId}`,
          poAmountQAR: targetPO.totalAmountQAR,
          grnReceivedAmountQAR: targetPO.totalAmountQAR,
          invoiceAmountQAR: targetPO.totalAmountQAR,
          varianceAmountQAR: 0,
          matchStatus: '3-Way Matched (100% OK)',
          qaQcPassed: 'Yes',
          financeReleaseStatus: 'Approved for Payment',
          reviewedBy: 'Procurement Specialist',
          auditRemarks: `Auto-reconciled on shipment clearance (${shipment.shipmentId})`,
        };
        updatedReconciliations = [newRecon, ...updatedReconciliations];
      }
    }

    // 3. Update inventory
    const targetPO = purchaseOrders.find((p) => p.poNumber === shipment.poNumber);
    const updatedInventory = targetPO
      ? this.resolveInventoryFromPO({ ...targetPO, status: 'Delivered' }, inventory)
      : inventory;

    return {
      updatedPOs,
      updatedReconciliations,
      updatedInventory,
    };
  }

  /**
   * Resolve Equipment Issuance to Project Asset
   */
  static resolveEquipmentIssuance(
    issuance: EquipmentIssuance,
    equipmentList: EquipmentMasterItem[],
    projectAssets: ProjectAssetAssignment[]
  ): {
    updatedEquipment: EquipmentMasterItem[];
    updatedProjectAssets: ProjectAssetAssignment[];
  } {
    // 1. Update Equipment Master status
    const updatedEquipment = equipmentList.map((eq) => {
      if (eq.code === issuance.equipmentCode) {
        const newStock = Math.max(0, eq.currentStock - issuance.quantityIssued);
        return {
          ...eq,
          currentStock: newStock,
          reorderStatus: newStock <= eq.minimumStockLevel ? 'Critical Reorder' : 'Sufficient',
        };
      }
      return eq;
    });

    // 2. Track in Project Assets
    const newAsset: ProjectAssetAssignment = {
      assetId: `AST-${issuance.issueId}`,
      itemId: issuance.equipmentCode,
      productName: issuance.equipmentName,
      brand: 'Enterprise ELV',
      model: `MOD-${issuance.equipmentCode}`,
      serialNumber: `SN-EQ-${issuance.equipmentCode}`,
      assignedProjectId: 'PRJ-2025-001',
      projectName: 'Lusail Tower CCTV & Access',
      clientName: 'Lusail Real Estate',
      installedLocation: `Site Location / Eng. ${issuance.issuedTo}`,
      installationDate: issuance.issueDate,
      warrantyExpiryDate: '2026-12-31',
      status: 'Installed Active',
      notes: `Issued by ${issuance.issuedBy} to ${issuance.issuedTo}`,
    };

    const existingIndex = projectAssets.findIndex((a) => a.assetId === newAsset.assetId);
    let updatedProjectAssets = [...projectAssets];
    if (existingIndex >= 0) {
      updatedProjectAssets[existingIndex] = newAsset;
    } else {
      updatedProjectAssets = [newAsset, ...updatedProjectAssets];
    }

    return {
      updatedEquipment,
      updatedProjectAssets,
    };
  }

  /**
   * Resolve Winning Quotation Cascade
   */
  static resolveQuotationAward(
    awardedQuoteId: string,
    quotations: QuotationResult[],
    boqs: BOQRecord[],
    purchaseOrders: PurchaseOrder[]
  ): {
    updatedQuotations: QuotationResult[];
    updatedBOQs: BOQRecord[];
    newPO: PurchaseOrder | null;
    updatedPOs: PurchaseOrder[];
  } {
    const quote = quotations.find((q) => q.quoteId === awardedQuoteId);
    if (!quote) {
      return {
        updatedQuotations: quotations,
        updatedBOQs: boqs,
        newPO: null,
        updatedPOs: purchaseOrders,
      };
    }

    // 1 & 2. Update Quotations
    const updatedQuotations = quotations.map((q) => {
      if (q.quoteId === awardedQuoteId) {
        return { ...q, status: 'Accepted' as const, selected: 'Yes' as const };
      }
      if (q.boqId === quote.boqId && q.quoteId !== awardedQuoteId) {
        return { ...q, status: 'Rejected' as const, selected: 'No' as const };
      }
      return q;
    });

    // 3. Update BOQ
    const updatedBOQs = boqs.map((b) => {
      if (b.boqId === quote.boqId) {
        return {
          ...b,
          remarks: `Winning Vendor: ${quote.supplier} (QAR ${quote.quotedValue.toLocaleString()})`,
        };
      }
      return b;
    });

    // 4. Generate PO
    const newPoId = `PO-2025-${String(purchaseOrders.length + 1).padStart(4, '0')}`;
    const newPO: PurchaseOrder = {
      poNumber: newPoId,
      prId: `PR-${quote.quoteId}`,
      boqId: quote.boqId || 'BOQ-001',
      projectName: quote.projectName,
      supplier: quote.supplier,
      issueDate: new Date().toISOString().split('T')[0],
      deliveryDueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      totalAmountQAR: quote.quotedValue,
      paymentTerms: quote.paymentTerms,
      deliveryLocation: `Project Site: ${quote.projectName}`,
      turnaroundHours: 24,
      authorizedBy: 'Procurement Director',
      budgetAllocated: 'Yes',
      materialSubmittalApproved: 'Yes',
      status: 'Issued to Vendor',
      lineItemsCount: 6,
      remarks: `Converted from awarded quotation ${quote.quoteId} (${quote.supplier})`,
    };

    const updatedPOs = [newPO, ...purchaseOrders];

    return {
      updatedQuotations,
      updatedBOQs,
      newPO,
      updatedPOs,
    };
  }

  /**
   * Resolve Lead-to-Project Conversion
   */
  static resolveLeadConversion(
    lead: LeadRecord,
    existingProjects: ProjectOverview[]
  ): ProjectOverview {
    const newProjectId = `PRJ-${lead.id.replace('LEAD-', '')}`;
    return {
      id: newProjectId,
      projectName: lead.companyName ? `${lead.companyName} Security Integration` : 'New Security Project',
      clientName: lead.companyName,
      sector: lead.sector || 'Commercial',
      category: 'CCTV & Integrated Security',
      boqValue: lead.leadValue || 150000,
      contractValue: lead.leadValue || 150000,
      startDate: new Date().toISOString().split('T')[0],
      plannedEndDate: new Date(Date.now() + 180 * 86400000).toISOString().split('T')[0],
      status: 'Planned',
      projectManager: 'Eng. Tariq Al-Mansoor',
      remarks: `Converted from won sales lead ${lead.id} (${lead.contactPerson})`,
    };
  }
}
