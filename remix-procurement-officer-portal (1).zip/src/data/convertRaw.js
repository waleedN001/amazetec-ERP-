import fs from 'fs';
import path from 'path';

function parseRawFile(content) {
  const lines = content.split('\n');
  const items = [];
  let currentCategory = 'General';

  for (let line of lines) {
    line = line.trim();
    if (!line) continue;

    if (
      line.startsWith('ACCESORIES') ||
      line.startsWith('ACS DEVICE') ||
      line.startsWith('ANPR CAMERA') ||
      line.startsWith('ANPR LICENSE') ||
      line.startsWith('ANPR SERVER') ||
      line.startsWith('ANPR SOFTWARE') ||
      line.startsWith('BATTERY') ||
      line.startsWith('CORE SWITCH') ||
      line.startsWith('EDGE SWITCH')
    ) {
      currentCategory = line;
      continue;
    }

    if (line.startsWith('Sr.No')) continue;

    const parts = line.split('\t');
    if (parts.length >= 4) {
      const srNo = parts[0].trim();
      const system = parts[1] ? parts[1].trim() : currentCategory;
      const productName = parts[2] ? parts[2].trim() : 'N/A';
      const modelName = parts[3] ? parts[3].trim() : 'N/A';
      const brand = parts[4] ? parts[4].trim() : (parts[3] || 'N/A');

      if (productName && productName !== 'N/A') {
        items.push({
          srNo,
          system,
          productName,
          modelName,
          brand
        });
      }
    }
  }

  return items;
}

const rawText1 = fs.readFileSync(path.join(process.cwd(), 'src/data/rawPart1.txt'), 'utf8');
const items1 = parseRawFile(rawText1);
console.log('Parsed items count:', items1.length);
