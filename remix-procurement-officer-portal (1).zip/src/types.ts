export type RoleTab =
  | 'dashboard'
  | 'sales'
  | 'procurement'
  | 'catalog'
  | 'projects'
  | 'moi'
  | 'amc'
  | 'inventory'
  | 'finance'
  | 'client-portal'
  | 'administrator'
  | 'hr'
  | 'ba'
  | 'pm'
  | 'journey';

export type ViewMode = 'bento' | 'spreadsheet';

// ---------------------- ADMINISTRATOR ----------------------
export interface AssetRecord {
  id: string;
  assetName: string;
  category: string;
  modelSerial: string;
  location: string;
  status: 'Active' | 'Issued' | 'Under Maintenance' | 'Retired' | 'In Stock';
  purchaseDate: string;
  purchasePrice: number;
  currentValue: number;
  assignedTo: string;
  warrantyExpiry: string;
  maintenanceSchedule: string;
  lastMaintenance: string;
  nextMaintenance: string;
  supplier: string;
  remarks: string;
}

export type OfficialQuotationCategory =
  | 'DOME AND BULLET CAMERAS - AUTO-IRIS'
  | 'PTZ CAMERAS'
  | 'STORAGE'
  | 'FAILOVER STORAGE'
  | 'VMS AND SERVER'
  | 'WORKSTATION AND MONITORS'
  | 'ANPR SYSTEM'
  | 'NETWORKSWITCHES'
  | 'PASSIVE COMPONENTS'
  | 'KPOI CAMERAS'
  | 'UPS AND BATTERY'
  | 'ACCESS CONTROL SYSTEM'
  | 'PROFESSIONAL SERVICES';

export interface SecurityProductCatalogItem {
  id: string;
  category: OfficialQuotationCategory | string;
  productType: string; // e.g. Dome Camera, Bullet Camera, PTZ, Face Recognition Terminal, Cat6 UTP Cable
  componentClass?: 'Active' | 'Passive'; // Active (Powered/Electronic: MOI or Non-MOI) vs Passive (Infrastructure/Cable/Containment)
  brand: string; // Hikvision, Dahua, ZKTeco, Comunello, BFT, Belden, Cisco, Aruba, Carecom, Schneider, etc.
  model: string; // DS-2CD2143G0-I, IPC-HFW2431S, SenseFace 2A, Border 400, etc.
  description: string;
  moiApproved: 'Yes' | 'No' | 'Pending';
  moiCertificateNo?: string;
  cityLocation: 'Doha' | 'Lusail' | 'Al Rayyan' | 'Al Wakrah' | 'Al Khor' | 'Ras Laffan' | 'All Qatar';
  unitPriceQAR: number;
  timeUnitPeriod: string; // e.g., 'Per Unit (12 Months Warranty)', '30 Days Quote Validity', 'Annual (12 M)'
  supplyDeliveryTime: string; // e.g. 'Ex-Stock Doha (1-2 Days)', '7-10 Days Import', '3 Weeks Air Freight'
  warrantyPeriod: string; // e.g., '1 Year', '2 Years', '3 Years MOI Standard'
  stockAvailability: 'In Stock (Doha Warehouse)' | '7 Days Import' | 'On Order' | 'Available for AMC';
  notes: string;
}

export interface EquipmentMasterItem {
  code: string;
  name: string;
  category: string;
  brand: string;
  model: string;
  totalQuantity: number;
  unitPrice: number;
  totalValue: number; // calculated: totalQuantity * unitPrice
  moiApproved: 'Yes' | 'No';
  minimumStockLevel: number;
  currentStock: number;
  reorderStatus: string; // auto-calc
}

export interface EquipmentIssuance {
  issueId: string;
  equipmentCode: string;
  equipmentName: string;
  quantityIssued: number;
  issueDate: string;
  issuedTo: string;
  issuedBy: string;
  expectedReturnDate: string;
  actualReturnDate?: string;
  status: 'Issued' | 'Returned' | 'Partially Returned' | 'Lost' | 'Damaged';
  conditionOnIssue: string;
  conditionOnReturn?: string;
  remarks: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  designation: string;
  department: string;
  date: string;
  checkIn: string;
  checkOut: string;
  totalHours: string;
  status: 'Present' | 'Absent' | 'Leave' | 'Half Day' | 'Holiday' | 'Sick Leave' | 'Work From Home';
  isLate: 'Yes' | 'No';
  lateMinutes: number;
  overtimeHours: number;
  leaveType?: string;
  remarks: string;
}

export interface KYCQuery {
  id: string;
  employeeId: string;
  employeeName: string;
  nationality: string;
  profession: string;
  queryType: string;
  dateRaised: string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Resolved' | 'Rejected' | 'On Hold';
  assignedTo: string;
  resolutionDate?: string;
  actionTaken: string;
  remarks: string;
}

// ---------------------- HUMAN RESOURCES (HR) ----------------------
export interface EmployeeRecord {
  id: string;
  name: string;
  designation: string;
  department: string;
  dateOfJoining: string;
  employmentType: 'Permanent' | 'Contract' | 'Temporary' | 'Intern' | 'Probation';
  nationality: string;
  gender: string;
  maritalStatus: string;
  dob: string;
  contactNumber: string;
  email: string;
  emergencyContact: string;
  emergencyPhone: string;
  passportNo: string;
  qidNo: string;
  visaStatus: string;
  status: 'Active' | 'Inactive' | 'On Leave' | 'Terminated' | 'Resigned';
}

export interface SalaryBracket {
  employeeId: string;
  employeeName: string;
  designation: string;
  department: string;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  otherAllowances: number;
  totalAllowances: number; // auto-calc: housing + transport + other
  grossSalary: number; // auto-calc: basic + totalAllowances
  socialSecurity: number;
  healthInsurance: number;
  lifeInsurance: number;
  totalBenefits: number; // auto-calc: socSec + health + life
  netSalary: number; // auto-calc: gross - totalBenefits
  annualPackage: number; // auto-calc: netSalary * 12
  salaryReviewDate: string;
  nextReviewDate: string;
  remarks: string;
}

export interface EmployeeBenefit {
  id: string;
  benefitName: string;
  description: string;
  applicableTo: string;
  coverageAmount: number;
  monthlyCost: number;
  annualCost: number;
  startDate: string;
  endDate: string;
  status: 'Active' | 'Inactive';
}

export interface EmployeeContract {
  contractId: string;
  employeeId: string;
  employeeName: string;
  contractType: 'Permanent' | 'Contract' | 'Temporary' | 'Fixed Term' | 'Probation';
  startDate: string;
  endDate: string;
  status: 'Active' | 'Expired' | 'Terminated' | 'Under Review' | 'Pending Renewal';
  probationPeriod: string;
  contractTerm: string;
  revisionNo: string;
  revisionDate?: string;
  revisionReason?: string;
  approvedBy: string;
  remarks: string;
}

// ---------------------- BUSINESS ANALYST (BA) ----------------------
export interface LeadRecord {
  id: string;
  sourceType: string;
  sourceName: string;
  dateReceived: string;
  companyName: string;
  industry: string;
  sector: string;
  contactPerson: string;
  phone: string;
  email: string;
  leadValue: number;
  qualified: 'Yes' | 'No';
  assignedTo: string;
  status: 'New' | 'In Progress' | 'Under Preparation' | 'Proposal Submitted' | 'Negotiation' | 'Won' | 'Lost' | 'On Hold';
  stage: 'Lead Generation' | 'Qualification' | 'Assessment' | 'Proposal' | 'Negotiation' | 'Closing' | 'Won' | 'Lost';
  probability: number; // %
  expectedCloseDate: string;
  winLossReason?: string;
  remarks: string;
}

export interface LeadConversionRate {
  month: string;
  totalLeads: number;
  qualifiedLeads: number;
  proposalsSent: number;
  proposalsWon: number;
  proposalsLost: number;
  conversionRate: number; // auto calc %
  revenueGenerated: number;
  targetConversionRate: number;
  remarks: string;
}

export interface VisitScheduling {
  visitId: string;
  projectLeadName: string;
  visitType: 'Site Survey (ELV)' | 'DSA Submission' | 'DIA Inspection' | 'Site Assessment' | 'Installation Check' | 'Final Handover';
  location: string;
  visitDate: string;
  visitTime: string;
  assignedTo: string;
  status: 'Pending' | 'Completed' | 'Rescheduled' | 'Cancelled' | 'In Progress';
  siteSurveyComplete: 'Yes' | 'No';
  dsaSubmissionDate?: string;
  dsaApprovalDate?: string;
  diaSubmissionDate?: string;
  diaInspectionDate?: string;
  diaApprovalDate?: string;
  remarks: string;
}

export interface BOQRecord {
  boqId: string;
  projectName: string;
  boqValue: number;
  boqDate: string;
  preparedBy: string;
  approvedBy: string;
  approvalDate?: string;
  status: 'Draft' | 'In Progress' | 'Under Review' | 'Approved' | 'Rejected' | 'On Hold';
  category: string;
  sector: string;
  clientName: string;
  totalItems?: number;
  materialCost?: number;
  labourCost?: number;
  overheadCost?: number;
  marginPercent?: number;
  remarks: string;
}

export interface ProcurementAssignment {
  id: string;
  boqId: string;
  projectName: string;
  assignedTo: string;
  dateAssigned: string;
  quoteDueDate: string;
  quoteReceivedDate?: string;
  supplierSelected?: string;
  quoteValue?: number;
  status: 'Pending' | 'In Progress' | 'Completed' | 'On Hold' | 'Cancelled';
  remarks: string;
}

export type ProcurementSubModule =
  | 'kpi'
  | 'scm_pipeline'
  | 'catalog'
  | 'pr_boq'
  | 'quote'
  | 'po_logistics'
  | 'supplier'
  | 'price'
  | 'followup';

// ---------------------- PROCUREMENT OFFICER ----------------------
export interface PurchaseRequisition {
  prId: string;
  boqId: string;
  projectName: string;
  siteLocation: string;
  requestedBy: string;
  dateRequested: string;
  requiredDate: string;
  priority: 'Urgent' | 'High' | 'Medium' | 'Low';
  itemDescription: string;
  quantity: number;
  unit: string;
  estimatedBudgetQAR: number;
  technicalVetting: 'Verified with Specs' | 'Pending Specs Check' | 'Non-Compliant (Hold)';
  consultantApprovalNeeded: 'Yes' | 'No';
  status: 'Pending Review' | 'Vetted & Approved' | 'RFQ Floated' | 'PO Issued' | 'Rejected';
  stage?: 'Requested' | 'Approved' | 'Ordered' | 'Delivered';
  remarks: string;
}

export interface MaterialSubmittal {
  submittalId: string;
  boqId: string;
  projectName: string;
  category: string;
  itemDescription: string;
  brand: string;
  model: string;
  supplier: string;
  datasheetRef: string;
  dateSubmitted: string;
  consultantName: string;
  approvalStatus: 'Approved (Code A)' | 'Approved with Comments (Code B)' | 'Revise & Resubmit (Code C)' | 'Rejected (Code D)' | 'Under Review';
  approvalDate?: string;
  moiCertificateAttached: 'Yes' | 'No' | 'N/A';
  complianceNotes: string;
}

export interface POLineItem {
  itemCode: string;
  description: string;
  brand: string;
  model: string;
  qty: number;
  unit: string;
  unitRateQAR: number;
  totalQAR: number;
}

export interface PurchaseOrder {
  poNumber: string;
  prId: string;
  boqId: string;
  projectName: string;
  supplier: string;
  issueDate: string;
  deliveryDueDate: string;
  totalAmountQAR: number;
  paymentTerms: string;
  deliveryLocation: string;
  turnaroundHours: number; // JD Metric: < 48 hours
  authorizedBy: string;
  budgetAllocated: 'Yes' | 'No';
  materialSubmittalApproved: 'Yes' | 'No';
  status: 'Draft' | 'Approved' | 'Issued to Vendor' | 'Partially Delivered' | 'Delivered' | 'Closed' | 'Cancelled';
  lineItemsCount: number;
  remarks: string;
}

export interface LogisticsShipment {
  shipmentId: string;
  poNumber: string;
  supplier: string;
  originCountry: string;
  shippingMode: 'Ex-Stock Doha' | 'Air Freight' | 'Sea Cargo' | 'Road Transport';
  carrierForwarder: string;
  awbOrBolNo: string;
  dispatchDate: string;
  etaPortOrWarehouse: string;
  customsStatus: 'Customs Cleared' | 'Port Clearance in Progress' | 'Inspection Scheduled' | 'Pending Duty Payment' | 'Direct Delivery (Local)';
  siteDeliveryStatus: 'Delivered to Site' | 'Delivered to Central Warehouse' | 'In Transit' | 'Delayed';
  actualDeliveryDate?: string;
  onTimeStatus: 'On-Time (Schedule Met)' | 'Delayed' | 'Ahead of Schedule';
  qaQcInspectionStatus: 'Passed 100% (Defect Free)' | 'Minor Defects (Rectified)' | 'Rejected / Return' | 'Pending Inspection';
  remarks: string;
}

export interface InvoiceReconciliationRecord {
  reconciliationId: string;
  invoiceNumber: string;
  invoiceDate: string;
  poNumber: string;
  supplier: string;
  deliveryAdviceNo: string;
  grnNo: string;
  poAmountQAR: number;
  grnReceivedAmountQAR: number;
  invoiceAmountQAR: number;
  varianceAmountQAR: number; // auto-calc: invoiceAmount - poAmount
  matchStatus: '3-Way Matched (100% OK)' | 'Price Discrepancy' | 'Quantity Mismatch' | 'Pending GRN' | 'Pending Approval';
  qaQcPassed: 'Yes' | 'No';
  financeReleaseStatus: 'Approved for Payment' | 'Payment On Hold' | 'Paid' | 'Under Audit';
  reviewedBy: string;
  auditRemarks: string;
}

export interface QuotationResult {
  quoteId: string;
  boqId: string;
  projectName: string;
  supplier: string;
  quotedValue: number;
  receivedDate: string;
  validity: string;
  paymentTerms: string;
  deliveryTime: string;
  warranty: string;
  status: 'Received' | 'Under Review' | 'Accepted' | 'Rejected' | 'Expired' | 'On Hold';
  selected: 'Yes' | 'No' | 'Pending';
  remarks: string;
}

export interface SupplierRecord {
  code: string;
  name: string;
  country: string;
  city: string;
  contactPerson: string;
  phone: string;
  email: string;
  website: string;
  moiApproved: 'Yes' | 'No' | 'Pending';
  products: string;
  creditTerms: string;
  paymentTerms: string;
  deliveryLeadTime: string;
  rating: number; // 1-5
  status: 'Active' | 'Inactive' | 'Onboarding' | 'Suspended' | 'Pending Approval';
  onboardingDate: string;
  lastOrderDate?: string;
  remarks: string;
}

export interface ProcurementFollowUp {
  id: string;
  supplier: string;
  subject: string;
  dateCreated: string;
  currentStatus: 'In Progress' | 'Completed' | 'Pending' | 'On Hold';
  nextFollowUpDate: string;
  assignedTo: string;
  priority: 'High' | 'Medium' | 'Low';
  resolution: string;
  remarks: string;
}

export interface ProcurementRevision {
  revisionId: string;
  boqId: string;
  projectName: string;
  revisionDate: string;
  revisionNo: string; // R1, R2, ...
  revisionType: string;
  oldValue: number;
  newValue: number;
  changeReason: string;
  approvedBy: string;
  status: 'Approved' | 'Pending' | 'Rejected';
}

// ---------------------- PROJECT MANAGER (PM) ----------------------
export interface ProjectOverview {
  id: string;
  projectName: string;
  clientName: string;
  sector: string;
  category: string;
  boqValue: number;
  contractValue: number;
  startDate: string;
  plannedEndDate: string;
  actualEndDate?: string;
  status: 'Planned' | 'Ongoing' | 'Completed' | 'On Hold' | 'Cancelled' | 'Tender' | 'Under Review';
  projectManager: string;
  remarks: string;
}

export interface ProjectPaymentMilestone {
  id: string;
  projectId: string;
  projectName: string;
  mobilization: number; // 10%
  materialSupply: number; // 50%
  installation: number; // 25%
  commissioning: number; // 10%
  retention: number; // 5%
  finalDue: number;
  total: number;
}

export interface AdvanceCheck {
  id: string;
  projectId: string;
  advanceAmount: number;
  receivedDate: string;
  chequeNumber: string;
  bank: string;
  clearanceStatus: 'Cleared' | 'Pending' | 'Bounced' | 'On Hold' | 'Under Verification';
  dateCleared?: string;
  remarks: string;
}

export interface TeamSelection {
  id: string;
  projectId: string;
  projectName: string;
  pm: string;
  siteEngineer: string;
  elvSupervisor: string;
  elvTechniciansCount: number;
  helpersCount: number;
  totalTeam: number;
  startDate: string;
  endDate: string;
  status: 'Active' | 'Planned' | 'Completed';
}

export interface ExecutionPhase {
  id: string;
  projectId: string;
  projectName: string;
  phase1: string; // 1st Fix
  phase2: string; // 2nd Fix
  phase3: string; // Equipment
  phase4: string; // Testing
  phase5: string; // DIA
  phase6: string; // Handover
  overallProgress: number; // %
}

export interface WeeklyExecutionReport {
  reportId: string;
  projectId: string;
  weekEnding: string;
  progressPercent: number;
  keyAchievements: string;
  issuesChallenges: string;
  mitigation: string;
  nextWeekPlan: string;
  preparedBy: string;
  approvedBy: string;
}

export interface QualityCheckInspection {
  id: string;
  projectId: string;
  qcCheckDate: string;
  qcTeam: string;
  cameraResolution: string;
  storageRetention: string;
  raidConfig: string;
  moiCompliance: string;
  overallRatingPercent: number;
  findings: string;
  actionTaken: string;
  status: 'Pending' | 'In Progress' | 'Passed' | 'Failed' | 'On Hold';
}

export interface ClientCommunication {
  id: string;
  projectId: string;
  clientName: string;
  dateSent: string;
  updateType: 'Kick-off' | 'Progress Report' | 'Weekly Update' | 'Monthly Summary' | 'Issue Alert' | 'Completion Notice' | 'Invoice';
  status: 'Sent' | 'Pending' | 'Acknowledged';
  attachments: string;
  responseReceived: 'Yes' | 'No';
  responseDate?: string;
  remarks: string;
}

export interface ProjectCompletionApproval {
  id: string;
  projectId: string;
  projectName: string;
  completionDate: string;
  diaSubmissionDate: string;
  inspectionDate: string;
  inspectionStatus: 'Passed' | 'Failed' | 'Pending';
  moiCertificateStatus: 'Issued' | 'Pending' | 'In Progress';
  certificateDate?: string;
  dsaApprovalStatus: 'Approved' | 'Pending' | 'In Progress';
  diaApprovalStatus: 'Approved' | 'Pending' | 'In Progress';
  overallStatus: 'Completed' | 'Ongoing' | 'Planned';
  remarks: string;
}

// ---------------------- DROPDOWNS MASTER ----------------------
export interface DropdownMaster {
  categoryName: string;
  options: string[];
}

// ---------------------- JOURNEY & PROCESS WORKFLOW ----------------------
export type LeadChannelType = 'LinkedIn (B2B)' | 'Referrals' | 'Upwork / Fiverr' | 'Direct Inbound';

export type DispatchedRoleType = 'ELV Engineer' | 'Technician (ET)' | 'Technical Team (TT)';

export type StaffCategory = 'Permanent Staff (PS - ELV Certified)' | 'Contract Staff (Project-based)' | 'Daily Wage Laborer';

export type ProjectExecutionStep = 'Initial Setup' | 'Piping & Conduit' | 'Installation' | 'Testing & Commissioning';

export interface WorkflowJourneyState {
  id: string;
  leadId: string;
  projectId?: string;
  clientName: string;
  channel: LeadChannelType;
  // Step 1: Lead Acquisition
  leadStatus: 'Acquired' | 'Qualified' | 'In Progress';
  leadNotes: string;
  // Step 2: Site Visit & Cert Check
  siteVisitStatus: 'Pending' | 'Scheduled' | 'Completed';
  dispatchedRoles: DispatchedRoleType[];
  certificationsChecked: ('MEA' | 'MOI' | 'Civil Defence')[];
  siteRequirementsSummary: string;
  // Step 3: BOQ & Business Proposal
  boqCreated: boolean;
  boqTotalValue: number;
  supplierQuotesGathered: boolean;
  bpStatus: 'Draft' | 'Sent via Email' | 'Sent via WhatsApp' | 'Revision Requested' | 'Approved';
  bpRevisionNotes?: string;
  // Step 4: PO & 50% Advance
  poIssuedToSuppliers: boolean;
  clientAdvance50Received: boolean;
  supplierAdvance50Paid: boolean;
  // Step 5: Project Plan, Material & Execution
  projectPlanCreated: boolean;
  materialInspectedOnSite: boolean;
  currentExecutionStep: ProjectExecutionStep;
  staffAllocated: {
    permanentStaffCount: number;
    contractStaffCount: number;
    dailyWageCount: number;
  };
  // Step 6: Post-Project & AMC
  amcActive: boolean;
  amcDurationMonths: number;
  amcStartDate?: string;
  amcEndDate?: string;
  amcMaintenanceLogs: {
    date: string;
    type: 'Fix' | 'System Update' | 'Repainting' | 'Inspection';
    notes: string;
    performedBy: string;
  }[];
}

// ---------------------- MODULE 1: SALES & TENDERS ----------------------
export interface TenderRecord {
  tenderId: string;
  tenderName: string;
  clientName: string;
  source: 'Monaqasat (Qatar Tender Portal)' | 'Direct Client RFP' | 'Ashghal / Kahramaa' | 'Partner Subcontract' | 'Referral';
  sector: 'Government' | 'Enterprise' | 'Commercial' | 'Hospitality' | 'Residential' | 'Healthcare';
  submissionDeadline: string;
  estimatedValueQAR: number;
  status: 'Identified' | 'In Progress' | 'Technical Vetting' | 'Submitted' | 'Won' | 'Lost' | 'Cancelled';
  assignedSales: string;
  documents: string[];
  notes: string;
}

export interface ProposalContract {
  proposalId: string;
  clientName: string;
  projectName: string;
  relatedQuotationId: string;
  proposalDate: string;
  contractValueQAR: number;
  paymentTerms: string;
  status: 'Draft' | 'Sent' | 'Negotiating' | 'Signed' | 'Rejected';
  contractDocUrl?: string;
  projectManager: string;
  validUntil: string;
  scopeSummary: string;
}

export interface ActivityLog {
  activityId: string;
  relatedTo: string; // Lead, Tender, Project, or Client
  activityType: 'Call' | 'Meeting' | 'Email' | 'Site Visit' | 'Consultant Technical Review' | 'MOI Pre-check';
  date: string;
  description: string;
  followUpRequired: boolean;
  followUpDate?: string;
  assignedTo: string;
  outcome?: string;
}

// ---------------------- MODULE 3: PROJECT MANAGEMENT & GANTT ----------------------
export type ProjectInstallationPhase =
  | '1st Fix (Conduits, PVC/GI & Backboxes)'
  | '2nd Fix (Cable Pulling & Fluke Test)'
  | 'Equipment Installation (Cameras, NVR, Server)'
  | 'System Integration & VMS Config'
  | 'Commissioning & Handover';

export interface PhasedProjectTask {
  taskId: string;
  projectId: string;
  projectName: string;
  taskName: string;
  phase: ProjectInstallationPhase;
  assignedTo: string;
  startDate: string;
  dueDate: string;
  status: 'Not Started' | 'In Progress' | 'Completed' | 'Blocked';
  priority: 'High' | 'Medium' | 'Low';
  progressPercent: number;
  dependencies?: string[];
  notes: string;
}

// ---------------------- MODULE 4: MOI SSD COMPLIANCE ----------------------
export interface MOIDSARecord {
  dsaId: string;
  projectId: string;
  projectName: string;
  clientName: string;
  submissionDate: string;
  moiReference: string;
  status: 'Draft' | 'Submitted' | 'Under Review' | 'Revision Required' | 'Approved' | 'Rejected';
  revisionDueDate?: string;
  approvalDate?: string;
  validUntil?: string;
  drawingsAttached: boolean;
  equipmentScheduleVerified: boolean;
  cameraCount: number;
  remarks: string;
}

export interface MOIDIARecord {
  diaId: string;
  projectId: string;
  projectName: string;
  clientName: string;
  dsaApprovalRef: string;
  inspectionRequestDate: string;
  moiReference: string;
  scheduledInspectionDate: string;
  status: 'Pending Submission' | 'Scheduled' | 'Under Inspection' | 'Approved' | 'Punch List Rectification' | 'Rejected';
  inspectorName?: string;
  inspectionNotes?: string;
  approvalDate?: string;
  certificateNumber?: string;
  certificateExpiryDate?: string;
  remarks: string;
}

export interface MOIComplianceChecklistItem {
  id: string;
  requirement: string;
  specification: string;
  complianceRule: string;
  verified: boolean;
  status: 'Compliant' | 'Non-Compliant' | 'Pending Review';
  notes: string;
}

// ---------------------- MODULE 5: AMC & SERVICE MANAGEMENT ----------------------
export interface AMCMasterRecord {
  amcId: string;
  clientName: string;
  projectName: string;
  contractType: 'Basic (Preventive Only)' | 'Standard (Bi-Monthly + SLA)' | 'Premium (24/7 Rapid Response)' | 'Enterprise Comprehensive';
  startDate: string;
  endDate: string;
  annualValueQAR: number;
  slaResponseTimeHours: number; // e.g. 2, 4, 8
  slaResolutionTimeHours: number; // e.g. 12, 24, 48
  status: 'Active' | 'Pending Renewal' | 'Expired' | 'Terminated';
  renewalReminderDate: string;
  billingFrequency: 'Quarterly' | 'Bi-Annual' | 'Annual Upfront';
  moiApprovedContractor: boolean;
  contactPerson: string;
  contactPhone: string;
  daysToExpiry: number;
  renewalAlertStage: '45 Days Notice' | '30 Days Urgent' | '15 Days Final' | 'Expired' | 'Healthy';
}

export interface ServiceTicketRecord {
  ticketId: string;
  clientName: string;
  amcRefId?: string;
  projectId?: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  category: 'CCTV Camera Offline' | 'NVR/Storage Fault' | 'Access Control Door Malfunction' | 'VMS License/Software' | 'Network Switch Issue' | 'UPS / Power Failure' | 'Other';
  description: string;
  status: 'New' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed';
  assignedTechnician: string;
  createdDate: string;
  targetResolutionDate: string;
  actualResolutionDate?: string;
  slaMet: 'Yes' | 'No' | 'In Progress';
  partsUsed?: string;
  siteLocation: string;
  workNotes: string;
}

export interface TechnicianSchedule {
  scheduleId: string;
  ticketId?: string;
  projectId?: string;
  technicianName: string;
  scheduledDate: string;
  scheduledTime: string;
  durationHours: number;
  status: 'Scheduled' | 'En Route' | 'In Progress' | 'Completed' | 'Cancelled';
  preVisitNotes: string;
  completionReport?: string;
  customerSignatureObtained?: boolean;
}

// ---------------------- MODULE 6: INVENTORY & ASSETS ----------------------
export interface InventoryItemRecord {
  itemId: string;
  catalogRefId?: string;
  brand: string;
  model: string;
  category: string;
  description: string;
  serialNumber?: string;
  warehouseLocation: string;
  quantityOnHand: number;
  minimumStockLevel: number;
  reorderQuantity: number;
  reorderStatus: 'Sufficient' | 'Low Stock' | 'Critical Reorder';
  status: 'In Stock' | 'Reserved for Project' | 'Issued / On Site' | 'RMA Under Repair';
  unitCostQAR: number;
  totalValueQAR: number;
  preferredSupplier: string;
  moiApproved: 'Yes' | 'No';
}

export interface ProjectAssetAssignment {
  assetId: string;
  itemId: string;
  productName: string;
  brand: string;
  model: string;
  serialNumber: string;
  assignedProjectId: string;
  projectName: string;
  clientName: string;
  installedLocation: string;
  installationDate: string;
  warrantyExpiryDate: string;
  status: 'Installed Active' | 'Needs Replacement' | 'Decommissioned';
  notes: string;
}

// ---------------------- MODULE 7: FINANCIAL MANAGEMENT ----------------------
export interface ProjectBudgetRecord {
  budgetId: string;
  projectId: string;
  projectName: string;
  clientName: string;
  hardwareBudgetQAR: number;
  hardwareActualQAR: number;
  labourBudgetQAR: number;
  labourActualQAR: number;
  logisticsBudgetQAR: number;
  logisticsActualQAR: number;
  overheadBudgetQAR: number;
  overheadActualQAR: number;
  totalBudgetQAR: number;
  totalActualQAR: number;
  varianceQAR: number; // actual - budget (negative is saving)
  profitMarginPercent: number;
}

export interface ClientInvoiceRecord {
  invoiceId: string;
  invoiceNumber: string;
  projectId: string;
  projectName: string;
  clientName: string;
  invoiceDate: string;
  dueDate: string;
  amountQAR: number;
  paidAmountQAR: number;
  status: 'Draft' | 'Sent' | 'Paid' | 'Overdue' | 'Partially Paid';
  paymentDate?: string;
  paymentMethod?: string;
  taxInvoiceUrl?: string;
  notes: string;
}

export interface ProjectExpenseRecord {
  expenseId: string;
  projectId: string;
  projectName: string;
  date: string;
  category: 'Procurement / Freight' | 'Site Transport / Logistics' | 'Labour Overtime' | 'Tools & Consumables' | 'MOI Submission & Gov Fees' | 'Client Hospitality & Meeting';
  description: string;
  amountQAR: number;
  paidBy: string;
  status: 'Pending Approval' | 'Approved' | 'Reimbursed' | 'Rejected';
  approvedBy?: string;
}

// ---------------------- MODULE 8: CLIENT PORTAL & REPORTS ----------------------
export interface ClientPortalAccount {
  clientId: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  activeProjects: string[];
  activeAMCs: string[];
  portalAccess: boolean;
  lastLogin?: string;
}

export interface AutomatedReportRecord {
  reportId: string;
  reportType: 'Weekly Project Status' | 'Monthly MOI Compliance' | 'Quarterly System Health' | 'AMC Coverage & Renewal' | 'Annual Security ROI';
  projectName: string;
  clientName: string;
  period: string;
  generatedDate: string;
  status: 'Ready' | 'Generating' | 'Sent to Client';
  summaryMetrics: string;
}

// ---------------------- AUTOMATED SCM & QUOTATION PIPELINE ----------------------

export interface PriceHistoryVersion {
  version: string;
  effectiveDate: string;
  supplier: string;
  costQAR: number;
  reason: string;
  sourceRFQ?: string;
}

export interface PriceHistoryRecord {
  id?: string;
  productCode: string;
  itemCode?: string; // Unified alias to productCode
  productName: string;
  description?: string; // Unified alias to productName
  category?: 'Cables & Containment' | 'Controllers & Access' | 'Cameras & VMS' | 'Panels & Racks' | 'Accessories & Hardware' | 'Labor & Engineering' | string;
  uom?: 'Meter' | 'Pcs' | 'Set' | 'Lot' | 'Hour' | 'Day' | 'Roll' | string;
  brand?: string;
  model?: string;
  componentClass?: 'Active' | 'Passive';
  cityLocation?: 'Doha' | 'Lusail' | 'Al Rayyan' | 'Al Wakrah' | 'Al Khor' | 'Ras Laffan' | 'All Qatar' | 'All';
  supplier: string;
  preferredSupplier?: string; // Unified alias to supplier
  alternativeSuppliers?: string[];
  oldPrice: number;
  newPrice: number;
  standardCostWarehouseQAR?: number; // Unified alias to oldPrice / baseline
  lastSupplierPriceQAR?: number; // Unified alias to newPrice
  priceChange: number; // auto-calc: new - old
  percentChange: number; // auto-calc: ((new - old)/old)*100
  changeType: 'Decrease' | 'Increase' | 'Unchanged';
  effectiveDate: string;
  validDuration?: string;
  lastUpdatedDate?: string;
  minOrderQty?: number;
  reason: string;
  moiApproved: 'Yes' | 'No' | 'Pending';
  projectName?: string;
  quotationName?: string;
  revisionNumber?: string;
  leadTime?: string;
  notes: string;
  versionHistory?: PriceHistoryVersion[];
}

// Backward compatibility alias: MasterPriceItem points to PriceHistoryRecord
export type MasterPriceItem = PriceHistoryRecord;

export interface DrawingTakeoffItem {
  id: string;
  itemCode: string;
  description: string;
  category: string;
  uom: string;
  drawingRef: string;
  detectionMethod: 'Auto-AI Detection' | 'Takeoff Overlay Tool' | 'Manual Count';
  detectedCountOrLength: number;
  siteAnomalyAdjustment: number; // e.g. +10% for high ceiling / riser bends
  calculatedQuantity: number; // auto-calc: detectedCountOrLength + siteAnomalyAdjustment
  locationNotes: string;
  status: 'Detected' | 'Verified' | 'Modified';
}

export interface DrawingTakeoffSession {
  sessionId: string;
  drawingName: string;
  drawingType: 'PDF' | 'DWG' | 'CAD';
  projectRef: string;
  clientRef: string;
  scale: string;
  uploadDate: string;
  totalDevicesCount: number;
  totalCableMeters: number;
  takeoffItems: DrawingTakeoffItem[];
  status: 'Processing' | 'Takeoff Complete' | 'Exported to BOQ';
}

export interface StructuredBOQItem {
  id: string;
  itemCode: string;
  description: string;
  category: string;
  uom: string;
  takeoffQuantity: number;
  manualAdjustment: number;
  finalQuantity: number;
  unitCostBaseQAR: number;
  totalCostBaseQAR: number;
}

export interface RulesEngineAConfig {
  materialMarkupPercent: number; // e.g., 15%
  directLaborRateMode: 'PercentageOfMaterial' | 'FixedHourly';
  directLaborPercent: number; // e.g., 12%
  directLaborHourlyRateQAR: number; // e.g., 45 QAR/hr
  estimatedLaborHours: number;
  overheadsPercent: number; // e.g., 8%
  wastageScrapPercent: number; // e.g., 5%
  logisticsTransportMode: 'Percentage' | 'FixedFee';
  logisticsTransportPercent: number; // e.g., 4%
  logisticsFixedFeeQAR: number;
  insuranceAndBondsPercent: number; // e.g., 2%
  standardProfitMarginP1: number; // e.g., 18%
}

export interface DraftQuotationItem {
  itemCode: string;
  description: string;
  category: string;
  uom: string;
  quantity: number;
  baseUnitCostQAR: number;
  baseMaterialTotalQAR: number;
  materialWithWastageQAR: number;
  materialWithMarkupQAR: number;
  directLaborAllocatedQAR: number;
  overheadsAllocatedQAR: number;
  logisticsAllocatedQAR: number;
  insuranceAllocatedQAR: number;
  profitMarginP1AllocatedQAR: number;
  draftUnitSellingPriceQAR: number;
  draftTotalSellingPriceQAR: number;
}

export interface DraftQuotationSummary {
  quoteId: string;
  boqId: string;
  projectName: string;
  generatedDate: string;
  rawMaterialCostQAR: number;
  wastageCostQAR: number;
  effectiveMaterialCostQAR: number;
  materialMarkupValueQAR: number;
  directLaborCostQAR: number;
  overheadsCostQAR: number;
  transportLogisticsCostQAR: number;
  insuranceBondsCostQAR: number;
  standardProfitP1QAR: number;
  totalDraftQuotationQAR: number;
  grossMarginPercent: number;
  items: DraftQuotationItem[];
}

export interface RFQItem {
  itemCode: string;
  description: string;
  uom: string;
  quantity: number;
  standardCostWarehouseQAR: number;
}

export interface SupplierRFQBid {
  bidId: string;
  rfqId: string;
  itemCode: string;
  supplierName: string;
  quotedUnitPriceQAR: number;
  deliveryLeadTime: string;
  paymentTerms: string;
  validityDays: number;
  warrantyPeriod: string;
  complianceStatus: 'Fully Compliant' | 'Approved Equivalent' | 'Deviations';
  varianceVsStandardCostQAR: number;
  varianceVsStandardCostPercent: number;
  isWinningBid?: boolean;
}

export interface RFQBundle {
  rfqId: string;
  rfqNumber: string;
  boqId: string;
  title: string;
  targetSuppliers: string[];
  items: RFQItem[];
  issueDate: string;
  dueDate: string;
  status: 'Draft' | 'Floated' | 'Bids Received' | 'Master Table Synced';
  bids: SupplierRFQBid[];
}

export interface TieredVolumeDiscount {
  minVolumeQAR: number;
  discountPercent: number;
}

export interface RulesEngineBConfig {
  supplierSelectionLogic: 'LowestCost' | 'MostReliable' | 'Balanced' | 'PreferredSupplier';
  bulkDiscountsEnabled: boolean;
  bulkDiscountTiers: TieredVolumeDiscount[];
  competitiveAdjustmentPercent: number; // e.g., -3.5% reduction to win bid
  urgencyPremiumPercent: number; // e.g., +5.0% for fast track
  exchangeRateBufferPercent: number; // e.g., +2.0% for FX volatility
  paymentTermsMode: 'CashInAdvance' | 'Standard30PDC' | 'ExtendedCredit60PDC' | 'LC90Days';
  paymentTermModifierPercent: number; // -2.5% for cash, +3.0% for 90-day LC
  finalRoundingRule: 'Exact' | 'Nearest5' | 'Nearest10' | 'Nearest50' | 'Nearest100';
  approvalThresholdLimitQAR: number; // e.g. 200,000 QAR requires executive signoff
}

export interface FinalQuotationItem {
  itemCode: string;
  description: string;
  category: string;
  uom: string;
  quantity: number;
  draftUnitRateQAR: number;
  selectedSupplier: string;
  supplierUnitPriceQAR: number;
  supplierDiscountedUnitRateQAR: number;
  revisedUnitSellingPriceQAR: number;
  revisedTotalSellingPriceQAR: number;
  costSavingsPerUnitQAR: number;
}

export interface FinalCommercialQuotation {
  finalQuoteId: string;
  boqId: string;
  projectName: string;
  clientName: string;
  creationDate: string;
  validUntil: string;
  draftQuoteTotalQAR: number;
  marketSourcedBaseCostQAR: number;
  supplierNegotiatedSavingsQAR: number;
  bulkDiscountSavingsQAR: number;
  competitiveDiscountQAR: number;
  urgencySurchargeQAR: number;
  fxBufferAmountQAR: number;
  paymentTermAdjustmentQAR: number;
  preRoundedTotalQAR: number;
  finalQuotationTotalQAR: number;
  netProfitQAR: number;
  netProfitMarginPercent: number;
  requiresExecutiveApproval: boolean;
  approvalStatus: 'Auto-Approved' | 'Requires Director Signoff' | 'Approved by CEO' | 'Pending Review';
  items: FinalQuotationItem[];
}

export interface QuotationComparativeAnalysis {
  draftQuote: DraftQuotationSummary;
  finalQuote: FinalCommercialQuotation;
  totalCostDifferenceQAR: number;
  totalSellingPriceDifferenceQAR: number;
  costReductionPercent: number;
  clientPriceAdvantagePercent: number;
  profitDifferenceQAR: number;
  competitivenessRating: 'Aggressive / Highly Competitive' | 'Optimal Market Price' | 'Premium / Low Risk';
}

// Convenient Aliases
export type ProposalRecord = ProposalContract;
export type PhasedTask = PhasedProjectTask;
export type MOIChecklistItem = MOIComplianceChecklistItem;
export type AMCContract = AMCMasterRecord;
export type ServiceTicket = ServiceTicketRecord;
export type InventoryItem = InventoryItemRecord;
export type ProjectAsset = ProjectAssetAssignment;
export type ProjectBudget = ProjectBudgetRecord;
export type ClientInvoice = ClientInvoiceRecord;
export type ProjectExpense = ProjectExpenseRecord;
export type AutomatedReport = AutomatedReportRecord;


