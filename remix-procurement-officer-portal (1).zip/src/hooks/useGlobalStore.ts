import { useAppData } from '../context/useAppData';
import { GlobalReferenceService } from '../services/GlobalReferenceService';
import {
  PurchaseOrder,
  PurchaseRequisition,
  QuotationResult,
  LogisticsShipment,
  InvoiceReconciliationRecord,
  BOQRecord,
  LeadRecord,
  EquipmentIssuance,
  InventoryItem,
  ProjectOverview,
} from '../types';

/**
 * useGlobalStore
 * Primary central custom hook giving business components direct access
 * to normalized reactive state, domain selectors, and relational dispatchers.
 */
export function useGlobalStore() {
  const context = useAppData();
  return context;
}

/**
 * useProcurementModule
 * Dedicated hook for procurement & supply chain actions with automatic cross-module cascades.
 */
export function useProcurementModule() {
  const {
    boqs,
    quotations,
    purchaseRequisitions,
    materialSubmittals,
    purchaseOrders,
    logisticsShipments,
    invoiceReconciliations,
    suppliers,
    priceHistory,
    procurementFollowUps,
    procurementRevisions,
    securityProductCatalog,
    inventoryItems,
    projectBudgets,
    handleUpdateState,
    setActiveTab,
    setProcurementSubModule,
    convertPRToPO,
    convertQuoteToPO,
    createReconciliationForPO,
    createSubmittalFromProduct,
  } = useAppData();

  // Award a vendor quote and cascade changes across BOQ, other quotes, and POs
  const awardQuotationAndGeneratePO = (quoteId: string) => {
    const cascade = GlobalReferenceService.resolveQuotationAward(
      quoteId,
      quotations,
      boqs,
      purchaseOrders
    );

    if (cascade.newPO) {
      handleUpdateState('quotations', cascade.updatedQuotations);
      handleUpdateState('boqs', cascade.updatedBOQs);
      handleUpdateState('purchaseOrders', cascade.updatedPOs);

      // Also resolve inventory
      const updatedInv = GlobalReferenceService.resolveInventoryFromPO(
        cascade.newPO,
        inventoryItems
      );
      handleUpdateState('inventoryItems', updatedInv);

      // Also update budget
      const updatedBudgets = GlobalReferenceService.resolveProjectBudget(
        cascade.newPO.projectName,
        projectBudgets,
        cascade.updatedPOs,
        invoiceReconciliations
      );
      handleUpdateState('projectBudgets', updatedBudgets);

      return cascade.newPO;
    }
    return null;
  };

  // Deliver shipment and cascade across Customs, PO status, 3-way match, and inventory
  const markShipmentDelivered = (shipment: LogisticsShipment) => {
    const cascade = GlobalReferenceService.resolveShipmentDelivery(
      { ...shipment, siteDeliveryStatus: 'Delivered to Site' },
      purchaseOrders,
      invoiceReconciliations,
      inventoryItems
    );

    const updatedShipments = logisticsShipments.map((s) =>
      s.shipmentId === shipment.shipmentId ? { ...s, siteDeliveryStatus: 'Delivered to Site' as const } : s
    );

    handleUpdateState('logisticsShipments', updatedShipments);
    handleUpdateState('purchaseOrders', cascade.updatedPOs);
    handleUpdateState('invoiceReconciliations', cascade.updatedReconciliations);
    handleUpdateState('inventoryItems', cascade.updatedInventory);
  };

  return {
    boqs,
    quotations,
    purchaseRequisitions,
    materialSubmittals,
    purchaseOrders,
    logisticsShipments,
    invoiceReconciliations,
    suppliers,
    priceHistory,
    procurementFollowUps,
    procurementRevisions,
    securityProductCatalog,
    awardQuotationAndGeneratePO,
    markShipmentDelivered,
    convertPRToPO,
    convertQuoteToPO,
    createReconciliationForPO,
    createSubmittalFromProduct,
    setActiveTab,
    setProcurementSubModule,
  };
}

/**
 * useProjectModule
 * Dedicated hook for PM actions, milestones, task phases, and live financials.
 */
export function useProjectModule() {
  const {
    projects,
    phasedTasks,
    projectPaymentMilestones,
    advanceChecks,
    teamSelection,
    executionPhases,
    weeklyReports,
    qualityChecks,
    clientCommunications,
    projectCompletions,
    projectBudgets,
    projectExpenses,
    clientInvoices,
    handleUpdateState,
  } = useAppData();

  const updateProjectProgress = (projectId: string, status?: ProjectOverview['status']) => {
    const updatedProjects = projects.map((p) => {
      if (p.id === projectId) {
        return {
          ...p,
          status: status || p.status,
        };
      }
      return p;
    });
    handleUpdateState('projects', updatedProjects);
  };

  return {
    projects,
    phasedTasks,
    projectPaymentMilestones,
    advanceChecks,
    teamSelection,
    executionPhases,
    weeklyReports,
    qualityChecks,
    clientCommunications,
    projectCompletions,
    projectBudgets,
    projectExpenses,
    clientInvoices,
    updateProjectProgress,
  };
}

/**
 * useInventoryModule
 * Dedicated hook for stock levels, tool issuances, and project asset assignments.
 */
export function useInventoryModule() {
  const {
    inventoryItems,
    projectAssets,
    equipmentMaster,
    equipmentIssuance,
    handleUpdateState,
  } = useAppData();

  const issueEquipmentToSite = (issuance: EquipmentIssuance) => {
    const cascade = GlobalReferenceService.resolveEquipmentIssuance(
      issuance,
      equipmentMaster,
      projectAssets
    );

    handleUpdateState('equipmentIssuance', [issuance, ...equipmentIssuance]);
    handleUpdateState('equipmentMaster', cascade.updatedEquipment);
    handleUpdateState('projectAssets', cascade.updatedProjectAssets);
  };

  return {
    inventoryItems,
    projectAssets,
    equipmentMaster,
    equipmentIssuance,
    issueEquipmentToSite,
  };
}

/**
 * useSalesModule
 * Dedicated hook for CRM pipelines, lead-to-project conversions, and tenders.
 */
export function useSalesModule() {
  const {
    leads,
    conversions,
    tenders,
    proposals,
    activities,
    projects,
    handleUpdateState,
  } = useAppData();

  const winLeadAndCreateProject = (lead: LeadRecord) => {
    const updatedLead: LeadRecord = { ...lead, status: 'Won' };
    const updatedLeads = leads.map((l) => (l.id === lead.id ? updatedLead : l));

    const newProject = GlobalReferenceService.resolveLeadConversion(updatedLead, projects);
    const updatedProjects = [newProject, ...projects];

    handleUpdateState('leads', updatedLeads);
    handleUpdateState('projects', updatedProjects);

    return newProject;
  };

  return {
    leads,
    conversions,
    tenders,
    proposals,
    activities,
    winLeadAndCreateProject,
  };
}
