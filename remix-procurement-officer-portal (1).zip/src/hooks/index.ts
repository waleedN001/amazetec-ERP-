export {
  useGlobalStore,
  useProcurementModule,
  useProjectModule,
  useInventoryModule,
  useSalesModule,
} from './useGlobalStore';
