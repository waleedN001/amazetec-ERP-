import * as XLSX from 'xlsx';

export function exportMasterWorkbookToExcel(dataState: {
  assets: any[];
  equipmentMaster: any[];
  equipmentIssuance: any[];
  attendance: any[];
  kycQueries: any[];
  employees: any[];
  salaryBrackets: any[];
  benefits: any[];
  contracts: any[];
  leads: any[];
  conversions: any[];
  visits: any[];
  boqs: any[];
  procurementAssignments: any[];
  purchaseRequisitions?: any[];
  materialSubmittals?: any[];
  quotations: any[];
  purchaseOrders?: any[];
  shipments?: any[];
  reconciliations?: any[];
  suppliers: any[];
  priceHistory: any[];
  procurementFollowUps: any[];
  procurementRevisions: any[];
  securityCatalog?: any[];
  projects: any[];
  paymentMilestones: any[];
  advanceChecks: any[];
  teamSelections: any[];
  executionPhases: any[];
  weeklyReports: any[];
  qualityChecks: any[];
  clientCommunications: any[];
  projectCompletions: any[];
  dropdowns: any[];
}) {
  const wb = XLSX.utils.book_new();

  // 1. MASTER DASHBOARD SUMMARY SHEET
  const dashboardSummary = [
    { KPI: 'Company Name', Value: 'AMAZETEC TRADING & CONTRACTING W.L.L.' },
    { KPI: 'Classification', Value: 'Master Operations & Procurement ERP Workbook' },
    { KPI: 'Location', Value: 'Doha, State of Qatar' },
    { KPI: 'Total Active Employees', Value: dataState.employees.length },
    { KPI: 'Total Leads Captured', Value: dataState.leads.length },
    { KPI: 'Total Projects Managed', Value: dataState.projects.length },
    { KPI: 'Active Purchase Orders (PO)', Value: (dataState.purchaseOrders || []).length },
    { KPI: 'Active Requisitions (PR)', Value: (dataState.purchaseRequisitions || []).length },
    { KPI: 'Material Submittals (MAS)', Value: (dataState.materialSubmittals || []).length },
    { KPI: 'Customs & Logistics Shipments', Value: (dataState.shipments || []).length },
    { KPI: '3-Way Reconciled Invoices', Value: (dataState.reconciliations || []).length },
    { KPI: 'Active Suppliers (AVL)', Value: dataState.suppliers.filter((s) => s.status === 'Active').length },
  ];
  const wsDashboard = XLSX.utils.json_to_sheet(dashboardSummary);
  XLSX.utils.book_append_sheet(wb, wsDashboard, 'Master Dashboard');

  // 2. SITE PURCHASE REQUISITIONS (PR)
  if (dataState.purchaseRequisitions && dataState.purchaseRequisitions.length > 0) {
    const wsPR = XLSX.utils.json_to_sheet(dataState.purchaseRequisitions);
    XLSX.utils.book_append_sheet(wb, wsPR, 'Site Requisitions (PR)');
  }

  // 3. MATERIAL SUBMITTALS (MAS)
  if (dataState.materialSubmittals && dataState.materialSubmittals.length > 0) {
    const wsMAS = XLSX.utils.json_to_sheet(dataState.materialSubmittals);
    XLSX.utils.book_append_sheet(wb, wsMAS, 'Material Submittals (MAS)');
  }

  // 4. MASTER BOQ COSTINGS
  if (dataState.boqs && dataState.boqs.length > 0) {
    const wsBOQ = XLSX.utils.json_to_sheet(dataState.boqs);
    XLSX.utils.book_append_sheet(wb, wsBOQ, 'Master BOQ Costings');
  }

  // 5. QUOTATION COMPARISON MATRIX (CBE)
  if (dataState.quotations && dataState.quotations.length > 0) {
    const wsQuote = XLSX.utils.json_to_sheet(dataState.quotations);
    XLSX.utils.book_append_sheet(wb, wsQuote, 'Quotation Matrix (CBE)');
  }

  // 6. OFFICIAL PURCHASE ORDERS (PO)
  if (dataState.purchaseOrders && dataState.purchaseOrders.length > 0) {
    const wsPO = XLSX.utils.json_to_sheet(dataState.purchaseOrders);
    XLSX.utils.book_append_sheet(wb, wsPO, 'Purchase Orders (PO)');
  }

  // 7. LOGISTICS & CUSTOMS CLEARANCE
  if (dataState.shipments && dataState.shipments.length > 0) {
    const wsLogistics = XLSX.utils.json_to_sheet(dataState.shipments);
    XLSX.utils.book_append_sheet(wb, wsLogistics, 'Logistics & Customs');
  }

  // 8. 3-WAY INVOICE RECONCILIATION
  if (dataState.reconciliations && dataState.reconciliations.length > 0) {
    const wsRecon = XLSX.utils.json_to_sheet(dataState.reconciliations);
    XLSX.utils.book_append_sheet(wb, wsRecon, '3-Way Reconciliation');
  }

  // 9. APPROVED VENDORS LIST (AVL)
  if (dataState.suppliers && dataState.suppliers.length > 0) {
    const wsSuppliers = XLSX.utils.json_to_sheet(dataState.suppliers);
    XLSX.utils.book_append_sheet(wb, wsSuppliers, 'Approved Suppliers (AVL)');
  }

  // 10. PRICE HISTORY & VARIANCE LOGS
  if (dataState.priceHistory && dataState.priceHistory.length > 0) {
    const wsPrice = XLSX.utils.json_to_sheet(dataState.priceHistory);
    XLSX.utils.book_append_sheet(wb, wsPrice, 'Price History Logs');
  }

  // 11. SECURITY PRODUCT CATALOG
  const catalogData = dataState.securityCatalog || [];
  if (catalogData.length > 0) {
    const wsCat = XLSX.utils.json_to_sheet(catalogData);
    XLSX.utils.book_append_sheet(wb, wsCat, 'Security Product Catalog');
  }

  // 12. ADMINISTRATOR & ASSETS
  const adminData = [
    { SECTION: '--- ASSET MANAGEMENT ---' },
    ...dataState.assets,
    { SECTION: '' },
    { SECTION: '--- EQUIPMENT STORE MASTER ---' },
    ...dataState.equipmentMaster,
    { SECTION: '' },
    { SECTION: '--- EQUIPMENT ISSUANCE ---' },
    ...dataState.equipmentIssuance,
    { SECTION: '' },
    { SECTION: '--- ATTENDANCE RECORDS ---' },
    ...dataState.attendance,
    { SECTION: '' },
    { SECTION: '--- KYC & GOVERNMENT QUERIES ---' },
    ...dataState.kycQueries,
  ];
  const wsAdmin = XLSX.utils.json_to_sheet(adminData);
  XLSX.utils.book_append_sheet(wb, wsAdmin, 'Administrator');

  // 13. HUMAN RESOURCES
  const hrData = [
    { SECTION: '--- EMPLOYEE RECORDS ---' },
    ...dataState.employees,
    { SECTION: '' },
    { SECTION: '--- SALARY BRACKETS & BENEFITS ---' },
    ...dataState.salaryBrackets,
    { SECTION: '' },
    { SECTION: '--- EMPLOYEE BENEFITS MASTER ---' },
    ...dataState.benefits,
    { SECTION: '' },
    { SECTION: '--- EMPLOYEE CONTRACTS & REVISIONS ---' },
    ...dataState.contracts,
  ];
  const wsHR = XLSX.utils.json_to_sheet(hrData);
  XLSX.utils.book_append_sheet(wb, wsHR, 'Human Resources');

  // 14. BUSINESS ANALYST & LEADS
  const baData = [
    { SECTION: '--- LEADS SOURCES & TRACKING ---' },
    ...dataState.leads,
    { SECTION: '' },
    { SECTION: '--- CONVERSION RATES ---' },
    ...dataState.conversions,
    { SECTION: '' },
    { SECTION: '--- VISIT SCHEDULING (ELV / DIA / DSA) ---' },
    ...dataState.visits,
  ];
  const wsBA = XLSX.utils.json_to_sheet(baData);
  XLSX.utils.book_append_sheet(wb, wsBA, 'Business Analyst');

  // 15. PROJECT MANAGER
  const pmData = [
    { SECTION: '--- PROJECT OVERVIEW ---' },
    ...dataState.projects,
    { SECTION: '' },
    { SECTION: '--- PAYMENT MILESTONES & ADVANCE CHECKS ---' },
    ...dataState.paymentMilestones,
    ...dataState.advanceChecks,
    { SECTION: '' },
    { SECTION: '--- TEAM SELECTION & RESOURCE PLANNING ---' },
    ...dataState.teamSelections,
    { SECTION: '' },
    { SECTION: '--- EXECUTION PHASES ---' },
    ...dataState.executionPhases,
    { SECTION: '' },
    { SECTION: '--- WEEKLY EXECUTION REPORTS ---' },
    ...dataState.weeklyReports,
    { SECTION: '' },
    { SECTION: '--- QUALITY CHECKS ---' },
    ...dataState.qualityChecks,
    { SECTION: '' },
    { SECTION: '--- CLIENT COMMUNICATIONS ---' },
    ...dataState.clientCommunications,
    { SECTION: '' },
    { SECTION: '--- COMPLETION & APPROVAL STATUS ---' },
    ...dataState.projectCompletions,
  ];
  const wsPM = XLSX.utils.json_to_sheet(pmData);
  XLSX.utils.book_append_sheet(wb, wsPM, 'Project Manager');

  // Save File
  XLSX.writeFile(wb, `Amazetec_Procurement_Operations_ERP_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export function exportSingleTableToCSV(tableData: any[], fileName: string) {
  const ws = XLSX.utils.json_to_sheet(tableData);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
