import React from 'react';
import { AppDataProvider, useAppData } from './context/useAppData';
import { DashboardLayout } from './layouts/DashboardLayout';

import { MasterDashboard } from './components/MasterDashboard';
import { AdministratorView } from './components/AdministratorView';
import { HRView } from './components/HRView';
import { BAView } from './components/BAView';
import { ProcurementView } from './components/ProcurementView';
import { ProductCatalogView } from './components/ProductCatalogView';
import { PMView } from './components/PMView';
import { JourneyTrackerView } from './components/JourneyTrackerView';
import { MasterSpreadsheetView } from './components/MasterSpreadsheetView';
import { SalesCRMView } from './components/SalesCRMView';
import { ProjectManagementView } from './components/ProjectManagementView';
import { MOIComplianceView } from './components/MOIComplianceView';
import { AMCServiceView } from './components/AMCServiceView';
import { InventoryAssetView } from './components/InventoryAssetView';
import { FinancialManagementView } from './components/FinancialManagementView';
import { ClientPortalView } from './components/ClientPortalView';

function ViewRouter() {
  const {
    activeTab,
    setActiveTab,
    procurementSubModule,
    setProcurementSubModule,
    viewMode,
    setIsQuickAddOpen,
    setGeminiIntelligenceMode,
    setGeminiSelectedBoqId,
    setIsGeminiIntelligenceOpen,

    // Datasets
    assets,
    equipmentMaster,
    equipmentIssuance,
    attendance,
    kycQueries,
    employees,
    salaryBrackets,
    benefits,
    contracts,
    leads,
    conversions,
    visits,
    boqs,
    procurementAssignments,
    purchaseRequisitions,
    materialSubmittals,
    quotations,
    purchaseOrders,
    logisticsShipments,
    invoiceReconciliations,
    suppliers,
    priceHistory,
    procurementFollowUps,
    procurementRevisions,
    securityProductCatalog,
    projects,
    projectPaymentMilestones,
    advanceChecks,
    teamSelection,
    executionPhases,
    weeklyReports,
    qualityChecks,
    clientCommunications,
    projectCompletions,
    dropdownMaster,

    // Extended Datasets
    tenders,
    proposals,
    activities,
    phasedTasks,
    dsaRecords,
    diaRecords,
    complianceChecklist,
    amcContracts,
    serviceTickets,
    schedules,
    inventoryItems,
    projectAssets,
    projectBudgets,
    clientInvoices,
    projectExpenses,

    // Mutation Handlers
    handleUpdateState,
    handleExportAll,
  } = useAppData();

  // Backward compatible dataState bundle
  const dataState = {
    assets,
    equipmentMaster,
    equipmentIssuance,
    attendance,
    kycQueries,
    employees,
    salaryBrackets,
    benefits,
    contracts,
    leads,
    conversions,
    visits,
    boqs,
    procurementAssignments,
    purchaseRequisitions,
    materialSubmittals,
    quotations,
    purchaseOrders,
    logisticsShipments,
    shipments: logisticsShipments,
    invoiceReconciliations,
    reconciliations: invoiceReconciliations,
    suppliers,
    priceHistory,
    procurementFollowUps,
    followUps: procurementFollowUps,
    procurementRevisions,
    revisions: procurementRevisions,
    securityProductCatalog,
    securityCatalog: securityProductCatalog,
    projects,
    projectPaymentMilestones,
    advanceChecks,
    teamSelections: teamSelection,
    teamSelection,
    executionPhases,
    weeklyReports,
    qualityChecks,
    clientCommunications,
    projectCompletions,
    dropdownMaster,
    dropdowns: dropdownMaster,
    tenders,
    proposals,
    activities,
    phasedTasks,
    dsaRecords,
    diaRecords,
    complianceChecklist,
    amcContracts,
    serviceTickets,
    schedules,
    inventoryItems,
    projectAssets,
    projectBudgets,
    clientInvoices,
    projectExpenses,
  };

  if (viewMode === 'spreadsheet') {
    return (
      <MasterSpreadsheetView
        dataState={dataState}
        onUpdateState={(key, newData) => handleUpdateState(key as any, newData)}
        onExportMasterExcel={handleExportAll}
      />
    );
  }

  return (
    <>
      {activeTab === 'dashboard' && (
        <MasterDashboard
          dataState={dataState}
          onNavigateTab={(tab) => setActiveTab(tab)}
        />
      )}

      {activeTab === 'sales' && (
        <SalesCRMView
          tenders={tenders}
          proposals={proposals}
          activityLogs={activities}
          leads={leads}
          boqs={boqs}
          dropdowns={dropdownMaster as any}
          onUpdateTenders={(d) => handleUpdateState('tenders', d)}
          onUpdateProposals={(d) => handleUpdateState('proposals', d)}
          onUpdateActivityLogs={(d) => handleUpdateState('activities', d)}
          onUpdateLeads={(d) => handleUpdateState('leads', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          onNavigateToBOQ={() => {
            setActiveTab('procurement');
            setProcurementSubModule('pr_boq');
          }}
        />
      )}

      {activeTab === 'ba' && (
        <BAView
          leads={leads}
          conversions={conversions}
          visits={visits}
          boqs={boqs}
          procurementAssignments={procurementAssignments}
          dropdowns={dropdownMaster as any}
          onUpdateLeads={(d) => handleUpdateState('leads', d)}
          onUpdateConversions={(d) => handleUpdateState('conversions', d)}
          onUpdateVisits={(d) => handleUpdateState('visits', d)}
          onUpdateBOQs={(d) => handleUpdateState('boqs', d)}
          onUpdateProcurementAssignments={(d) => handleUpdateState('procurementAssignments', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'projects' && (
        <ProjectManagementView
          projects={projects}
          tasks={phasedTasks}
          teams={teamSelection}
          executionPhases={executionPhases}
          weeklyReports={weeklyReports}
          dropdowns={dropdownMaster as any}
          onUpdateProjects={(d) => handleUpdateState('projects', d)}
          onUpdateTasks={(d) => handleUpdateState('phasedTasks', d)}
          onUpdateTeams={(d) => handleUpdateState('teamSelection', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'moi' && (
        <MOIComplianceView
          dsaRecords={dsaRecords}
          diaRecords={diaRecords}
          checklist={complianceChecklist}
          onUpdateDSARecords={(d) => handleUpdateState('dsaRecords', d)}
          onUpdateDIARecords={(d) => handleUpdateState('diaRecords', d)}
          onUpdateChecklist={(d) => handleUpdateState('complianceChecklist', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'amc' && (
        <AMCServiceView
          contracts={amcContracts}
          tickets={serviceTickets}
          schedules={schedules}
          onUpdateContracts={(d) => handleUpdateState('amcContracts', d)}
          onUpdateTickets={(d) => handleUpdateState('serviceTickets', d)}
          onUpdateSchedules={(d) => handleUpdateState('schedules', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'inventory' && (
        <InventoryAssetView
          inventoryItems={inventoryItems}
          projectAssets={projectAssets}
          materialSubmittals={materialSubmittals}
          purchaseOrders={purchaseOrders}
          shipments={logisticsShipments}
          suppliers={suppliers}
          boqs={boqs}
          priceHistory={priceHistory}
          onUpdateInventory={(d) => handleUpdateState('inventoryItems', d)}
          onUpdateProjectAssets={(d) => handleUpdateState('projectAssets', d)}
          onUpdateMaterialSubmittals={(d) => handleUpdateState('materialSubmittals', d)}
          onUpdatePurchaseOrders={(d) => handleUpdateState('purchaseOrders', d)}
          onUpdateShipments={(d) => handleUpdateState('logisticsShipments', d)}
          onUpdateSuppliers={(d) => handleUpdateState('suppliers', d)}
          onUpdatePriceHistory={(d) => handleUpdateState('priceHistory', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'finance' && (
        <FinancialManagementView
          budgets={projectBudgets}
          invoices={clientInvoices}
          expenses={projectExpenses}
          onUpdateBudgets={(d) => handleUpdateState('projectBudgets', d)}
          onUpdateInvoices={(d) => handleUpdateState('clientInvoices', d)}
          onUpdateExpenses={(d) => handleUpdateState('projectExpenses', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'client-portal' && (
        <ClientPortalView
          projects={projects}
          amcContracts={amcContracts}
          tickets={serviceTickets}
          diaRecords={diaRecords}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'administrator' && (
        <AdministratorView
          assets={assets}
          equipmentMaster={equipmentMaster}
          equipmentIssuance={equipmentIssuance}
          attendance={attendance}
          kycQueries={kycQueries}
          dropdowns={dropdownMaster as any}
          onUpdateAssets={(d) => handleUpdateState('assets', d)}
          onUpdateEquipmentMaster={(d) => handleUpdateState('equipmentMaster', d)}
          onUpdateEquipmentIssuance={(d) => handleUpdateState('equipmentIssuance', d)}
          onUpdateAttendance={(d) => handleUpdateState('attendance', d)}
          onUpdateKYCQueries={(d) => handleUpdateState('kycQueries', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'hr' && (
        <HRView
          employees={employees}
          salaryBrackets={salaryBrackets}
          benefits={benefits}
          contracts={contracts}
          dropdowns={dropdownMaster as any}
          onUpdateEmployees={(d) => handleUpdateState('employees', d)}
          onUpdateSalaryBrackets={(d) => handleUpdateState('salaryBrackets', d)}
          onUpdateBenefits={(d) => handleUpdateState('benefits', d)}
          onUpdateContracts={(d) => handleUpdateState('contracts', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'journey' && (
        <JourneyTrackerView
          leads={leads}
          projects={projects}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'catalog' && (
        <ProductCatalogView
          catalog={securityProductCatalog}
          onUpdateCatalog={(d) => handleUpdateState('securityProductCatalog', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}

      {activeTab === 'procurement' && (
        <ProcurementView
          boqs={boqs}
          quotations={quotations}
          suppliers={suppliers}
          priceHistory={priceHistory}
          followUps={procurementFollowUps}
          revisions={procurementRevisions}
          securityCatalog={securityProductCatalog}
          purchaseRequisitions={purchaseRequisitions}
          materialSubmittals={materialSubmittals}
          purchaseOrders={purchaseOrders}
          shipments={logisticsShipments}
          reconciliations={invoiceReconciliations}
          dropdowns={dropdownMaster as any}
          activeSubModule={procurementSubModule}
          onSubModuleChange={setProcurementSubModule}
          onUpdateBOQs={(d) => handleUpdateState('boqs', d)}
          onUpdateQuotations={(d) => handleUpdateState('quotations', d)}
          onUpdateSuppliers={(d) => handleUpdateState('suppliers', d)}
          onUpdatePriceHistory={(d) => handleUpdateState('priceHistory', d)}
          onUpdateFollowUps={(d) => handleUpdateState('procurementFollowUps', d)}
          onUpdateRevisions={(d) => handleUpdateState('procurementRevisions', d)}
          onUpdateSecurityCatalog={(d) => handleUpdateState('securityProductCatalog', d)}
          onUpdatePurchaseRequisitions={(d) => handleUpdateState('purchaseRequisitions', d)}
          onUpdateMaterialSubmittals={(d) => handleUpdateState('materialSubmittals', d)}
          onUpdatePurchaseOrders={(d) => handleUpdateState('purchaseOrders', d)}
          onUpdateShipments={(d) => handleUpdateState('logisticsShipments', d)}
          onUpdateReconciliations={(d) => handleUpdateState('invoiceReconciliations', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
          onOpenGeminiAnalysis={(boqId) => {
            if (boqId) setGeminiSelectedBoqId(boqId);
            setGeminiIntelligenceMode('quote-analysis');
            setIsGeminiIntelligenceOpen(true);
          }}
        />
      )}

      {activeTab === 'pm' && (
        <PMView
          projects={projects}
          paymentMilestones={projectPaymentMilestones}
          advanceChecks={advanceChecks}
          teamSelections={teamSelection}
          executionPhases={executionPhases}
          weeklyReports={weeklyReports}
          qualityChecks={qualityChecks}
          clientCommunications={clientCommunications}
          projectCompletions={projectCompletions}
          dropdowns={dropdownMaster as any}
          onUpdateProjects={(d) => handleUpdateState('projects', d)}
          onUpdateMilestones={(d) => handleUpdateState('projectPaymentMilestones', d)}
          onUpdateAdvanceChecks={(d) => handleUpdateState('advanceChecks', d)}
          onUpdateTeamSelections={(d) => handleUpdateState('teamSelection', d)}
          onUpdateExecutionPhases={(d) => handleUpdateState('executionPhases', d)}
          onUpdateWeeklyReports={(d) => handleUpdateState('weeklyReports', d)}
          onUpdateQualityChecks={(d) => handleUpdateState('qualityChecks', d)}
          onUpdateClientCommunications={(d) => handleUpdateState('clientCommunications', d)}
          onUpdateProjectCompletions={(d) => handleUpdateState('projectCompletions', d)}
          onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        />
      )}
    </>
  );
}

export default function App() {
  return (
    <AppDataProvider>
      <DashboardLayout>
        <ViewRouter />
      </DashboardLayout>
    </AppDataProvider>
  );
}
