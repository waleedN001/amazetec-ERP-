const fs = require('fs');
const file = 'src/components/SCMPipelineView.tsx';
let content = fs.readFileSync(file, 'utf8');

// Replace flex-col with flex-row for the slider containers
content = content.replace(/<div className="flex flex-col gap-1">/g, '<div className="flex items-center justify-between gap-3">');

// Adjust the label div to not take full width, and fix width of slider
content = content.replace(/<div className="flex justify-between items-center text-\[10px\] font-medium text-slate-600">/g, '<div className="text-[10px] font-medium text-slate-600 min-w-[140px]">');

content = content.replace(/<input type="range"([^>]+)className="w-full h-1\.5/g, '<input type="range"$1className="flex-1 h-1.5');

fs.writeFileSync(file, content);
