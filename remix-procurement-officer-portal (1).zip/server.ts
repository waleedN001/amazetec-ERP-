import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy GoogleGenAI client initialization
let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is missing. Please configure it in Settings > Secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Resilient Gemini Execution with automated multi-model fallback & retry
const FALLBACK_MODELS = [
  'gemini-3.7-flash',
  'gemini-3.1-flash-lite',
  'gemini-flash-latest',
];

async function callGeminiResilient(
  preferredModel: string,
  params: {
    contents: any;
    config?: any;
  }
): Promise<{ text: string; modelUsed: string }> {
  const ai = getAI();
  const candidates = Array.from(new Set([preferredModel, ...FALLBACK_MODELS])).filter(Boolean);

  let lastError: any = null;

  for (let i = 0; i < candidates.length; i++) {
    const currentModel = candidates[i];
    try {
      const response = await ai.models.generateContent({
        model: currentModel,
        contents: params.contents,
        config: params.config,
      });

      const responseText = response.text || '';
      if (responseText.trim().length > 0) {
        return {
          text: responseText,
          modelUsed: currentModel,
        };
      }
    } catch (err: any) {
      console.warn(`[Gemini Fallback] Model '${currentModel}' failed:`, err?.message || err);
      lastError = err;

      // If more candidates exist, briefly delay and try next model
      if (i < candidates.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 350));
      }
    }
  }

  throw lastError || new Error('All Gemini models are temporarily unavailable.');
}

// ----------------------------------------------------
// 1. Multi-Turn Gemini Chat Endpoint
// ----------------------------------------------------
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const {
      messages = [],
      message,
      model = 'gemini-3.5-flash-lite',
      role = 'procurement_officer',
      projectContext,
    } = req.body;

    if (!message && (!messages || messages.length === 0)) {
      return res.status(400).json({ error: 'Message or conversation history is required.' });
    }

    // Role-based system instructions
    let systemInstruction = `You are a Senior Qatar Security & ELV Procurement Expert and Technical BOQ Estimator working for Amazetec / Remix in Doha, Qatar.
Your expertise spans MOI-SSD (Ministry of Interior - Security Systems Department) compliance, CCTV systems (Hikvision, Dahua, Uniview, Axis, Bosch, Honeywell), SAN/NVR storage calculations (120-day MOI retention rules), fiber/copper structured cabling, access control, and commercial negotiation in Qatari Riyal (QAR).

Guidelines:
1. Provide accurate, professional, and practical procurement advice with commercial acumen (payment terms, lead times, warranty, and cash flow risk).
2. All financial figures should reference Qatari Riyals (QAR) unless asked otherwise.
3. Be clear, formatted with structured bullet points or tables where appropriate.
4. When evaluating vendors, compare pricing vs market benchmarks, lead times, credit terms (e.g. L/C vs 30/60 Days Credit vs Advance Cash), and local agency stock readiness in Qatar.`;

    if (role === 'moi_compliance') {
      systemInstruction = `You are the Lead MOI-SSD Qatar Security Compliance Auditor.
Your role is to strictly verify security system designs, camera resolutions (minimum 2MP/4MP/4K for perimeter), frame rates (25fps for SSD), 120-day raid storage retention, redundancy power (UPS runtime), and approved brand lists according to State of Qatar Law No. (9) of 2011 and SSD technical specifications.`;
    } else if (role === 'negotiation_strategist') {
      systemInstruction = `You are a Chief Commercial Procurement & Vendor Negotiation Strategist.
Your role is to craft aggressive yet professional counter-offers, discount requests, bulk rebate negotiations, extended payment terms (e.g., converting 50% advance to 60-day LC or post-delivery credit), and penalty clauses for delayed shipments into Doha ports/Hamad airport.`;
    } else if (role === 'value_engineer') {
      systemInstruction = `You are a Senior Value Engineering & Hardware Optimization Consultant for Qatar Construction & Security projects.
Your goal is to propose cost-saving alternatives that maintain or exceed functional specifications and retain MOI-SSD approvals while trimming 10% to 25% off project BOQ costs.`;
    } else if (role === 'journey_lifecycle_assistant' || role === 'business_analyst') {
      systemInstruction = `You are the Amazetec Senior Business Operations & Project Journey Intelligence Advisor in Doha, Qatar.
Your expertise spans the entire 6-Stage End-to-End ELV Project Lifecycle, commercial cash flows, business metrics, and stakeholder governance:
1. Stage 1: Lead Acquisition & Qualification (Channels: LinkedIn B2B, Referrals, Upwork/Fiverr, Inbound).
2. Stage 2: Technical Site Survey & Certification Verification (ELV Engineers, ET Technicians, TT team, MEA/MOI/Civil Defence compliance).
3. Stage 3: BOQ Costing, Margin Analysis & Business Proposal (BP) drafting & client approvals.
4. Stage 4: Supplier Purchase Orders (PO) & 50% Advance Cashflow Collection & Supplier Deposits.
5. Stage 5: Execution, Site Staffing & Commissioning (Permanent ELV staff, Contract staff, Daily wage laborers, Cabling, VMS configuration).
6. Stage 6: Post-Handover 1-Year Annual Maintenance Contract (AMC) (Routine inspections, hardware fixes, firmware patches, repainting).

When the user asks for business reports, overall status, financial analytics, risk audits, or stage progress:
- Provide comprehensive, structured, and highly detailed executive reports.
- Include concrete numbers in QAR (Total Pipeline Value, 50% Advances Collected vs Outstanding, Client Status Breakdown, Staffing Allocations).
- Use clear markdown with bold headers, bulleted lists, financial tables, and strategic recommendations for next steps.`;
    }

    // Add live project context if provided
    if (projectContext) {
      systemInstruction += `\n\nActive System Data Context:\n${typeof projectContext === 'string' ? projectContext : JSON.stringify(projectContext, null, 2)}`;
    }

    // Prepare contents array
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(messages) && messages.length > 0) {
      for (const m of messages) {
        contents.push({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.text || m.content || '' }],
        });
      }
    }

    if (message) {
      contents.push({
        role: 'user',
        parts: [{ text: message }],
      });
    }

    const { text, modelUsed } = await callGeminiResilient(model, {
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({
      reply: text,
      model: modelUsed,
      role,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/chat:', error);
    return res.status(500).json({
      error: error.message || 'Failed to process chat with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 2. AI Quotation Evaluation & Negotiation Advisor
// ----------------------------------------------------
app.post('/api/gemini/analyze-quotations', async (req, res) => {
  try {
    const { boq, quotations = [], suppliers = [] } = req.body;

    if (!boq || quotations.length === 0) {
      return res.status(400).json({ error: 'BOQ and at least one quotation are required for analysis.' });
    }

    const prompt = `Perform a comprehensive Commercial & Technical Evaluation for the following project in Qatar:

PROJECT / BOQ TARGET:
${JSON.stringify(boq, null, 2)}

SUBMITTED VENDOR QUOTATIONS:
${JSON.stringify(quotations, null, 2)}

SUPPLIER MASTER DATA:
${JSON.stringify(suppliers, null, 2)}

Please provide a detailed strategic evaluation containing:
1. Executive Summary & Recommended Award Winner with clear justification.
2. Price Variance Analysis (QAR values, savings vs target budget, lowest bid analysis).
3. Delivery & Lead Time Risk Evaluation (impact on project schedule in Doha).
4. Payment Terms & Cash Flow Exposure (assessment of upfront cash drain vs credit terms).
5. Specific Counter-Offer Strategy: Recommended target price, revised payment terms, and delivery commitments to request from the top 2 bidders.
6. Draft Negotiation Email / Letter ready to send to the preferred vendor requesting a final best-and-final-offer (BAFO).`;

    const { text } = await callGeminiResilient('gemini-3.5-flash-lite', {
      contents: prompt,
      config: {
        systemInstruction: 'You are an elite Senior Procurement Director in Qatar specializing in security systems, CCTV, ELV, and commercial vendor management.',
        temperature: 0.5,
      },
    });

    return res.json({
      analysis: text,
      analyzedQuotesCount: quotations.length,
      boqId: boq.boqId || boq.id,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/analyze-quotations:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze quotations with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 3. AI BOQ Line Item & Specs Generator
// ----------------------------------------------------
app.post('/api/gemini/generate-boq-specs', async (req, res) => {
  try {
    const { itemName, category, projectType, requirements } = req.body;

    if (!itemName) {
      return res.status(400).json({ error: 'Item name or description is required.' });
    }

    const prompt = `Generate a complete, MOI-SSD compliant technical specification and costing benchmark for a BOQ line item in Qatar:
- Item: ${itemName}
- Category: ${category || 'CCTV & Security'}
- Project Type: ${projectType || 'Commercial / Residential Compound'}
- Additional Requirements: ${requirements || 'Standard Qatar MOI SSD guidelines'}

Provide:
1. Standard Technical Specification Paragraph (suitable for consultant BOQ submission)
2. MOI-SSD Qatar Mandatory Parameters (Resolution, sensor size, WDR, codec, frame rate, IR distance, ONVIF Profile)
3. Estimated QAR Unit Cost Range (Supply only vs Supply & Installation)
4. Recommended Tier-1 & Tier-2 Brands/Models available in Qatar
5. Key Accessories & Structured Cabling dependencies`;

    const { text } = await callGeminiResilient('gemini-2.5-flash-lite', {
      contents: prompt,
      config: {
        systemInstruction: 'You are a Senior Security Systems Design Engineer and Estimator in Doha, Qatar.',
      },
    });

    return res.json({
      specs: text,
      itemName,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/generate-boq-specs:', error);
    return res.status(500).json({
      error: error.message || 'Failed to generate BOQ specs with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 4. AI Negotiation Letter & Counter-Offer Draft
// ----------------------------------------------------
app.post('/api/gemini/draft-negotiation-letter', async (req, res) => {
  try {
    const {
      supplierName,
      projectName,
      currentQuotedValue,
      targetPrice,
      currentDelivery,
      targetDelivery,
      currentTerms,
      targetTerms,
      notes,
    } = req.body;

    const prompt = `Draft a high-impact, professional, and courteous Supplier Negotiation & Counter-Offer Letter from Remix / Amazetec Procurement Department in Qatar to:
- Supplier / Distributor: ${supplierName || 'Distributor'}
- Project: ${projectName || 'Qatar Security Upgrade'}
- Current Quoted Amount: QAR ${currentQuotedValue?.toLocaleString?.() || currentQuotedValue}
- Target Counter-Offer Price: QAR ${targetPrice?.toLocaleString?.() || targetPrice}
- Current Quoted Delivery: ${currentDelivery || '4 Weeks'} -> Target Expedited Delivery: ${targetDelivery || '2 Weeks'}
- Current Payment Terms: ${currentTerms || '50% Advance'} -> Requested Terms: ${targetTerms || '30 Days Credit / LC'}
- Strategic Negotiation Notes: ${notes || 'We have competing bids within budget; prompt confirmation secures immediate purchase order.'}

Format as a formal commercial correspondence ready for email or official letterhead transmission in Doha, Qatar.`;

    const { text } = await callGeminiResilient('gemini-3.5-flash-lite', {
      contents: prompt,
      config: {
        systemInstruction: 'You are an expert commercial procurement manager and contract negotiator in Qatar.',
      },
    });

    return res.json({
      letter: text,
      supplierName,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/draft-negotiation-letter:', error);
    return res.status(500).json({
      error: error.message || 'Failed to draft negotiation letter with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 5. AI Value Engineering & Alternative Product Advisor
// ----------------------------------------------------
app.post('/api/gemini/value-engineering', async (req, res) => {
  try {
    const { product, targetSavingsPercent = 15 } = req.body;

    if (!product) {
      return res.status(400).json({ error: 'Product details are required.' });
    }

    const prompt = `Perform Value Engineering for the following security product used in Qatar:
Product: ${JSON.stringify(product, null, 2)}
Target Cost Reduction: ${targetSavingsPercent}%

Provide:
1. Technical Feature Comparison of the current unit.
2. 2-3 Alternative Models / Brands (e.g. comparing Hikvision vs Dahua vs Uniview vs Milesight) that satisfy the same MOI SSD specifications at lower unit cost.
3. Quantified Estimated Cost Savings per unit in QAR.
4. Compatibility or Trade-off considerations (VMS integration, warranty in Qatar, power consumption).`;

    const { text } = await callGeminiResilient('gemini-3.5-flash-lite', {
      contents: prompt,
    });

    return res.json({
      recommendation: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/value-engineering:', error);
    return res.status(500).json({
      error: error.message || 'Failed to run value engineering advisor with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 6. AI .DWG / CAD Plan to BOQ Extractor & Spec Parser
// ----------------------------------------------------
app.post('/api/gemini/parse-dwg-plan', async (req, res) => {
  try {
    const {
      fileBase64,
      fileName = 'Drawing.dwg',
      mimeType = 'application/octet-stream',
      extractedText = '',
      projectNotes = '',
    } = req.body;

    if (!fileBase64 && !extractedText) {
      return res.status(400).json({ error: 'Drawing file (base64) or extracted text is required.' });
    }

    // Helper: Extract printable strings from DWG binary buffer if it is a .dwg / CAD binary
    let cadEntitiesText = extractedText || '';
    if (fileBase64 && (fileName.toLowerCase().endsWith('.dwg') || mimeType.includes('octet-stream') || mimeType.includes('acad') || mimeType.includes('dwg'))) {
      try {
        const buffer = Buffer.from(fileBase64, 'base64');
        const binaryStr = buffer.toString('binary');
        // Extract sequences of 4+ printable ASCII chars
        const matches = binaryStr.match(/[A-Za-z0-9_\-\.\:\/ ]{4,100}/g) || [];
        const filteredTags = matches.filter((s) => {
          const lower = s.toLowerCase();
          return (
            lower.includes('bbv') ||
            lower.includes('cctv') ||
            lower.includes('elv') ||
            lower.includes('cat6') ||
            lower.includes('rj45') ||
            lower.includes('wifi') ||
            lower.includes('ap') ||
            lower.includes('tdw') ||
            lower.includes('grms') ||
            lower.includes('lcp') ||
            lower.includes('rack') ||
            lower.includes('camera') ||
            lower.includes('door') ||
            lower.includes('access') ||
            lower.includes('conduit') ||
            lower.includes('drawing') ||
            lower.includes('maldives') ||
            lower.includes('rosewood') ||
            lower.includes('amazetec') ||
            lower.includes('shaker') ||
            lower.includes('estithmar') ||
            lower.includes('rev') ||
            lower.includes('plan')
          );
        });
        if (filteredTags.length > 0) {
          cadEntitiesText += `\nExtracted CAD Entities & Layer Tags:\n${Array.from(new Set(filteredTags)).slice(0, 80).join('\n')}`;
        }
      } catch (e) {
        console.warn('CAD binary string extraction notice:', e);
      }
    }

    const systemInstruction = `You are a Principal ELV & Low Current Estimator and Quantity Surveyor specializing in extracting Bill of Quantities (BOQ) directly from AutoCAD drawings (.dwg, .dxf), engineering PDF plans, and symbol schedules.
Your task is to analyze the provided engineering drawing, symbol legend, tag annotations, title block, and floor plan layout, then output a strictly formatted JSON response for automated BOQ creation in Qatar Riyals (QAR).

You MUST output ONLY a valid JSON object matching this schema exactly without markdown fences or additional conversational prose:
{
  "projectName": "String (e.g. Royal Rosewood Resort - 1 Bedroom Beach Villa)",
  "clientName": "String (e.g. Estithmar Holding / UCC)",
  "drawingNumber": "String (e.g. RRM-SCG-FOH-BV1-ELV-LC-IFC-GF-PL-201)",
  "package": "String (e.g. P-04 Guest Villas)",
  "category": "String (e.g. Low Current & ELV Systems)",
  "sector": "String (e.g. Hospitality / Residential / Commercial)",
  "summary": "String (Brief executive summary of detected systems, floor plan area, and equipment scope)",
  "items": [
    {
      "itemCode": "String (e.g. SEC-CAB-001)",
      "tag": "String (e.g. 1BBV-GF-TDW-01 / 02)",
      "description": "String (Detailed engineering description with brand/specifications)",
      "category": "String (e.g. Structured Cabling, Wi-Fi & Active Networking, Access Control & GRMS, Containment & Conduits, Labor & Testing)",
      "quantity": Number,
      "unit": "String (e.g. Nos., Sets, Rolls, Meters, Lot)",
      "unitMaterialCostQAR": Number,
      "unitLabourCostQAR": Number,
      "totalCostQAR": Number,
      "specs": "String (Technical notes, MOI or hospitality compliance parameter)"
    }
  ],
  "totalMaterialCost": Number,
  "totalLabourCost": Number,
  "overheadCost": Number,
  "marginPercent": Number,
  "totalBOQValue": Number,
  "currency": "QAR",
  "detectedTags": ["String"],
  "drawingNotes": ["String"]
}`;

    const promptText = `Analyze this engineering drawing file (${fileName}) and generate the complete quantified BOQ.
Project context / Drawing notes:
${projectNotes || 'Extract all Low Current / ELV / CCTV / Wi-Fi / Access Control / GRMS / Structured Cabling components, conduits, and accessories.'}
${cadEntitiesText ? `\nCAD Entities & Tags Data:\n${cadEntitiesText}` : ''}`;

    const contentParts: any[] = [{ text: promptText }];

    // If PDF or image, attach as inlineData
    if (fileBase64 && (mimeType.startsWith('image/') || mimeType === 'application/pdf')) {
      contentParts.push({
        inlineData: {
          mimeType,
          data: fileBase64,
        },
      });
    }

    const { text } = await callGeminiResilient('gemini-3.6-flash', {
      contents: [{ role: 'user', parts: contentParts }],
      config: {
        systemInstruction,
        temperature: 0.2,
        responseMimeType: 'application/json',
      },
    });

    // Parse JSON
    let parsedData: any = {};
    try {
      const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleanJson);
    } catch (parseErr) {
      console.error('Failed to parse Gemini JSON output:', parseErr, text);
      return res.status(500).json({
        error: 'Failed to parse structured BOQ from drawing. Raw response received.',
        raw: text,
      });
    }

    return res.json({
      success: true,
      boq: parsedData,
      fileName,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/parse-dwg-plan:', error);
    return res.status(500).json({
      error: error.message || 'Failed to parse drawing with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 7. AI Sales & Tender Proposal Generator
// ----------------------------------------------------
app.post('/api/gemini/sales-proposal', async (req, res) => {
  try {
    const { tender, clientName, projectName, scope, estimatedValueQAR, sector } = req.body;

    const prompt = `Draft an executive Commercial & Technical Tender Proposal (Business Proposal) for a Qatar client:
Client Name: ${clientName || tender?.clientName || 'Valued Client in Qatar'}
Project Name: ${projectName || tender?.tenderName || 'State-of-the-art Security & ELV System'}
Sector: ${sector || tender?.sector || 'Commercial'}
Estimated Value: QAR ${estimatedValueQAR?.toLocaleString?.() || estimatedValueQAR || '350,000'}
Scope & Details: ${scope || tender?.notes || 'Supply, installation, cabling, VMS integration and MOI-SSD approval of security surveillance system.'}

Provide a comprehensive, professional proposal in Markdown formatted with:
1. Executive Summary & Value Proposition
2. Scope of Work (Supply, 1st Fix, 2nd Fix, Testing & Commissioning, MOI SSD Approval)
3. Proposed Milestone & Payment Schedule (e.g. 30% Advance, 60% On Delivery, 10% Handover)
4. MOI SSD Warranty & Post-Handover 1-Year AMC SLA Commitment
5. Why Choose Amazetec Qatar (Certifications, Local Spares Stock, Certified Engineers)`;

    const { text } = await callGeminiResilient('gemini-3.7-flash', {
      contents: prompt,
      config: {
        systemInstruction: 'You are an executive Commercial Director and Bid Estimator for Amazetec Security Solutions in Doha, Qatar.',
      },
    });

    return res.json({
      proposal: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/sales-proposal:', error);
    return res.status(500).json({
      error: error.message || 'Failed to generate proposal with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 8. AI MOI-SSD Compliance & Storage Audit Engine
// ----------------------------------------------------
app.post('/api/gemini/moi-audit', async (req, res) => {
  try {
    const { cameraCount = 100, resolution = '4MP', fps = 25, compression = 'H.265', retentionDays = 120, sector = 'Commercial', dsaCriteria = [] } = req.body;

    const prompt = `Perform a comprehensive Qatar MOI-SSD (Ministry of Interior - Security Systems Department) Compliance & Storage Audit:
- Total Camera Count: ${cameraCount}
- Standard Resolution: ${resolution}
- Frame Rate: ${fps} FPS (SSD Standard)
- Video Compression: ${compression}
- Mandatory Storage Retention: ${retentionDays} Days (MOI Requirement)
- Sector Type: ${sector}
- Additional Criteria / Checklist: ${JSON.stringify(dsaCriteria)}

Calculate and provide:
1. Bitrate calculation per camera stream (Mbps)
2. Total RAW storage requirement (TB/PB) for ${retentionDays} days continuous recording
3. RAID 6 / RAID 60 usable capacity overhead calculation (+20% hot spare & parity)
4. Recommended SAN / NVR Storage Architecture (approved brands in Qatar: Dell EMC, Synology Enterprise, Promise, Seagate)
5. Mandatory MOI-SSD Checklist & DSA / DIA Inspection items
6. UPS battery backup runtime requirement (minimum 2 to 4 hours per SSD regulations)`;

    const { text } = await callGeminiResilient('gemini-3.7-flash', {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Chief MOI-SSD Security Systems Auditor in Doha, Qatar.',
      },
    });

    return res.json({
      audit: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/moi-audit:', error);
    return res.status(500).json({
      error: error.message || 'Failed to perform MOI audit with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 9. AI Project Timeline & Milestone Risk Audit
// ----------------------------------------------------
app.post('/api/gemini/pm-risk-analysis', async (req, res) => {
  try {
    const { project, tasks = [], milestones = [] } = req.body;

    const prompt = `Analyze the project execution schedule, milestone progression, and site risk for the following ELV project in Qatar:
PROJECT DATA:
${JSON.stringify(project, null, 2)}

ACTIVE TASKS / MILESTONES:
${JSON.stringify(tasks.length ? tasks : milestones, null, 2)}

Provide:
1. Schedule Health & Critical Path Analysis (1st Fix, 2nd Fix, Pulling Cables, Rack Termination, Final MOI Inspection)
2. Top 3 Identified Schedule Risks & Bottlenecks
3. Site Labor & Resource Optimization Advice (ELV Engineers, ET Techs, TT Team)
4. Practical Mitigation Actions to ensure on-time client handover`;

    const { text } = await callGeminiResilient('gemini-3.7-flash', {
      contents: prompt,
      config: {
        systemInstruction: 'You are a Senior PMP-certified Project Management & ELV Site Operations Director in Doha, Qatar.',
      },
    });

    return res.json({
      riskAnalysis: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/pm-risk-analysis:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze project risks with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 10. AI AMC Trouble Ticket Diagnostic & SLA Advisor
// ----------------------------------------------------
app.post('/api/gemini/amc-diagnostic', async (req, res) => {
  try {
    const { ticket, contract, clientHistory } = req.body;

    const prompt = `Perform an intelligent diagnostic & field resolution guide for this AMC Service Ticket in Qatar:
TICKET:
${JSON.stringify(ticket, null, 2)}

CONTRACT DETAILS:
${JSON.stringify(contract, null, 2)}

Provide:
1. Immediate Root Cause Hypotheses (e.g. PoE switch port failure, IP conflict, fiber patch cable damage, NVR HDD degradation)
2. Step-by-Step Field Troubleshooting Workflow for on-site ELV technician
3. Spare Parts & Replacement Tools Checklist (Multimeter, Fluke tester, spare SFP transceivers, PTZ power supply)
4. SLA Escalation & Customer Communication Draft (to avoid SLA penalty clause)`;

    const { text } = await callGeminiResilient('gemini-3.7-flash', {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Lead AMC Technical Support & Service Helpdesk Manager for Security & ELV Systems in Qatar.',
      },
    });

    return res.json({
      diagnostic: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/amc-diagnostic:', error);
    return res.status(500).json({
      error: error.message || 'Failed to generate diagnostic with Gemini.',
    });
  }
});

// ----------------------------------------------------
// 11. AI 3-Way Reconciliation & Financial Variance Audit
// ----------------------------------------------------
app.post('/api/gemini/finance-audit', async (req, res) => {
  try {
    const { purchaseOrder, deliveryNote, invoice, variances = [] } = req.body;

    const prompt = `Perform a strict 3-Way Financial Reconciliation Audit (Purchase Order vs Goods Receipt Note vs Vendor Invoice) for Qatar procurement:
PO DETAILS:
${JSON.stringify(purchaseOrder, null, 2)}

GRN / DELIVERY:
${JSON.stringify(deliveryNote, null, 2)}

VENDOR INVOICE:
${JSON.stringify(invoice, null, 2)}

DETECTED DISCREPANCIES:
${JSON.stringify(variances, null, 2)}

Provide:
1. Reconciliation Verdict (Approved / Rejected / Approved with Debit Note)
2. Detailed Breakdown of Price Discrepancies, Quantity Shortages, or Freight Overcharges in QAR
3. Actionable Recommendation for Accounts Payable & Finance Controller
4. Draft Debit Note / Discrepancy Notice to Vendor`;

    const { text } = await callGeminiResilient('gemini-3.7-flash', {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Senior Financial Controller and Procurement Audit Specialist in Doha, Qatar.',
      },
    });

    return res.json({
      financeAudit: text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/gemini/finance-audit:', error);
    return res.status(500).json({
      error: error.message || 'Failed to perform finance audit with Gemini.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    geminiConfigured: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString(),
  });
});

// Vite middleware for development & Static file serving for production
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error('Failed to start server:', err);
});
