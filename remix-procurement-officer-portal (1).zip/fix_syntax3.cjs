const fs = require('fs');
const file = 'src/components/SCMPipelineView.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/<\/div>\n                <\/div>\n            <\/div>\n            \{\/\* Right Column: Rules Options & Stats \*\/\}/g, '</div>\n                </div>\n              </div>\n            </div>\n            {/* Right Column: Rules Options & Stats */}');

fs.writeFileSync(file, content);
