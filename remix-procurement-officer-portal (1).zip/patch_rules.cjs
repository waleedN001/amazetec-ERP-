const fs = require('fs');
const file = 'src/components/SCMPipelineView.tsx';
let content = fs.readFileSync(file, 'utf8');

const stateRegex = /const \[rulesAConfig, setRulesAConfig\] = useState<RulesEngineAConfig>\(defaultRulesEngineAConfig\);/;
const stateReplacement = `const [rulesAConfig, setRulesAConfig] = useState<RulesEngineAConfig>(defaultRulesEngineAConfig);
  const [customRules, setCustomRules] = useState<any[]>([]);
  const [isAddingRule, setIsAddingRule] = useState(false);
  const [newRule, setNewRule] = useState({ name: '', age: '', scope: 'Overall item' });`;

content = content.replace(stateRegex, stateReplacement);

const uiRegex = /\{\/\* Direct Labor Mode \*\/\}/;
const uiReplacement = `{/* Custom Rules Section */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 mt-3">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[11px] font-bold text-slate-800">Custom Pricing Rules</h4>
                  {!isAddingRule && (
                    <button onClick={() => setIsAddingRule(true)} className="text-[10px] bg-white border border-slate-200 text-indigo-600 px-2 py-1 rounded-md font-bold hover:bg-slate-50 flex items-center gap-1">
                      <Plus className="w-3 h-3" /> Add Rule
                    </button>
                  )}
                </div>
                
                {isAddingRule && (
                  <div className="bg-white border border-indigo-100 rounded-lg p-2.5 mb-3 flex flex-wrap gap-2 items-end">
                    <div className="flex-1 min-w-[120px]">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Rule Name</label>
                      <input type="text" value={newRule.name} onChange={(e) => setNewRule({...newRule, name: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1" placeholder="e.g. VIP Discount" />
                    </div>
                    <div className="w-20">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Age/Value</label>
                      <input type="text" value={newRule.age} onChange={(e) => setNewRule({...newRule, age: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1" placeholder="e.g. 5" />
                    </div>
                    <div className="w-28">
                      <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Scope</label>
                      <select value={newRule.scope} onChange={(e) => setNewRule({...newRule, scope: e.target.value})} className="w-full text-xs border border-slate-200 rounded px-2 py-1 bg-white">
                        <option value="Overall item">Overall item</option>
                        <option value="Brand-wise">Brand-wise</option>
                        <option value="Date-wise">Date-wise</option>
                      </select>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => {
                        if (newRule.name) {
                          setCustomRules([...customRules, { ...newRule, id: Date.now().toString() }]);
                          setNewRule({ name: '', age: '', scope: 'Overall item' });
                          setIsAddingRule(false);
                        }
                      }} className="bg-indigo-600 text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-indigo-700">Add</button>
                      <button onClick={() => setIsAddingRule(false)} className="bg-slate-100 text-slate-600 text-[10px] font-bold px-3 py-1.5 rounded hover:bg-slate-200">Cancel</button>
                    </div>
                  </div>
                )}

                {customRules.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {customRules.map(rule => (
                      <div key={rule.id} className="bg-white border border-slate-200 rounded-md px-2 py-1 flex items-center gap-2">
                        <div className="text-[10px]">
                          <span className="font-bold text-slate-700">{rule.name}</span>
                          <span className="text-slate-400 mx-1">|</span>
                          <span className="text-indigo-600 font-medium">Age: {rule.age}</span>
                          <span className="text-slate-400 mx-1">|</span>
                          <span className="text-slate-500">{rule.scope}</span>
                        </div>
                        <button onClick={() => setCustomRules(customRules.filter(r => r.id !== rule.id))} className="text-slate-400 hover:text-red-500">
                          &times;
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-400 italic">No custom rules applied.</p>
                )}
              </div>

              {/* Direct Labor Mode */}`;

content = content.replace(uiRegex, uiReplacement);
fs.writeFileSync(file, content);
